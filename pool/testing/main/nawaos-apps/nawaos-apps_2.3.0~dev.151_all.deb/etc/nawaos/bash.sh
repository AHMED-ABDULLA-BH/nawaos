# shellcheck shell=bash
# NawaOS interactive shell setup.
# Installed as /etc/nawaos/bash.sh and sourced from the END of ~/.bashrc
# (/etc/skel/.bashrc, hook 05), so it wins over Debian's default prompt and
# aliases. Safe to source more than once; does nothing in non-interactive
# shells. Opt out of any part with the variables below in ~/.bashrc before
# the source line:
#   NAWAOS_NO_FETCH=1     no fastfetch on the first terminal of a session
#   NAWAOS_NO_PROMPT=1    keep your own PS1 / prompt
#   NAWAOS_NO_ALIASES=1   keep plain ls / cat
# Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved

case $- in *i*) ;; *) return 0 2>/dev/null || exit 0 ;; esac

# ---- shell behaviour ---------------------------------------------------
shopt -s histappend checkwinsize cdspell autocd globstar 2>/dev/null
HISTSIZE=20000
HISTFILESIZE=50000
HISTCONTROL=ignoreboth:erasedups
HISTTIMEFORMAT='%F %T  '

if ! shopt -oq posix && [ -z "${BASH_COMPLETION_VERSINFO:-}" ] \
        && [ -f /usr/share/bash-completion/bash_completion ]; then
    . /usr/share/bash-completion/bash_completion
fi

# ---- tools: bat, eza, fzf (each only when installed) ---------------------
if [ -z "${NAWAOS_NO_ALIASES:-}" ]; then
    if command -v batcat >/dev/null 2>&1; then
        alias bat='batcat --theme=ansi'
        export MANPAGER="sh -c 'col -bx | batcat -l man -p --theme=ansi'"
    fi
    if command -v eza >/dev/null 2>&1; then
        alias ls='eza --group-directories-first'
        alias ll='eza -lh --group-directories-first --git'
        alias la='eza -lah --group-directories-first --git'
        alias lt='eza --tree --level=2 --group-directories-first'
    else
        alias ls='ls --color=auto --group-directories-first'
        alias ll='ls -lh --color=auto --group-directories-first'
        alias la='ls -lah --color=auto --group-directories-first'
    fi
    alias grep='grep --color=auto'
    alias ..='cd ..'
    alias ...='cd ../..'
    alias df='df -h'
    alias free='free -h'
    # NawaOS shortcuts (see `nawaos help`)
    alias update='nawaos update'
    alias gamemode='nawaos gamemode'
    alias fps='nawaos fps'
fi

if command -v fzf >/dev/null 2>&1; then
    export FZF_DEFAULT_OPTS="--height 40% --layout=reverse --border=rounded \
--color=bg+:#1A2332,bg:#0B0F1A,fg:#E8EDF4,fg+:#E8EDF4,hl:#37BCE0,hl+:#50E6E2,\
info:#9AA7B8,prompt:#37BCE0,pointer:#50E6E2,marker:#4ADE80,spinner:#37BCE0,header:#5A6678,border:#1A76BA"
    # Ctrl+R history search, Ctrl+T file picker, Alt+C cd
    if [ -f /usr/share/doc/fzf/examples/key-bindings.bash ]; then
        . /usr/share/doc/fzf/examples/key-bindings.bash
    fi
    if [ -f /usr/share/doc/fzf/examples/completion.bash ]; then
        . /usr/share/doc/fzf/examples/completion.bash
    fi
fi

# ---- prompt ----------------------------------------------------------------
if [ -z "${NAWAOS_NO_PROMPT:-}" ]; then
    if command -v starship >/dev/null 2>&1; then
        if [ -z "${STARSHIP_CONFIG:-}" ] && [ ! -f "$HOME/.config/starship.toml" ] \
                && [ -f /etc/nawaos/starship.toml ]; then
            export STARSHIP_CONFIG=/etc/nawaos/starship.toml
        fi
        eval "$(starship init bash)"
    else
        # Fallback without starship: user@host dir › in the brand colours.
        PS1='\[\e[1;36m\]\u\[\e[0;90m\]@\h \[\e[1;37m\]\w\[\e[0m\] \[\e[1;36m\]›\[\e[0m\] '
        case "$TERM" in xterm*|rxvt*|vte*) PS1="\[\e]0;\u@\h: \w\a\]$PS1" ;; esac
    fi
fi

# ---- welcome: system summary on the first terminal of a session ------------
# Only in a pseudo-terminal (GUI terminal, ssh): the live system autologs the
# user in on tty1 too, and that console shell must not print the summary nor
# consume the once-per-session marker before the first real terminal opens.
if [ -z "${NAWAOS_NO_FETCH:-}" ] && [ ! -e "$HOME/.config/nawaos/no-fetch" ] \
        && [ -t 1 ] && command -v fastfetch >/dev/null 2>&1 \
        && case "$(tty 2>/dev/null)" in /dev/pts/*) true ;; *) false ;; esac; then
    _nawaos_marker="${XDG_RUNTIME_DIR:-/tmp}/nawaos-fetch-shown-$(id -u)"
    if [ ! -e "$_nawaos_marker" ]; then
        fastfetch 2>/dev/null
        printf '\033[0;90m%s\033[0m\n' "Type 'nawaos help' for Game Mode, FPS overlay, updates and more."
        : > "$_nawaos_marker" 2>/dev/null
    fi
    unset _nawaos_marker
fi
