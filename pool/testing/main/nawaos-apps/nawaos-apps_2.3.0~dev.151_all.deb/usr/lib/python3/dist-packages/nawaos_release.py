#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS release information for the apps.

The image's version has one source: NAWAOS_VERSION in scripts/lib/common.sh.
The build writes it to /etc/nawaos/build-version and hook 02 builds
/etc/os-release from it. Apps read it here instead of each keeping its own
copy of an os-release parser with a hard-coded fallback (before 2.2 five
apps did, all falling back to "2.0").
"""

OS_RELEASE = "/etc/os-release"


def read(path=OS_RELEASE):
    """All KEY=value pairs of os-release, quotes removed. {} if unreadable."""
    info = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                info[key.strip()] = value.strip().strip('"').strip("'")
    except OSError:
        pass
    return info


def version(path=OS_RELEASE):
    """VERSION_ID, e.g. "2.2.0" or "2.2.0-dev"; "" when unknown."""
    return read(path).get("VERSION_ID", "")


def variant(path=OS_RELEASE):
    """VARIANT_ID: "full", "lite" or "handheld"; "" when unknown."""
    return read(path).get("VARIANT_ID", "")
