#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Lightweight i18n Helper

A tiny, dependency-free translation helper shared by all NawaOS apps.
It is intentionally much simpler than GNU gettext: apps register (or ship
as JSON) flat ``{msgid: translation}`` dictionaries per language code and
call ``_()`` around every user-visible string.

Usage in an app:

    import nawaos_i18n
    nawaos_i18n.register('ar', {"Hello": "مرحباً"})
    nawaos_i18n.init('my-app')
    _ = nawaos_i18n.gettext
    label = _("Hello")            # -> "مرحباً" when Arabic is active

Language resolution order (first match wins):
    1. ~/.config/nawaos/language        (explicit NawaOS user choice)
    2. $LANGUAGE / $LC_ALL / $LC_MESSAGES / $LANG
    3. locale.getlocale()
    4. 'en'

Optional external catalogs: /usr/share/nawaos/i18n/<lang>.json — a flat
JSON object merged over any in-module registrations, so packagers can add
or fix translations without touching app code.

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import json
import locale
import os

__all__ = [
    "init", "gettext", "register", "set_language", "get_language", "is_rtl",
    "setup",
]

# Supported language codes.  NawaOS ships fully bilingual Arabic/English;
# unknown locales safely fall back to English.
_SUPPORTED = ("en", "ar")
_RTL_LANGUAGES = ("ar", "he", "fa", "ur")

# Directory of optional JSON catalogs installed system-wide.
I18N_DIR = "/usr/share/nawaos/i18n"

# Per-user persisted language choice (written by the Welcome Wizard and the
# Control Panel's localization page).
_USER_LANG_FILE = os.path.join(
    os.path.expanduser("~"), ".config", "nawaos", "language")

# In-memory registry: {lang_code: {msgid: translation}}
_translations = {"en": {}, "ar": {}}

_language = "en"
_app_name = None
_initialized = False


def _normalize(code):
    """Reduce 'ar_BH.UTF-8' / 'ar-bh' / 'ar' to a supported base code."""
    if not code:
        return None
    code = str(code).strip().lower().replace("-", "_")
    base = code.split(".")[0].split("_")[0].split(":")[0]
    if base in _SUPPORTED:
        return base
    return None


def _detect_language():
    """Best-effort language detection with safe fallbacks (never raises)."""
    # 1. Explicit NawaOS per-user choice.
    try:
        with open(_USER_LANG_FILE, "r", encoding="utf-8") as f:
            lang = _normalize(f.read())
            if lang:
                return lang
    except OSError:
        pass
    except Exception:
        pass

    # 2. Environment variables (same precedence gettext uses).
    for var in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG"):
        lang = _normalize(os.environ.get(var))
        if lang:
            return lang

    # 3. Python locale.
    try:
        loc = locale.getlocale()
        if loc and loc[0]:
            lang = _normalize(loc[0])
            if lang:
                return lang
    except Exception:
        pass

    return "en"


def _load_json_catalog(lang):
    """Merge /usr/share/nawaos/i18n/<lang>.json over registered strings."""
    path = os.path.join(I18N_DIR, "%s.json" % lang)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            table = _translations.setdefault(lang, {})
            for key, value in data.items():
                if isinstance(key, str) and isinstance(value, str):
                    table[key] = value
    except (OSError, ValueError):
        pass
    except Exception:
        pass


def register(lang, mapping):
    """Register an in-module translation dict for ``lang``.

    Safe to call any number of times (later calls win per msgid) and safe
    to call before or after init().
    """
    if not isinstance(mapping, dict):
        return
    base = _normalize(lang) or str(lang).lower()
    table = _translations.setdefault(base, {})
    for key, value in mapping.items():
        if isinstance(key, str) and isinstance(value, str):
            table[key] = value


def init(app_name=None):
    """Initialize i18n for an app: detect language, load JSON catalogs.

    Returns the active language code. Never raises.
    """
    global _app_name, _language, _initialized
    _app_name = app_name
    _language = _detect_language()
    for lang in list(_translations.keys()):
        if lang != "en":
            _load_json_catalog(lang)
    _load_json_catalog(_language)
    _initialized = True
    return _language


def set_language(code):
    """Switch the active language at runtime ('ar' or 'en').

    Unknown codes fall back to English. Returns the language now active.
    """
    global _language
    _language = _normalize(code) or "en"
    _load_json_catalog(_language)
    return _language


def get_language():
    """Return the active language code (e.g. 'en' or 'ar')."""
    if not _initialized:
        # Lazily detect so `_()`/is_rtl() work even without an init() call.
        init(_app_name)
    return _language


def is_rtl():
    """True when the active language is written right-to-left."""
    return get_language() in _RTL_LANGUAGES


def gettext(msgid):
    """Translate ``msgid`` into the active language, or return it as-is."""
    if not isinstance(msgid, str):
        return msgid
    lang = get_language()
    if lang == "en":
        return msgid
    table = _translations.get(lang)
    if table:
        return table.get(msgid, msgid)
    return msgid


# Conventional short alias so modules can do: from nawaos_i18n import _
_ = gettext


def setup(app_name, ar_strings):
    """One-call setup used by every NawaOS app (2.2).

    Registers the app's Arabic strings, initialises the language and returns
    (gettext, get_language, is_rtl). Before 2.2 each app carried its own
    30-line copy of this plus a private language-detection fallback.
    """
    register("ar", ar_strings)
    init(app_name)
    return gettext, get_language, is_rtl
