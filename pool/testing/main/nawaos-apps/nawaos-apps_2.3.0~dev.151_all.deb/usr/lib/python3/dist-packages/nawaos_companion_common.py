#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Companion - shared helpers
Code shared by nawaos-companion-server and nawaos-companion-gui.
Installed as the importable module ``nawaos_companion_common``.
Version 2.0

Developed by: Ahmed Abdulla
"""

import contextlib
import hashlib
import json
import os
import secrets
import socket
import ssl
import stat
import subprocess
from urllib.parse import urlencode

try:
    import fcntl
except ImportError:      # Windows dev machines: no flock, tests still run
    fcntl = None

# ========================================
# PAIRING TOKEN (authentication)
# ========================================
# The server is reachable on the LAN, so every client MUST authenticate with a
# shared pairing token before any command is executed. The token is stored in a
# 0600 file under the user's config dir and shared between the server and the
# GUI (which embeds it in the pairing QR code).
TOKEN_PATH = os.path.join(
    os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
    "nawaos", "companion-token",
)


class TokenError(RuntimeError):
    """The pairing token could not be read or stored safely."""


def _read_existing_token(path):
    """Return the stored token, or None when it must be (re)generated.

    Accepts only a regular file owned by this user, opened without
    following symlinks. A file that is readable by group/other is treated
    as exposed: it returns None so the caller writes a fresh token (the
    replacement is created 0600), i.e. the credential is rotated rather
    than silently re-trusted.
    """
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
    except FileNotFoundError:
        return None
    except OSError:
        # ELOOP (symlink) or unreadable: replace it.
        return None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            return None
        if hasattr(os, "geteuid") and st.st_uid != os.geteuid():
            return None
        if os.name == "posix" and stat.S_IMODE(st.st_mode) & 0o077:
            return None
        with os.fdopen(fd, "r", closefd=False) as f:
            token = f.read().strip()
    finally:
        os.close(fd)
    return token or None


def _write_token(path, token):
    """Write token atomically: 0600 temp file in the same dir, then rename.

    os.replace() swaps the directory entry, so a symlink planted at path is
    replaced rather than followed, and readers never see a half-written file.
    """
    tmp = "%s.tmp.%d" % (path, os.getpid())
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    try:
        os.unlink(tmp)
    except FileNotFoundError:
        pass
    fd = os.open(tmp, flags, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(token)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


@contextlib.contextmanager
def _token_lock(path):
    """Exclusive lock on path + ".lock" (a separate file, so the token file
    itself can be replaced atomically while the lock is held)."""
    try:
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
        lock_fd = os.open(path + ".lock", os.O_RDWR | os.O_CREAT, 0o600)
    except OSError as e:
        raise TokenError("cannot prepare %s: %s" % (os.path.dirname(path), e))
    try:
        if fcntl is not None:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(lock_fd)          # closing the fd releases the flock


def _store_new_token(path):
    token = secrets.token_hex(16)
    try:
        _write_token(path, token)
    except OSError as e:
        raise TokenError("cannot store the pairing token in %s: %s" % (path, e))
    return token


def get_pairing_token(path=None):
    """Load the pairing token, creating a random one (0600) if needed.

    Safe for concurrent callers (the GUI and the server start together):
    the whole read/create step runs under an exclusive lock on a separate
    lock file, and a caller that finds a valid token returns it instead of
    replacing it -- so every caller gets the same persisted token.

    Raises TokenError when the token cannot be stored, instead of handing
    out a token that nothing else will ever see.
    """
    path = path or TOKEN_PATH
    with _token_lock(path):
        return _read_existing_token(path) or _store_new_token(path)


def rotate_pairing_token(path=None):
    """Reset pairing: replace the token with a new random one and return it.

    Every phone or browser paired with the old token has to scan the new QR
    code. A running server re-reads the token file and disconnects clients
    that logged in with the old one (NawaOSCompanionServer.enforce_pairing).
    Raises TokenError when the new token cannot be stored; the old token
    then stays valid.
    """
    path = path or TOKEN_PATH
    with _token_lock(path):
        return _store_new_token(path)


# ========================================
# SERVER RUNTIME STATE (what the running server really does)
# ========================================
# The server writes this file once it is listening, and removes it on exit.
# The GUI reads it to show the ACTUAL transport (TLS on/off, fingerprint)
# instead of guessing from the config file.
STATE_PATH = os.path.join(
    os.environ.get("XDG_RUNTIME_DIR")
    or os.path.join(os.environ.get("XDG_STATE_HOME",
                                   os.path.expanduser("~/.local/state")), "nawaos"),
    "nawaos-companion-state.json",
)

# Exit code of the server when TLS was required but could not be set up.
EXIT_TLS_FAILED = 3


def write_server_state(state, path=None):
    path = path or STATE_PATH
    try:
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
        tmp = "%s.tmp.%d" % (path, os.getpid())
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(state, f)
        os.replace(tmp, path)
        return True
    except OSError:
        return False


def read_server_state(pid=None, path=None):
    """State written by the running server, or None. With pid, only the
    state written by that process counts (ignores stale files)."""
    try:
        with open(path or STATE_PATH) as f:
            state = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(state, dict):
        return None
    if pid is not None and state.get("pid") != pid:
        return None
    return state


def clear_server_state(pid, path=None):
    path = path or STATE_PATH
    state = read_server_state(pid=pid, path=path)
    if state is not None:
        try:
            os.unlink(path)
        except OSError:
            pass


def get_local_ip():
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"


# ========================================
# SERVER CONFIG (shared reader)
# ========================================
# Optional JSON config: {"host": "0.0.0.0", "port": 9876, "tls": true}
CONFIG_PATH = os.path.join(
    os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
    "nawaos", "companion-server.json",
)


def load_server_config():
    """Load the optional server config file. Returns {} if absent/invalid."""
    try:
        with open(CONFIG_PATH, "r") as f:
            config = json.load(f)
        if isinstance(config, dict):
            return config
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return {}


# ========================================
# TLS CERTIFICATE (wss:// encryption)
# ========================================
# Self-signed certificate shared by the WebSocket server (wss://) and the web
# client HTTPS server. Generated once with the ``openssl`` CLI (avoids a hard
# dependency on python3-cryptography) and pinned on the client side via its
# SHA-256 fingerprint, which is embedded in the pairing QR/URI and the mDNS
# TXT record -- so a self-signed cert still gives MITM protection to any
# client that checks the pin.
CERT_DIR = os.path.join(
    os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
    "nawaos", "companion-certs",
)
CERT_PATH = os.path.join(CERT_DIR, "server.crt")
KEY_PATH = os.path.join(CERT_DIR, "server.key")


def ensure_certificates():
    """Ensure a self-signed TLS cert/key pair exists (0600). True on success.

    Uses the ``openssl`` CLI (P-256 EC key, 10-year validity). Any failure --
    openssl missing, timeout, non-zero exit -- returns False so the caller can
    fall back to plain ws:// instead of crashing.
    """
    if os.path.isfile(CERT_PATH) and os.path.isfile(KEY_PATH):
        return True
    try:
        os.makedirs(CERT_DIR, mode=0o700, exist_ok=True)
    except OSError:
        return False
    # Restrictive umask in the child so server.key is never readable by
    # group/other, even for an instant. preexec_fn is POSIX-only; on other
    # platforms we rely on the post-hoc chmod below (dev environments only --
    # NawaOS itself is Linux).
    popen_kwargs = {}
    if os.name == "posix":
        popen_kwargs["preexec_fn"] = lambda: os.umask(0o077)
    try:
        result = subprocess.run(
            ["openssl", "req", "-x509",
             "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1",
             "-keyout", KEY_PATH, "-out", CERT_PATH,
             "-days", "3650", "-nodes",
             "-subj", "/CN=NawaOS-Companion"],
            capture_output=True, timeout=30, **popen_kwargs)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False
    if result.returncode != 0 or not (os.path.isfile(CERT_PATH)
                                      and os.path.isfile(KEY_PATH)):
        # Never leave a half-written pair behind: it would poison every
        # later start (exists-check above would skip regeneration).
        for path in (CERT_PATH, KEY_PATH):
            try:
                os.remove(path)
            except OSError:
                pass
        return False
    for path in (CERT_PATH, KEY_PATH):
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
        except OSError:
            pass
    return True


def get_cert_fingerprint(cert_path=CERT_PATH):
    """SHA-256 fingerprint (lowercase hex, no colons) of the DER-encoded cert.

    Pure stdlib (ssl.PEM_cert_to_DER_cert + hashlib), so no dependency on
    python3-cryptography. Returns None if the cert is missing/unreadable.
    """
    try:
        with open(cert_path, "r") as f:
            pem = f.read()
        der = ssl.PEM_cert_to_DER_cert(pem)
        return hashlib.sha256(der).hexdigest()
    except Exception:
        return None


def build_connection_uri(ip, port, token, fingerprint=None, tls=False):
    """Pairing URI embedded in the QR code / shown for manual entry.

    Format: nawaos-companion://<ip>:<port>?token=...&fp=<sha256>&tls=1
    (tls=0 and no fp when running plain ws://).
    """
    params = {"token": token}
    if tls and fingerprint:
        params["fp"] = fingerprint
        params["tls"] = "1"
    else:
        params["tls"] = "0"
    return "nawaos-companion://{}:{}?{}".format(ip, port, urlencode(params))
