#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS task runner: run a command inside the app, with live output.

    import nawaos_taskrunner
    nawaos_taskrunner.run_task(window, _("Security scan"),
                               nawaos_taskrunner.shell(SCRIPT), root=True,
                               on_done=lambda state, rc: ...)

Until 2.2 every Control Panel and Gaming Center tool button opened a
terminal window (gnome-terminal, or xterm) and asked the user to "press
Enter to close". The dialog here replaces that: a spinner while the command
runs, its stdout/stderr streamed into a log view, a Cancel button, and a
success/failure state at the end plus a desktop notification through
nawaos_notify. Root tasks go through pkexec, so the polkit dialog still
appears; exit 126/127 from pkexec means the authentication was cancelled or
denied and is reported as such, never as a failed command.

The command is an argv list (never a shell string parsed later), stdin is
/dev/null so a leftover ``read`` in a script returns at once instead of
hanging, and the process gets its own session so Cancel can stop the whole
group.

The pure-logic helpers (build_argv, shell, outcome, outcome_text,
strip_ansi) have no GTK dependency and are unit tested; the dialog itself
needs GTK and is only defined when gi is importable.
"""

import os
import re
import shlex
import signal
import subprocess
import threading

import nawaos_i18n
import nawaos_notify

try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib, Pango
except (ImportError, ValueError):   # unit tests on a host without GTK
    Gtk = GLib = Pango = None

try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

AR_STRINGS = {
    "Running…": "جارٍ التنفيذ…",
    "Stopping…": "جارٍ الإيقاف…",
    "Cancel": "إلغاء",
    "Close": "إغلاق",
    "Completed": "اكتمل",
    "Failed (exit %s)": "فشل (رمز الخروج %s)",
    "Cancelled": "أُلغي",
    "Authentication cancelled or not authorized": "أُلغيت المصادقة أو لا توجد صلاحية",
    "%s completed": "اكتمل %s",
    "%s failed (exit %s)": "فشل %s (رمز الخروج %s)",
    "%s cancelled": "أُلغي %s",
    "%s: authentication cancelled or not authorized": "%s: أُلغيت المصادقة أو لا توجد صلاحية",
    "Command not found: %s": "الأمر غير موجود: %s",
    "Cancel requested…": "طُلب الإلغاء…",
    "This task runs as administrator and cannot be cancelled. Wait for it to finish.":
        "تعمل هذه المهمة بصلاحيات المدير ولا يمكن إلغاؤها. انتظر حتى تنتهي.",
}
nawaos_i18n.register("ar", AR_STRINGS)
_ = nawaos_i18n.gettext

STATES = ("success", "failed", "cancelled", "auth")

_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def build_argv(argv, root=False):
    """The argv actually executed: ``pkexec`` in front for root tasks."""
    argv = [str(a) for a in argv]
    if not argv:
        raise ValueError("empty command")
    return ["pkexec"] + argv if root else argv


def shell(script):
    """argv for a bash script body (multi-line tool scripts)."""
    return ["bash", "-c", script]


def quote(argv):
    """One shell-safe line for display in the log header."""
    return " ".join(shlex.quote(str(a)) for a in argv)


def strip_ansi(line):
    """Drop terminal colour codes the tool scripts print."""
    return _ANSI.sub("", line)


def outcome(returncode, root=False, cancelled=False):
    """Map an exit status to one of STATES."""
    if cancelled:
        return "cancelled"
    if returncode == 0:
        return "success"
    if root and returncode in (126, 127):
        return "auth"
    return "failed"


def outcome_text(label, state, returncode=None):
    """Notification text for a finished task."""
    if state == "success":
        return _("%s completed") % label
    if state == "cancelled":
        return _("%s cancelled") % label
    if state == "auth":
        return _("%s: authentication cancelled or not authorized") % label
    return _("%s failed (exit %s)") % (label, returncode)


def status_text(state, returncode=None):
    """Short state line shown in the dialog header."""
    if state == "success":
        return _("Completed")
    if state == "cancelled":
        return _("Cancelled")
    if state == "auth":
        return _("Authentication cancelled or not authorized")
    return _("Failed (exit %s)") % returncode


CANNOT_CANCEL = "This task runs as administrator and cannot be cancelled. Wait for it to finish."


def signal_group(pid, sig=signal.SIGTERM):
    """Signal a task's process group (the task was started in its own session).

    Returns "sent", "gone" (the task already exited) or "denied". "denied" is
    what a pkexec task gives once authentication is done: the command then
    runs as root and a user process may not signal it, so Cancel cannot stop
    it and must not claim it did.
    """
    try:
        os.killpg(pid, sig)
        return "sent"
    except ProcessLookupError:
        return "gone"
    except PermissionError:
        return "denied"


def task_env(extra=None):
    """Environment for a task: plain text output, no pagers."""
    env = dict(os.environ)
    env.update({"TERM": "dumb", "NO_COLOR": "1", "PAGER": "cat",
                "SYSTEMD_PAGER": "", "DEBIAN_FRONTEND": "noninteractive"})
    if extra:
        env.update(extra)
    return env


if Gtk is not None:

    class TaskDialog(Gtk.Dialog):
        """Non-blocking dialog that runs one command and streams its output."""

        def __init__(self, parent, title, argv, root=False, env=None,
                     on_done=None, category="system", source="",
                     icon_name="system-run-symbolic"):
            super().__init__(title=title, transient_for=parent, flags=0)
            self.set_default_size(640, 420)
            self.set_modal(False)
            self._argv = build_argv(argv, root)
            self._root = root
            self._env = task_env(env)
            self._on_done = on_done
            self._category = category
            self._source = source
            self._label = title
            self._proc = None
            self._cancelled = False
            self._state = None

            area = self.get_content_area()
            area.set_spacing(12)
            area.set_border_width(16)

            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            self._spinner = Gtk.Spinner()
            self._spinner.set_size_request(24, 24)
            self._spinner.start()
            self._state_icon = Gtk.Image()
            self._state_icon.set_pixel_size(24)
            self._state_icon.set_no_show_all(True)
            header.pack_start(self._spinner, False, False, 0)
            header.pack_start(self._state_icon, False, False, 0)
            if nawaos_theme is not None:
                header.pack_start(nawaos_theme.icon(icon_name, 24), False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            title_label = Gtk.Label()
            title_label.set_markup("<b>%s</b>" % GLib.markup_escape_text(title))
            title_label.set_halign(Gtk.Align.START)
            title_label.get_style_context().add_class("card-title")
            text.pack_start(title_label, False, False, 0)
            self._status = Gtk.Label(label=_("Running…"))
            self._status.set_halign(Gtk.Align.START)
            self._status.get_style_context().add_class("card-subtitle")
            text.pack_start(self._status, False, False, 0)
            header.pack_start(text, True, True, 0)
            area.pack_start(header, False, False, 0)

            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scroll.set_shadow_type(Gtk.ShadowType.NONE)
            scroll.get_style_context().add_class("card")
            self._view = Gtk.TextView()
            self._view.set_editable(False)
            self._view.set_cursor_visible(False)
            self._view.set_monospace(True)
            self._view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
            self._view.set_left_margin(8)
            self._view.set_right_margin(8)
            self._view.set_top_margin(6)
            self._view.set_bottom_margin(6)
            # Command output is always left-to-right, whatever the UI language.
            self._view.set_direction(Gtk.TextDirection.LTR)
            self._view.get_style_context().add_class("task-log")
            self._buf = self._view.get_buffer()
            self._end = self._buf.create_mark("end", self._buf.get_end_iter(), False)
            scroll.add(self._view)
            area.pack_start(scroll, True, True, 0)

            self._cancel_btn = self.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
            self._cancel_btn.get_style_context().add_class("destructive")
            self._close_btn = self.add_button(_("Close"), Gtk.ResponseType.CLOSE)
            self._close_btn.get_style_context().add_class("action-btn")
            self._close_btn.set_sensitive(False)
            self.connect("response", self._on_response)
            self.connect("delete-event", self._on_delete)

            # Echo the command line, except for inline scripts (bash -c ...),
            # whose body would only clutter the log.
            shown = self._argv[1:] if root else self._argv
            if shown[:2] != ["bash", "-c"]:
                self._append("$ " + quote(self._argv) + "\n")

        # -- running ---------------------------------------------------------
        def start(self):
            self.show_all()
            threading.Thread(target=self._worker, daemon=True).start()
            return self

        def _worker(self):
            try:
                self._proc = subprocess.Popen(
                    self._argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL, text=True, errors="replace",
                    bufsize=1, env=self._env, start_new_session=True)
            except FileNotFoundError:
                GLib.idle_add(self._append, _("Command not found: %s") % self._argv[0] + "\n")
                GLib.idle_add(self._finish, 127)
                return
            except OSError as exc:
                GLib.idle_add(self._append, "%s\n" % exc)
                GLib.idle_add(self._finish, 1)
                return
            for line in self._proc.stdout:
                GLib.idle_add(self._append, strip_ansi(line))
            rc = self._proc.wait()
            GLib.idle_add(self._finish, rc)

        def _append(self, text):
            self._buf.insert(self._buf.get_end_iter(), text)
            self._view.scroll_mark_onscreen(self._end)
            return False

        def _finish(self, rc):
            self._state = outcome(rc, self._root, self._cancelled)
            self._spinner.stop()
            self._spinner.hide()
            ok = self._state == "success"
            self._state_icon.set_from_icon_name(
                "emblem-ok-symbolic" if ok else "dialog-error-symbolic",
                Gtk.IconSize.LARGE_TOOLBAR)
            self._state_icon.get_style_context().add_class(
                "status-ok" if ok else "status-err")
            self._state_icon.show()
            self._status.set_text(status_text(self._state, rc))
            self._cancel_btn.hide()
            self._close_btn.set_sensitive(True)
            self._close_btn.grab_default()
            nawaos_notify.notify(self._label, outcome_text(self._label, self._state, rc),
                                 category=self._category,
                                 urgency="normal" if ok else "critical",
                                 source=self._source)
            if self._on_done is not None:
                try:
                    self._on_done(self._state, rc)
                except Exception:
                    pass
            return False

        # -- buttons ---------------------------------------------------------
        def cancel(self):
            """Stop the whole process group. A root task past the polkit
            prompt cannot be signalled by the user: say so, disable Cancel
            and let the real exit status decide the outcome."""
            if self._proc is None or self._proc.poll() is not None:
                return
            result = signal_group(self._proc.pid)
            if result == "sent":
                self._cancelled = True
                self._status.set_text(_("Stopping…"))
                self._append(_("Cancel requested…") + "\n")
            elif result == "denied":
                self._append(_(CANNOT_CANCEL) + "\n")
                self._cancel_btn.set_sensitive(False)
                self._cancel_btn.set_tooltip_text(_(CANNOT_CANCEL))

        def _on_response(self, _dialog, response):
            if response == Gtk.ResponseType.CANCEL:
                self.cancel()
            elif response == Gtk.ResponseType.CLOSE:
                self.destroy()

        def _on_delete(self, *_args):
            # Closing the window while the task runs keeps the task going
            # in the background; the notification still reports the result.
            return False

    def run_task(parent, title, argv, root=False, env=None, on_done=None,
                 category="system", source="", icon_name="system-run-symbolic"):
        """Open the task dialog and start the command; returns the dialog."""
        return TaskDialog(parent, title, argv, root=root, env=env, on_done=on_done,
                          category=category, source=source,
                          icon_name=icon_name).start()
