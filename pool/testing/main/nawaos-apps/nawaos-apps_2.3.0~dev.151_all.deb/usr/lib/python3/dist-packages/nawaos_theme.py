#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Shared GTK Theme

Single source of truth for the NawaOS "Ultimate Gaming Edition" dark look and
for the CSS-loading boilerplate that every NawaOS GTK app used to duplicate.

Usage in an app:

    try:
        import nawaos_theme
    except ImportError:
        nawaos_theme = None

    ...
    if nawaos_theme:
        nawaos_theme.apply_theme(self, APP_SPECIFIC_CSS)
    else:
        # local fallback (kept so the app still runs without this module)
        ...

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import sys

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib

# ---------------------------------------------------------------------------
# Design tokens — change the NawaOS palette here and every app follows.
# ---------------------------------------------------------------------------
PALETTE = {
    # NawaOS 2.0 design tokens (single design language, keep in sync with
    # apps/nawaos-theme/cinnamon/cinnamon.css and gtk-3.0/user-overrides.css)
    "bg":           "#0B0F1A",   # deep window background
    "bg_alt":       "#111827",   # surface: sidebars / toolbars
    "surface":      "#1A2332",   # elevated: cards / popovers
    "hover":        "#232D3F",   # hover fill
    "border":       "rgba(55, 188, 224, 0.15)",
    "border_hover": "rgba(55, 188, 224, 0.35)",
    "text":         "#E8EDF4",
    "text_dim":     "#9AA7B8",
    "text_mute":    "#5A6678",
    "accent":       "#37BCE0",   # NawaOS cyan
    "accent_cy":    "#50E6E2",   # light cyan (gradient end)
    "accent_deep":  "#1A76BA",   # deep blue (gradient start)
    "success":      "#4ADE80",
    "warning":      "#FBBF24",
    "danger":       "#F87171",
    "font":         "'Noto Sans', 'Noto Sans Arabic', 'Noto Kufi Arabic', sans-serif",
}

# ---------------------------------------------------------------------------
# Base CSS shared by all apps. Kept intentionally additive: it defines the
# global font/colour, the window background and a set of reusable
# `nawaos-*` helper classes. App-specific classes are passed via extra_css so
# this base never fights an individual app's existing layout rules.
# ---------------------------------------------------------------------------
BASE_CSS = """
/* =====================================================================
   NawaOS 2.0 base design system - shared by all 9 NawaOS GTK apps.
   Apps call apply_theme() and layer their own classes on top; the
   class names below are the shared vocabulary (.sidebar, .card,
   .action-btn, ...) every app can rely on.
   ===================================================================== */

* {{
    font-family: {font};
    color: {text};
}}

window {{
    background-color: {bg};
}}

/* ---- Base widget styling (matches user-overrides.css / Arc accent) -- */
entry {{
    background-color: {bg};
    border: 1px solid {border};
    border-radius: 6px;
    padding: 8px 12px;
    caret-color: {accent};
    transition: border-color 150ms ease, box-shadow 150ms ease;
}}
entry:focus {{
    border-color: {accent};
    box-shadow: 0 0 0 2px rgba(55, 188, 224, 0.18);
}}
entry selection {{
    background-color: {accent};
    color: {bg};
}}

scrollbar slider {{
    background-color: rgba(55, 188, 224, 0.25);
    border-radius: 100px;
    min-width: 6px;
    min-height: 6px;
    transition: background-color 150ms ease;
}}
scrollbar slider:hover {{
    background-color: rgba(55, 188, 224, 0.45);
}}
scrollbar slider:active {{
    background-color: {accent};
}}

switch {{
    border-radius: 100px;
    border: 1px solid {border};
    background-color: {bg};
    transition: all 200ms ease;
}}
switch:checked {{
    background: linear-gradient(90deg, {accent_deep}, {accent});
    border-color: {border_hover};
}}
switch slider {{
    border-radius: 100px;
    background-color: {text};
}}

progressbar trough {{
    background-color: {bg};
    border-radius: 100px;
    min-height: 6px;
}}
progressbar progress {{
    background: linear-gradient(90deg, {accent_deep}, {accent}, {accent_cy});
    border-radius: 100px;
    min-height: 6px;
}}

tooltip {{
    background-color: {surface};
    border: 1px solid {border};
    border-radius: 16px;
    color: {text};
    padding: 6px 10px;
}}

/* ---- Window / layout ------------------------------------------------ */
.nawaos-window {{
    background-color: {bg};
}}

.sidebar {{
    background-color: {bg_alt};
    border-right: 1px solid {border};
}}

.sidebar-row {{
    color: {text_dim};
    border-radius: 100px;
    padding: 8px 16px;
    margin: 2px 8px;
    transition: all 150ms ease;
}}
.sidebar-row:hover {{
    background-color: {hover};
    color: {text};
}}
.sidebar-row:selected {{
    background-color: rgba(55, 188, 224, 0.18);
    color: {accent};
    font-weight: 600;
}}

.toolbar {{
    background-color: {bg_alt};
    border-bottom: 1px solid {border};
    padding: 8px 12px;
}}

/* ---- Cards ---------------------------------------------------------- */
.card {{
    background-color: {surface};
    border: 1px solid {border};
    border-radius: 10px;
    padding: 16px;
    transition: border-color 200ms ease, box-shadow 200ms ease;
}}
.card:hover {{
    border-color: {border_hover};
    box-shadow: 0 0 12px rgba(55, 188, 224, 0.12);
}}

.card-title {{
    color: {text};
    font-size: 15px;
    font-weight: 600;
}}

.card-subtitle {{
    color: {text_dim};
    font-size: 12px;
}}

/* ---- Buttons -------------------------------------------------------- */
.action-btn {{
    background-color: {surface};
    color: {text};
    border: 1px solid {border};
    border-radius: 10px;
    padding: 8px 16px;
    font-weight: 600;
    transition: all 150ms ease;
}}
.action-btn:hover {{
    background-color: {hover};
    border-color: {border_hover};
}}
.action-btn:active {{
    background-color: rgba(55, 188, 224, 0.20);
}}

.action-btn-primary {{
    background: linear-gradient(135deg, {accent_deep}, {accent});
    color: #ffffff;
    border: none;
    border-radius: 10px;
    padding: 8px 16px;
    font-weight: 600;
    transition: all 150ms ease;
}}
.action-btn-primary:hover {{
    background: linear-gradient(135deg, {accent}, {accent_cy});
    box-shadow: 0 2px 8px rgba(55, 188, 224, 0.35);
}}

.destructive {{
    background: linear-gradient(135deg, #DC5B5B, {danger});
    color: #ffffff;
    border: none;
    border-radius: 10px;
    padding: 8px 16px;
    font-weight: 600;
    transition: all 150ms ease;
}}
.destructive:hover {{
    box-shadow: 0 2px 8px rgba(248, 113, 113, 0.35);
}}

/* ---- Badges / stats / status ---------------------------------------- */
.pill-badge {{
    background-color: rgba(55, 188, 224, 0.15);
    color: {accent};
    border: 1px solid {border};
    border-radius: 100px;
    padding: 2px 12px;
    font-size: 11px;
    font-weight: 600;
}}

.stat-value {{
    color: {accent};
    font-size: 28px;
    font-weight: 700;
}}

.stat-label {{
    color: {text_dim};
    font-size: 11px;
}}

.status-ok {{
    color: {success};
    font-weight: 600;
}}
.status-warn {{
    color: {warning};
    font-weight: 600;
}}
.status-err {{
    color: {danger};
    font-weight: 600;
}}

/* Symbolic icons take the widget colour: UI glyphs are drawn in accent. */
.nawaos-icon {{
    color: {accent};
}}

/* Task runner log (nawaos_taskrunner): command output on the ground colour */
.task-log, .task-log text {{
    background-color: {bg};
    color: {text};
    font-family: "JetBrains Mono", "DejaVu Sans Mono", monospace;
    font-size: 12px;
}}

/* ---- Legacy aliases (kept for older call sites) --------------------- */
.nawaos-card {{
    background-color: {surface};
    border: 1px solid {border};
    border-radius: 10px;
    padding: 16px;
    transition: border-color 200ms ease;
}}
.nawaos-card:hover {{
    border-color: {border_hover};
}}

.nawaos-title {{
    color: {text};
    font-size: 20px;
    font-weight: 600;
}}

.nawaos-subtitle {{
    color: {text_dim};
    font-size: 13px;
}}

.nawaos-btn {{
    background: linear-gradient(135deg, {accent_deep} 0%, {accent} 100%);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 10px 18px;
    font-weight: 600;
    transition: all 150ms ease;
}}
.nawaos-btn:hover {{
    background: linear-gradient(135deg, {accent} 0%, {accent_cy} 100%);
}}

.nawaos-btn-secondary {{
    background: {bg_alt};
    color: {text};
    border: 1px solid {border};
    border-radius: 10px;
    padding: 10px 18px;
    font-weight: 600;
    transition: all 150ms ease;
}}
.nawaos-btn-secondary:hover {{
    border-color: {accent};
}}
""".format(**PALETTE)


def _as_bytes(css):
    if css is None:
        return b""
    if isinstance(css, bytes):
        return css
    return css.encode("utf-8")


def icon(names, px=24, fallback="applications-games-symbolic"):
    """Gtk.Image of the first of ``names`` the icon theme has.

    NawaOS apps draw no emoji (2.2): UI glyphs are ``*-symbolic`` icons,
    drawn in accent through the ``.nawaos-icon`` class, and a third-party
    app or game shows its own app icon (NawaOS-Icons inherits Papirus,
    which has them).
    """
    if isinstance(names, str):
        names = (names,)
    theme = Gtk.IconTheme.get_default()
    name = next((n for n in names if theme.has_icon(n)), fallback)
    image = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.DIALOG)
    image.set_pixel_size(px)
    image.get_style_context().add_class("nawaos-icon")
    return image


def apply_theme(window=None, extra_css=b"", prefer_dark=True):
    """Apply the NawaOS dark theme to the default screen.

    - Enables GTK's dark-theme variant (once).
    - Loads BASE_CSS plus any app-specific ``extra_css`` (str or bytes) into a
      single screen-level CSS provider.

    ``window`` is accepted for call-site compatibility but is deliberately
    unused: the provider is attached screen-wide via
    ``Gtk.StyleContext.add_provider_for_screen`` (one provider for the whole
    app), not per-window.

    If ``extra_css`` fails to parse, the theme falls back to BASE_CSS alone
    and logs a warning instead of raising, so a CSS typo in one app cannot
    crash it at startup.

    Returns the created Gtk.CssProvider (or None if no screen is available,
    e.g. when imported in a headless context).
    """
    if prefer_dark:
        try:
            settings = Gtk.Settings.get_default()
            if settings is not None:
                settings.set_property("gtk-application-prefer-dark-theme", True)
        except Exception:
            pass

    screen = Gdk.Screen.get_default()
    if screen is None:
        return None

    css = _as_bytes(BASE_CSS) + b"\n" + _as_bytes(extra_css)
    provider = Gtk.CssProvider()
    try:
        provider.load_from_data(css)
    except GLib.GError as e:
        # Broken app-specific CSS: warn and retry with the base theme alone.
        print(f"nawaos_theme: invalid extra_css ({e}); "
              "falling back to base theme", file=sys.stderr)
        provider = Gtk.CssProvider()
        try:
            provider.load_from_data(_as_bytes(BASE_CSS))
        except GLib.GError as e2:
            print(f"nawaos_theme: base CSS failed to load ({e2}); "
                  "no theme applied", file=sys.stderr)
            return None
    Gtk.StyleContext.add_provider_for_screen(
        screen,
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
    )
    return provider
