#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS save-sync core: collect game saves and upload them to the cloud.

Single source of truth for BOTH save-sync paths:

* the Backup Manager GUI ("Sync Now" / "Cloud Sync" buttons), and
* the headless watcher ``nawaos-savesync watch``, which runs
  ``python3 -m nawaos_savesync sync`` after a gaming session ends.

Before 2.1.1 the watcher uploaded the staging folder as it was, without
re-collecting the saves from the games first, and the two paths used
different cloud folders (NawaOS-Saves vs NawaOS-Backups). Both now go
through :func:`stage_saves` and :func:`upload_cmd`, so they always collect
the current saves and upload to the same place.

Safety rules:

* a save location that does not exist on this PC is skipped and reported,
  never treated as "delete everything in the staged copy";
* a failed or cancelled collection never proceeds to the upload;
* an empty staging folder is never uploaded (``rclone sync`` would wipe the
  cloud copy to match it);
* files that an upload replaces or deletes in the cloud are moved to
  ``<remote>:NawaOS-Saves-versions/<timestamp>/`` instead of being lost.

No GTK imports here: the module is used from a plain shell daemon and from
the unit tests.
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

CONFIG_PATH = Path.home() / ".nawaos" / "backup-config.json"
DEFAULT_SYNC_FOLDER = Path.home() / "NawaOS-SaveSync"

# One cloud folder for manual and automatic sync. Older versions of the
# Backup Manager also wrote <remote>:NawaOS-Backups/; that folder is left
# untouched (nothing here deletes it).
REMOTE_DIR = "NawaOS-Saves"
VERSIONS_SUFFIX = "-versions"

# rsync exit code 24: some source files vanished mid-transfer (a game was
# still writing). The rest of the copy is fine.
RSYNC_OK = (0, 24)


def default_game_saves():
    home = Path.home()
    return [
        {"name": "Steam Games", "path": str(home / ".steam/steam/steamapps/compatdata"), "enabled": True},
        {"name": "Lutris Saves", "path": str(home / ".local/share/lutris/runners"), "enabled": True},
        {"name": "RetroArch", "path": str(home / ".config/retroarch/saves"), "enabled": True},
        {"name": "Wine Prefixes", "path": str(home / ".wine/drive_c/users"), "enabled": False},
        {"name": "DOSBox", "path": str(home / ".dosbox"), "enabled": True},
    ]


def load_config(path=None):
    """Backup Manager config merged over the save-sync defaults."""
    cfg = {
        "sync_folder": str(DEFAULT_SYNC_FOLDER),
        "savesync_enabled": False,
        "savesync_remote": "",
        "game_saves": default_game_saves(),
    }
    path = Path(path) if path else CONFIG_PATH
    try:
        with open(path) as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            cfg.update(loaded)
    except (OSError, ValueError):
        pass
    return cfg


def slot_name(game):
    """Folder name of one save location inside the staging folder."""
    return str(game["name"]).replace(" ", "_").replace("/", "_")


def normalize_remote(remote):
    """'gdrive' and 'gdrive:' both mean the rclone remote 'gdrive:'."""
    remote = str(remote or "").strip()
    if not remote:
        return ""
    return remote if remote.endswith(":") else remote + ":"


def remote_destination(remote):
    return f"{normalize_remote(remote)}{REMOTE_DIR}/"


def rsync_cmd(src, dest, delete=False):
    cmd = ["rsync", "-a"]
    if delete:
        cmd.append("--delete")
    # Never copy Steam game binaries.
    cmd.append("--exclude=Steam/steamapps/common")
    # Never recurse into the destination if it lives inside the source.
    try:
        rel = Path(dest).resolve().relative_to(Path(src).resolve())
        cmd.append("--exclude=/" + rel.as_posix())
    except (ValueError, OSError):
        pass
    cmd += [str(src) + "/", str(dest) + "/"]
    return cmd


def upload_cmd(sync_folder, remote, stamp=None, max_duration=None):
    """rclone command that mirrors the staging folder to the cloud.

    Files replaced or removed in the cloud are kept under a timestamped
    versions folder next to the main one (--backup-dir must not overlap the
    destination, hence a sibling folder rather than a subfolder).
    """
    remote = normalize_remote(remote)
    stamp = stamp or time.strftime("%Y%m%d-%H%M%S")
    cmd = ["rclone", "sync", str(sync_folder) + "/", f"{remote}{REMOTE_DIR}/",
           "--backup-dir", f"{remote}{REMOTE_DIR}{VERSIONS_SUFFIX}/{stamp}/"]
    if max_duration:
        cmd += ["--max-duration", str(max_duration)]
    return cmd


def has_content(folder):
    """True if the folder holds at least one regular file."""
    for _root, _dirs, files in os.walk(folder):
        if files:
            return True
    return False


class StageResult:
    """Outcome of stage_saves(). ok is False when a copy failed or the
    operation was cancelled; missing lists save locations that do not exist
    on this PC (skipped, not an error)."""

    def __init__(self):
        self.staged = []
        self.missing = []
        self.failed = None      # (game name, error text)
        self.cancelled = False

    @property
    def ok(self):
        return self.failed is None and not self.cancelled


def _run(cmd):
    """Default runner: (returncode, stderr text); rc None never happens."""
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
    except OSError as e:
        return 127, str(e)
    return proc.returncode, (proc.stderr or "").strip()


def stage_saves(sync_folder, games, run=None, cancelled=None, progress=None):
    """Copy every enabled save location into sync_folder/<slot>.

    run(cmd) -> (rc, err); rc None means "cancelled". cancelled() -> bool is
    polled between locations. progress(done, total, game) is called before
    each location. The staged copy of a location that is missing on this PC
    is kept as it is.
    """
    run = run or _run
    sync_folder = Path(sync_folder)
    sync_folder.mkdir(parents=True, exist_ok=True)
    result = StageResult()
    enabled = [g for g in games if g.get("enabled", True)]
    for i, game in enumerate(enabled):
        if cancelled is not None and cancelled():
            result.cancelled = True
            return result
        if progress is not None:
            progress(i, len(enabled), game)
        src = Path(os.path.expanduser(str(game.get("path", ""))))
        if not str(game.get("path", "")) or not src.is_dir():
            result.missing.append(game["name"])
            continue
        dest = sync_folder / slot_name(game)
        dest.mkdir(parents=True, exist_ok=True)
        rc, err = run(rsync_cmd(src, dest, delete=True))
        if rc is None:
            result.cancelled = True
            return result
        if rc not in RSYNC_OK:
            result.failed = (game["name"], err or f"rsync exit {rc}")
            return result
        result.staged.append(game["name"])
    return result


def sync_from_config(cfg, run=None, which=shutil.which, stamp=None,
                     max_duration="10m"):
    """Headless collect + upload. Returns (exit_code, message).

    exit_code 0 = uploaded, 1 = failed (message says why). The message is
    meant for a desktop notification and the log.
    """
    run = run or _run
    remote = normalize_remote(cfg.get("savesync_remote"))
    if not remote:
        return 1, "No cloud remote configured. Open Backup Manager to pick one."
    if which("rclone") is None:
        return 1, "rclone is not installed."
    if which("rsync") is None:
        return 1, "rsync is not installed."
    folder = Path(os.path.expanduser(str(cfg.get("sync_folder") or DEFAULT_SYNC_FOLDER)))
    games = [g for g in cfg.get("game_saves", []) if g.get("enabled", True)]
    if not games:
        return 1, "No game save locations are selected in Backup Manager."

    try:
        staged = stage_saves(folder, games, run=run)
    except OSError as e:
        return 1, f"Could not prepare the sync folder {folder}: {e}"
    if not staged.ok:
        name, err = staged.failed or ("?", "cancelled")
        return 1, f"Could not collect the saves of {name}: {err.splitlines()[-1] if err else 'error'}"
    if not has_content(folder):
        return 1, ("No save files were found to upload, so the cloud copy "
                   "was left unchanged.")

    rc, err = run(upload_cmd(folder, remote, stamp=stamp, max_duration=max_duration))
    if rc != 0:
        tail = err.splitlines()[-1] if err else ""
        return 1, f"Upload failed (rclone exit {rc}). {tail}".strip()

    msg = f"Game saves uploaded to {remote_destination(remote)}"
    if staged.missing:
        msg += " (not on this PC: " + ", ".join(staged.missing) + ")"
    return 0, msg


def _log_runner(log_path):
    """Runner that also appends each command's output to log_path."""
    def run(cmd):
        rc, err = _run(cmd)
        try:
            with open(log_path, "a") as f:
                f.write("$ " + " ".join(cmd[:2]) + " ... -> exit %s\n" % rc)
                if err:
                    f.write(err[-4000:] + "\n")
        except OSError:
            pass
        return rc, err
    return run


def main(argv=None):
    p = argparse.ArgumentParser(prog="nawaos_savesync")
    p.add_argument("command", choices=["sync"])
    p.add_argument("--config", default=str(CONFIG_PATH))
    p.add_argument("--log", default=None)
    args = p.parse_args(argv)
    cfg = load_config(args.config)
    run = _log_runner(args.log) if args.log else None
    code, msg = sync_from_config(cfg, run=run)
    print(msg)
    return code


if __name__ == "__main__":
    sys.exit(main())
