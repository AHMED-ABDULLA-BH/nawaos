#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Shared Game Scanner

Single source of truth for discovering installed games (Steam, Lutris, Flatpak,
native .desktop) used by both the Gaming Center and the Game Mode UI, which
previously each carried their own near-identical scanner.

Each scanner returns a list of ``Game`` objects. Consumers adapt them to their
own UI shape via the provided helpers:

    - Game.launch()         -> launch via an argument list (no shell);
                               returns True on spawn, False on failure
    - Game.launch_string()  -> "steam steam://rungameid/123" style string
    - Game.as_dict()        -> dict shape used by the controller Game Mode UI
    - Game.icon_name        -> themed icon name (Game Mode UI)
    - Game.icon_names       -> icon names to try, the game's own first
                               (Gaming Center)

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import os
import shlex
import subprocess
from pathlib import Path

# Steam library roots used for both manifests and cached cover art.
STEAM_ROOTS = [
    Path.home() / ".steam" / "steam",
    Path.home() / ".local" / "share" / "Steam",
]

_ICON_NAME = {
    "steam": "steam",
    "lutris": "lutris",
    "flatpak": "flatpak",
    "native": "applications-games",
}


class Game:
    """A detected game from any source."""

    __slots__ = ("name", "source", "app_id", "path", "launch_cmd", "cover")

    def __init__(self, name, source, app_id=None, path=None,
                 launch_cmd=None, cover=None):
        self.name = name
        self.source = source              # steam | lutris | flatpak | native
        self.app_id = app_id
        self.path = path
        self.launch_cmd = list(launch_cmd) if launch_cmd else []
        self.cover = cover                # path to cover art or None

    @property
    def icon_name(self):
        return _ICON_NAME.get(self.source, "applications-games")

    @property
    def icon_names(self):
        """The game's own icon when it has one (Steam installs
        steam_icon_<appid>; a Flatpak's icon is its app id), then the
        source's icon."""
        own = {"steam": "steam_icon_%s", "flatpak": "%s"}.get(self.source)
        names = [own % self.app_id] if own and self.app_id else []
        return names + [self.icon_name]

    def launch_string(self):
        return " ".join(shlex.quote(a) for a in self.launch_cmd)

    def launch(self):
        """Launch the game. Returns True if the process was spawned,
        False if there is no launch command or the launcher binary is
        missing/not executable (module policy: swallow-and-report, so GTK
        callers never crash on a missing 'steam'/'lutris'/'flatpak')."""
        if not self.launch_cmd:
            return False
        try:
            subprocess.Popen(self.launch_cmd,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except OSError:
            # FileNotFoundError / PermissionError etc.
            return False

    def as_dict(self):
        return {
            "name": self.name,
            "source": self.source,
            "app_id": self.app_id,
            "launch": self.launch_string(),
            "icon": self.icon_name,
            "cover": self.cover,
        }


# ---------------------------------------------------------------------------
# Source scanners
# ---------------------------------------------------------------------------
def _find_steam_cover(appid):
    """Locate Steam's cached vertical cover art for an app id, if present."""
    if not appid:
        return None
    for root in STEAM_ROOTS:
        cache = root / "appcache" / "librarycache"
        candidates = [
            cache / appid / "library_600x900.jpg",
            cache / f"{appid}_library_600x900.jpg",
            cache / appid / "logo.png",
            cache / f"{appid}_header.jpg",
        ]
        for c in candidates:
            if c.exists():
                return str(c)
    return None


def scan_steam():
    games = []
    seen_dirs = set()
    for root in STEAM_ROOTS:
        sp = root / "steamapps"
        if not sp.exists():
            continue
        # ~/.steam/steam is usually a symlink to ~/.local/share/Steam, so both
        # roots resolve to the same steamapps directory. Resolve and dedup so
        # each manifest is parsed once -- otherwise every Steam game appeared
        # twice in the library grid.
        try:
            real = sp.resolve()
        except OSError:
            real = sp
        if real in seen_dirs:
            continue
        seen_dirs.add(real)
        for manifest in sp.glob("appmanifest_*.acf"):
            try:
                text = manifest.read_text()
                name = ""
                appid = ""
                for line in text.split("\n"):
                    if '"name"' in line:
                        name = line.split('"')[3]
                    if '"appid"' in line:
                        appid = line.split('"')[3]
                if name and "Proton" not in name and "Steamworks" not in name:
                    games.append(Game(
                        name=name,
                        source="steam",
                        app_id=appid,
                        launch_cmd=["steam", f"steam://rungameid/{appid}"],
                        cover=_find_steam_cover(appid),
                    ))
            except Exception:
                pass
    return games


def scan_lutris():
    games = []
    db_path = Path.home() / ".local" / "share" / "lutris" / "pga.db"
    if db_path.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(db_path))
            for row in conn.execute(
                    "SELECT name, slug FROM games WHERE installed=1"):
                slug = row[1]
                games.append(Game(
                    name=row[0],
                    source="lutris",
                    app_id=slug,
                    path=f"lutris:rungame/{slug}",
                    launch_cmd=["lutris", f"lutris:rungame/{slug}"],
                ))
            conn.close()
        except Exception:
            pass
    return games


def scan_flatpak():
    games = []
    gaming_ids = ["game", "emulator", "retroarch", "pcsx2", "dolphin",
                  "duckstation", "ppsspp", "rpcs3", "xemu", "bottles",
                  "heroic", "lutris", "steam"]
    try:
        result = subprocess.run(
            ["flatpak", "list", "--app", "--columns=application,name"],
            capture_output=True, text=True, timeout=10)
        for line in result.stdout.strip().split("\n"):
            parts = line.split("\t")
            if len(parts) >= 2:
                app_id = parts[0].strip()
                name = parts[1].strip()
                if any(g in app_id.lower() for g in gaming_ids):
                    games.append(Game(
                        name=name,
                        source="flatpak",
                        app_id=app_id,
                        launch_cmd=["flatpak", "run", app_id],
                    ))
    except Exception:
        pass
    return games


def is_game_categories(categories, game_categories):
    """True when the desktop entry's Categories= names a game category.

    Whole entries only: "TerminalEmulator" must not match "Emulator" (that
    put XTerm in the game library before 2.2).
    """
    entries = {c.strip() for c in (categories or "").split(";") if c.strip()}
    return any(c in entries for c in game_categories)


def scan_desktop():
    games = []
    dirs = [
        "/usr/share/applications",
        os.path.expanduser("~/.local/share/applications"),
    ]
    game_categories = ["Game", "ActionGame", "AdventureGame", "ArcadeGame",
                       "BoardGame", "Emulator", "RolePlaying", "Simulation",
                       "SportsGame", "StrategyGame"]
    exclude_names = [
        "nawaos", "game center", "game mode", "control panel",
        "lxterminal", "terminal", "goverlay", "mangohud",
        "file manager", "text editor", "settings", "system monitor",
        "task manager", "software", "update", "installer",
    ]
    exclude_files = [
        "nawaos-", "org.gnome.", "org.xfce.", "lxterminal",
        "nemo.desktop", "cinnamon-settings", "synaptic",
    ]
    for d in dirs:
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if not f.endswith(".desktop"):
                continue
            if any(ex in f.lower() for ex in exclude_files):
                continue
            try:
                name = ""
                exe = ""
                cats = ""
                with open(os.path.join(d, f), "r", errors="ignore") as df:
                    for line in df:
                        if line.startswith("Name=") and not name:
                            name = line.strip().split("=", 1)[1]
                        elif line.startswith("Exec="):
                            exe = line.strip().split("=", 1)[1]
                        elif line.startswith("Categories="):
                            cats = line.strip().split("=", 1)[1]
                if name and exe and is_game_categories(cats, game_categories):
                    if "steam" in exe.lower() or "lutris" in exe.lower():
                        continue
                    if any(ex in name.lower() for ex in exclude_names):
                        continue
                    exec_clean = exe.split("%")[0].strip()
                    try:
                        launch_cmd = shlex.split(exec_clean)
                    except ValueError:
                        launch_cmd = [exec_clean]
                    games.append(Game(
                        name=name,
                        source="native",
                        app_id=f,
                        path=exec_clean,
                        launch_cmd=launch_cmd,
                    ))
            except Exception:
                pass
    return games


def scan_all(include_desktop=True):
    """Return all detected games. ``include_desktop`` adds native .desktop
    games (used by the Game Mode UI; the Gaming Center omits them)."""
    games = []
    games.extend(scan_steam())
    games.extend(scan_lutris())
    games.extend(scan_flatpak())
    if include_desktop:
        games.extend(scan_desktop())
    return games
