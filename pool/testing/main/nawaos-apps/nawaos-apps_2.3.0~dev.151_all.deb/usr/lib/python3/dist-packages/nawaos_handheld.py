#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Shared Handheld Support

Single source of truth for handheld-device knowledge that used to be
duplicated (and drift apart) between the handheld daemon, the Game Mode UI
and the TDP control tool:

- KNOWN_DEVICES: DMI-match table of supported handhelds with TDP defaults
  and the preferred TDP interface for each device.
- detect(): DMI/SMBIOS detection returning (is_handheld, device_name, profile).
- tdp_limits(): the power-limit range nawaos-tdp-helper enforces (it runs
  this module as root, so the helper and the UIs share one table).
- XPAD_JS_BUTTONS: joystick-API button index -> evdev button code mapping for
  the standard Xbox (xpad) layout, so js readers and evdev readers agree.
- device_has_key() / find_gamepad_event_device(): evdev capability probing.
- GuideButtonReader: evdev-based reader that fires a callback on real
  Guide-button presses (used by the daemon; usable by the UI as well).
- set_tdp(): apply a TDP limit through the polkit-blessed nawaos-tdp-helper;
  last_tdp() returns the last value applied (re-applied after resume).

Usage in an app:

    try:
        import nawaos_handheld
    except ImportError:
        nawaos_handheld = None  # keep a minimal inline fallback for dev runs

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import os
import re
import glob
import struct
import subprocess
from typing import Any, Callable, Dict, Optional, Tuple

# ---------------------------------------------------------------------------
# Known handheld devices
# ---------------------------------------------------------------------------
# Every profile carries a "dmi" rule. A rule matches when sys_vendor matches
# (if the rule names one) AND at least one of its other fields matches. Each
# pattern must match the WHOLE DMI value (case-insensitive), so "ROG Ally"
# no longer matches "ROG Xbox Ally", "Legion Go" no longer matches
# "Legion Go S", and "GPD" no longer matches every GPD laptop.
#
# Rules are tried in insertion order, most specific first. The first match
# wins.
#
# DMI strings marked "UNVERIFIED" come from public bug reports and kernel
# quirk tables rather than from a device in hand; check them on hardware
# (cat /sys/class/dmi/id/{sys_vendor,product_name,product_version,board_name}).
_ASUS = "ASUSTeK COMPUTER INC."
_LENOVO = "LENOVO"

KNOWN_DEVICES: Dict[str, Dict[str, Any]] = {
    # ROG Xbox Ally X (2025, Ryzen AI Z2 Extreme). UNVERIFIED: board RC73XA,
    # TDP range kept conservative (Turbo is documented as 35 W plugged in).
    "ROG Xbox Ally X": {
        "name": "ASUS ROG Xbox Ally X",
        "dmi": {"sys_vendor": _ASUS,
                "product_name": "ROG Xbox Ally X( .*)?",
                "board_name": "RC73XA"},
        "tdp_range": (5, 30),
        "tdp_default": 17,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "asus-wmi",
        "gpu": "amd",
        "buttons": {"guide": "asus_guide"},
    },
    # ROG Xbox Ally (2025, Ryzen Z2 A, 6-20 W class). UNVERIFIED: board RC73YA.
    "ROG Xbox Ally": {
        "name": "ASUS ROG Xbox Ally",
        "dmi": {"sys_vendor": _ASUS,
                "product_name": "ROG Xbox Ally( RC.*)?",
                "board_name": "RC73YA"},
        "tdp_range": (6, 20),
        "tdp_default": 13,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "asus-wmi",
        "gpu": "amd",
        "buttons": {"guide": "asus_guide"},
    },
    # Product name "ROG Ally X RC72LA_RC72LA", board "RC72LA".
    "ROG Ally X": {
        "name": "ASUS ROG Ally X",
        "dmi": {"sys_vendor": _ASUS,
                "product_name": "ROG Ally X( RC72L.*)?",
                "board_name": "RC72LA?"},
        "tdp_range": (5, 35),
        "tdp_default": 17,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "asus-wmi",
        "gpu": "amd",
        "buttons": {"guide": "asus_guide"},
    },
    # Product name "ROG Ally RC71L_RC71L", board "RC71L".
    "ROG Ally": {
        "name": "ASUS ROG Ally",
        "dmi": {"sys_vendor": _ASUS,
                "product_name": "ROG Ally( RC71L.*)?",
                "board_name": "RC71L"},
        "tdp_range": (5, 30),
        "tdp_default": 15,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "asus-wmi",
        "gpu": "amd",
        "buttons": {"guide": "asus_guide"},
    },
    # Lenovo puts the machine type in product_name and the model in
    # product_version. Legion Go S (Ryzen Z2 Go / Z1 Extreme). UNVERIFIED:
    # machine types 83L3/83N6/83Q2/83Q3, TDP range and panel rotation (left
    # "normal" so the daemon does not rotate; the original Go needs "left").
    "Legion Go S": {
        "name": "Lenovo Legion Go S",
        "dmi": {"sys_vendor": _LENOVO,
                "product_name": "83L3|83N6|83Q2|83Q3",
                "product_version": "Legion Go S( .*)?"},
        "tdp_range": (5, 25),
        "tdp_default": 15,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {"guide": "legion_guide"},
    },
    # Legion Go 2 (2025, Ryzen Z2 / Z2 Extreme). UNVERIFIED: matched on
    # product_version only (machine type unknown); TDP range conservative;
    # rotation left "normal" until checked on hardware.
    "Legion Go 2": {
        "name": "Lenovo Legion Go 2",
        "dmi": {"sys_vendor": _LENOVO,
                "product_version": "Legion Go 2( .*)?"},
        "tdp_range": (5, 30),
        "tdp_default": 20,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {"guide": "legion_guide"},
    },
    # Original Legion Go: machine type 83E1, version "Legion Go 8APU1";
    # portrait panel (kernel panel-orientation quirk: left side up).
    "Legion Go": {
        "name": "Lenovo Legion Go",
        "dmi": {"sys_vendor": _LENOVO,
                "product_name": "83E1",
                "product_version": "Legion Go( [0-9]+[A-Z]+[0-9]+)?"},
        "tdp_range": (5, 40),
        "tdp_default": 20,
        "has_gyro": True,
        "screen_rotation": "left",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {"guide": "legion_guide"},
    },
    # Valve: product_name "Jupiter" (LCD) / "Galileo" (OLED).
    "Steam Deck": {
        "name": "Valve Steam Deck",
        "dmi": {"sys_vendor": "Valve",
                "product_name": "Jupiter"},
        "tdp_range": (3, 15),
        "tdp_default": 12,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "steam-deck",
        "gpu": "amd",
        "buttons": {"guide": "steam_guide"},
    },
    "Steam Deck OLED": {
        "name": "Valve Steam Deck (OLED)",
        "dmi": {"sys_vendor": "Valve",
                "product_name": "Galileo"},
        "tdp_range": (3, 15),
        "tdp_default": 12,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "steam-deck",
        "gpu": "amd",
        "buttons": {"guide": "steam_guide"},
    },
    # AYANEO also sells mini PCs, so match the handheld product lines only.
    # Product names follow the kernel's oxp-sensors / ayaneo tables.
    "AYANEO": {
        "name": "AYANEO",
        "dmi": {"sys_vendor": "AYA ?NEO|AYADEVICE",
                "product_name": "(AIR|NEXT|KUN|FLIP|SLIDE|GEEK)( .*)?|2S?|AYA ?NEO( .*)?"},
        "tdp_range": (5, 35),
        "tdp_default": 15,
        "has_gyro": True,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {},
    },
    # GPD: only the handhelds (WIN 4 = G1618-xx, WIN Mini = G1617-xx), not
    # the Pocket/Duo/WIN Max laptops. UNVERIFIED for newer revisions.
    "GPD": {
        "name": "GPD WIN",
        "dmi": {"sys_vendor": "GPD",
                "product_name": "G161[78]-[0-9]+"},
        "tdp_range": (5, 28),
        "tdp_default": 15,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {},
    },
    "ONEXPLAYER": {
        "name": "ONEXPLAYER",
        "dmi": {"sys_vendor": "ONE-NETBOOK( .*)?",
                "product_name": "ONE ?X ?PLAYER( .*)?|ONEXFLY( .*)?"},
        "tdp_range": (5, 35),
        "tdp_default": 18,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {},
    },
    "AOKZOE": {
        "name": "AOKZOE",
        "dmi": {"sys_vendor": "AOKZOE",
                "product_name": "AOKZOE A[0-9]( .*)?"},
        "tdp_range": (5, 33),
        "tdp_default": 15,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "amd",
        "buttons": {},
    },
    # MSI: product_name "Claw A1M", "Claw 7 AI+ A2VM", "Claw 8 AI+ A2VM".
    "Claw 8": {
        "name": "MSI Claw 8",
        "dmi": {"sys_vendor": "Micro-Star International Co., Ltd\\.?",
                "product_name": "Claw 8( .*)?"},
        "tdp_range": (5, 37),
        "tdp_default": 20,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "intel-rapl",
        "gpu": "intel",
        "buttons": {},
    },
    "Claw A1M": {
        "name": "MSI Claw A1M",
        "dmi": {"sys_vendor": "Micro-Star International Co., Ltd\\.?",
                "product_name": "Claw A1M( .*)?"},
        "tdp_range": (5, 35),
        "tdp_default": 20,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "intel-rapl",
        "gpu": "intel",
        "buttons": {},
    },
    "MSI Claw": {
        "name": "MSI Claw",
        "dmi": {"sys_vendor": "Micro-Star International Co., Ltd\\.?",
                "product_name": "Claw( .*)?"},
        "tdp_range": (5, 35),
        "tdp_default": 20,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "intel-rapl",
        "gpu": "intel",
        "buttons": {},
    },
}

# Default profile for unknown handhelds
DEFAULT_PROFILE: Dict[str, Any] = {
    "name": "Generic Handheld",
    "tdp_range": (5, 30),
    "tdp_default": 15,
    "has_gyro": False,
    "screen_rotation": "normal",
    "tdp_interface": "ryzenadj",
    "gpu": "unknown",
    "buttons": {},
}

# Power limits the TDP helper allows when the device is NOT in the table: a
# conservative cap, so an unknown laptop/desktop cannot be pushed past what
# any thin-and-light APU is designed for.
UNKNOWN_TDP_RANGE: Tuple[int, int] = (4, 15)

DMI_DIR = '/sys/class/dmi/id'
DMI_FIELDS = ('sys_vendor', 'product_name', 'product_version',
              'board_name', 'product_family')


def read_dmi(dmi_dir: Optional[str] = None) -> Dict[str, str]:
    """Read the DMI strings used for matching; missing files read as ''."""
    dmi_dir = dmi_dir or DMI_DIR
    values = {}
    for field in DMI_FIELDS:
        try:
            with open(os.path.join(dmi_dir, field)) as f:
                values[field] = f.read().strip()
        except (IOError, OSError):
            values[field] = ''
    return values


def match_device(dmi: Dict[str, str]) -> Optional[str]:
    """Return the KNOWN_DEVICES key whose DMI rule matches, or None."""
    def full(pattern: str, value: str) -> bool:
        return bool(value) and re.fullmatch(pattern, value, re.IGNORECASE) is not None

    for key, profile in KNOWN_DEVICES.items():
        rule = profile["dmi"]
        vendor = rule.get("sys_vendor")
        if vendor and not full(vendor, dmi.get("sys_vendor", "")):
            continue
        for field, pattern in rule.items():
            if field != "sys_vendor" and full(pattern, dmi.get(field, "")):
                return key
    return None


def detect() -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """Detect a handheld gaming device via DMI/SMBIOS.

    Returns (is_handheld, device_name, profile). profile is None on
    desktops/laptops; callers that need a profile anyway should fall back to
    DEFAULT_PROFILE.
    """
    key = match_device(read_dmi())
    if key is None:
        return False, "Desktop", None
    profile = KNOWN_DEVICES[key]
    return True, profile["name"], profile


def tdp_limits() -> Tuple[int, int, bool]:
    """(min_watts, max_watts, known_device) the TDP helper may apply here."""
    is_handheld, _name, profile = detect()
    if is_handheld and profile:
        lo, hi = profile["tdp_range"]
        return lo, hi, True
    lo, hi = UNKNOWN_TDP_RANGE
    return lo, hi, False


def get_cpu_vendor() -> str:
    """Return 'amd', 'intel' or 'unknown' from /proc/cpuinfo vendor_id."""
    try:
        with open('/proc/cpuinfo') as f:
            for line in f:
                if line.startswith('vendor_id'):
                    vendor = line.split(':', 1)[1].strip()
                    if vendor == 'AuthenticAMD':
                        return 'amd'
                    if vendor == 'GenuineIntel':
                        return 'intel'
                    return 'unknown'
    except (IOError, OSError):
        pass
    return 'unknown'


# ---------------------------------------------------------------------------
# Controller button codes (evdev) and joystick-API mapping
# ---------------------------------------------------------------------------
BTN_A = 304       # Confirm / Select
BTN_B = 305       # Back / Cancel
BTN_X = 307       # Quick Action
BTN_Y = 308       # Menu
BTN_LB = 310      # Left bumper (BTN_TL)
BTN_RB = 311      # Right bumper (BTN_TR)
BTN_SELECT = 314  # View / Back
BTN_START = 315   # Menu / Options
BTN_GUIDE = 316   # Home / Guide / Steam button (BTN_MODE)
BTN_THUMBL = 317  # Left stick click
BTN_THUMBR = 318  # Right stick click

# Holding Guide at least this long switches Desktop Mode <-> Game Mode (the
# handheld daemon); a shorter press belongs to the console UI and to games.
GUIDE_HOLD_SECONDS = 1.0

# Joystick-API (/dev/input/js*) button index -> evdev code for the standard
# Xbox xpad layout. WHY: js indices are NOT evdev codes; naive arithmetic like
# "index + 304" maps Guide (index 8) to 312 instead of BTN_MODE (316) and
# misfires X/Y/LB/RB, because evdev skips codes 306/309/312/313 in this range.
XPAD_JS_BUTTONS: Dict[int, int] = {
    0: BTN_A,
    1: BTN_B,
    2: BTN_X,
    3: BTN_Y,
    4: BTN_LB,
    5: BTN_RB,
    6: BTN_SELECT,   # Back / View
    7: BTN_START,
    8: BTN_GUIDE,
    9: BTN_THUMBL,
    10: BTN_THUMBR,
}

# js event flags/types (linux/joystick.h)
JS_EVENT_BUTTON = 0x01
JS_EVENT_AXIS = 0x02
JS_EVENT_INIT = 0x80  # synthetic initial-state events; NOT real presses


# ---------------------------------------------------------------------------
# evdev capability probing
# ---------------------------------------------------------------------------
def device_has_key(event_name: str, code: int) -> bool:
    """Check whether /dev/input/<event_name> advertises key/button <code>.

    Parses /sys/class/input/<eventN>/device/capabilities/key, a list of
    hex words with the MOST significant word first.
    """
    path = os.path.join('/sys/class/input', event_name,
                        'device', 'capabilities', 'key')
    try:
        with open(path) as f:
            words = f.read().split()
        bits = 0
        for w in words:
            bits = (bits << 64) | int(w, 16)
        return bool(bits & (1 << code))
    except (IOError, OSError, ValueError):
        return False


def find_gamepad_event_device(require_code: int = BTN_GUIDE) -> Optional[str]:
    """Find an evdev device that exposes the given button code.

    Prefers devices advertising the requested code (BTN_MODE by default);
    falls back to a device that at least exposes BTN_A (i.e. is a gamepad).
    Returns a /dev/input/eventN path or None.
    """
    gamepad_fallback = None
    for dev_path in sorted(glob.glob('/dev/input/event*')):
        event_name = os.path.basename(dev_path)
        if device_has_key(event_name, require_code):
            return dev_path
        if gamepad_fallback is None and device_has_key(event_name, BTN_A):
            gamepad_fallback = dev_path
    return gamepad_fallback


# ---------------------------------------------------------------------------
# Guide button reader (evdev)
# ---------------------------------------------------------------------------
class GuideButtonReader:
    """Blocking evdev reader that invokes a callback on Guide-button presses.

    Intended to be run from a worker thread; call stop() to end the loop.
    Only real key-down events (type EV_KEY, value 1) trigger the callback.
    """

    EV_KEY = 0x01
    EVENT_SIZE = 24  # struct input_event on 64-bit

    def __init__(self, callback: Callable[[], None]) -> None:
        self.callback = callback
        self.running = False

    def stop(self) -> None:
        self.running = False

    def run(self) -> None:
        import time
        self.running = True
        while self.running:
            dev = find_gamepad_event_device(BTN_GUIDE)
            if not dev:
                time.sleep(5)
                continue
            try:
                self._read_device(dev)
            except (IOError, OSError):
                time.sleep(2)

    def _read_device(self, dev: str) -> None:
        with open(dev, 'rb') as f:
            while self.running:
                data = f.read(self.EVENT_SIZE)
                if len(data) < self.EVENT_SIZE:
                    break
                # tv_sec(8) + tv_usec(8) + type(2) + code(2) + value(4)
                evt_type = struct.unpack_from('H', data, 16)[0]
                code = struct.unpack_from('H', data, 18)[0]
                value = struct.unpack_from('i', data, 20)[0]
                if evt_type == self.EV_KEY and code == BTN_GUIDE and value == 1:
                    self.callback()


# ---------------------------------------------------------------------------
# TDP application through the polkit helper
# ---------------------------------------------------------------------------
TDP_HELPER = "/usr/local/bin/nawaos-tdp-helper"


def tdp_state_file() -> str:
    """Per-user record of the last power limit applied; the same file the
    Control Center applet uses (nawaos_controlcenter: tdp-watts)."""
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(
        os.path.expanduser("~"), ".local", "state")
    return os.path.join(base, "nawaos", "tdp-watts")


def last_tdp() -> Optional[int]:
    """The last power limit applied in this user's session, or None."""
    try:
        with open(tdp_state_file()) as f:
            value = f.read().strip()
        return int(value) if value.isdigit() else None
    except (IOError, OSError):
        return None


def set_tdp(watts: int, timeout: int = 15) -> bool:
    """Apply a TDP limit (watts) via `pkexec nawaos-tdp-helper set N`.

    The helper validates the value, clamps it to the device range, picks the
    right backend (asus-wmi ppt / ryzenadj / RAPL) and verifies by reading
    back; its exit code is the real success signal. Returns True only on
    verified success, and then records the value so the handheld daemon can
    re-apply it after boot and resume (firmware resets the limit).
    """
    try:
        watts = int(watts)
    except (TypeError, ValueError):
        return False
    try:
        result = subprocess.run(
            ['pkexec', TDP_HELPER, 'set', str(watts)],
            capture_output=True, timeout=timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False
    if result.returncode != 0:
        return False
    try:
        path = tdp_state_file()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            f.write("%d\n" % watts)
        os.replace(path + ".tmp", path)
    except (IOError, OSError):
        pass
    return True
