#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS notifications: one API for every NawaOS app and script.

    from nawaos_notify import notify, notify_gaming, notify_system
    notify_gaming("Proton-GE", "Installed")

    nawaos-notify "Title" "Body" -c gaming -u critical      (command line)

Notifications go straight to the desktop notification server (Cinnamon's,
through notify-send), so they appear as popups and in the history of the
panel's notifications applet. Until 2.2 they went to a separate NawaOS
Notification Center daemon that kept its own second history and mirrored
each message to notify-send anyway; that center was removed in 2.2. The
function names and the CLI stay the same, so callers do not change.
"""

import argparse
import subprocess
import sys

VALID_CATEGORIES = ["system", "gaming", "companion", "performance", "update", "network", "general"]
VALID_URGENCIES = ["low", "normal", "critical"]

CATEGORY_ICONS = {
    "system": "system-software-update",
    "gaming": "applications-games",
    "companion": "phone",
    "performance": "utilities-system-monitor",
    "update": "software-update-available",
    "network": "network-wireless",
    "general": "dialog-information",
}


def build_command(title, body="", category="general", urgency="normal", source=""):
    """The notify-send command for one notification (testable)."""
    if category not in VALID_CATEGORIES:
        category = "general"
    if urgency not in VALID_URGENCIES:
        urgency = "normal"
    app = "NawaOS" + (" " + str(source) if source else "")
    return ["notify-send", "-a", app, "-i", CATEGORY_ICONS[category],
            "-u", urgency, str(title), str(body)]


def notify(title, body="", category="general", urgency="normal", source=""):
    """Show a desktop notification. True if it was handed to notify-send."""
    try:
        subprocess.Popen(build_command(title, body, category, urgency, source),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except OSError:
        return False        # no notify-send (headless): nothing to show


def notify_system(title, body="", source="NawaOS"):
    return notify(title, body, category="system", source=source)


def notify_gaming(title, body="", source="Gaming Center"):
    return notify(title, body, category="gaming", source=source)


def notify_companion(title, body="", source="Companion"):
    return notify(title, body, category="companion", source=source)


def notify_performance(title, body="", urgency="normal", source="System Monitor"):
    return notify(title, body, category="performance", urgency=urgency, source=source)


def notify_update(title, body="", source="Updates"):
    return notify(title, body, category="update", source=source)


def notify_network(title, body="", source="Network"):
    return notify(title, body, category="network", source=source)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="nawaos-notify",
                                     description="Show a NawaOS desktop notification")
    parser.add_argument("title")
    parser.add_argument("body", nargs="?", default="")
    parser.add_argument("-c", "--category", default="general", choices=VALID_CATEGORIES)
    parser.add_argument("-u", "--urgency", default="normal", choices=VALID_URGENCIES)
    parser.add_argument("-s", "--source", default="")
    args = parser.parse_args(argv)
    return 0 if notify(args.title, args.body, args.category, args.urgency, args.source) else 1


if __name__ == "__main__":
    sys.exit(main())
