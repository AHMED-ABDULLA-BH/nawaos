#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS Store backend: catalog, package state, updates and commands.

Everything the Store knows about apt and Flatpak lives here, with no GTK
dependency, so it can be unit tested on any host:

  * the curated catalog (``/usr/share/nawaos/store-catalog.json``) and its
    validation,
  * installed state + versions in two batch calls (``dpkg-query`` and
    ``flatpak list``), candidate versions from ``apt-cache policy``,
  * the pending updates list (``apt list --upgradable`` and
    ``flatpak remote-ls --updates``),
  * the exact argv for every operation (install, remove, refresh, update
    all, launch) - argument lists only, never a shell string,
  * progress parsing of apt's ``APT::Status-Fd`` lines and Flatpak's
    percentages so the UI can show a real progress bar,
  * package details (``apt-cache show``) and, for Flatpak apps, the Flathub
    appstream record (summary, long description, screenshots) fetched lazily
    and cached under ``~/.cache/nawaos-store``.

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import html
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import time
import urllib.request

import nawaos_i18n

AR_STRINGS = {
    "The catalog file was not found or contains no valid entries.":
        "ملف الفهرس غير موجود أو لا يحتوي على مدخلات صالحة.",
    "The store catalog could not be loaded.": "تعذر تحميل فهرس المتجر.",
    "Command not found: %s": "الأمر غير موجود: %s",
}
nawaos_i18n.register("ar", AR_STRINGS)
_ = nawaos_i18n.gettext

SYSTEM_CATALOG = "/usr/share/nawaos/store-catalog.json"
CACHE_DIR = os.path.join(
    os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
    "nawaos-store")

SECTION_ORDER = [
    "Gaming",
    "Emulators",
    "Streaming/Recording",
    "Communication",
    "Media",
    "Productivity",
    "System Tools",
]

SOURCES = ("apt", "flatpak")
KINDS = ("gui", "cli")

STATE_UNKNOWN = "unknown"        # detection still running
STATE_INSTALLED = "installed"
STATE_ABSENT = "absent"

FLATHUB_API = "https://flathub.org/api/v2/appstream/%s"
METADATA_MAX_AGE = 7 * 24 * 3600
USER_AGENT = "NawaOS-Store/2.2 (+https://nawaos.org)"


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------
class StoreEntry:
    """One curated application from the catalog."""

    __slots__ = ("id", "name", "name_ar", "description", "description_ar",
                 "section", "icon", "source", "pkg", "homepage", "developer",
                 "license", "kind", "tags", "featured", "desktop",
                 "state", "installed_version", "candidate_version",
                 "update_version")

    def __init__(self, data):
        self.id = data["id"]
        self.name = data["name"]
        self.name_ar = data.get("name_ar") or self.name
        self.description = data.get("description", "")
        self.description_ar = data.get("description_ar") or self.description
        self.section = data["section"]
        self.icon = data.get("icon") or ""
        self.source = data["source"]          # "apt" | "flatpak"
        self.pkg = data["pkg"]
        self.homepage = data.get("homepage", "")
        self.developer = data.get("developer", "")
        self.license = data.get("license", "")
        self.kind = data.get("kind") if data.get("kind") in KINDS else "gui"
        tags = data.get("tags")
        self.tags = [t for t in tags if isinstance(t, str)] if isinstance(tags, list) else []
        self.featured = bool(data.get("featured", False))
        self.desktop = data.get("desktop") or ""
        self.state = STATE_UNKNOWN
        self.installed_version = ""
        self.candidate_version = ""
        self.update_version = ""

    # -- localized accessors ------------------------------------------------
    def display_name(self):
        return self.name_ar if nawaos_i18n.get_language() == "ar" else self.name

    def display_description(self):
        if nawaos_i18n.get_language() == "ar":
            return self.description_ar
        return self.description

    @property
    def is_gui(self):
        return self.kind == "gui"

    @property
    def installed(self):
        return self.state == STATE_INSTALLED

    @property
    def has_update(self):
        return bool(self.update_version) and self.installed

    def search_haystack(self):
        """Lower-cased text used for the search filter (both languages)."""
        return " ".join((self.name, self.name_ar, self.description,
                         self.description_ar, self.pkg, self.id,
                         self.developer, " ".join(self.tags))).lower()


def load_catalog(paths=None):
    """Load and validate the catalog.

    Returns (entries, sections, error_message). ``entries`` is a list of
    StoreEntry, ``sections`` the ordered section names actually present.
    Invalid entries are skipped, not fatal; only a missing/unreadable file
    or an empty result produces an error message.
    """
    path = None
    for candidate in (paths or (SYSTEM_CATALOG,)):
        if candidate and os.path.isfile(candidate):
            path = candidate
            break
    if path is None:
        return [], [], _("The catalog file was not found or contains no valid entries.")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError) as exc:
        return [], [], "%s (%s)" % (_("The store catalog could not be loaded."), exc)

    if isinstance(data, dict):
        raw_entries = data.get("entries", [])
    elif isinstance(data, list):
        raw_entries = data
    else:
        raw_entries = []

    entries = []
    seen_ids = set()
    for item in raw_entries:
        if not isinstance(item, dict):
            continue
        required = ("id", "name", "section", "source", "pkg")
        if any(not isinstance(item.get(k), str) or not item.get(k).strip()
               for k in required):
            continue
        if item["source"] not in SOURCES or item["id"] in seen_ids:
            continue
        seen_ids.add(item["id"])
        entries.append(StoreEntry(item))

    if not entries:
        return [], [], _("The catalog file was not found or contains no valid entries.")

    present = [s for s in SECTION_ORDER if any(e.section == s for e in entries)]
    for entry in entries:
        if entry.section not in present:
            present.append(entry.section)
    return entries, present, None


# ---------------------------------------------------------------------------
# Search and filtering
# ---------------------------------------------------------------------------
def score_entry(entry, query):
    """Relevance of ``entry`` for ``query`` (0 = no match).

    Every word of the query must match somewhere; the best field decides
    the score so "steam" ranks Steam above "a Steam-like launcher".
    """
    words = [w for w in (query or "").lower().split() if w]
    if not words:
        return 1
    total = 0
    names = (entry.name.lower(), entry.name_ar.lower())
    tags = [t.lower() for t in entry.tags]
    for word in words:
        best = 0
        if any(n.startswith(word) for n in names):
            best = 100
        elif any(word in n for n in names):
            best = 80
        elif any(word == t or t.startswith(word) for t in tags):
            best = 60
        elif word in entry.pkg.lower() or word in entry.id.lower():
            best = 50
        elif word in entry.developer.lower():
            best = 40
        elif word in entry.search_haystack():
            best = 30
        if best == 0:
            return 0
        total += best
    return total


def filter_entries(entries, query="", section=None, source=None,
                   installed_only=False, featured_only=False):
    """Entries matching all the given criteria, best search hits first."""
    out = []
    for entry in entries:
        if section and entry.section != section:
            continue
        if source and entry.source != source:
            continue
        if installed_only and not entry.installed:
            continue
        if featured_only and not entry.featured:
            continue
        score = score_entry(entry, query)
        if score == 0:
            continue
        out.append((score, entry))
    if query.strip():
        out.sort(key=lambda s: (-s[0], s[1].name.lower()))
    return [e for _s, e in out]


# ---------------------------------------------------------------------------
# Running commands
# ---------------------------------------------------------------------------
def task_env(extra=None):
    """Environment for package tools: plain text output, no prompts."""
    env = dict(os.environ)
    env.update({"TERM": "dumb", "NO_COLOR": "1", "PAGER": "cat",
                "DEBIAN_FRONTEND": "noninteractive", "LC_ALL": "C.UTF-8"})
    if extra:
        env.update(extra)
    return env


def run(cmd, timeout=None):
    """Run a command list; returns (returncode, stdout, stderr).

    A missing binary is reported as returncode 127 with a readable stderr
    instead of raising, so callers can treat it as an ordinary failure.
    """
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout, env=task_env())
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except FileNotFoundError:
        return 127, "", _("Command not found: %s") % cmd[0]
    except subprocess.TimeoutExpired:
        return 124, "", "timeout: %s" % " ".join(cmd)
    except OSError as exc:
        return 126, "", str(exc)


# Hosts the Store actually depends on. A TCP connect to any one of them is
# enough to call the machine "online"; nothing is downloaded by the probe.
ONLINE_PROBES = (("deb.debian.org", 443), ("dl.flathub.org", 443),
                 ("1.1.1.1", 443))


def is_online(timeout=3.0):
    """True when at least one package source is reachable."""
    for host, port in ONLINE_PROBES:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False


NETWORK_ERROR_MARKERS = (
    "could not resolve", "temporary failure resolving", "failed to fetch",
    "network is unreachable", "unable to connect", "could not connect",
    "connection timed out", "connection refused", "name resolution",
    "no route to host", "while pulling", "unable to load summary",
    "could not download", "resolving host",
)


def looks_like_network_error(text):
    """Best effort: does a failed command's output point at connectivity?"""
    low = (text or "").lower()
    return any(marker in low for marker in NETWORK_ERROR_MARKERS)


def output_tail(stderr, stdout="", max_lines=15, max_chars=1600):
    """Human-readable tail of a failed command's output for a dialog."""
    text = (stderr or "").strip() or (stdout or "").strip()
    if not text:
        return ""
    tail = "\n".join(text.splitlines()[-max_lines:])
    return tail[-max_chars:] if len(tail) > max_chars else tail


# ---------------------------------------------------------------------------
# Installed state and versions
# ---------------------------------------------------------------------------
DPKG_QUERY_FORMAT = "${Package}\t${db:Status-Status}\t${Version}\n"


def parse_dpkg_query(out):
    """``dpkg-query -W -f DPKG_QUERY_FORMAT`` output -> {pkg: (status, version)}."""
    result = {}
    for line in (out or "").splitlines():
        parts = line.split("\t")
        if len(parts) >= 2 and parts[0].strip():
            version = parts[2].strip() if len(parts) > 2 else ""
            result[parts[0].strip()] = (parts[1].strip(), version)
    return result


def parse_flatpak_list(out):
    """``flatpak list --app --columns=application,version`` -> {app_id: version}."""
    result = {}
    for line in (out or "").splitlines():
        parts = line.split("\t")
        app_id = parts[0].strip()
        if app_id:
            result[app_id] = parts[1].strip() if len(parts) > 1 else ""
    return result


def parse_apt_policy(out):
    """``apt-cache policy pkg...`` -> {pkg: (installed, candidate)} ('(none)' -> '')."""
    result = {}
    current = None
    for line in (out or "").splitlines():
        if line and not line[0].isspace() and line.rstrip().endswith(":"):
            current = line.strip()[:-1]
            result[current] = ["", ""]
        elif current and line.strip().startswith("Installed:"):
            result[current][0] = _policy_version(line)
        elif current and line.strip().startswith("Candidate:"):
            result[current][1] = _policy_version(line)
    return {k: tuple(v) for k, v in result.items()}


def _policy_version(line):
    value = line.split(":", 1)[1].strip()
    return "" if value == "(none)" else value


def detect_installed_bulk(entries):
    """Installed state and versions for every entry with a few batch commands.

    Returns {entry_id: (STATE_*, installed_version, candidate_version)}.
    Runs in a worker thread.
    """
    states = {}
    apt_entries = [e for e in entries if e.source == "apt"]
    flatpak_entries = [e for e in entries if e.source == "flatpak"]

    dpkg = {}
    if apt_entries and shutil.which("dpkg-query"):
        cmd = ["dpkg-query", "-W", "-f", DPKG_QUERY_FORMAT]
        cmd += sorted({e.pkg for e in apt_entries})
        # dpkg-query exits non-zero when any package is unknown, but still
        # prints the known ones on stdout - parse stdout regardless.
        _rc, out, _err = run(cmd, timeout=60)
        dpkg = parse_dpkg_query(out)
    policy = {}
    if apt_entries and shutil.which("apt-cache"):
        _rc, out, _err = run(["apt-cache", "policy"] +
                             sorted({e.pkg for e in apt_entries}), timeout=60)
        policy = parse_apt_policy(out)
    for entry in apt_entries:
        status, version = dpkg.get(entry.pkg, ("", ""))
        installed = status == "installed"
        candidate = policy.get(entry.pkg, ("", ""))[1]
        states[entry.id] = (STATE_INSTALLED if installed else STATE_ABSENT,
                            version if installed else "", candidate)

    flatpaks = {}
    if flatpak_entries and shutil.which("flatpak"):
        rc, out, _err = run(["flatpak", "list", "--app",
                             "--columns=application,version"], timeout=60)
        if rc == 0:
            flatpaks = parse_flatpak_list(out)
    for entry in flatpak_entries:
        installed = entry.pkg in flatpaks
        states[entry.id] = (STATE_INSTALLED if installed else STATE_ABSENT,
                            flatpaks.get(entry.pkg, "") if installed else "", "")
    return states


def check_entry_installed(entry):
    """Authoritative single-entry re-check -> (installed, version)."""
    if entry.source == "apt":
        rc, out, _err = run(["dpkg-query", "-W", "-f", DPKG_QUERY_FORMAT, entry.pkg],
                            timeout=30)
        status, version = parse_dpkg_query(out).get(entry.pkg, ("", ""))
        return (rc == 0 and status == "installed"), version
    rc, out, _err = run(["flatpak", "info", "--show-metadata", entry.pkg], timeout=30)
    if rc != 0:
        return False, ""
    rc, out, _err = run(["flatpak", "list", "--app",
                         "--columns=application,version"], timeout=30)
    return True, parse_flatpak_list(out).get(entry.pkg, "")


# ---------------------------------------------------------------------------
# Updates
# ---------------------------------------------------------------------------
class UpdateItem:
    """One pending update (apt package or Flatpak app)."""

    __slots__ = ("name", "source", "old", "new", "entry")

    def __init__(self, name, source, old="", new="", entry=None):
        self.name = name
        self.source = source
        self.old = old
        self.new = new
        self.entry = entry

    def display_name(self):
        return self.entry.display_name() if self.entry is not None else self.name


_APT_UPGRADABLE = re.compile(
    r"^(?P<pkg>[^/\s]+)/\S+\s+(?P<new>\S+)\s+\S+\s+\[upgradable from:\s*(?P<old>[^\]]*)\]")


def parse_apt_upgradable(out):
    """``apt list --upgradable`` -> [UpdateItem] (the 'Listing...' line is skipped)."""
    items = []
    for line in (out or "").splitlines():
        m = _APT_UPGRADABLE.match(line.strip())
        if m:
            items.append(UpdateItem(m.group("pkg"), "apt", m.group("old").strip(),
                                    m.group("new")))
    return items


def parse_flatpak_updates(out, installed_versions=None):
    """``flatpak remote-ls --updates --app --columns=application,version`` -> [UpdateItem]."""
    installed_versions = installed_versions or {}
    items = []
    seen = set()
    for line in (out or "").splitlines():
        parts = line.split("\t")
        app_id = parts[0].strip()
        if not app_id or app_id in seen:
            continue
        seen.add(app_id)
        items.append(UpdateItem(app_id, "flatpak", installed_versions.get(app_id, ""),
                                parts[1].strip() if len(parts) > 1 else ""))
    return items


def list_updates(entries=()):
    """Pending apt and Flatpak updates, linked to catalog entries when known.

    Needs no privileges: apt reads the already downloaded package lists and
    flatpak asks the remotes. Returns (items, errors) where errors are
    (step, tail) pairs for commands that failed.
    """
    by_pkg = {(e.source, e.pkg): e for e in entries}
    items, errors = [], []

    if shutil.which("apt"):
        rc, out, err = run(["apt", "list", "--upgradable"], timeout=120)
        if rc == 0:
            for item in parse_apt_upgradable(out):
                item.entry = by_pkg.get(("apt", item.name))
                items.append(item)
        else:
            errors.append(("apt list --upgradable", output_tail(err, out)))

    if shutil.which("flatpak"):
        _rc, out, _err = run(["flatpak", "list", "--app",
                              "--columns=application,version"], timeout=60)
        installed = parse_flatpak_list(out)
        rc, out, err = run(["flatpak", "remote-ls", "--updates", "--app",
                            "--columns=application,version"], timeout=180)
        if rc == 0:
            for item in parse_flatpak_updates(out, installed):
                item.entry = by_pkg.get(("flatpak", item.name))
                items.append(item)
        else:
            errors.append(("flatpak remote-ls --updates", output_tail(err, out)))

    items.sort(key=lambda i: (i.entry is None, i.display_name().lower()))
    return items, errors


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
APT_STATUS_OPTS = ["-o", "APT::Status-Fd=1", "-o", "Dpkg::Progress-Fancy=0"]
# unattended-upgrades runs in the background and holds the dpkg lock for
# minutes; wait for it instead of failing at once with "Could not get lock".
APT_LOCK_OPTS = ["-o", "DPkg::Lock::Timeout=300"]


def build_action_command(entry, action):
    """Argv for install/remove of one entry (apt through pkexec)."""
    if entry.source == "apt":
        verb = "install" if action == "install" else "remove"
        return ["pkexec", "apt-get", verb, "-y"] + APT_LOCK_OPTS + APT_STATUS_OPTS + [entry.pkg]
    if action == "install":
        return ["flatpak", "install", "-y", "--noninteractive", "flathub", entry.pkg]
    return ["flatpak", "uninstall", "-y", "--noninteractive", entry.pkg]


def build_refresh_command():
    """Refresh the apt package lists (Flatpak needs no refresh step)."""
    return ["pkexec", "apt-get", "update"] + APT_LOCK_OPTS


# "Update all" runs the same full update as Control Panel -> Update System and
# `nawaos update`: Timeshift snapshot, apt-get dist-upgrade (the only way a new
# kernel package gets installed; plain "upgrade" never does), autoremove,
# Flatpak, firmware. "--progress" adds apt's status lines for the progress bar.
UPDATE_MANAGER = "/usr/local/bin/nawaos-update-manager"


def build_update_all_commands(have_flatpak=True):
    """The steps of "Update all": the update manager's full update (holds
    respected), then a user-level Flatpak update. The update manager runs as
    root and so only updates system-wide Flatpaks; the second step covers
    apps installed per user and is quick when there is nothing left."""
    steps = [("system", ["pkexec", UPDATE_MANAGER, "update", "--progress"])]
    if have_flatpak:
        steps.append(("flatpak", ["flatpak", "update", "-y", "--noninteractive"]))
    return steps


def build_update_command(item):
    """Update a single pending item."""
    if item.source == "apt":
        return ["pkexec", "apt-get", "install", "-y", "--only-upgrade"] + \
            APT_LOCK_OPTS + APT_STATUS_OPTS + [item.name]
    return ["flatpak", "update", "-y", "--noninteractive", item.name]


_DESKTOP_DIRS = ("/usr/share/applications", "/usr/local/share/applications")


def find_desktop_id(entry, dpkg_files=None):
    """Desktop-file id used to launch an installed apt app, or ''.

    Prefers the catalog's ``desktop`` field when that file exists, then the
    first ``/usr/share/applications/*.desktop`` the package ships
    (``dpkg -L``, or the ``dpkg_files`` list in tests).
    """
    if entry.source == "flatpak":
        return entry.pkg
    if entry.desktop:
        for d in _DESKTOP_DIRS:
            if os.path.isfile(os.path.join(d, entry.desktop + ".desktop")):
                return entry.desktop
    if dpkg_files is None:
        rc, out, _err = run(["dpkg", "-L", entry.pkg], timeout=30)
        dpkg_files = out.splitlines() if rc == 0 else []
    for path in dpkg_files:
        path = path.strip()
        if path.endswith(".desktop") and os.path.dirname(path) in _DESKTOP_DIRS:
            return os.path.basename(path)[:-len(".desktop")]
    return ""


def build_launch_command(entry, desktop_id):
    """Argv that opens an installed app; '' desktop_id means not launchable."""
    if entry.source == "flatpak":
        return ["flatpak", "run", entry.pkg]
    if not desktop_id:
        return []
    return ["gtk-launch", desktop_id]


# ---------------------------------------------------------------------------
# Progress parsing
# ---------------------------------------------------------------------------
_APT_STATUS = re.compile(r"^(dlstatus|pmstatus):[^:]*:(\d+(?:\.\d+)?):")
_PERCENT = re.compile(r"(?<![\d.])(\d{1,3})%")


def progress_fraction(line):
    """0.0-1.0 progress carried by one output line, or None.

    apt (with APT::Status-Fd=1) prints ``pmstatus:pkg:45.0:Installing``;
    Flatpak prints e.g. ``Installing 1/3… 45%``. Downloads count for the
    first half of an apt operation, dpkg for the second.
    """
    text = (line or "").strip()
    m = _APT_STATUS.match(text)
    if m:
        pct = min(100.0, max(0.0, float(m.group(2))))
        if m.group(1) == "dlstatus":
            return pct / 200.0
        return 0.5 + pct / 200.0
    m = _PERCENT.search(text)
    if m:
        return min(100, int(m.group(1))) / 100.0
    return None


def is_status_line(line):
    """apt status-fd lines are machine progress, hidden from the log."""
    return bool(_APT_STATUS.match((line or "").strip()))


# ---------------------------------------------------------------------------
# Package details (apt)
# ---------------------------------------------------------------------------
def parse_apt_show(out):
    """First stanza of ``apt-cache show`` -> dict with a plain-text long description."""
    info = {}
    desc_lines = []
    in_desc = False
    for line in (out or "").splitlines():
        if not line.strip():
            if info:
                break           # end of the first stanza
            continue
        if line[0].isspace():
            if in_desc:
                stripped = line.strip()
                if stripped == ".":
                    desc_lines.append("")
                elif stripped[:2] in ("- ", "* ") or stripped.startswith("\u2022"):
                    desc_lines.append("\n" + stripped)      # bullet: its own line
                else:
                    desc_lines.append(stripped)
            continue
        in_desc = False
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if key == "Description" or (key.startswith("Description-")
                                    and key != "Description-md5"):
            info["summary"] = value
            in_desc = True
        else:
            info[key] = value
    paragraphs, current = [], []
    for item in desc_lines:
        if item == "":
            if current:
                paragraphs.append(" ".join(current))
                current = []
        else:
            current.append(item)
    if current:
        paragraphs.append(" ".join(current))
    info["description"] = "\n\n".join(paragraphs).replace(" \n", "\n").strip()
    try:
        info["installed_bytes"] = int(info.get("Installed-Size", "0")) * 1024
    except ValueError:
        info["installed_bytes"] = 0
    try:
        info["download_bytes"] = int(info.get("Size", "0"))
    except ValueError:
        info["download_bytes"] = 0
    return info


def apt_details(pkg):
    """``apt-cache show`` details for one package ({} when unavailable)."""
    rc, out, _err = run(["apt-cache", "show", pkg], timeout=60)
    return parse_apt_show(out) if rc == 0 else {}


def format_size(num_bytes):
    """Human readable size with SI units ('' for 0/None)."""
    try:
        n = float(num_bytes)
    except (TypeError, ValueError):
        return ""
    if n <= 0:
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1000 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1000.0
    return ""


# ---------------------------------------------------------------------------
# Flathub metadata (lazy, cached)
# ---------------------------------------------------------------------------
_BLOCK_END = re.compile(r"</(p|ul|ol|h\d|div)>", re.I)
_LINE_BREAKS = re.compile(r"</li>|<br\s*/?>", re.I)
_LI = re.compile(r"<li[^>]*>", re.I)
_TAGS = re.compile(r"<[^>]+>")


def html_to_text(markup):
    """Appstream description HTML -> readable plain text."""
    text = markup or ""
    text = _LI.sub("• ", text)
    text = _BLOCK_END.sub("\n\n", text)
    text = _LINE_BREAKS.sub("\n", text)
    text = _TAGS.sub("", text)
    text = html.unescape(text)
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in text.splitlines()]
    out, blank = [], False
    for ln in lines:
        if ln:
            out.append(ln)
            blank = False
        elif not blank and out:
            out.append("")
            blank = True
    return "\n".join(out).strip()


def pick_screenshot(sizes, want=624):
    """The screenshot URL closest to ``want`` px wide from an appstream size list."""
    best, best_diff = "", None
    for size in sizes or ():
        src = size.get("src") if isinstance(size, dict) else None
        if not src:
            continue
        try:
            width = int(size.get("width", 0))
        except (TypeError, ValueError):
            width = 0
        diff = abs(width - want) if width else 10 ** 6
        if best_diff is None or diff < best_diff:
            best, best_diff = src, diff
    return best


def parse_flathub_appstream(data):
    """Flathub ``/api/v2/appstream/ID`` JSON -> the fields the Store shows."""
    if not isinstance(data, dict):
        return {}
    shots = []
    for shot in data.get("screenshots") or ():
        if isinstance(shot, dict):
            url = pick_screenshot(shot.get("sizes"))
            if url:
                shots.append(url)
    releases = data.get("releases") or []
    version = ""
    if releases and isinstance(releases[0], dict):
        version = str(releases[0].get("version") or "")
    urls = data.get("urls") or {}
    return {
        "name": data.get("name") or "",
        "summary": data.get("summary") or "",
        "description": html_to_text(data.get("description") or ""),
        "developer": data.get("developer_name") or "",
        "license": data.get("project_license") or "",
        "version": version,
        "screenshots": shots,
        "homepage": urls.get("homepage") or "" if isinstance(urls, dict) else "",
    }


def _cache_path(key, suffix=""):
    os.makedirs(CACHE_DIR, exist_ok=True)
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:24]
    return os.path.join(CACHE_DIR, digest + suffix)


def _fresh(path, max_age):
    try:
        return time.time() - os.path.getmtime(path) < max_age
    except OSError:
        return False


def fetch_url(url, timeout=12):
    """GET ``url`` -> bytes, or None on any failure (never raises)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception:
        return None


def flathub_metadata(app_id, max_age=METADATA_MAX_AGE, fetch=fetch_url):
    """Parsed Flathub appstream for ``app_id`` ({} when offline and uncached)."""
    path = _cache_path("appstream:" + app_id, ".json")
    raw = None
    if _fresh(path, max_age):
        try:
            with open(path, "rb") as f:
                raw = f.read()
        except OSError:
            raw = None
    if raw is None:
        raw = fetch(FLATHUB_API % app_id)
        if raw:
            try:
                with open(path, "wb") as f:
                    f.write(raw)
            except OSError:
                pass
    if not raw:
        return {}
    try:
        return parse_flathub_appstream(json.loads(raw.decode("utf-8")))
    except (ValueError, UnicodeDecodeError):
        return {}


def cached_image(url, max_age=30 * 24 * 3600, fetch=fetch_url):
    """Local path of a downloaded screenshot, or '' when it cannot be fetched."""
    path = _cache_path("img:" + url, ".img")
    if _fresh(path, max_age):
        return path
    data = fetch(url)
    if not data:
        return path if os.path.isfile(path) else ""
    try:
        with open(path, "wb") as f:
            f.write(data)
    except OSError:
        return ""
    return path
