#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS Control Center backend.

The Cinnamon applet ``nawaos-control-center@nawaos`` is a thin UI: it runs

    python3 -m nawaos_controlcenter status          -> one JSON object
    python3 -m nawaos_controlcenter set KEY VALUE   -> exit 0 on success

and redraws from the JSON. Every state read and every change lives here so
it can be unit-tested without a desktop (the command runner is injectable).

Changes go through tools NawaOS already ships and validates:

    Game Mode / profile  pkexec nawaos-gamemode on|off|apply-power-profile
                         (polkit com.nawaos.gamemode, no password for the
                         active local user)
    Handheld power       pkexec nawaos-tdp-helper set N (com.nawaos.tdp-helper)
    Wi-Fi                nmcli radio wifi on|off
    Bluetooth            bluetoothctl power on|off
    Volume               wpctl (PipeWire/WirePlumber)
    Brightness           Cinnamon settings daemon over D-Bus (gdbus)
    Do Not Disturb       gsettings org.cinnamon.desktop.notifications
    FPS overlay          ~/.config/MangoHud/MangoHud.conf "no_display",
                         which MangoHud re-reads while a game runs

A missing tool or device is reported as ``"available": false`` and the
applet hides or greys out that control; nothing here raises to the caller.
"""

import json
import os
import re
import subprocess
import sys
from pathlib import Path

GAMEMODE_BIN = "/usr/local/bin/nawaos-gamemode"
TDP_HELPER = "/usr/local/bin/nawaos-tdp-helper"
GAMEMODE_STATE = "/run/nawaos/gamemode-state"
POWER_SUPPLY = "/sys/class/power_supply"
BLUETOOTH_SYSFS = "/sys/class/bluetooth"
BOOT_ID = "/proc/sys/kernel/random/boot_id"
READ_TIMEOUT = 3     # seconds; a status read must never stall the panel

# Profile name -> nawaos-gamemode apply-power-profile <governor> <gpu> <wifi>,
# the same values the Control Panel uses. "performance" IS Game Mode there
# (apply-power-profile enables it), every other profile turns it off first.
PROFILES = {
    "quiet": ("powersave", "low", "auto"),
    "balanced": ("schedutil", "auto", "auto"),
    "performance": ("performance", "high", "on"),
}

GDBUS_POWER = ["gdbus", "call", "--session",
               "--dest", "org.cinnamon.SettingsDaemon.Power",
               "--object-path", "/org/cinnamon/SettingsDaemon/Power"]
DND_SCHEMA = ["org.cinnamon.desktop.notifications", "display-notifications"]


def _state_dir():
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(
        os.path.expanduser("~"), ".local", "state")
    return Path(base) / "nawaos"


def _mangohud_conf():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(
        os.path.expanduser("~"), ".config")
    return Path(base) / "MangoHud" / "MangoHud.conf"


def run(cmd, timeout=READ_TIMEOUT):
    """Default runner: (returncode, stdout). 127 when the tool is missing."""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout
    except FileNotFoundError:
        return 127, ""
    except (subprocess.TimeoutExpired, OSError):
        return 124, ""


def _read(path, default=None):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def _write_state(name, value):
    try:
        d = _state_dir()
        d.mkdir(parents=True, exist_ok=True)
        tmp = d / (name + ".tmp")
        tmp.write_text(str(value) + "\n")
        os.replace(tmp, d / name)
    except OSError:
        pass


# ---------------------------------------------------------------- readers --

def split_terse(line):
    """Split one `nmcli -t` line. Fields are ':'-separated and a literal
    ':' or '\\' inside a field is escaped with a backslash."""
    fields, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            fields.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    fields.append("".join(cur))
    return fields


def nm_devices(r=run):
    """[(type, state), ...] of every NetworkManager device, [] without nmcli.
    One call serves both network_status and wifi_status."""
    rc, out = r(["nmcli", "-t", "-f", "TYPE,STATE", "device"])
    devices = []
    for line in out.splitlines() if rc == 0 else []:
        f = split_terse(line)
        if len(f) >= 2:
            devices.append((f[0], f[1]))
    return devices


def network_status(r=run, devices=None):
    """What the panel icon shows: the connected link, if any."""
    if devices is None:
        devices = nm_devices(r)
    kinds = [t for t, state in devices if state == "connected" and t in ("wifi", "ethernet")]
    if "ethernet" in kinds:
        return {"kind": "ethernet", "connected": True}
    if "wifi" in kinds:
        return {"kind": "wifi", "connected": True}
    return {"kind": "none", "connected": False}


def wifi_status(r=run, devices=None):
    if devices is None:
        devices = nm_devices(r)
    if "wifi" not in [t for t, _ in devices]:
        return {"available": False, "enabled": False, "network": None}
    rc, out = r(["nmcli", "-t", "radio", "wifi"])
    enabled = rc == 0 and out.strip() == "enabled"
    network, signal = None, 0
    if enabled:
        rc, out = r(["nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL", "device", "wifi",
                     "list", "--rescan", "no"])
        for line in out.splitlines() if rc == 0 else []:
            f = split_terse(line)
            if len(f) >= 3 and f[0] == "yes" and f[1]:
                network = f[1]
                signal = int(f[2]) if f[2].isdigit() else 0
                break
    return {"available": True, "enabled": enabled, "network": network, "signal": signal}


def wifi_networks(r=run, limit=10):
    """Nearby networks, strongest first, the connected one on top.
    Hidden networks (empty SSID) are left to the network settings."""
    rc, out = r(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi",
                 "list", "--rescan", "auto"], timeout=20)
    best = {}
    for line in out.splitlines() if rc == 0 else []:
        f = split_terse(line)
        if len(f) < 4 or not f[1]:
            continue
        net = {"ssid": f[1], "in_use": f[0] == "*",
               "signal": int(f[2]) if f[2].isdigit() else 0,
               "secure": f[3] not in ("", "--")}
        old = best.get(net["ssid"])
        if old is None or net["in_use"] or (not old["in_use"] and net["signal"] > old["signal"]):
            best[net["ssid"]] = net
    nets = sorted(best.values(), key=lambda n: (not n["in_use"], -n["signal"], n["ssid"].lower()))
    return nets[:limit]


# ------------------------------------------------------------------ media --
# Media players publish MPRIS on the session bus (org.mpris.MediaPlayer2.*):
# VLC, browsers playing audio or video, Spotify, Rhythmbox ... The bus is
# reached through a small adapter so the logic is testable without D-Bus.

MPRIS_PREFIX = "org.mpris.MediaPlayer2."
MPRIS_PATH = "/org/mpris/MediaPlayer2"
MEDIA_ACTIONS = {"play-pause": "PlayPause", "next": "Next", "previous": "Previous"}
_MPRIS_NAME = re.compile(r"^org\.mpris\.MediaPlayer2\.[A-Za-z0-9_.\-]+$")


class _GioBus:
    """Session-bus adapter (python3-gi). Raises on any D-Bus problem."""

    def __init__(self):
        from gi.repository import Gio, GLib
        self.Gio, self.GLib = Gio, GLib
        self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)

    def _call(self, dest, path, iface, method, args=None, reply="(v)"):
        GLib = self.GLib
        res = self.bus.call_sync(dest, path, iface, method, args, None,
                                 self.Gio.DBusCallFlags.NONE, 1500, None)
        return res.unpack() if res is not None else None

    def list_names(self):
        return self._call("org.freedesktop.DBus", "/org/freedesktop/DBus",
                          "org.freedesktop.DBus", "ListNames")[0]

    def get_all(self, name, iface):
        GLib = self.GLib
        return self._call(name, MPRIS_PATH, "org.freedesktop.DBus.Properties", "GetAll",
                          GLib.Variant("(s)", (iface,)))[0]

    def call(self, name, method):
        self._call(name, MPRIS_PATH, "org.mpris.MediaPlayer2.Player", method)


def _art_path(url):
    """Local cover art only: a remote URL would mean a network request."""
    if isinstance(url, str) and url.startswith("file://"):
        from urllib.parse import unquote, urlparse
        path = unquote(urlparse(url).path)
        if os.path.isfile(path):
            return path
    return None


def _players(bus):
    found = []
    for name in bus.list_names():
        if not name.startswith(MPRIS_PREFIX) or not _MPRIS_NAME.match(name):
            continue
        try:
            props = bus.get_all(name, "org.mpris.MediaPlayer2.Player")
            root = bus.get_all(name, "org.mpris.MediaPlayer2")
        except Exception:
            continue
        meta = props.get("Metadata") or {}
        artists = meta.get("xesam:artist") or []
        if isinstance(artists, str):
            artists = [artists]
        title = meta.get("xesam:title") or ""
        url = meta.get("xesam:url")
        if not title and isinstance(url, str) and url.startswith("file://"):
            # Untagged local files: show the file name, as players do.
            from urllib.parse import unquote, urlparse
            title = os.path.splitext(os.path.basename(unquote(urlparse(url).path)))[0]
        found.append({
            "player": name,
            "identity": root.get("Identity") or name[len(MPRIS_PREFIX):].split(".")[0],
            "status": props.get("PlaybackStatus", "Stopped"),
            "title": title,
            "artist": ", ".join(a for a in artists if a),
            "art": _art_path(meta.get("mpris:artUrl")),
            "can_previous": bool(props.get("CanGoPrevious", False)),
            "can_next": bool(props.get("CanGoNext", False)),
            "can_play_pause": bool(props.get("CanPause", False) or props.get("CanPlay", False)),
        })
    return found


def media_status(bus=None):
    """The player to show: playing first, then paused, then any other."""
    try:
        players = _players(bus or _GioBus())
    except Exception:
        players = []
    if not players:
        return {"available": False}
    rank = {"Playing": 0, "Paused": 1}
    best = sorted(players, key=lambda p: rank.get(p["status"], 2))[0]
    return dict(best, available=True, players=len(players))


def media_action(action, player, bus=None):
    if action not in MEDIA_ACTIONS:
        raise ValueError("media action must be one of %s" % ", ".join(MEDIA_ACTIONS))
    if not _MPRIS_NAME.match(player or ""):
        raise ValueError("not a media player bus name: %r" % player)
    bus = bus or _GioBus()
    if player not in bus.list_names():
        raise ValueError("media player not running: %s" % player)
    bus.call(player, MEDIA_ACTIONS[action])
    return True


def _pw_default(objects, key):
    for o in objects:
        if o.get("type") != "PipeWire:Interface:Metadata":
            continue
        if (o.get("props") or {}).get("metadata.name") != "default":
            continue
        for item in o.get("metadata") or []:
            if item.get("key") != key:
                continue
            value = item.get("value")
            if isinstance(value, str):
                try:
                    value = json.loads(value)
                except ValueError:
                    return value
            if isinstance(value, dict):
                return value.get("name")
    return None


def audio_devices(r=run):
    """Outputs and inputs from pw-dump, with the current defaults marked."""
    rc, out = r(["pw-dump"], timeout=10)
    try:
        objects = json.loads(out) if rc == 0 else []
    except ValueError:
        objects = []
    result = {"outputs": [], "inputs": []}
    defaults = {"Audio/Sink": _pw_default(objects, "default.audio.sink"),
                "Audio/Source": _pw_default(objects, "default.audio.source")}
    for o in objects:
        if o.get("type") != "PipeWire:Interface:Node":
            continue
        props = ((o.get("info") or {}).get("props")) or {}
        cls = props.get("media.class")
        if cls not in defaults or props.get("node.name") == "auto_null":
            continue
        dev = {"id": o.get("id"), "name": props.get("node.name", ""),
               "description": props.get("node.description") or props.get("node.nick")
               or props.get("node.name", ""),
               "default": props.get("node.name") == defaults[cls]}
        result["outputs" if cls == "Audio/Sink" else "inputs"].append(dev)
    for k in result:
        result[k].sort(key=lambda d: d["description"].lower())
    return result


def bluetooth_status(r=run, sysfs=BLUETOOTH_SYSFS):
    # No adapter: say so without asking bluetoothctl, which waits about ten
    # seconds for bluetoothd when the service is not running.
    try:
        adapters = [n for n in os.listdir(sysfs) if n.startswith("hci")]
    except OSError:
        adapters = []
    if not adapters:
        return {"available": False, "enabled": False, "connected": 0}
    rc, out = r(["bluetoothctl", "list"])
    if rc != 0 or "Controller" not in out:
        return {"available": False, "enabled": False, "connected": 0}
    rc, out = r(["bluetoothctl", "show"])
    enabled = rc == 0 and re.search(r"^\s*Powered:\s*yes", out, re.M) is not None
    connected = 0
    if enabled:
        rc, out = r(["bluetoothctl", "devices", "Connected"])
        if rc == 0:
            connected = sum(1 for l in out.splitlines() if l.startswith("Device "))
    return {"available": True, "enabled": enabled, "connected": connected}


def gamemode_status():
    state = (_read(GAMEMODE_STATE, "") or "").lower()
    return {"available": os.path.exists(GAMEMODE_BIN),
            "enabled": state in ("enabled", "on")}


def _boot_id():
    return _read(BOOT_ID)


def profile_status(gamemode_on):
    """(profile, applied). Performance is Game Mode, so it follows the Game
    Mode state. Quiet and Balanced are kept only as long as they are really
    in effect: the state file names the boot it was applied in, and after a
    reboot (the kernel defaults are back, nothing is applied) the default
    "balanced" is reported with applied=False, so the applet lets the user
    apply any profile again, the highlighted one included."""
    if gamemode_on:
        return "performance", True
    saved = (_read(_state_dir() / "power-profile", "") or "").split()
    boot = _boot_id()
    if len(saved) == 2 and saved[0] in PROFILES and boot and saved[1] == boot:
        return saved[0], True
    return "balanced", False


def fps_status():
    path = _mangohud_conf()
    text = _read(path, "") or ""
    hidden = any(l.strip() == "no_display" for l in text.splitlines())
    return {"available": True, "enabled": not hidden}


def dnd_status(r=run):
    rc, out = r(["gsettings", "get"] + DND_SCHEMA)
    if rc != 0:
        return {"available": False, "enabled": False}
    return {"available": True, "enabled": out.strip() == "false"}


def volume_status(r=run):
    # With no sound device PipeWire falls back to "Dummy Output" (auto_null),
    # which accepts and ignores volume changes: hide the slider instead.
    rc, info = r(["wpctl", "inspect", "@DEFAULT_AUDIO_SINK@"])
    if rc == 0 and re.search(r'node\.name\s*=\s*"auto_null"', info):
        return {"available": False, "percent": 0, "muted": False}
    rc, out = r(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"])
    m = re.search(r"Volume:\s*([0-9.]+)", out) if rc == 0 else None
    if not m:
        return {"available": False, "percent": 0, "muted": False}
    return {"available": True, "percent": max(0, min(150, round(float(m.group(1)) * 100))),
            "muted": "[MUTED]" in out}


def brightness_status(r=run):
    rc, out = r(GDBUS_POWER + ["--method",
                               "org.cinnamon.SettingsDaemon.Power.Screen.GetPercentage"])
    # gdbus prints "(uint32 70,)": take the value, not the "32" of the type.
    m = re.search(r"\(\s*(?:u?int\d+\s+)?(\d+)\s*,", out) if rc == 0 else None
    if not m:
        return {"available": False, "percent": 0}
    return {"available": True, "percent": max(0, min(100, int(m.group(1))))}


def battery_status(root=POWER_SUPPLY):
    try:
        names = sorted(os.listdir(root))
    except OSError:
        names = []
    for name in names:
        base = os.path.join(root, name)
        if (_read(os.path.join(base, "type")) or "") != "Battery":
            continue
        cap = _read(os.path.join(base, "capacity"))
        if cap is None or not cap.isdigit():
            continue
        status = (_read(os.path.join(base, "status")) or "").lower()
        return {"available": True, "percent": int(cap),
                "charging": status in ("charging", "full")}
    return {"available": False, "percent": 0, "charging": False}


def tdp_status(detect=None):
    """Handheld power limit: only on a recognised handheld."""
    if detect is None:
        try:
            import nawaos_handheld
            detect = nawaos_handheld.detect
        except ImportError:
            return {"available": False}
    try:
        is_handheld, name, profile = detect()
    except Exception:
        return {"available": False}
    if not is_handheld or not profile or not os.path.exists(TDP_HELPER):
        return {"available": False}
    lo, hi = profile.get("tdp_range", (5, 30))
    default = profile.get("tdp_default", (lo + hi) // 2)
    saved = _read(_state_dir() / "tdp-watts")
    watts = int(saved) if saved and saved.isdigit() else default
    return {"available": True, "device": name, "min": lo, "max": hi,
            "watts": max(lo, min(hi, watts))}


def language():
    try:
        import nawaos_i18n
        lang = nawaos_i18n.get_language()
        return lang, bool(nawaos_i18n.is_rtl())
    except Exception:
        return "en", False


def status(r=run, detect=None):
    gm = gamemode_status()
    lang, rtl = language()
    devices = nm_devices(r)
    profile, applied = profile_status(gm["enabled"])
    return {
        "language": lang, "rtl": rtl,
        "network": network_status(r, devices),
        "wifi": wifi_status(r, devices),
        "bluetooth": bluetooth_status(r),
        "gamemode": gm,
        "profile": profile,
        "profile_applied": applied,
        "fps": fps_status(),
        "dnd": dnd_status(r),
        "volume": volume_status(r),
        "brightness": brightness_status(r),
        "battery": battery_status(),
        "tdp": tdp_status(detect),
    }


# ---------------------------------------------------------------- setters --

def _onoff(value):
    v = str(value).strip().lower()
    if v in ("on", "true", "1", "yes"):
        return True
    if v in ("off", "false", "0", "no"):
        return False
    raise ValueError("expected on or off, got %r" % value)


def _percent(value, hi=100):
    v = int(str(value).strip())
    if not 0 <= v <= hi:
        raise ValueError("expected 0..%d, got %d" % (hi, v))
    return v


def set_fps(on):
    path = _mangohud_conf()
    lines = (_read(path, "") or "").splitlines()
    lines = [l for l in lines if l.strip() != "no_display"]
    if not on:
        lines.append("no_display")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text("\n".join(lines) + ("\n" if lines else ""))
    os.replace(tmp, path)
    return True


def apply(key, value, r=run, detect=None):
    """Apply one change. Returns True on success; ValueError on bad input."""
    if key == "wifi":
        return r(["nmcli", "radio", "wifi", "on" if _onoff(value) else "off"])[0] == 0
    if key == "bluetooth":
        on = _onoff(value)
        if on:
            r(["rfkill", "unblock", "bluetooth"])      # best effort, may need root
        return r(["bluetoothctl", "power", "on" if on else "off"])[0] == 0
    if key == "gamemode":
        # Turning Game Mode off restores the values it saved when it was
        # turned on, i.e. the profile that was in effect before: the
        # remembered Quiet/Balanced profile stays right, nothing to write.
        return r(["pkexec", GAMEMODE_BIN, "on" if _onoff(value) else "off"], timeout=60)[0] == 0
    if key == "profile":
        name = str(value).strip().lower()
        if name not in PROFILES:
            raise ValueError("profile must be one of %s" % ", ".join(PROFILES))
        gov, gpu, wifi = PROFILES[name]
        ok = r(["pkexec", GAMEMODE_BIN, "apply-power-profile", gov, gpu, wifi],
               timeout=60)[0] == 0
        # Performance is Game Mode and read from its state; for the others
        # remember which boot they were applied in (see profile_status).
        if ok and name != "performance":
            _write_state("power-profile", "%s %s" % (name, _boot_id() or "-"))
        return ok
    if key == "wifi-connect":
        ssid = str(value)
        if not ssid or len(ssid.encode()) > 32 or "\n" in ssid:
            raise ValueError("not a valid network name")
        # No password on the command line: NetworkManager reuses a saved
        # profile, or asks the session's secret agent (Cinnamon's own
        # password dialog) for a new secured network.
        return r(["nmcli", "--wait", "90", "device", "wifi", "connect", ssid],
                 timeout=100)[0] == 0
    if key in ("output", "input"):
        try:
            node = int(str(value).strip())
        except ValueError:
            raise ValueError("device id must be a number")
        devices = audio_devices(r)["outputs" if key == "output" else "inputs"]
        if node not in [d["id"] for d in devices]:
            raise ValueError("no such %s device: %d" % (key, node))
        return r(["wpctl", "set-default", str(node)])[0] == 0
    if key == "media":
        action, _, player = str(value).partition(":")
        try:
            return media_action(action, player)
        except ValueError:
            raise
        except Exception:
            return False
    if key == "fps":
        return set_fps(_onoff(value))
    if key == "dnd":
        # Do Not Disturb ON = Cinnamon shows no notification popups.
        show = "false" if _onoff(value) else "true"
        return r(["gsettings", "set"] + DND_SCHEMA + [show])[0] == 0
    if key == "volume":
        pct = _percent(value, 150)
        return r(["wpctl", "set-volume", "-l", "1.5", "@DEFAULT_AUDIO_SINK@",
                  "%.2f" % (pct / 100.0)])[0] == 0
    if key == "mute":
        return r(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@",
                  "1" if _onoff(value) else "0"])[0] == 0
    if key == "brightness":
        pct = _percent(value)
        return r(GDBUS_POWER + ["--method",
                                "org.cinnamon.SettingsDaemon.Power.Screen.SetPercentage",
                                str(pct)])[0] == 0
    if key == "tdp":
        info = tdp_status(detect)
        if not info.get("available"):
            raise ValueError("no supported handheld detected")
        watts = int(str(value).strip())
        if not info["min"] <= watts <= info["max"]:
            raise ValueError("watts must be %d..%d" % (info["min"], info["max"]))
        ok = r(["pkexec", TDP_HELPER, "set", str(watts)], timeout=30)[0] == 0
        if ok:
            _write_state("tdp-watts", watts)
        return ok
    raise ValueError("unknown setting %r" % key)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["status"]:
        print(json.dumps(status()))
        return 0
    if argv == ["list", "wifi"]:
        print(json.dumps(wifi_networks()))
        return 0
    if argv == ["list", "audio"]:
        print(json.dumps(audio_devices()))
        return 0
    if argv == ["list", "media"]:
        print(json.dumps(media_status()))
        return 0
    if len(argv) == 3 and argv[0] == "set":
        try:
            ok = apply(argv[1], argv[2])
        except ValueError as e:
            print("nawaos-control-center: %s" % e, file=sys.stderr)
            return 2
        return 0 if ok else 1
    print("usage: nawaos-control-center status | list wifi|audio|media | set KEY VALUE",
          file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
