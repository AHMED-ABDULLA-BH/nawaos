#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Handheld Daemon
Background service that:
- Detects handheld gaming devices (ROG Ally, Legion Go, Steam Deck, etc.)
- Manages automatic switching between Desktop Mode and Game Mode
- Monitors hardware buttons (hold Guide/Steam for 1 s) for mode toggle
- Re-applies the last power limit (TDP) after boot and after resume
- Applies device-specific optimizations
- Manages controller orientation and screen rotation

Version 1.7
Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import os
import sys
import json
import time
import signal
import glob
import struct
import subprocess
import threading
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
from nawaos_notify import notify_system, notify_gaming  # noqa: E402

# Shared handheld knowledge (device table, detection, evdev helpers). Kept
# optional so a bare dev checkout still runs with the minimal fallback below.
try:
    import nawaos_handheld
except ImportError:
    nawaos_handheld = None

# ========================================
# CONSTANTS
# ========================================
CONFIG_DIR = os.path.expanduser("~/.config/nawaos/handheld")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
# WHY: the PID file lives in the per-session runtime dir (tmpfs, cleared on
# reboot) instead of ~/.config, so a stale PID file can never survive a reboot
# and block the next start.
RUNTIME_DIR = os.environ.get("XDG_RUNTIME_DIR") or "/tmp"
PID_FILE = os.path.join(RUNTIME_DIR, "nawaos-handheld-daemon.pid")
STATE_FILE = os.path.join(CONFIG_DIR, "state.json")

if nawaos_handheld is not None:
    # Canonical tables live in the shared module (apps/nawaos-common).
    KNOWN_DEVICES = nawaos_handheld.KNOWN_DEVICES
    DEFAULT_PROFILE = nawaos_handheld.DEFAULT_PROFILE
else:
    # Minimal fallback for dev runs without the shared module installed.
    KNOWN_DEVICES = {
        key: {
            "name": key,
            "tdp_range": (5, 30),
            "tdp_default": 15,
            "has_gyro": False,
            "screen_rotation": "normal",
            "tdp_interface": "ryzenadj",
            "gpu": "unknown",
            "buttons": {},
        }
        for key in ("ROG Ally X", "ROG Ally", "Legion Go", "Steam Deck",
                    "AYANEO", "AYA NEO", "GPD", "ONEXPLAYER", "AOKZOE",
                    "MSI Claw")
    }
    DEFAULT_PROFILE = {
        "name": "Generic Handheld",
        "tdp_range": (5, 30),
        "tdp_default": 15,
        "has_gyro": False,
        "screen_rotation": "normal",
        "tdp_interface": "ryzenadj",
        "gpu": "unknown",
        "buttons": {},
    }

# Current modes
MODE_DESKTOP = "desktop"
MODE_GAMEMODE = "gamemode"

# Root work goes through the fixed, polkit-authorised helpers (allow_active=yes,
# so a keyboardless handheld never sees a password prompt). Never pkexec bash.
GAMEMODE_HELPER = "/usr/local/bin/nawaos-gamemode"
TDP_HELPER = "/usr/local/bin/nawaos-tdp-helper"
# Pattern of the installed Game Mode UI launcher (as nawaos-mode-switch uses).
GAMEMODE_UI_PATTERN = "/usr/local/bin/nawaos-gamemode-ui$"

# WHY: Guide also opens the Steam overlay and the console UI's own menu, so a
# short press must never switch modes (it used to, even in-game). Only a
# deliberate hold of this many seconds toggles Desktop Mode <-> Game Mode.
GUIDE_HOLD_SECONDS = nawaos_handheld.GUIDE_HOLD_SECONDS if nawaos_handheld is not None else 1.0

running = True


def signal_handler(sig: int, frame: Any) -> None:
    global running
    running = False


# ========================================
# DEVICE DETECTION
# ========================================
class DeviceDetector:
    """Detects handheld gaming devices via DMI/SMBIOS info."""

    @staticmethod
    def detect() -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """Returns (is_handheld, device_name, profile)"""
        if nawaos_handheld is not None:
            return nawaos_handheld.detect()
        dmi_paths = [
            '/sys/class/dmi/id/product_name',
            '/sys/class/dmi/id/board_name',
            '/sys/class/dmi/id/product_family',
        ]
        for path in dmi_paths:
            try:
                if os.path.exists(path):
                    with open(path) as f:
                        name = f.read().strip()
                    for key, profile in KNOWN_DEVICES.items():
                        if key.lower() in name.lower():
                            return True, name, profile
            except (IOError, PermissionError):
                pass

        # Not a recognised handheld: treat as a desktop/laptop.
        return False, "Desktop", None

    @staticmethod
    def get_gpu_vendor() -> str:
        """Detect GPU vendor."""
        try:
            for card in glob.glob('/sys/class/drm/card*/device/vendor'):
                with open(card) as f:
                    vendor = f.read().strip()
                    if vendor == '0x1002':
                        return 'amd'
                    elif vendor == '0x10de':
                        return 'nvidia'
                    elif vendor == '0x8086':
                        return 'intel'
        except:
            pass
        return 'unknown'

    @staticmethod
    def has_controller() -> bool:
        """Check if a gamepad/joystick is connected."""
        return len(glob.glob('/dev/input/js*')) > 0


# ========================================
# MODE MANAGER
# ========================================
class ModeManager:
    """Manages switching between Desktop Mode and Game Mode."""

    def __init__(self, profile: Dict[str, Any], config: Optional["DaemonConfig"] = None) -> None:
        self.profile: Dict[str, Any] = profile
        self.config = config
        self.current_mode: str = MODE_DESKTOP
        self._state_mtime = 0.0  # last-seen mtime of STATE_FILE
        self._load_state()

    def reload_state_if_changed(self) -> None:
        """Re-read STATE_FILE if its mtime changed.
        WHY: nawaos-mode-switch.sh writes state.json directly; without this the
        daemon's cached current_mode drifts out of sync with external toggles."""
        try:
            if not os.path.exists(STATE_FILE):
                return
            mtime = os.path.getmtime(STATE_FILE)
            if mtime == self._state_mtime:
                return
            self._state_mtime = mtime
            with open(STATE_FILE) as f:
                state = json.load(f)
            mode = state.get("mode")
            if mode in (MODE_DESKTOP, MODE_GAMEMODE):
                self.current_mode = mode
        except:
            # WHY: ignore partial/bad writes; keep last known mode, never crash.
            pass

    def _apply_tdp(self, watts: Optional[int]) -> None:
        """Apply a TDP limit via the polkit helper (best-effort, non-blocking)."""
        if not watts:
            return
        try:
            lo, hi = self.profile.get("tdp_range", (0, 0))
            if lo and hi:
                watts = max(lo, min(hi, int(watts)))
            watts = int(watts)
        except (TypeError, ValueError):
            return
        if not os.path.exists(TDP_HELPER):
            print(f"[TDP] {TDP_HELPER} is missing; {watts}W not applied")
            return
        threading.Thread(target=self._set_tdp, args=(watts,), daemon=True).start()

    @staticmethod
    def _set_tdp(watts: int) -> None:
        # nawaos_handheld.set_tdp also records the value for reapply_tdp().
        if nawaos_handheld is not None:
            ok = nawaos_handheld.set_tdp(watts)
        else:
            try:
                ok = subprocess.run(['pkexec', TDP_HELPER, 'set', str(watts)],
                                    capture_output=True, timeout=15).returncode == 0
            except (OSError, subprocess.TimeoutExpired):
                ok = False
        print(f"[TDP] {watts}W {'applied' if ok else 'NOT applied'} via nawaos-tdp-helper")

    def reapply_tdp(self) -> None:
        """Re-apply the last power limit; firmware resets it at boot and on
        resume from suspend, so a chosen TDP silently stopped applying."""
        watts = nawaos_handheld.last_tdp() if nawaos_handheld is not None else None
        if watts:
            print(f"[TDP] Re-applying last power limit ({watts}W)")
            self._apply_tdp(watts)

    def _load_state(self) -> None:
        try:
            if os.path.exists(STATE_FILE):
                self._state_mtime = os.path.getmtime(STATE_FILE)
                with open(STATE_FILE) as f:
                    state = json.load(f)
                    self.current_mode = state.get("mode", MODE_DESKTOP)
        except:
            pass

    def _save_state(self) -> None:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        try:
            with open(STATE_FILE, 'w') as f:
                json.dump({"mode": self.current_mode}, f)
            # WHY: record our own write so reload_state_if_changed doesn't
            # re-read (and re-apply) a state we just authored.
            self._state_mtime = os.path.getmtime(STATE_FILE)
        except:
            pass

    @staticmethod
    def _ui_running() -> bool:
        try:
            return subprocess.run(['pgrep', '-f', GAMEMODE_UI_PATTERN],
                                  stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL).returncode == 0
        except OSError:
            return False

    def switch_to_gamemode(self, apply_tdp: bool = True) -> None:
        # WHY: state.json lives in ~/.config and survives a reboot; "already in
        # Game Mode" must not stop the UI from being started again at boot.
        if self.current_mode == MODE_GAMEMODE and self._ui_running():
            return
        self.current_mode = MODE_GAMEMODE
        self._save_state()

        print("[Mode] Switching to Game Mode...")
        notify_gaming("Game Mode", "Switching to Game Mode UI", source="Handheld Daemon")

        # Apply gaming optimizations
        self._apply_gaming_tweaks()

        # Apply gaming TDP (configurable; falls back to the device default)
        if apply_tdp and (self.config is None or self.config.get("auto_tdp")):
            watts = None
            if self.config is not None:
                watts = self.config.get("tdp_gaming")
            if not watts:
                watts = self.profile.get("tdp_default")
            self._apply_tdp(watts)

        # Launch Game Mode UI (once)
        if self._ui_running():
            return
        try:
            env = os.environ.copy()
            env["DISPLAY"] = os.environ.get("DISPLAY", ":0")
            subprocess.Popen(
                ['nawaos-gamemode-ui'],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except Exception as e:
            print(f"[Error] Failed to launch Game Mode UI: {e}")

    def switch_to_desktop(self) -> None:
        if self.current_mode == MODE_DESKTOP:
            return
        self.current_mode = MODE_DESKTOP
        self._save_state()

        print("[Mode] Switching to Desktop Mode...")
        notify_system("Desktop Mode", "Switched back to desktop", source="Handheld Daemon")

        # Close the console UI (as nawaos-mode-switch does) and restore the
        # desktop settings.
        try:
            subprocess.run(['pkill', '-f', GAMEMODE_UI_PATTERN],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
        self._apply_desktop_tweaks()

        # Restore desktop TDP if the user configured one
        if self.config is not None and self.config.get("auto_tdp"):
            desktop_watts = self.config.get("tdp_desktop")
            if desktop_watts:
                self._apply_tdp(desktop_watts)

    def toggle(self) -> None:
        # The UI or nawaos-mode-switch may have changed the mode since the
        # main loop last looked.
        self.reload_state_if_changed()
        if self.current_mode == MODE_DESKTOP:
            self.switch_to_gamemode()
        else:
            self.switch_to_desktop()

    @staticmethod
    def _run_gamemode_helper(action: str) -> None:
        """nawaos-gamemode on/off: snapshot-and-restore Game Mode tuning.

        WHY: this used `pkexec bash -c <script>`, which polkit treats as an
        arbitrary root shell (password prompt on every mode switch, with no
        keyboard on a handheld) and which bypassed the snapshot that lets
        "off" put back exactly what the machine had.
        """
        try:
            result = subprocess.run(['pkexec', GAMEMODE_HELPER, action],
                                    capture_output=True, timeout=60)
            if result.returncode != 0:
                print(f"[Mode] nawaos-gamemode {action} failed ({result.returncode})")
        except (OSError, subprocess.TimeoutExpired) as e:
            print(f"[Mode] nawaos-gamemode {action} failed: {e}")

    def _apply_gaming_tweaks(self):
        """Apply performance optimizations for gaming."""
        self._run_gamemode_helper('on')

    def _apply_desktop_tweaks(self):
        """Restore the settings the machine had before Game Mode."""
        self._run_gamemode_helper('off')


# ========================================
# BUTTON MONITOR
# ========================================
class ButtonMonitor:
    """Monitors hardware buttons for mode toggle (Guide/Steam button)."""

    def __init__(self, on_guide_press):
        self.on_guide_press = on_guide_press
        self.running = False
        self.thread = None

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    @staticmethod
    def _device_has_key(event_name, code):
        """Check whether an event device advertises key/button <code>.

        Parses /sys/class/input/<eventN>/device/capabilities/key (hex words,
        most significant first). Fallback used when the shared module is
        unavailable.
        """
        path = os.path.join('/sys/class/input', event_name,
                            'device', 'capabilities', 'key')
        try:
            with open(path) as f:
                words = f.read().split()
            bits = 0
            for w in words:
                bits = (bits << 64) | int(w, 16)
            return bool(bits & (1 << code))
        except (IOError, OSError, ValueError):
            return False

    def _find_guide_button_device(self):
        """Find the input device for the Guide/Steam button."""
        BTN_MODE = 316
        BTN_A = 304
        if nawaos_handheld is not None:
            dev = nawaos_handheld.find_gamepad_event_device(BTN_MODE)
            if dev:
                return dev
        else:
            # WHY: a name substring like 'controller' alone matched things such
            # as fan/LED controllers; require the device to actually expose
            # gamepad buttons (BTN_MODE, or at least BTN_A) as well.
            fallback = None
            for dev_path in sorted(glob.glob('/dev/input/event*')):
                try:
                    event_name = os.path.basename(dev_path)
                    name_path = os.path.join('/sys/class/input', event_name,
                                             'device', 'name')
                    with open(name_path) as f:
                        name = f.read().strip().lower()
                    if not any(k in name for k in ['xbox', 'gamepad', 'controller',
                                                   'asus', 'legion', 'valve']):
                        continue
                    if self._device_has_key(event_name, BTN_MODE):
                        return dev_path
                    if fallback is None and self._device_has_key(event_name, BTN_A):
                        fallback = dev_path
                except:
                    pass
            if fallback:
                return fallback

        # Fallback: try js0
        js_devices = sorted(glob.glob('/dev/input/js*'))
        return js_devices[0] if js_devices else None

    def _monitor_loop(self):
        while self.running:
            dev = self._find_guide_button_device()
            if not dev:
                time.sleep(5)
                continue

            try:
                if dev.startswith('/dev/input/js'):
                    self._monitor_js(dev)
                else:
                    self._monitor_evdev(dev)
            except (IOError, OSError):
                time.sleep(2)

    def _guide_event(self, pressed: bool, seconds: float) -> None:
        """Track one Guide press/release (event timestamps, in seconds);
        toggle on release only when it was held for GUIDE_HOLD_SECONDS."""
        if pressed:
            self._guide_down_at = seconds
            return
        down_at, self._guide_down_at = getattr(self, "_guide_down_at", None), None
        if down_at is not None and seconds - down_at >= GUIDE_HOLD_SECONDS:
            print(f"[Button] Guide held {seconds - down_at:.1f}s: toggling mode")
            self.on_guide_press()

    def _monitor_js(self, dev):
        """Monitor joystick device for Guide button (js index 8 on xpad)."""
        # Only the xpad Guide index: 10 is the right-stick click on xpad, so
        # the old {8, 10, 12} let a held R3 switch modes.
        guide_buttons = {8}
        self._guide_down_at = None
        with open(dev, 'rb') as f:
            while self.running:
                data = f.read(8)
                if len(data) < 8:
                    break
                timestamp, value, evt_type, number = struct.unpack('IhBB', data)
                # WHY: JS_EVENT_INIT (0x80) marks synthetic initial-state
                # events emitted on device open; treating them as presses made
                # the daemon toggle modes the moment a controller appeared.
                if evt_type & 0x80:
                    continue
                if evt_type == 0x01 and number in guide_buttons:
                    # js timestamps are milliseconds (u32).
                    self._guide_event(value == 1, timestamp / 1000.0)

    def _monitor_evdev(self, dev):
        """Monitor evdev device for Guide button (KEY_MODE / BTN_MODE = 316)."""
        BTN_MODE = 316
        EVENT_SIZE = 24  # struct input_event size on 64-bit
        self._guide_down_at = None
        with open(dev, 'rb') as f:
            while self.running:
                data = f.read(EVENT_SIZE)
                if len(data) < EVENT_SIZE:
                    break
                # Parse: tv_sec(8) + tv_usec(8) + type(2) + code(2) + value(4)
                sec, usec = struct.unpack_from('qq', data, 0)
                evt_type = struct.unpack_from('H', data, 16)[0]
                code = struct.unpack_from('H', data, 18)[0]
                value = struct.unpack_from('i', data, 20)[0]

                # value 1 = press, 0 = release (2 = autorepeat, ignored)
                if evt_type == 1 and code == BTN_MODE and value in (0, 1):
                    self._guide_event(value == 1, sec + usec / 1e6)


# ========================================
# SCREEN ROTATION (for devices with rotated panels)
# ========================================
class ScreenManager:
    """Manages screen rotation for handheld devices with rotated panels."""

    @staticmethod
    def apply_rotation(rotation):
        if rotation == "normal":
            return
        try:
            display = os.environ.get("DISPLAY", ":0")
            subprocess.run(
                ['xrandr', '--output', ScreenManager._get_primary_output(), '--rotate', rotation],
                env={**os.environ, "DISPLAY": display},
                capture_output=True, timeout=5
            )
            print(f"[Screen] Applied rotation: {rotation}")
        except:
            pass

    @staticmethod
    def _get_primary_output():
        try:
            result = subprocess.run(['xrandr', '--query'], capture_output=True, text=True, timeout=5,
                                    env={**os.environ, "DISPLAY": os.environ.get("DISPLAY", ":0")})
            for line in result.stdout.split('\n'):
                if ' connected' in line:
                    return line.split()[0]
        except:
            pass
        return "eDP-1"


# ========================================
# RESUME WATCH (logind PrepareForSleep)
# ========================================
def watch_resume(on_resume) -> bool:
    """Call on_resume() a few seconds after every resume from suspend.

    logind emits PrepareForSleep(true) before sleeping and (false) after
    waking. Runs a GLib main loop in a background thread; returns False if
    Gio or the system bus is unavailable (TDP is then only applied at start).
    """
    try:
        import gi
        from gi.repository import Gio, GLib
    except (ImportError, ValueError):
        print("[Resume] python3-gi not available; no re-apply after resume")
        return False

    def on_signal(_conn, _sender, _path, _iface, _signal, params, *_args):
        if not params.unpack()[0]:
            # Give the firmware a moment to finish its own resume work.
            threading.Timer(3.0, on_resume).start()

    try:
        bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        bus.signal_subscribe('org.freedesktop.login1',
                             'org.freedesktop.login1.Manager',
                             'PrepareForSleep', '/org/freedesktop/login1',
                             None, Gio.DBusSignalFlags.NONE, on_signal)
    except Exception as e:
        print(f"[Resume] cannot watch logind: {e}")
        return False
    threading.Thread(target=GLib.MainLoop().run, daemon=True).start()
    return True


# ========================================
# DAEMON CONFIG
# ========================================
class DaemonConfig:
    """Persistent daemon configuration."""

    DEFAULTS = {
        "auto_gamemode_on_boot": True,
        "auto_gamemode_on_controller": True,
        "guide_button_toggle": True,
        "auto_tdp": True,
        "tdp_gaming": None,  # Will use device default
        "tdp_desktop": None,
        "apply_screen_rotation": True,
    }

    def __init__(self):
        self.config = dict(self.DEFAULTS)
        self._mtime = 0.0  # last-seen mtime of CONFIG_FILE; 0 => not yet read
        self._load()

    def _load(self):
        try:
            if os.path.exists(CONFIG_FILE):
                self._mtime = os.path.getmtime(CONFIG_FILE)
                with open(CONFIG_FILE) as f:
                    saved = json.load(f)
                    self.config.update(saved)
        except:
            # WHY: keep last good config on parse/IO error so the loop never crashes.
            pass

    def reload_if_changed(self):
        """Re-read CONFIG_FILE only if its mtime changed (avoids disk churn).
        WHY: the Game Mode UI edits config.json at runtime; without this the
        daemon would keep using the startup snapshot until restarted."""
        try:
            if not os.path.exists(CONFIG_FILE):
                return
            mtime = os.path.getmtime(CONFIG_FILE)
            if mtime == self._mtime:
                return
            self._mtime = mtime
            with open(CONFIG_FILE) as f:
                saved = json.load(f)
            # Reset to defaults then apply saved so removed keys revert cleanly.
            merged = dict(self.DEFAULTS)
            merged.update(saved)
            self.config = merged
        except:
            # WHY: bad/partial write -> keep last good config, never crash loop.
            pass

    def save(self):
        os.makedirs(CONFIG_DIR, exist_ok=True)
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(self.config, f, indent=2)
        except:
            pass

    def get(self, key, default=None):
        # WHY: `default or DEFAULTS.get(key)` discarded falsy explicit
        # defaults (False/0/""), silently substituting the class default.
        fallback = default if default is not None else self.DEFAULTS.get(key)
        return self.config.get(key, fallback)

    def set(self, key, value):
        self.config[key] = value
        self.save()


# ========================================
# MAIN DAEMON
# ========================================
def write_pid():
    os.makedirs(RUNTIME_DIR, exist_ok=True)
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))


def remove_pid():
    try:
        os.unlink(PID_FILE)
    except:
        pass


def is_already_running():
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE) as f:
                pid = int(f.read().strip())
            os.kill(pid, 0)
            return True
        except (ValueError, ProcessLookupError, PermissionError):
            remove_pid()
    return False


def run_daemon():
    global running

    # WHY: the systemd user unit is enabled globally for ALL graphical
    # sessions, so on ordinary desktops/laptops (no handheld hardware) the
    # daemon must exit 0 immediately: SuccessExitStatus=0 + Restart=on-failure
    # means systemd records a clean stop and never restart-loops a pointless
    # daemon. Set NAWAOS_HANDHELD_FORCE=1 to keep it running for development.
    is_handheld, device_name, profile = DeviceDetector.detect()
    if not is_handheld and os.environ.get("NAWAOS_HANDHELD_FORCE") != "1":
        print("No handheld hardware detected; nothing to do. Exiting cleanly.")
        sys.exit(0)

    if is_already_running():
        print("NawaOS Handheld Daemon is already running.", file=sys.stderr)
        sys.exit(1)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    write_pid()

    if profile is None:
        profile = DEFAULT_PROFILE

    config = DaemonConfig()

    print("=" * 50)
    print("  NawaOS Handheld Daemon")
    print("=" * 50)
    print(f"  Device: {device_name}")
    print(f"  Handheld: {'Yes' if is_handheld else 'No'}")
    print(f"  Profile: {profile['name']}")
    print(f"  GPU: {profile['gpu']}")
    print(f"  TDP Range: {profile['tdp_range'][0]}W - {profile['tdp_range'][1]}W")
    print(f"  Controller: {'Connected' if DeviceDetector.has_controller() else 'Not found'}")
    print(f"  PID: {os.getpid()}")
    print("=" * 50)

    # Mode manager
    mode_manager = ModeManager(profile, config)

    # Apply screen rotation if needed
    if is_handheld and config.get("apply_screen_rotation"):
        ScreenManager.apply_rotation(profile["screen_rotation"])

    # Button monitor for Guide button → toggle mode
    button_monitor = None
    if config.get("guide_button_toggle"):
        button_monitor = ButtonMonitor(on_guide_press=mode_manager.toggle)
        button_monitor.start()
        print("[Daemon] Button monitor started")

    # The firmware resets the power limit at boot and on resume: re-apply the
    # last one the user chose (Game Mode's own auto_tdp value only applies
    # when nothing was chosen yet).
    remembered_tdp = nawaos_handheld.last_tdp() if nawaos_handheld is not None else None
    if is_handheld:
        watch_resume(mode_manager.reapply_tdp)

    # Auto-start Game Mode on handheld boot
    if is_handheld and config.get("auto_gamemode_on_boot"):
        print("[Daemon] Auto-starting Game Mode on handheld device...")
        time.sleep(3)  # Wait for desktop to load
        mode_manager.switch_to_gamemode(apply_tdp=remembered_tdp is None)
    if is_handheld and remembered_tdp:
        mode_manager.reapply_tdp()

    # Notification
    if is_handheld:
        notify_system(
            "Handheld Mode",
            f"Device detected: {profile['name']}. Hold the Guide button for 1 second to switch modes.",
            source="Handheld Daemon"
        )

    # Controller hotplug monitoring
    last_controller_state = DeviceDetector.has_controller()

    # Main loop
    while running:
        time.sleep(3)

        # WHY: pick up runtime edits made by the Game Mode UI (config.json) and
        # nawaos-mode-switch.sh (state.json) without requiring a daemon restart.
        # Both are mtime-gated so a quiescent system does no extra disk reads.
        config.reload_if_changed()
        mode_manager.reload_state_if_changed()

        # Check controller hotplug
        if config.get("auto_gamemode_on_controller"):
            has_controller = DeviceDetector.has_controller()
            if has_controller and not last_controller_state:
                print("[Daemon] Controller connected")
                notify_gaming("Controller", "Gamepad connected", source="Handheld Daemon")
                if is_handheld and mode_manager.current_mode == MODE_DESKTOP:
                    mode_manager.switch_to_gamemode()
            elif not has_controller and last_controller_state:
                print("[Daemon] Controller disconnected")
                notify_system("Controller", "Gamepad disconnected", source="Handheld Daemon")
            last_controller_state = has_controller

    # Cleanup
    if button_monitor:
        button_monitor.stop()
    remove_pid()
    print("[Daemon] Stopped.")


if __name__ == "__main__":
    run_daemon()
