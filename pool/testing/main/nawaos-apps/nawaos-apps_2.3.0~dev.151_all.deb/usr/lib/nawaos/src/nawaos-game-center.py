#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Gaming Center
Professional Gaming Hub with Game Library
Version 2.0

Developed by: Ahmed Abdulla
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango, GdkPixbuf
import subprocess
import os
import sys
import json
import shlex
import shutil
import threading
import socket
from pathlib import Path


# Release info shared by all NawaOS apps (nawaos-common/nawaos_release.py).
try:
    import nawaos_release
except ImportError:
    nawaos_release = None

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402
import nawaos_theme  # noqa: E402
import nawaos_taskrunner  # noqa: E402
from nawaos_notify import notify_gaming  # noqa: E402

APP_NAME = "nawaos-game-center"

# ---------------------------------------------------------------------------
# Built-in Arabic UI strings. Every user-visible string goes through _() with
# this dictionary; product and tool names stay in Latin script.
# ---------------------------------------------------------------------------
AR_STRINGS = {
    # -- Shell / navigation ------------------------------------------------
    "NawaOS Gaming Center": "مركز ألعاب NawaOS",
    "Gaming Center": "مركز الألعاب",
    "Dashboard": "لوحة التحكم",
    "My Games": "ألعابي",
    "Open Source": "مفتوحة المصدر",
    "Game Mode": "وضع الألعاب",
    "Profiles": "الملفات الشخصية",
    "Tools": "الأدوات",
    "Launchers": "المشغلات",
    "Settings": "الإعدادات",
    "ON": "مُفعّل",
    "OFF": "مُعطّل",

    # -- Dashboard ---------------------------------------------------------
    "Welcome to NawaOS Gaming Center": "مرحباً بك في مركز ألعاب NawaOS",
    "Games": "الألعاب",
    "Enabled": "مُفعّل",
    "Disabled": "مُعطّل",
    "Installed": "مثبت",
    "Not Installed": "غير مثبت",
    "Quick Actions": "إجراءات سريعة",
    "Enable Game Mode": "تفعيل وضع الألعاب",
    "Install Proton-GE": "تثبيت Proton-GE",
    "Launch Steam": "تشغيل Steam",

    # -- Library -----------------------------------------------------------
    "Search games…": "ابحث عن الألعاب…",
    "Refresh Games": "تحديث قائمة الألعاب",
    "All": "الكل",
    "Play": "تشغيل",
    "No games found. Install Steam, Lutris, or Flatpak games!":
        "لم يتم العثور على ألعاب. ثبّت ألعاب Steam أو Lutris أو Flatpak!",
    "Refreshing games...": "جارٍ تحديث قائمة الألعاب...",
    "Launching %s...": "جارٍ تشغيل %s...",

    # -- Game Mode page ----------------------------------------------------
    "Optimize your system for maximum gaming performance":
        "اضبط نظامك للحصول على أقصى أداء في الألعاب",
    "Status:": "الحالة:",
    "CPU Governor → Performance mode": "منظّم المعالج ← وضع الأداء",
    "Swappiness → Reduced to 10": "قيمة Swappiness ← تُخفَّض إلى 10",
    "Network → Low latency mode": "الشبكة ← وضع الاستجابة المنخفضة",
    "Compositor → Disabled (optional)": "مُركِّب سطح المكتب ← معطّل (اختياري)",
    "Mouse → Raw input mode": "الفأرة ← وضع الإدخال الخام",
    "Disable Game Mode": "تعطيل وضع الألعاب",
    "Enabling…": "جارٍ التفعيل…",
    "Disabling…": "جارٍ التعطيل…",
    "✓ Enabled": "✓ مُفعّل",
    "Game Mode enabled! System optimized for gaming.":
        "تم تفعيل وضع الألعاب! تم ضبط النظام للعب.",
    "Game Mode disabled. System restored to normal.":
        "تم تعطيل وضع الألعاب. عاد النظام إلى وضعه الطبيعي.",
    "Failed to change Game Mode. Check if script exists.":
        "تعذّر تغيير وضع الألعاب. تحقق من وجود السكربت.",

    # -- Profiles ----------------------------------------------------------
    "Game Profiles": "ملفات الألعاب الشخصية",
    "Create custom optimization profiles for different games":
        "أنشئ ملفات ضبط مخصصة لألعاب مختلفة",
    "New Profile": "ملف شخصي جديد",
    "Edit Profile": "تعديل الملف الشخصي",
    "No profiles yet. Click 'New Profile' to create one!":
        "لا توجد ملفات شخصية بعد. اضغط «ملف شخصي جديد» لإنشاء واحد!",
    "CPU: %s | Swap: %s": "المعالج: %s | التبديل: %s",
    "Activate Profile": "تفعيل الملف الشخصي",
    "Delete Profile": "حذف الملف الشخصي",
    "Delete profile '%s'?": "هل تريد حذف الملف الشخصي '%s'؟",
    "FPS Games": "ألعاب التصويب",
    "General Gaming": "ألعاب عامة",
    "Low Memory": "ذاكرة منخفضة",
    "Profile '%s' has an invalid swappiness value.":
        "الملف الشخصي '%s' يحتوي على قيمة swappiness غير صالحة.",
    "Profile '%s' activated!": "تم تفعيل الملف الشخصي '%s'!",
    "Failed to activate '%s' (authentication cancelled or rejected).":
        "تعذّر تفعيل '%s' (أُلغيت المصادقة أو رُفضت).",
    "Profile Name:": "اسم الملف الشخصي:",
    "CPU Governor:": "منظّم المعالج:",
    "Swappiness:": "قيمة Swappiness:",

    # -- Launchers ---------------------------------------------------------
    "Game Launchers": "مشغلات الألعاب",
    "Launch your favorite gaming platforms with one click":
        "شغّل منصات الألعاب المفضلة لديك بنقرة واحدة",
    "9 platforms": "9 منصات",
    "Main Platforms": "المنصات الرئيسية",
    "Emulators & Retro Gaming": "المحاكيات والألعاب الكلاسيكية",
    "Windows Gaming (Wine)": "ألعاب Windows عبر Wine",
    "Gaming Tools": "أدوات الألعاب",
    "Official Steam client for thousands of games":
        "عميل Steam الرسمي لآلاف الألعاب",
    "Open gaming platform for all your games": "منصة ألعاب مفتوحة لجميع ألعابك",
    "Play Epic Games, GOG and Amazon Prime Games":
        "شغّل ألعاب Epic Games وGOG وAmazon Prime Games",
    "All-in-one retro game emulator": "محاكي شامل للألعاب الكلاسيكية",
    "Classic DOS game emulator": "محاكي ألعاب DOS الكلاسيكية",
    "Modern Wine manager with sandboxing": "مدير Wine حديث مع عزل التطبيقات",
    "Manage Proton-GE and Wine-GE": "إدارة Proton-GE وWine-GE",
    "Valve gaming compositor for better performance":
        "مُركِّب Valve للألعاب لأداء أفضل",
    "AMD GPU overclocking and control": "رفع تردد بطاقات AMD والتحكم بها",
    "Map controller to keyboard/mouse": "ربط ذراع التحكم بلوحة المفاتيح والفأرة",
    "Launch %s": "تشغيل %s",

    # -- Open source games -------------------------------------------------
    "Open Source Games": "ألعاب مفتوحة المصدر",
    "Free and open source games from GitHub - Download and play!":
        "ألعاب مجانية ومفتوحة المصدر من GitHub - نزّلها والعب!",
    "A free, open-source RTS game of ancient warfare":
        "لعبة استراتيجية آنية مجانية ومفتوحة المصدر عن حروب العصور القديمة",
    "A free kart racing game with Tux and friends":
        "لعبة سباق كارت مجانية مع Tux وأصدقائه",
    "Multiplayer voxel RPG inspired by games such as Cube World":
        "لعبة تقمص أدوار جماعية بأسلوب الفوكسل مستوحاة من ألعاب مثل Cube World",
    "Fast-paced arena shooter, fork of Nexuiz":
        "لعبة تصويب سريعة الإيقاع في الساحات، مشتقة من Nexuiz",
    "Open-source engine for TES III: Morrowind":
        "محرك مفتوح المصدر للعبة TES III: Morrowind",
    "Open source voxel game engine - Minecraft alternative":
        "محرك ألعاب فوكسل مفتوح المصدر - بديل لـ Minecraft",
    "Turn-based strategy game with fantasy theme":
        "لعبة استراتيجية بالأدوار بأجواء خيالية",
    "Classic RTS games rebuilt for the modern era":
        "ألعاب استراتيجية كلاسيكية أُعيد بناؤها للعصر الحديث",
    "Space exploration and combat game": "لعبة استكشاف فضائي وقتال",
    "Free and open implementation of Civilization":
        "تطبيق حر ومفتوح للعبة Civilization",
    "Open source transport business simulation":
        "محاكاة أعمال النقل مفتوحة المصدر",
    "Turn-based survival game set in a post-apocalyptic world":
        "لعبة بقاء بالأدوار في عالم ما بعد الكارثة",
    "Real-time strategy game originally by Pumpkin Studios":
        "لعبة استراتيجية آنية من إنتاج Pumpkin Studios أصلاً",
    "2D retro multiplayer shooter":
        "لعبة تصويب جماعية ثنائية الأبعاد بطابع كلاسيكي",
    "DDraceNetwork - Cooperative 2D platformer":
        "DDraceNetwork - لعبة منصات تعاونية ثنائية الأبعاد",
    "Strategy": "استراتيجية",
    "Racing": "سباقات",
    "RPG": "تقمص أدوار",
    "FPS": "FPS",
    "Sandbox": "عالم مفتوح",
    "Space": "فضاء",
    "Simulation": "محاكاة",
    "Roguelike": "Roguelike",
    "Shooter": "تصويب",
    "Platformer": "منصات",
    "Install": "تثبيت",
    "Open Website": "فتح الموقع",
    "Installing…": "جارٍ التثبيت…",
    "No internet connection! Cannot install %s.":
        "لا يوجد اتصال بالإنترنت! تعذّر تثبيت %s.",
    "%s installed successfully!": "تم تثبيت %s بنجاح!",
    "Error launching: %s": "خطأ في التشغيل: %s",

    # -- Advanced tools ----------------------------------------------------
    "Advanced Tools": "أدوات متقدمة",
    "Powerful gaming tools to optimize your experience":
        "أدوات قوية لتحسين تجربة اللعب",
    "GameScope Session": "جلسة GameScope",
    "Console-style full-screen gaming compositor with VRR, FSR, and HDR":
        "مُركِّب ألعاب بملء الشاشة بأسلوب أجهزة الكونسول مع دعم VRR وFSR وHDR",
    "HDR Gaming": "الألعاب بتقنية HDR",
    "High Dynamic Range support for Vulkan and DirectX games":
        "دعم النطاق الديناميكي العالي HDR لألعاب Vulkan وDirectX",
    "Wayland Gaming": "الألعاب على Wayland",
    "Modern display session with XWayland compatibility for all games":
        "جلسة عرض حديثة مع توافق XWayland لجميع الألعاب",
    "Proton-GE Auto Updater": "المحدّث التلقائي لـ Proton-GE",
    "Automatic daily updates for the latest Proton-GE compatibility layer":
        "تحديثات يومية تلقائية لأحدث طبقة توافق Proton-GE",
    "Gaming Meta Package": "حزمة الألعاب الشاملة",
    "One-click installation of Steam, Lutris, Wine, MangoHud, GameMode, and more":
        "تثبيت بنقرة واحدة لـ Steam وLutris وWine وMangoHud وGameMode وغيرها",
    "Game Performance Mode": "وضع أداء الألعاب",
    "Toggle CPU/GPU/I/O optimizations for maximum gaming performance":
        "تبديل تحسينات المعالج وكرت الشاشة والقرص لأقصى أداء في الألعاب",
    "vkBasalt &amp; GOverlay": "vkBasalt وGOverlay",
    "FSR-like sharpening and post-processing effects for Vulkan games":
        "تحسين حدة الصورة بأسلوب FSR ومؤثرات المعالجة اللاحقة لألعاب Vulkan",
    "Handheld / Steam Deck Tools": "أدوات الأجهزة المحمولة وSteam Deck",
    "Support for Steam Deck, ROG Ally, Legion Go and other handhelds":
        "دعم أجهزة Steam Deck وROG Ally وLegion Go وغيرها من الأجهزة المحمولة",
    "PipeWire Gaming Audio": "صوت الألعاب عبر PipeWire",
    "Low-latency audio presets for gaming and music production":
        "إعدادات صوت منخفضة الاستجابة للألعاب وإنتاج الموسيقى",
    "Discord Wayland Fix": "إصلاح Discord على Wayland",
    "Fix screen sharing on Wayland desktop":
        "إصلاح مشاركة الشاشة على سطح مكتب Wayland",
    "Bluetooth Controller": "ذراع تحكم Bluetooth",
    "Setup Xbox, PlayStation, Nintendo controllers":
        "إعداد أذرع تحكم Xbox وPlayStation وNintendo",
    "VRR/FreeSync Toggle": "تبديل VRR/FreeSync",
    "Enable Variable Refresh Rate for smooth gaming":
        "فعّل معدل التحديث المتغير للعب أكثر سلاسة",
    "NTSYNC (Wine/Proton)": "NTSYNC لـ Wine وProton",
    "Better Windows game performance via Linux kernel":
        "أداء أفضل لألعاب Windows عبر نواة Linux",

    # -- Tool buttons ------------------------------------------------------
    "Start Session": "بدء الجلسة",
    "Check HDR": "فحص HDR",
    "Enable HDR": "تفعيل HDR",
    "Session Info": "معلومات الجلسة",
    "Enable Timer": "تفعيل المؤقّت",
    "Update Now": "التحديث الآن",
    "Status": "الحالة",
    "Full Setup": "إعداد كامل",
    "Minimal": "إعداد مبسّط",
    "Enable": "تفعيل",
    "Disable": "تعطيل",
    "Toggle": "تبديل",
    "Install vkBasalt": "تثبيت vkBasalt",
    "Install Tools": "تثبيت الأدوات",
    "GOverlay": "GOverlay",
    "GameScope": "GameScope",
    "Gaming Mode": "وضع اللعب",
    "Music Mode": "وضع الموسيقى",
    "Default": "افتراضي",
    "Apply Fix": "تطبيق الإصلاح",
    "Pair": "اقتران",
    "Test": "اختبار",
    "Running…": "جارٍ التنفيذ…",
    "%s launched": "تم تشغيل %s",
    "Tool not found": "الأداة غير موجودة",
    "'%s' is not installed.": "'%s' غير مثبت.",
    "GOverlay launched": "تم تشغيل GOverlay",
    "GOverlay not installed": "GOverlay غير مثبت",
    "Install it with:\nflatpak install flathub io.github.benjamimgois.goverlay":
        "ثبّته عبر الأمر:\nflatpak install flathub io.github.benjamimgois.goverlay",

    # -- Settings page -----------------------------------------------------
    "Version %s": "الإصدار %s",
    "Developed by:": "تطوير:",
    "Visit Website": "زيارة الموقع",
    "MangoHud Overlay Preset": "إعداد طبقة MangoHud",
    "Choose what the in-game performance overlay shows. "
    "Presets are saved to ~/.config/MangoHud/presets.conf.":
        "اختر ما تعرضه طبقة الأداء أثناء اللعب. "
        "تُحفظ الإعدادات في ~/.config/MangoHud/presets.conf.",
    "Off": "إيقاف",
    "FPS only": "FPS فقط",
    "Full": "كامل",
    "Streaming": "البث",
    "Tip: Shift+F12 cycles presets in-game; enable the overlay "
    "per game with Steam launch options: mangohud %command%":
        "تلميح: يبدّل Shift+F12 بين الإعدادات أثناء اللعب؛ فعّل الطبقة "
        "لكل لعبة عبر خيارات تشغيل Steam: mangohud %command%",
    "Current: custom (hand-edited presets.conf -- pick a preset to replace it)":
        "الحالي: مخصص (ملف presets.conf مُحرَّر يدوياً - اختر إعداداً لاستبداله)",
    "Current: Off -- no presets.conf (F12 still toggles the default overlay)":
        "الحالي: إيقاف - لا يوجد ملف presets.conf (يظل F12 يبدّل الطبقة الافتراضية)",
    "Current: %s": "الحالي: %s",
    "Existing presets.conf preserved as presets.conf.bak":
        "تم الاحتفاظ بملف presets.conf الحالي باسم presets.conf.bak",
    "Could not write MangoHud preset: %s":
        "تعذّر كتابة إعداد MangoHud: %s",
    "MangoHud presets removed -- overlay uses its default config":
        "تمت إزالة إعدادات MangoHud - تستخدم الطبقة إعداداتها الافتراضية",
    "MangoHud preset saved: %s": "تم حفظ إعداد MangoHud: %s",

    # -- Launching apps / errors -------------------------------------------
    "Launching…": "جارٍ التشغيل…",
    "Launched successfully": "تم التشغيل بنجاح",
    "App not installed: %s": "التطبيق غير مثبت: %s",
    "Error: %s": "خطأ: %s",
    "Launching Steam...": "جارٍ تشغيل Steam...",
    "Steam is not installed": "Steam غير مثبت",
    "Install it from the Launchers page or with:\nsudo apt install steam":
        "ثبّته من صفحة المشغلات أو عبر الأمر:\nsudo apt install steam",
    "Could not launch Steam": "تعذّر تشغيل Steam",
    "NawaOS Gaming Center cannot start": "تعذّر بدء مركز ألعاب NawaOS",
    "The shared module 'nawaos_games' could not be imported (%s).\n\n"
    "Your NawaOS installation appears incomplete. "
    "Reinstall the NawaOS apps (deployment hook 05) to repair it.":
        "تعذّر استيراد الوحدة المشتركة 'nawaos_games' (%s).\n\n"
        "يبدو أن تثبيت NawaOS غير مكتمل. "
        "أعد تثبيت تطبيقات NawaOS (خطاف النشر 05) لإصلاحه.",

    # -- 2.2: in-app tasks, system tools moved to the Control Panel --------
    "Install %s": "تثبيت %s",
    "System Settings": "إعدادات النظام",
    "Drivers, updates, snapshots, disks and power live in the NawaOS Control Panel":
        "التعريفات والتحديثات واللقطات والأقراص والطاقة في لوحة تحكم NawaOS",
    "Drivers": "التعريفات",
    "Updates": "التحديثات",
    "Backup": "النسخ الاحتياطي",
    "Storage": "التخزين",
    "Power": "الطاقة",
    "Could not open the Control Panel": "تعذّر فتح لوحة التحكم",

    # -- 2.3: launch a Flatpak only when installed ------------------------------
    "%s is not installed": "%s غير مثبت",
    "Install it from the NawaOS Store, then launch it again.": "ثبّته من متجر NawaOS ثم شغّله مرة أخرى.",
    "Cancel": "إلغاء",
    "Open NawaOS Store": "فتح متجر NawaOS",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    return nawaos_i18n.setup(APP_NAME, AR_STRINGS)


_, get_language, is_rtl = _setup_i18n()

# nawaos_games is deployed to /usr/lib/nawaos/src by the same hook that
# installs this app, so it is a hard requirement: if the import fails the
# installation is broken, and main() reports that instead of silently
# degrading to a stale duplicate scanner.
try:
    import nawaos_games
    _NAWAOS_GAMES_ERROR = None
except ImportError as _e:
    nawaos_games = None
    _NAWAOS_GAMES_ERROR = _e

def get_nawaos_version():
    """NawaOS version for UI display (VERSION_ID), via nawaos_release."""
    return nawaos_release.version() if nawaos_release else ""


# SVG Icons as strings
ICONS = {
    'gamepad': '''<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="2" y="6" width="20" height="12" rx="3"/>
        <circle cx="8" cy="12" r="2"/>
        <path d="M14 10h4M16 8v4"/>
    </svg>''',
    'rocket': '''<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/>
        <path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/>
    </svg>''',
    'library': '''<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
    </svg>'''
}


class GameInfo:
    """Represents a detected game"""
    def __init__(self, name, path, source, icon=None, app_id=None, launch_cmd=None):
        self.name = name
        self.path = path
        self.source = source  # steam, lutris, flatpak, native
        self.icon = icon
        self.app_id = app_id
        self.launch_cmd = launch_cmd  # preferred argument-list launch command
    
    def launch(self):
        # Prefer an explicit argument-list command (provided by the shared
        # nawaos_games scanner) so e.g. Lutris launches correctly.
        if self.launch_cmd:
            subprocess.Popen(self.launch_cmd)
        elif self.source == "steam" and self.app_id:
            subprocess.Popen(["steam", f"steam://rungameid/{self.app_id}"])
        elif self.source == "flatpak":
            subprocess.Popen(["flatpak", "run", self.app_id])
        elif self.source == "lutris" and self.path:
            # A "lutris:rungame/<slug>" URI must be handed to the lutris
            # binary, not exec'd as a program (Popen([self.path]) would
            # raise FileNotFoundError).
            subprocess.Popen(["lutris", self.path])
        elif self.path:
            subprocess.Popen([self.path])


class GameScanner:
    """Thin adapter over the shared nawaos_games scanner.

    Discovery logic lives ONLY in nawaos_games (deployed by the same hook as
    this app) so every NawaOS UI sees the same game list; the old duplicated
    fallback scan_* methods drifted out of sync and were removed.
    """

    @staticmethod
    def scan_all():
        return [
            GameInfo(g.name, g.path, g.source, g.icon_names, g.app_id, g.launch_cmd)
            for g in nawaos_games.scan_all(include_desktop=False)
        ]


class GameProfile:
    def __init__(self, name, cpu_governor="performance", swappiness=10, 
                 compositor=False, mouse_accel=False, custom_env=None):
        self.name = name
        self.cpu_governor = cpu_governor
        self.swappiness = swappiness
        self.compositor = compositor
        self.mouse_accel = mouse_accel
        self.custom_env = custom_env or {}
    
    def to_dict(self):
        return {
            'name': self.name,
            'cpu_governor': self.cpu_governor,
            'swappiness': self.swappiness,
            'compositor': self.compositor,
            'mouse_accel': self.mouse_accel,
            'custom_env': self.custom_env
        }
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)


class NawaOSGameCenter(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("NawaOS Gaming Center"))
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)
        self.set_default_size(1000, 700)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.get_style_context().add_class("nawaos-window")
        
        # Config paths
        self.config_dir = Path.home() / '.config' / 'nawaos-game-center'
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.profiles_file = self.config_dir / 'profiles.json'
        
        # Load profiles
        self.profiles = self.load_profiles()
        self.current_profile = None
        
        # Apply dark theme
        settings = Gtk.Settings.get_default()
        settings.set_property("gtk-application-prefer-dark-theme", True)
        
        # Load CSS
        self.load_css()
        
        # Main container
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_box)
        
        # Sidebar
        self.create_sidebar()
        
        # Content area
        self.content_stack = Gtk.Stack()
        self.content_stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.content_stack.set_transition_duration(200)
        self.main_box.pack_start(self.content_stack, True, True, 0)

        # Start empty; the real scan runs in a background thread (below) so a
        # slow flatpak/sqlite query cannot delay the window or freeze the UI.
        self.games = []

        # Create pages
        self.create_dashboard_page()
        self.create_library_page()
        self.create_gamemode_page()
        self.create_profiles_page()
        self.create_tools_page()  # Advanced gaming tools
        self.create_opensource_games_page()  # Open Source Games
        self.create_launchers_page()
        self.create_settings_page()

        self.show_all()

        # Scan games off the main loop, then repopulate the grid.
        self._start_game_scan()

    def _start_game_scan(self):
        """Scan installed games on a worker thread and refresh the grid."""
        def worker():
            games = GameScanner.scan_all()
            def apply():
                self.games = games
                search = self.search_entry.get_text() if hasattr(self, 'search_entry') else ""
                self.populate_games(getattr(self, 'current_filter', 'all'), search)
                if hasattr(self, 'dashboard_games_label'):
                    self.dashboard_games_label.set_text(str(len(games)))
                return False
            GLib.idle_add(apply)
        threading.Thread(target=worker, daemon=True).start()
    
    def load_css(self):
        # Thin app-specific layer over the shared NawaOS 2.0 design system
        # (nawaos_theme.BASE_CSS provides .nawaos-window, .sidebar, .card,
        # .action-btn/.action-btn-primary, .stat-value/.stat-label, ...).
        # Brand: ground #0B0F1A / surface #1A2332 / hover #232D3F,
        # gradient #1A76BA -> #37BCE0 -> #50E6E2, text #E8EDF4 / #9AA7B8.
        css = b"""
        /* === NawaOS Gaming Center 2.0 - app layer === */
        .logo-box { background: linear-gradient(135deg, #1A76BA 0%, #37BCE0 55%, #50E6E2 100%); border-radius: 16px; padding: 16px 12px; margin-bottom: 20px; }
        .logo-text { color: #ffffff; font-size: 18px; font-weight: 700; }
        .logo-sub { color: rgba(255,255,255,0.85); font-size: 12px; font-weight: 600; }
        .logo-badge { background-color: rgba(11,15,26,0.35); color: #ffffff; border-radius: 100px; padding: 1px 10px; font-size: 11px; font-weight: 700; }

        .sidebar-btn { background: transparent; border: none; border-radius: 100px; color: #9AA7B8; min-height: 40px; padding: 2px 16px; margin: 2px 0; font-size: 14px; font-weight: 600; transition: all 150ms ease; }
        .sidebar-btn:hover { background-color: #232D3F; color: #E8EDF4; }
        .sidebar-btn:checked { background-color: rgba(55,188,224,0.18); color: #50E6E2; }

        .content-area { padding: 32px; }
        .page-title { color: #E8EDF4; font-size: 25px; font-weight: 700; }
        .title-underline { background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2); border-radius: 100px; }
        .page-subtitle { color: #9AA7B8; font-size: 14px; }
        .section-label { color: #9AA7B8; font-size: 10px; font-weight: 700; letter-spacing: 2px; }
        .card-desc { color: #9AA7B8; font-size: 13px; }

        /* Separation by elevation: cards keep only a whisper border */
        .card { border-color: rgba(55,188,224,0.08); }

        .nav-search { background-color: #1A2332; border: 1px solid rgba(55,188,224,0.08); border-radius: 100px; padding: 6px 14px; }
        .nav-search:focus { border-color: #37BCE0; }

        /* Ghost buttons: minor actions, borderless, hover pill */
        .ghost-btn { background: transparent; border: none; border-radius: 100px; color: #37BCE0; padding: 6px 14px; font-weight: 600; transition: all 150ms ease; }
        .ghost-btn:hover { background-color: rgba(55,188,224,0.12); color: #50E6E2; }
        .ghost-danger { background: transparent; border: none; border-radius: 100px; color: #F87171; padding: 6px 14px; font-weight: 600; }
        .ghost-danger:hover { background-color: rgba(248,113,113,0.12); }
        .icon-btn { background: transparent; border: none; border-radius: 100px; color: #9AA7B8; padding: 8px 10px; }
        .icon-btn:hover { background-color: #232D3F; color: #E8EDF4; }

        /* Accent-tint pill actions (Play / Launch / Install) */
        .tint-btn, .play-btn { background-color: rgba(55,188,224,0.15); color: #50E6E2; border: none; border-radius: 100px; padding: 8px 18px; font-weight: 600; transition: all 150ms ease; }
        .tint-btn:hover, .play-btn:hover { background-color: rgba(55,188,224,0.25); }

        .game-card { background-color: #1A2332; border: 1px solid rgba(55,188,224,0.08); border-radius: 12px; transition: border-color 200ms ease, box-shadow 200ms ease; }
        .game-card:hover { border-color: rgba(55,188,224,0.35); box-shadow: 0 0 12px rgba(55,188,224,0.12); }
        .game-cover { background: linear-gradient(180deg, rgba(55,188,224,0.10) 0%, rgba(26,35,50,0.6) 100%); border-bottom: 1px solid rgba(55,188,224,0.08); }

        .filter-btn { background-color: #1A2332; border: none; border-radius: 100px; color: #9AA7B8; padding: 6px 16px; font-size: 13px; font-weight: 600; }
        .filter-btn:hover { background-color: #232D3F; color: #E8EDF4; }
        .filter-btn:checked { background-color: rgba(55,188,224,0.18); color: #50E6E2; }

        .profile-card { background-color: #1A2332; border: 1px solid rgba(55,188,224,0.08); border-radius: 12px; padding: 14px 18px; transition: border-color 200ms ease; }
        .profile-card:hover { border-color: rgba(55,188,224,0.35); }
        .profile-card.active { border-color: #37BCE0; background-color: rgba(55,188,224,0.08); }
        .profile-info { color: #9AA7B8; font-size: 12px; }
        """
        nawaos_theme.apply_theme(self, css)
    
    def _make_brand_header(self):
        """Compact 2.0 brand block: logo mark + 'NawaOS' + version pill."""
        logo_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        logo_box.get_style_context().add_class("logo-box")

        brand_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        brand_row.set_halign(Gtk.Align.CENTER)
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_size(
                '/usr/share/pixmaps/nawaos-logo.png', 28, 28)
            brand_row.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        except Exception:
            pass  # logo mark is optional
        brand_label = Gtk.Label(label="NawaOS")
        brand_label.get_style_context().add_class("logo-text")
        brand_row.pack_start(brand_label, False, False, 0)
        badge = Gtk.Label(label=get_nawaos_version())
        badge.get_style_context().add_class("logo-badge")
        badge.set_valign(Gtk.Align.CENTER)
        brand_row.pack_start(badge, False, False, 0)
        logo_box.pack_start(brand_row, False, False, 0)

        app_label = Gtk.Label(label=_("Gaming Center"))
        app_label.get_style_context().add_class("logo-sub")
        logo_box.pack_start(app_label, False, False, 0)
        return logo_box

    def _make_nav_row(self, first_button, icon_name, label):
        """Sidebar row: 16px symbolic icon + clean text inside a pill."""
        btn = Gtk.RadioButton.new_from_widget(first_button)
        btn.set_mode(False)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.pack_start(
            Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU),
            False, False, 0)
        lbl = Gtk.Label(label=label)
        lbl.set_halign(Gtk.Align.START)
        row.pack_start(lbl, False, False, 0)
        btn.add(row)
        btn.get_style_context().add_class("sidebar-btn")
        return btn

    def create_sidebar(self):
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        sidebar.get_style_context().add_class("sidebar")
        sidebar.set_size_request(230, -1)
        sidebar.set_border_width(12)  # 12px outer padding around the rail

        sidebar.pack_start(self._make_brand_header(), False, False, 0)

        # Navigation (icons are standard symbolic names; they recolor with
        # the row's state automatically)
        nav_items = [
            ("go-home-symbolic", _("Dashboard"), "dashboard"),
            ("input-gaming-symbolic", _("My Games"), "library"),
            ("web-browser-symbolic", _("Open Source"), "opensource"),
            ("power-profile-performance-symbolic", _("Game Mode"), "gamemode"),
            ("system-users-symbolic", _("Profiles"), "profiles"),
            ("applications-utilities-symbolic", _("Tools"), "tools"),
            ("media-playback-start-symbolic", _("Launchers"), "launchers"),
            ("emblem-system-symbolic", _("Settings"), "settings"),
        ]

        first_button = None
        for icon_name, label, page in nav_items:
            btn = self._make_nav_row(first_button, icon_name, label)
            if first_button is None:
                first_button = btn
            btn.connect("toggled", self.on_nav_toggled, page)
            sidebar.pack_start(btn, False, False, 0)

        # Spacer
        sidebar.pack_start(Gtk.Box(), True, True, 0)

        # Quick status
        status_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        status_box.set_margin_start(10)
        status_box.set_margin_end(10)
        status_box.set_margin_bottom(10)

        self.gamemode_status = Gtk.Label()
        # Reflect the real state at startup (previously hardcoded to OFF even
        # when Game Mode was already active from a previous session).
        color, text = (("#4ADE80", _("ON")) if self.check_gamemode_status()
                       else ("#9AA7B8", _("OFF")))
        self.gamemode_status.set_markup(
            '<span size="small">%s: <span foreground="%s">%s</span></span>'
            % (GLib.markup_escape_text(_("Game Mode")), color,
               GLib.markup_escape_text(text)))
        self.gamemode_status.set_halign(Gtk.Align.START)
        status_box.pack_start(self.gamemode_status, False, False, 0)

        sidebar.pack_start(status_box, False, False, 0)

        self.main_box.pack_start(sidebar, False, False, 0)
    
    def on_nav_toggled(self, button, page):
        if button.get_active():
            self.content_stack.set_visible_child_name(page)

    def _page_header(self, title, subtitle=None):
        """2.0 page header: 25px/700 title + short brand-gradient underline."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        t = Gtk.Label(label=title)
        t.get_style_context().add_class("page-title")
        t.set_halign(Gtk.Align.START)
        box.pack_start(t, False, False, 0)
        bar = Gtk.Box()
        bar.get_style_context().add_class("title-underline")
        bar.set_size_request(48, 3)
        bar.set_halign(Gtk.Align.START)
        box.pack_start(bar, False, False, 0)
        if subtitle:
            s = Gtk.Label(label=subtitle)
            s.set_halign(Gtk.Align.START)
            s.get_style_context().add_class("page-subtitle")
            box.pack_start(s, False, False, 0)
        return box

    def _section_label(self, text, margin_top=0):
        """Uppercase letterspaced section label."""
        lbl = Gtk.Label(label=text.upper())
        lbl.get_style_context().add_class("section-label")
        lbl.set_halign(Gtk.Align.START)
        if margin_top:
            lbl.set_margin_top(margin_top)
        return lbl

    def create_dashboard_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.get_style_context().add_class("content-area")

        # Header
        page.pack_start(self._page_header(
            _("Dashboard"),
            _("Welcome to NawaOS Gaming Center")),
            False, False, 0)

        # Stats row
        stats_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        stats_box.set_homogeneous(True)

        # Check Game Mode status
        gamemode_enabled = self.check_gamemode_status()
        gamemode_text = _("Enabled") if gamemode_enabled else _("Disabled")
        gamemode_color = "#4ADE80" if gamemode_enabled else "#9AA7B8"
        protonge_installed = self.check_protonge() == "Installed"
        protonge_text = _("Installed") if protonge_installed else _("Not Installed")
        protonge_color = "#4ADE80" if protonge_installed else "#9AA7B8"

        # Numbers render in accent via .stat-value (28px/700 #37BCE0);
        # text statuses carry a semantic colour instead (never dark-on-dark).
        stats = [
            ("input-gaming-symbolic", "games", _("Games"), str(self.count_games()), None),
            ("system-users-symbolic", "profiles", _("Profiles"), str(len(self.profiles)), None),
            ("power-profile-performance-symbolic", "gamemode", _("Game Mode"), gamemode_text, gamemode_color),
            ("wine-symbolic", "protonge", "Proton-GE", protonge_text, protonge_color),
        ]

        for icon, key, label, value, color in stats:
            stat_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            stat_card.get_style_context().add_class("card")

            stat_card.pack_start(nawaos_theme.icon(icon, 32), False, False, 5)

            value_label = Gtk.Label()
            value_label.get_style_context().add_class("stat-value")
            if color:
                # Text statuses: semantic colour, scaled down from the 28px
                # .stat-value base so long values stay inside the tile.
                value_label.set_markup(
                    f'<span size="small" weight="bold" foreground="{color}">{value}</span>')
            else:
                value_label.set_text(value)
            stat_card.pack_start(value_label, False, False, 0)
            
            # Store references for cards that get updated later
            if key == "gamemode":
                self.dashboard_gamemode_label = value_label
            elif key == "games":
                # Updated by _start_game_scan once the async scan finishes.
                self.dashboard_games_label = value_label
            
            name_label = Gtk.Label(label=label)
            name_label.get_style_context().add_class("stat-label")
            stat_card.pack_start(name_label, False, False, 5)
            
            stats_box.pack_start(stat_card, True, True, 0)
        
        page.pack_start(stats_box, False, False, 10)
        
        # Quick actions -- one gradient primary per view, the rest ghost
        page.pack_start(self._section_label(_("Quick Actions"), margin_top=20),
                        False, False, 0)

        actions_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)

        quick_actions = [
            (_("Enable Game Mode"), self.on_quick_gamemode, "action-btn-primary"),
            (_("Install Proton-GE"), self.on_quick_protonge, "ghost-btn"),
            (_("Launch Steam"), self.on_launch_steam, "ghost-btn"),
        ]

        for label, callback, css_class in quick_actions:
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class(css_class)
            btn.connect("clicked", callback)
            actions_box.pack_start(btn, False, False, 0)
        
        page.pack_start(actions_box, False, False, 10)
        
        self.content_stack.add_named(page, "dashboard")
    
    def create_library_page(self):
        """Create professional game library page"""
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        # Header with search
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)

        header_box.pack_start(self._page_header(_("My Games")), False, False, 0)

        header_box.pack_start(Gtk.Box(), True, True, 0)  # Spacer

        # Search entry
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Search games…"))
        self.search_entry.get_style_context().add_class("nav-search")
        self.search_entry.set_size_request(250, -1)
        self.search_entry.set_valign(Gtk.Align.CENTER)
        self.search_entry.connect("search-changed", self.on_search_changed)
        header_box.pack_start(self.search_entry, False, False, 0)

        # Refresh button (ghost icon action)
        refresh_btn = Gtk.Button()
        refresh_btn.add(Gtk.Image.new_from_icon_name(
            "view-refresh-symbolic", Gtk.IconSize.MENU))
        refresh_btn.set_tooltip_text(_("Refresh Games"))
        refresh_btn.get_style_context().add_class("icon-btn")
        refresh_btn.set_valign(Gtk.Align.CENTER)
        refresh_btn.connect("clicked", self.on_refresh_games)
        header_box.pack_start(refresh_btn, False, False, 0)

        page.pack_start(header_box, False, False, 0)

        # Filter buttons
        filter_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)

        filters = [(_("All"), "all"), ("Steam", "steam"),
                   ("Lutris", "lutris"), ("Flatpak", "flatpak")]
        self.filter_buttons = []
        first_btn = None
        for label, filter_id in filters:
            btn = Gtk.RadioButton.new_with_label_from_widget(first_btn, label)
            if first_btn is None:
                first_btn = btn
            btn.set_mode(False)
            btn.get_style_context().add_class("filter-btn")
            btn.connect("toggled", self.on_filter_changed, filter_id)
            filter_box.pack_start(btn, False, False, 0)
            self.filter_buttons.append(btn)
        
        page.pack_start(filter_box, False, False, 0)
        
        # Games grid in scrolled window
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        self.games_flowbox = Gtk.FlowBox()
        self.games_flowbox.set_valign(Gtk.Align.START)
        self.games_flowbox.set_max_children_per_line(4)
        self.games_flowbox.set_min_children_per_line(2)
        self.games_flowbox.set_selection_mode(Gtk.SelectionMode.NONE)
        self.games_flowbox.set_homogeneous(True)
        self.games_flowbox.set_row_spacing(20)
        self.games_flowbox.set_column_spacing(20)
        
        scroll.add(self.games_flowbox)
        page.pack_start(scroll, True, True, 0)
        
        self.content_stack.add_named(page, "library")
        
        # Populate games after UI is ready
        GLib.idle_add(self.populate_games)
    
    def create_game_card(self, game):
        """Create a professional game card widget"""
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        card.get_style_context().add_class("game-card")
        card.set_size_request(180, 240)
        
        # Game cover placeholder
        cover_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        cover_box.get_style_context().add_class("game-cover")
        cover_box.set_size_request(180, 160)
        
        # Icon as placeholder
        icon = nawaos_theme.icon(game.icon or (), 72)
        icon.set_vexpand(True)
        icon.set_valign(Gtk.Align.CENTER)
        cover_box.pack_start(icon, True, True, 0)
        
        # Source badge (accent-tint pill)
        source_label = Gtk.Label(label=game.source.upper())
        source_label.get_style_context().add_class("pill-badge")
        source_label.set_halign(Gtk.Align.END)
        source_label.set_margin_end(8)
        source_label.set_margin_top(8)
        cover_box.pack_start(source_label, False, False, 0)
        
        card.pack_start(cover_box, False, False, 0)
        
        # Info section
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        info_box.get_style_context().add_class("game-info")
        info_box.set_margin_start(12)
        info_box.set_margin_end(12)
        info_box.set_margin_top(10)
        info_box.set_margin_bottom(10)
        
        # Game title -- escape the name: it comes from Steam .acf manifests,
        # the Lutris DB, flatpak output and .desktop files, so a name with '&'
        # ("Ratchet & Clank") or '<' would break Pango markup, and a crafted
        # .desktop Name= could inject span attributes.
        title_label = Gtk.Label()
        title_label.set_markup(f'<span weight="bold" foreground="#E8EDF4">{GLib.markup_escape_text(game.name[:25])}</span>')
        title_label.set_halign(Gtk.Align.START)
        title_label.set_ellipsize(Pango.EllipsizeMode.END)
        title_label.set_max_width_chars(20)
        info_box.pack_start(title_label, False, False, 0)

        # Play button
        play_btn = Gtk.Button(label=_("Play"))
        play_btn.get_style_context().add_class("play-btn")
        play_btn.connect("clicked", self.on_play_game, game)
        info_box.pack_start(play_btn, False, False, 5)
        
        card.pack_start(info_box, False, False, 0)
        
        return card
    
    def populate_games(self, filter_type="all", search_text=""):
        """Populate games grid"""
        # Clear existing
        for child in self.games_flowbox.get_children():
            self.games_flowbox.remove(child)
        
        # Never scan inline here (it would block the GTK main loop); the scan
        # runs on a worker thread that sets self.games and re-invokes us.
        games = getattr(self, 'games', [])
        
        for game in games:
            # Apply filter
            if filter_type != "all" and game.source != filter_type:
                continue
            # Apply search
            if search_text and search_text.lower() not in game.name.lower():
                continue
            
            card = self.create_game_card(game)
            self.games_flowbox.add(card)
        
        self.games_flowbox.show_all()
        
        # Show empty state if no games
        if len(self.games_flowbox.get_children()) == 0:
            empty_label = Gtk.Label()
            empty_label.set_markup(
                '<span size="large" foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(
                    _("No games found. Install Steam, Lutris, or Flatpak games!")))
            self.games_flowbox.add(empty_label)
            self.games_flowbox.show_all()
    
    def on_search_changed(self, entry):
        self.current_filter = getattr(self, 'current_filter', 'all')
        self.populate_games(self.current_filter, entry.get_text())
    
    def on_filter_changed(self, button, filter_type):
        if button.get_active():
            self.current_filter = filter_type
            search_text = self.search_entry.get_text() if hasattr(self, 'search_entry') else ""
            self.populate_games(filter_type, search_text)
    
    def on_refresh_games(self, button):
        # Rescan on a worker thread so refresh never freezes the UI.
        self._start_game_scan()
        self.show_notification(_("Refreshing games..."))
    
    def on_play_game(self, button, game):
        game.launch()
        self.show_notification(_("Launching %s...") % game.name)
    
    def create_gamemode_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(
            _("Game Mode"),
            _("Optimize your system for maximum gaming performance")),
            False, False, 0)

        # Game Mode Card
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        card.get_style_context().add_class("card")

        # Status
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        status_label = Gtk.Label()
        status_label.set_markup(
            '<span size="large" weight="bold" foreground="#E8EDF4">%s</span>'
            % GLib.markup_escape_text(_("Status:")))
        status_box.pack_start(status_label, False, False, 0)

        # Real state from /run/nawaos/gamemode-state (it always read
        # "Disabled" before, even with Game Mode on).
        self.gamemode_status_label = Gtk.Label()
        color, text = (("#4ADE80", _("✓ Enabled")) if self.check_gamemode_status()
                       else ("#9AA7B8", _("Disabled")))
        self.gamemode_status_label.set_markup(
            '<span size="large" foreground="%s"> %s</span>'
            % (color, GLib.markup_escape_text(text)))
        self.gamemode_status_label.set_margin_start(10)
        status_box.pack_start(self.gamemode_status_label, False, False, 0)
        card.pack_start(status_box, False, False, 0)

        # Features list
        features = [
            _("CPU Governor → Performance mode"),
            _("Swappiness → Reduced to 10"),
            _("Network → Low latency mode"),
            _("Compositor → Disabled (optional)"),
            _("Mouse → Raw input mode"),
        ]

        for feature in features:
            feat_label = Gtk.Label(label=feature)
            feat_label.set_halign(Gtk.Align.START)
            feat_label.get_style_context().add_class("card-desc")
            card.pack_start(feat_label, False, False, 2)

        # Buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        btn_box.set_margin_top(15)

        enable_btn = Gtk.Button(label=_("Enable Game Mode"))
        enable_btn.get_style_context().add_class("action-btn-primary")
        enable_btn.connect("clicked", self.on_enable_gamemode)
        btn_box.pack_start(enable_btn, False, False, 0)

        disable_btn = Gtk.Button(label=_("Disable Game Mode"))
        disable_btn.get_style_context().add_class("ghost-btn")
        disable_btn.connect("clicked", self.on_disable_gamemode)
        btn_box.pack_start(disable_btn, False, False, 0)
        
        card.pack_start(btn_box, False, False, 0)
        page.pack_start(card, False, False, 0)
        
        self.content_stack.add_named(page, "gamemode")
    
    def create_profiles_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.get_style_context().add_class("content-area")
        
        # Header with Add button
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)

        header_box.pack_start(self._page_header(
            _("Game Profiles"),
            _("Create custom optimization profiles for different games")),
            False, False, 0)

        header_box.pack_start(Gtk.Box(), True, True, 0)  # Spacer

        add_btn = Gtk.Button(label=_("New Profile"))
        add_btn.get_style_context().add_class("action-btn-primary")
        add_btn.set_valign(Gtk.Align.CENTER)
        add_btn.connect("clicked", self.on_add_profile)
        header_box.pack_start(add_btn, False, False, 0)

        page.pack_start(header_box, False, False, 0)
        
        # Profiles list
        self.profiles_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.refresh_profiles_list()
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.add(self.profiles_box)
        page.pack_start(scroll, True, True, 0)
        
        self.content_stack.add_named(page, "profiles")
    
    def refresh_profiles_list(self):
        # Clear existing
        for child in self.profiles_box.get_children():
            self.profiles_box.remove(child)
        
        if not self.profiles:
            empty_label = Gtk.Label(
                label=_("No profiles yet. Click 'New Profile' to create one!"))
            empty_label.get_style_context().add_class("card-desc")
            self.profiles_box.pack_start(empty_label, False, False, 20)
        else:
            for profile in self.profiles:
                card = self.create_profile_card(profile)
                self.profiles_box.pack_start(card, False, False, 0)
        
        self.profiles_box.show_all()
    
    def create_profile_card(self, profile):
        card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        card.get_style_context().add_class("profile-card")
        if self.current_profile and self.current_profile.name == profile.name:
            card.get_style_context().add_class("active")
        
        # Info
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        
        name_label = Gtk.Label()
        # Escape: profile names are free-form user text from the profile dialog.
        name_label.set_markup(f'<span weight="bold" foreground="#E8EDF4">{GLib.markup_escape_text(profile.name)}</span>')
        name_label.set_halign(Gtk.Align.START)
        info_box.pack_start(name_label, False, False, 0)
        
        details = _("CPU: %s | Swap: %s") % (profile.cpu_governor, profile.swappiness)
        details_label = Gtk.Label(label=details)
        details_label.set_halign(Gtk.Align.START)
        details_label.get_style_context().add_class("profile-info")
        info_box.pack_start(details_label, False, False, 0)
        
        card.pack_start(info_box, True, True, 0)
        
        # Row actions: ghost icon buttons (symbolic icons follow row colours)
        def _icon_button(icon_name, tooltip, css_class="icon-btn"):
            b = Gtk.Button()
            b.add(Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU))
            b.set_tooltip_text(tooltip)
            b.get_style_context().add_class(css_class)
            b.set_valign(Gtk.Align.CENTER)
            return b

        activate_btn = _icon_button("media-playback-start-symbolic",
                                    _("Activate Profile"))
        activate_btn.connect("clicked", self.on_activate_profile, profile)
        card.pack_start(activate_btn, False, False, 0)

        edit_btn = _icon_button("document-edit-symbolic", _("Edit Profile"))
        edit_btn.connect("clicked", self.on_edit_profile, profile)
        card.pack_start(edit_btn, False, False, 0)

        delete_btn = _icon_button("user-trash-symbolic", _("Delete Profile"),
                                  "ghost-danger")
        delete_btn.connect("clicked", self.on_delete_profile, profile)
        card.pack_start(delete_btn, False, False, 0)
        
        return card
    
    def create_launchers_page(self):
        """Create professional Game Launchers page with beautiful cards"""
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        # Header
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)

        header = self._page_header(
            _("Game Launchers"),
            _("Launch your favorite gaming platforms with one click"))
        title_box.pack_start(header, True, True, 0)

        # Quick stats (accent-tint pill badge)
        stats_label = Gtk.Label(label=_("9 platforms"))
        stats_label.get_style_context().add_class("pill-badge")
        stats_label.set_valign(Gtk.Align.START)
        title_box.pack_end(stats_label, False, False, 0)

        page.pack_start(title_box, False, False, 0)
        
        # Scrollable content
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=25)
        content_box.set_margin_top(15)
        
        # Category: Main Platforms
        content_box.pack_start(self._section_label(_("Main Platforms")), False, False, 0)

        main_grid = Gtk.Grid()
        main_grid.set_column_spacing(20)
        main_grid.set_row_spacing(20)
        main_grid.set_column_homogeneous(True)

        main_launchers = [
            ("Steam", "steam",
             _("Official Steam client for thousands of games"), ("steam", "input-gaming-symbolic")),
            ("Lutris", "lutris",
             _("Open gaming platform for all your games"), ("lutris", "wine-symbolic")),
            ("Heroic", "flatpak run com.heroicgameslauncher.hgl",
             _("Play Epic Games, GOG and Amazon Prime Games"), ("com.heroicgameslauncher.hgl", "applications-games-symbolic")),
        ]

        for i, (name, cmd, desc, icon) in enumerate(main_launchers):
            card = self._create_launcher_card(name, cmd, desc, icon, True)
            main_grid.attach(card, i, 0, 1, 1)

        content_box.pack_start(main_grid, False, False, 0)

        # Category: Emulators & Retro
        content_box.pack_start(self._section_label(_("Emulators & Retro Gaming"), 10),
                               False, False, 0)

        emu_grid = Gtk.Grid()
        emu_grid.set_column_spacing(20)
        emu_grid.set_row_spacing(20)
        emu_grid.set_column_homogeneous(True)

        emu_launchers = [
            ("RetroArch", "retroarch", _("All-in-one retro game emulator"), ("retroarch", "input-gaming-symbolic")),
            ("DOSBox", "dosbox", _("Classic DOS game emulator"), ("dosbox", "input-gaming-symbolic")),
        ]

        for i, (name, cmd, desc, icon) in enumerate(emu_launchers):
            card = self._create_launcher_card(name, cmd, desc, icon, False)
            emu_grid.attach(card, i, 0, 1, 1)

        content_box.pack_start(emu_grid, False, False, 0)

        # Category: Wine & Windows
        content_box.pack_start(self._section_label(_("Windows Gaming (Wine)"), 10),
                               False, False, 0)

        wine_grid = Gtk.Grid()
        wine_grid.set_column_spacing(20)
        wine_grid.set_row_spacing(20)
        wine_grid.set_column_homogeneous(True)

        wine_launchers = [
            ("Bottles", "flatpak run com.usebottles.bottles",
             _("Modern Wine manager with sandboxing"), ("com.usebottles.bottles", "wine-symbolic")),
            ("ProtonUp-Qt", "flatpak run net.davidotek.pupgui2",
             _("Manage Proton-GE and Wine-GE"), ("net.davidotek.pupgui2", "software-update-available-symbolic")),
        ]

        for i, (name, cmd, desc, icon) in enumerate(wine_launchers):
            card = self._create_launcher_card(name, cmd, desc, icon, False)
            wine_grid.attach(card, i, 0, 1, 1)

        content_box.pack_start(wine_grid, False, False, 0)

        # Category: Tools
        content_box.pack_start(self._section_label(_("Gaming Tools"), 10),
                               False, False, 0)

        tools_grid = Gtk.Grid()
        tools_grid.set_column_spacing(20)
        tools_grid.set_row_spacing(20)
        tools_grid.set_column_homogeneous(True)

        tools_launchers = [
            ("GameScope", "gamescope",
             _("Valve gaming compositor for better performance"), ("gamescope", "view-fullscreen-symbolic")),
            ("CoreCtrl", "corectrl", _("AMD GPU overclocking and control"), ("corectrl", "multimedia-equalizer-symbolic")),
            ("AntiMicroX", "antimicrox", _("Map controller to keyboard/mouse"), ("io.github.antimicrox.antimicrox", "input-gaming-symbolic")),
        ]

        for i, (name, cmd, desc, icon) in enumerate(tools_launchers):
            card = self._create_launcher_card(name, cmd, desc, icon, False)
            tools_grid.attach(card, i, 0, 1, 1)

        content_box.pack_start(tools_grid, False, False, 0)
        
        scroll.add(content_box)
        page.pack_start(scroll, True, True, 0)
        
        self.content_stack.add_named(page, "launchers")
    
    def _create_launcher_card(self, name, cmd, desc, icon, is_main=False):
        """Create a beautiful launcher card"""
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.get_style_context().add_class("card")
        if is_main:
            card.set_size_request(280, 160)
        else:
            card.set_size_request(250, 140)
        
        # Top section with colored icon
        top_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        top_box.set_margin_start(15)
        top_box.set_margin_top(15)
        
        top_box.pack_start(nawaos_theme.icon(icon, 48 if is_main else 40),
                           False, False, 0)
        
        # Name and description
        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        
        name_label = Gtk.Label()
        if is_main:
            name_label.set_markup(f'<span weight="bold" foreground="#E8EDF4" size="large">{name}</span>')
        else:
            name_label.set_markup(f'<span weight="bold" foreground="#E8EDF4">{name}</span>')
        name_label.set_halign(Gtk.Align.START)
        text_box.pack_start(name_label, False, False, 0)
        
        desc_label = Gtk.Label(label=desc)
        desc_label.get_style_context().add_class("card-desc")
        desc_label.set_halign(Gtk.Align.START)
        desc_label.set_line_wrap(True)
        desc_label.set_max_width_chars(30)
        text_box.pack_start(desc_label, False, False, 0)
        
        top_box.pack_start(text_box, True, True, 0)
        card.pack_start(top_box, True, True, 0)
        
        # Launch button
        btn_box = Gtk.Box()
        btn_box.set_margin_start(15)
        btn_box.set_margin_end(15)
        btn_box.set_margin_bottom(12)
        
        launch_btn = Gtk.Button(label=_("Launch %s") % name)
        launch_btn.get_style_context().add_class("tint-btn")
        launch_btn.connect("clicked", self.on_launch_app, cmd, name)
        btn_box.pack_start(launch_btn, True, True, 0)
        
        card.pack_start(btn_box, False, False, 0)
        
        return card
    
    def create_opensource_games_page(self):
        """Create Open Source Games page with GitHub games"""
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        # Header
        page.pack_start(self._page_header(
            _("Open Source Games"),
            _("Free and open source games from GitHub - Download and play!")),
            False, False, 0)
        
        # Scrollable content
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        games_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        games_box.set_margin_top(10)
        
        # Curated list of popular open source games
        opensource_games = [
            {
                'name': '0 A.D.',
                'desc': _('A free, open-source RTS game of ancient warfare'),
                'github': 'https://github.com/0ad/0ad',
                'website': 'https://play0ad.com/',
                'install_cmd': 'sudo apt install -y 0ad',
                'launch_cmd': '0ad',
                'check_cmd': 'which 0ad',
                'icon': '0ad',
                'category': _('Strategy')
            },
            {
                'name': 'SuperTuxKart',
                'desc': _('A free kart racing game with Tux and friends'),
                'github': 'https://github.com/supertuxkart/stk-code',
                'website': 'https://supertuxkart.net/',
                'install_cmd': 'sudo apt install -y supertuxkart',
                'launch_cmd': 'supertuxkart',
                'check_cmd': 'which supertuxkart',
                'icon': 'supertuxkart',
                'category': _('Racing')
            },
            {
                'name': 'Veloren',
                'desc': _('Multiplayer voxel RPG inspired by games such as Cube World'),
                'github': 'https://github.com/veloren/veloren',
                'website': 'https://veloren.net/',
                'install_cmd': 'flatpak install -y flathub net.veloren.veloren',
                'launch_cmd': 'flatpak run net.veloren.veloren',
                'check_cmd': 'flatpak info net.veloren.veloren',
                'icon': 'net.veloren.veloren',
                'category': _('RPG')
            },
            {
                'name': 'Xonotic',
                'desc': _('Fast-paced arena shooter, fork of Nexuiz'),
                'github': 'https://github.com/xonotic/xonotic',
                'website': 'https://xonotic.org/',
                'install_cmd': 'sudo apt install -y xonotic',
                'launch_cmd': 'xonotic-glx',
                'check_cmd': 'which xonotic-glx',
                'icon': 'xonotic',
                'category': _('FPS')
            },
            {
                'name': 'OpenMW',
                'desc': _('Open-source engine for TES III: Morrowind'),
                'github': 'https://github.com/OpenMW/openmw',
                'website': 'https://openmw.org/',
                'install_cmd': 'sudo apt install -y openmw',
                'launch_cmd': 'openmw-launcher',
                'check_cmd': 'which openmw-launcher',
                'icon': 'openmw',
                'category': _('RPG')
            },
            {
                'name': 'Minetest',
                'desc': _('Open source voxel game engine - Minecraft alternative'),
                'github': 'https://github.com/minetest/minetest',
                'website': 'https://www.minetest.net/',
                'install_cmd': 'sudo apt install -y minetest',
                'launch_cmd': 'minetest',
                'check_cmd': 'which minetest',
                'icon': 'minetest',
                'category': _('Sandbox')
            },
            {
                'name': 'Battle for Wesnoth',
                'desc': _('Turn-based strategy game with fantasy theme'),
                'github': 'https://github.com/wesnoth/wesnoth',
                'website': 'https://www.wesnoth.org/',
                'install_cmd': 'sudo apt install -y wesnoth',
                'launch_cmd': 'wesnoth',
                'check_cmd': 'which wesnoth',
                'icon': 'wesnoth',
                'category': _('Strategy')
            },
            {
                'name': 'OpenRA',
                'desc': _('Classic RTS games rebuilt for the modern era'),
                'github': 'https://github.com/OpenRA/OpenRA',
                'website': 'https://www.openra.net/',
                'install_cmd': 'flatpak install -y flathub net.openra.OpenRA',
                'launch_cmd': 'flatpak run net.openra.OpenRA',
                'check_cmd': 'flatpak info net.openra.OpenRA',
                'icon': 'net.openra.OpenRA',
                'category': _('Strategy')
            },
            {
                'name': 'Endless Sky',
                'desc': _('Space exploration and combat game'),
                'github': 'https://github.com/endless-sky/endless-sky',
                'website': 'https://endless-sky.github.io/',
                'install_cmd': 'sudo apt install -y endless-sky',
                'launch_cmd': 'endless-sky',
                'check_cmd': 'which endless-sky',
                'icon': 'endless-sky',
                'category': _('Space')
            },
            {
                'name': 'FreeCiv',
                'desc': _('Free and open implementation of Civilization'),
                'github': 'https://github.com/freeciv/freeciv',
                'website': 'https://www.freeciv.org/',
                'install_cmd': 'sudo apt install -y freeciv',
                'launch_cmd': 'freeciv-gtk3',
                'check_cmd': 'which freeciv-gtk3',
                'icon': 'freeciv-client',
                'category': _('Strategy')
            },
            {
                'name': 'OpenTTD',
                'desc': _('Open source transport business simulation'),
                'github': 'https://github.com/OpenTTD/OpenTTD',
                'website': 'https://www.openttd.org/',
                'install_cmd': 'sudo apt install -y openttd',
                'launch_cmd': 'openttd',
                'check_cmd': 'which openttd',
                'icon': 'openttd',
                'category': _('Simulation')
            },
            {
                'name': 'Cataclysm: DDA',
                'desc': _('Turn-based survival game set in a post-apocalyptic world'),
                'github': 'https://github.com/CleverRaven/Cataclysm-DDA',
                'website': 'https://cataclysmdda.org/',
                'install_cmd': 'flatpak install -y flathub org.cataclysmdda.CataclysmDDA',
                'launch_cmd': 'flatpak run org.cataclysmdda.CataclysmDDA',
                'check_cmd': 'flatpak info org.cataclysmdda.CataclysmDDA',
                'icon': 'cataclysm-dda',
                'category': _('Roguelike')
            },
            {
                'name': 'Warzone 2100',
                'desc': _('Real-time strategy game originally by Pumpkin Studios'),
                'github': 'https://github.com/Warzone2100/warzone2100',
                'website': 'https://wz2100.net/',
                'install_cmd': 'sudo apt install -y warzone2100',
                'launch_cmd': 'warzone2100',
                'check_cmd': 'which warzone2100',
                'icon': 'warzone2100',
                'category': _('Strategy')
            },
            {
                'name': 'Teeworlds',
                'desc': _('2D retro multiplayer shooter'),
                'github': 'https://github.com/teeworlds/teeworlds',
                'website': 'https://www.teeworlds.com/',
                'install_cmd': 'sudo apt install -y teeworlds',
                'launch_cmd': 'teeworlds',
                'check_cmd': 'which teeworlds',
                'icon': 'teeworlds',
                'category': _('Shooter')
            },
            {
                'name': 'DDNet',
                'desc': _('DDraceNetwork - Cooperative 2D platformer'),
                'github': 'https://github.com/ddnet/ddnet',
                'website': 'https://ddnet.org/',
                'install_cmd': 'flatpak install -y flathub org.ddnet.DDNet',
                'launch_cmd': 'flatpak run org.ddnet.DDNet',
                'check_cmd': 'flatpak info org.ddnet.DDNet',
                'icon': 'teeworlds',
                'category': _('Platformer')
            },
        ]
        
        for game in opensource_games:
            card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
            card.get_style_context().add_class("card")
            
            # Icon
            card.pack_start(nawaos_theme.icon(game["icon"], 48), False, False, 0)
            
            # Info
            info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            
            # Name and category
            name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            name_label = Gtk.Label()
            name_label.set_markup(f'<span size="large" weight="bold" foreground="#E8EDF4">{game["name"]}</span>')
            name_label.set_halign(Gtk.Align.START)
            name_box.pack_start(name_label, False, False, 0)

            cat_label = Gtk.Label(label=game["category"])
            cat_label.get_style_context().add_class("pill-badge")
            cat_label.set_valign(Gtk.Align.CENTER)
            name_box.pack_start(cat_label, False, False, 0)
            
            info_box.pack_start(name_box, False, False, 0)
            
            # Description
            desc_label = Gtk.Label(label=game['desc'])
            desc_label.set_halign(Gtk.Align.START)
            desc_label.get_style_context().add_class("card-desc")
            info_box.pack_start(desc_label, False, False, 0)
            
            card.pack_start(info_box, True, True, 0)
            
            # Action buttons
            btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            
            # Default to Install button (check async later)
            install_btn = Gtk.Button(label=_("Install"))
            install_btn.get_style_context().add_class("tint-btn")
            install_btn.connect("clicked", self.on_install_opensource, game['install_cmd'], game['name'], game.get('launch_cmd', ''))
            btn_box.pack_start(install_btn, False, False, 0)
            
            # Schedule async check for installed status
            launch_cmd = game.get('launch_cmd', '')
            check_cmd = game.get('check_cmd', '')
            if check_cmd and launch_cmd:
                threading.Thread(
                    target=self._async_check_installed,
                    args=(install_btn, check_cmd, launch_cmd, game['name']),
                    daemon=True
                ).start()
            
            # GitHub button (ghost secondary)
            github_btn = Gtk.Button(label="GitHub")
            github_btn.get_style_context().add_class("ghost-btn")
            github_btn.connect("clicked", self.on_open_url, game['github'])
            btn_box.pack_start(github_btn, False, False, 0)

            # Website button (ghost icon)
            web_btn = Gtk.Button()
            web_btn.add(Gtk.Image.new_from_icon_name(
                "web-browser-symbolic", Gtk.IconSize.MENU))
            web_btn.get_style_context().add_class("icon-btn")
            web_btn.set_tooltip_text(_("Open Website"))
            web_btn.connect("clicked", self.on_open_url, game['website'])
            btn_box.pack_start(web_btn, False, False, 0)
            
            card.pack_start(btn_box, False, False, 0)
            games_box.pack_start(card, False, False, 0)
        
        scroll.add(games_box)
        page.pack_start(scroll, True, True, 0)
        
        self.content_stack.add_named(page, "opensource")
    
    def check_internet_connection(self):
        """Check if internet is available (TCP to Flathub:443).

        Uses a socket connect rather than ICMP ping so it also works on
        networks that block ping. MUST be called off the GTK main loop
        (it can block up to the timeout).
        """
        try:
            socket.create_connection(("flathub.org", 443), timeout=4).close()
            return True
        except OSError:
            return False
    
    def on_install_opensource(self, button, cmd, name, launch_cmd=None):
        """Install open source game with internet check and progress indicator"""

        # Save original button state
        original_label = button.get_label()

        # Show installing state with spinner
        button.set_sensitive(False)
        button.set_label(_("Installing…"))
        button.get_style_context().add_class("installing")

        def install_thread():
            # Connectivity check runs HERE, off the GTK main loop, so an
            # offline / captive-portal network can't freeze the UI.
            if not self.check_internet_connection():
                GLib.idle_add(self._restore_button, button, original_label)
                GLib.idle_add(self.show_notification,
                              _("No internet connection! Cannot install %s.") % name)
                return
            # The install command is data from the games table ("sudo apt
            # install -y pkg" or "flatpak install -y flathub id"): split it
            # into argv; a leading sudo means "run as root" (pkexec).
            argv = shlex.split(cmd)
            root = bool(argv) and argv[0] == 'sudo'
            if root:
                argv = argv[1:]

            def done(state, _rc):
                # The task dialog reports the real exit status, so a failed
                # or cancelled install does NOT flip the button to Play.
                if state == "success" and launch_cmd:
                    self._update_button_to_play(button, name, launch_cmd)
                else:
                    self._restore_button(button, original_label)

            GLib.idle_add(lambda: (self._run_task(_("Install %s") % name, argv,
                                                  root=root, on_done=done), False)[1])

        thread = threading.Thread(target=install_thread)
        thread.daemon = True
        thread.start()
    
    def _restore_button(self, button, original_label):
        """Restore button to original state"""
        button.set_sensitive(True)
        button.set_label(original_label)
        button.get_style_context().remove_class("installing")
    
    def _update_button_to_play(self, button, name, launch_cmd):
        """Update Install button to Play button"""
        button.set_sensitive(True)
        button.set_label(_("Play"))
        button.get_style_context().remove_class("tint-btn")
        button.get_style_context().remove_class("installing")
        button.get_style_context().add_class("play-btn")
        
        # Disconnect old handler and connect new one
        try:
            button.disconnect_by_func(self.on_install_opensource)
        except:
            pass
        button.connect("clicked", self.on_launch_opensource_game, launch_cmd, name)
        self.show_notification(_("%s installed successfully!") % name)
    
    def on_launch_opensource_game(self, button, cmd, name):
        """Launch an installed open source game"""
        try:
            subprocess.Popen(cmd, shell=True)
            self.show_notification(_("Launching %s...") % name)
        except Exception as e:
            self.show_notification(_("Error launching: %s") % str(e))
    
    def _async_check_installed(self, button, check_cmd, launch_cmd, name):
        """Check if a game is installed in background thread and update button"""
        try:
            result = subprocess.run(check_cmd, shell=True, capture_output=True, timeout=5)
            if result.returncode == 0:
                GLib.idle_add(self._update_button_to_play, button, name, launch_cmd)
        except:
            pass
    
    def is_game_installed(self, check_cmd):
        """Check if a game is installed"""
        try:
            result = subprocess.run(check_cmd, shell=True, capture_output=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    
    def on_open_url(self, button, url):
        """Open URL in browser"""
        try:
            subprocess.Popen(['xdg-open', url])
        except:
            pass
    
    def create_tools_page(self):
        """Create advanced gaming tools page"""
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        # Header
        page.pack_start(self._page_header(
            _("Advanced Tools"),
            _("Powerful gaming tools to optimize your experience")),
            False, False, 0)
        
        # Scrollable content
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        tools_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        tools_box.set_margin_top(10)
        
        # Tool cards data. Buttons are structured specs executed by
        # on_run_tool -- no shell strings are re-parsed and nothing runs with
        # shell=True:
        #   {'label': ..., 'argv': [...],           # exec argv, data stays data
        #    'needs_root': bool,                    # run as root (pkexec)
        #    'needs_terminal': bool}                # show its output while it runs
        # Root tasks and tasks with output run in the in-app task dialog
        # (nawaos_taskrunner, 2.2); the rest are launched detached.
        # or {'label': ..., 'callback': handler} for tools with special logic.
        # System tools (drivers, updates, snapshots, mounts, battery, system
        # info) live in the Control Panel since 2.2: see the last card.
        tools = [
            {
                'icon': 'video-display-symbolic',
                'title': _('GameScope Session'),
                'desc': _('Console-style full-screen gaming compositor with VRR, FSR, and HDR'),
                # The old "Configure" button edited /etc/nawaos/gamescope.conf,
                # a file nothing creates or reads -- removed as dead UI.
                'buttons': [
                    {'label': _('Start Session'), 'argv': ['nawaos-gamescope-session']},
                ],
            },
            {
                'icon': 'preferences-color-symbolic',
                'title': _('HDR Gaming'),
                'desc': _('High Dynamic Range support for Vulkan and DirectX games'),
                'buttons': [
                    {'label': _('Check HDR'), 'argv': ['/usr/local/bin/nawaos-hdr-check'],
                     'needs_terminal': True},
                    {'label': _('Enable HDR'), 'argv': ['/usr/local/bin/nawaos-hdr-check', 'enable'],
                     'needs_terminal': True},
                ],
            },
            {
                'icon': 'focus-windows-symbolic',
                'title': _('Wayland Gaming'),
                'desc': _('Modern display session with XWayland compatibility for all games'),
                'buttons': [
                    {'label': _('Session Info'), 'argv': ['/usr/local/bin/nawaos-wayland-info'],
                     'needs_terminal': True},
                ],
            },
            {
                'icon': 'software-update-available-symbolic',
                'title': _('Proton-GE Auto Updater'),
                'desc': _('Automatic daily updates for the latest Proton-GE compatibility layer'),
                'buttons': [
                    {'label': _('Enable Timer'),
                     'argv': ['/usr/local/bin/nawaos-protonge-updater', '--enable-auto'],
                     'needs_terminal': True},
                    {'label': _('Update Now'), 'argv': ['/usr/local/bin/nawaos-protonge-updater'],
                     'needs_terminal': True},
                    {'label': _('Status'),
                     'argv': ['systemctl', '--user', 'status',
                              'nawaos-protonge-updater.timer', '--no-pager'],
                     'needs_terminal': True},
                ],
            },
            {
                'icon': 'package-x-generic-symbolic',
                'title': _('Gaming Meta Package'),
                'desc': _('One-click installation of Steam, Lutris, Wine, MangoHud, GameMode, and more'),
                'buttons': [
                    {'label': _('Full Setup'), 'argv': ['/usr/local/bin/nawaos-gaming-meta', '--full'],
                     'needs_root': True},
                    {'label': _('Minimal'), 'argv': ['/usr/local/bin/nawaos-gaming-meta', '--minimal'],
                     'needs_root': True},
                ],
            },
            {
                'icon': 'power-profile-performance-symbolic',
                'title': _('Game Performance Mode'),
                'desc': _('Toggle CPU/GPU/I/O optimizations for maximum gaming performance'),
                # Route through the main Game Mode handlers so the state file,
                # session-side compositor toggle, and every status widget stay
                # in sync (the old entries also pointed at a nonexistent
                # /usr/local/bin/nawaos-game-mode path -- the deployed name is
                # nawaos-gamemode).
                'buttons': [
                    {'label': _('Enable'), 'callback': self.on_enable_gamemode},
                    {'label': _('Disable'), 'callback': self.on_disable_gamemode},
                    {'label': _('Toggle'), 'callback': self.on_toggle_gamemode},
                ],
            },
            {
                'icon': 'image-x-generic-symbolic',
                'title': _('vkBasalt &amp; GOverlay'),
                'desc': _('FSR-like sharpening and post-processing effects for Vulkan games'),
                'buttons': [
                    {'label': _('Install vkBasalt'),
                     'argv': ['/usr/local/bin/nawaos-vkbasalt-installer'],
                     'needs_root': True, 'needs_terminal': True},
                    {'label': _('GOverlay'), 'callback': self.on_goverlay},
                ],
            },
            {
                'icon': 'input-gaming-symbolic',
                'title': _('Handheld / Steam Deck Tools'),
                'desc': _('Support for Steam Deck, ROG Ally, Legion Go and other handhelds'),
                'buttons': [
                    {'label': _('Install Tools'),
                     'argv': ['/usr/local/bin/nawaos-handheld-tools', 'install'],
                     'needs_root': True, 'needs_terminal': True},
                    {'label': _('GameScope'),
                     'argv': ['gamescope', '-e', '--', 'steam', '-gamepadui']},
                ],
            },
            {
                'icon': 'audio-speakers-symbolic',
                'title': _('PipeWire Gaming Audio'),
                'desc': _('Low-latency audio presets for gaming and music production'),
                'buttons': [
                    {'label': _('Gaming Mode'),
                     'argv': ['/usr/local/bin/nawaos-pipewire-preset', 'gaming']},
                    {'label': _('Music Mode'),
                     'argv': ['/usr/local/bin/nawaos-pipewire-preset', 'music']},
                    {'label': _('Default'),
                     'argv': ['/usr/local/bin/nawaos-pipewire-preset', 'default']},
                ],
            },
            {
                'icon': 'chat-message-new-symbolic',
                'title': _('Discord Wayland Fix'),
                'desc': _('Fix screen sharing on Wayland desktop'),
                'buttons': [
                    {'label': _('Apply Fix'), 'argv': ['/usr/local/bin/nawaos-discord-fix', 'fix'],
                     'needs_terminal': True},
                ],
            },
            {
                'icon': 'bluetooth-active-symbolic',
                'title': _('Bluetooth Controller'),
                'desc': _('Setup Xbox, PlayStation, Nintendo controllers'),
                'buttons': [
                    {'label': _('Install'),
                     'argv': ['/usr/local/bin/nawaos-bluetooth-controller', 'install'],
                     'needs_root': True, 'needs_terminal': True},
                    {'label': _('Pair'), 'argv': ['/usr/local/bin/nawaos-bluetooth-controller', 'pair'],
                     'needs_terminal': True},
                    {'label': _('Test'), 'argv': ['/usr/local/bin/nawaos-bluetooth-controller', 'test']},
                ],
            },
            {
                'icon': 'tv-symbolic',
                'title': _('VRR/FreeSync Toggle'),
                'desc': _('Enable Variable Refresh Rate for smooth gaming'),
                'buttons': [
                    {'label': _('Status'), 'argv': ['/usr/local/bin/nawaos-vrr-toggle', 'status'],
                     'needs_terminal': True},
                    {'label': _('Enable'), 'argv': ['/usr/local/bin/nawaos-vrr-toggle', 'enable'],
                     'needs_root': True, 'needs_terminal': True},
                ],
            },
            {
                'icon': 'wine-symbolic',
                'title': _('NTSYNC (Wine/Proton)'),
                'desc': _('Better Windows game performance via Linux kernel'),
                'buttons': [
                    {'label': _('Install'), 'argv': ['/usr/local/bin/nawaos-ntsync', 'install'],
                     'needs_root': True, 'needs_terminal': True},
                    {'label': _('Status'), 'argv': ['/usr/local/bin/nawaos-ntsync', 'status'],
                     'needs_terminal': True},
                ],
            },
            {
                'icon': 'emblem-system-symbolic',
                'title': _('System Settings'),
                'desc': _('Drivers, updates, snapshots, disks and power live in the NawaOS Control Panel'),
                'buttons': [
                    {'label': _('Drivers'), 'callback': lambda b: self.open_control_panel('drivers')},
                    {'label': _('Updates'), 'callback': lambda b: self.open_control_panel('updates')},
                    {'label': _('Backup'), 'callback': lambda b: self.open_control_panel('backup')},
                    {'label': _('Storage'), 'callback': lambda b: self.open_control_panel('storage')},
                    {'label': _('Power'), 'callback': lambda b: self.open_control_panel('power')},
                ],
            },
        ]
        
        for tool in tools:
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            card.get_style_context().add_class("card")
            
            # Header row
            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
            
            # Icon
            header.pack_start(nawaos_theme.icon(tool["icon"], 32), False, False, 0)
            
            # Title and desc
            text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            
            title_label = Gtk.Label()
            title_label.set_markup(f'<span size="large" weight="bold" foreground="#E8EDF4">{tool["title"]}</span>')
            title_label.set_halign(Gtk.Align.START)
            text_box.pack_start(title_label, False, False, 0)
            
            desc_label = Gtk.Label(label=tool['desc'])
            desc_label.set_halign(Gtk.Align.START)
            desc_label.get_style_context().add_class("card-desc")
            text_box.pack_start(desc_label, False, False, 0)
            
            header.pack_start(text_box, True, True, 0)
            card.pack_start(header, False, False, 0)
            
            # Buttons row
            buttons_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            buttons_box.set_margin_top(10)
            
            for spec in tool['buttons']:
                btn = Gtk.Button(label=spec['label'])
                btn.get_style_context().add_class("ghost-btn")
                if 'callback' in spec:
                    btn.connect("clicked", spec['callback'])
                else:
                    btn.connect("clicked", self.on_run_tool, spec)
                buttons_box.pack_start(btn, False, False, 0)
            
            card.pack_start(buttons_box, False, False, 0)
            tools_box.pack_start(card, False, False, 0)
        
        scroll.add(tools_box)
        page.pack_start(scroll, True, True, 0)
        
        self.content_stack.add_named(page, "tools")
    
    def on_run_tool(self, button, spec):
        """Execute a structured tool spec (see the tools table in
        create_tools_page). No shell strings are re-parsed here and nothing
        runs with shell=True.

        Root tasks and tasks whose output matters run in the in-app task
        dialog (live log, Cancel, result + notification). Plain launches
        (GUI apps, quick user-level commands) start detached as before.
        """
        label = spec['label']
        argv = list(spec['argv'])
        needs_root = spec.get('needs_root', False)
        needs_terminal = spec.get('needs_terminal', False)
        if needs_root or needs_terminal:
            self._run_task(label, argv, root=needs_root)
            return

        original_label = button.get_label()
        button.set_sensitive(False)
        button.set_label(_("Running…"))

        def run_thread():
            try:
                subprocess.Popen(argv, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                # Popen only proves the process started; don't claim
                # the tool "completed successfully".
                GLib.idle_add(self.show_notification, _("%s launched") % label)
            except FileNotFoundError:
                GLib.idle_add(self.show_error_dialog, _("Tool not found"),
                              _("'%s' is not installed.") % argv[0])
            except Exception as e:
                GLib.idle_add(self.show_notification, _("Error: %s") % str(e))
            finally:
                GLib.idle_add(self._restore_tool_button, button, original_label)

        threading.Thread(target=run_thread, daemon=True).start()

    def _run_task(self, title, argv, root=False, on_done=None):
        """Run a tool inside the app with live output (nawaos_taskrunner).

        2.2: replaces the terminal windows every tool button used to open.
        """
        return nawaos_taskrunner.run_task(self, title, argv, root=root, on_done=on_done,
                                          category="gaming", source=_("Gaming Center"),
                                          icon_name="input-gaming-symbolic")

    def open_control_panel(self, page):
        """System settings are in the Control Panel; open it on ``page``."""
        try:
            subprocess.Popen(["nawaos-control-panel", "--page", page],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            self.show_error_dialog(_("Could not open the Control Panel"), str(e))

    def on_goverlay(self, button):
        """Launch GOverlay: Flatpak build if installed, else the native binary.

        The old 'flatpak run ... || goverlay' string never reached its
        fallback: the flatpak BINARY exists even when the GOverlay app is not
        installed, so Popen succeeded and the '||' half was dead code. Check
        actual installation first.
        """
        def worker():
            try:
                r = subprocess.run(['flatpak', 'info', 'io.github.benjamimgois.goverlay'],
                                   capture_output=True, timeout=10)
                flatpak_installed = r.returncode == 0
            except (OSError, subprocess.TimeoutExpired):
                flatpak_installed = False
            if flatpak_installed:
                subprocess.Popen(['flatpak', 'run', 'io.github.benjamimgois.goverlay'],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                GLib.idle_add(self.show_notification, _("GOverlay launched"))
            elif shutil.which('goverlay'):
                subprocess.Popen(['goverlay'],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                GLib.idle_add(self.show_notification, _("GOverlay launched"))
            else:
                GLib.idle_add(self.show_error_dialog, _("GOverlay not installed"),
                              _("Install it with:\n"
                                "flatpak install flathub io.github.benjamimgois.goverlay"))
        threading.Thread(target=worker, daemon=True).start()
    
    def _restore_tool_button(self, button, original_label):
        """Restore tool button to original state"""
        button.set_sensitive(True)
        button.set_label(original_label)
    
    def create_settings_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Settings")), False, False, 0)

        # About card
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        card.get_style_context().add_class("card")

        about_title = Gtk.Label()
        about_title.set_markup(
            '<span size="x-large" weight="bold" foreground="#37BCE0">%s</span>'
            % GLib.markup_escape_text(_("NawaOS Gaming Center")))
        card.pack_start(about_title, False, False, 0)

        version = Gtk.Label(label=_("Version %s") % get_nawaos_version())
        version.get_style_context().add_class("card-desc")
        card.pack_start(version, False, False, 0)

        developer = Gtk.Label()
        developer.set_markup(
            '<span foreground="#E8EDF4">%s <b>Ahmed Abdulla</b></span>'
            % GLib.markup_escape_text(_("Developed by:")))
        card.pack_start(developer, False, False, 10)

        website = Gtk.LinkButton.new_with_label("https://nawaos.com",
                                                _("Visit Website"))
        card.pack_start(website, False, False, 0)

        page.pack_start(card, False, False, 0)

        # MangoHud preset picker (2.0): writes ~/.config/MangoHud/presets.conf
        mh_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        mh_card.get_style_context().add_class("card")

        mh_title = Gtk.Label()
        mh_title.set_markup(
            '<span size="large" weight="bold" foreground="#E8EDF4">%s</span>'
            % GLib.markup_escape_text(_("MangoHud Overlay Preset")))
        mh_title.set_halign(Gtk.Align.START)
        mh_card.pack_start(mh_title, False, False, 0)

        mh_desc = Gtk.Label(
            label=_("Choose what the in-game performance overlay shows. "
                    "Presets are saved to ~/.config/MangoHud/presets.conf."))
        mh_desc.set_halign(Gtk.Align.START)
        mh_desc.set_line_wrap(True)
        mh_desc.get_style_context().add_class("card-desc")
        mh_card.pack_start(mh_desc, False, False, 0)

        # Radio pills. Guard the toggled handler while restoring the saved
        # selection so building the page never rewrites the file.
        self._mangohud_loading = True
        preset_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.mangohud_buttons = {}
        first_btn = None
        for key, label in [('off', _("Off")),
                           ('fps', _("FPS only")),
                           ('full', _("Full")),
                           ('streaming', _("Streaming"))]:
            btn = Gtk.RadioButton.new_with_label_from_widget(first_btn, label)
            if first_btn is None:
                first_btn = btn
            btn.set_mode(False)
            btn.get_style_context().add_class("filter-btn")
            btn.connect("toggled", self.on_mangohud_preset_toggled, key)
            preset_box.pack_start(btn, False, False, 0)
            self.mangohud_buttons[key] = btn
        mh_card.pack_start(preset_box, False, False, 0)

        self.mangohud_status = Gtk.Label()
        self.mangohud_status.set_halign(Gtk.Align.START)
        mh_card.pack_start(self.mangohud_status, False, False, 0)

        current = self._mangohud_current_preset()
        if current in self.mangohud_buttons:
            self.mangohud_buttons[current].set_active(True)
        self._set_mangohud_status(current)
        self._mangohud_loading = False

        mh_note = Gtk.Label(
            label=_("Tip: Shift+F12 cycles presets in-game; enable the overlay "
                    "per game with Steam launch options: mangohud %command%"))
        mh_note.set_halign(Gtk.Align.START)
        mh_note.set_line_wrap(True)
        mh_note.get_style_context().add_class("card-desc")
        mh_card.pack_start(mh_note, False, False, 0)

        page.pack_start(mh_card, False, False, 0)

        self.content_stack.add_named(page, "settings")

    # ===== MANGOHUD PRESETS (2.0) =====
    # presets.conf bodies, written under a "[preset 1]" section.
    # 'full' mirrors the richness of the system-wide /etc/MangoHud/MangoHud.conf
    # that hook 01 ships (FPS + frametimes + CPU/GPU/memory/engine/battery).
    MANGOHUD_PRESETS = {
        'fps': ("FPS only",
                "fps_only\n"
                "position=top-left\n"
                "font_size=24\n"
                "background_alpha=0.2\n"),
        'full': ("Full",
                 "position=top-left\n"
                 "font_size=20\n"
                 "background_alpha=0.4\n"
                 "round_corners=10\n"
                 "fps\n"
                 "fps_color_change\n"
                 "fps_value=30,60\n"
                 "frametime\n"
                 "frame_timing\n"
                 "cpu_stats\n"
                 "cpu_temp\n"
                 "cpu_power\n"
                 "cpu_mhz\n"
                 "gpu_stats\n"
                 "gpu_temp\n"
                 "gpu_power\n"
                 "gpu_core_clock\n"
                 "gpu_mem_clock\n"
                 "gpu_fan\n"
                 "ram\n"
                 "vram\n"
                 "engine_version\n"
                 "vulkan_driver\n"
                 "wine\n"
                 "battery\n"
                 "gamepad_battery\n"),
        'streaming': ("Streaming",
                      "position=top-right\n"
                      "font_size=16\n"
                      "background_alpha=0.2\n"
                      "round_corners=8\n"
                      "fps\n"
                      "frametime\n"
                      "gpu_stats\n"
                      "gpu_temp\n"
                      "cpu_stats\n"
                      "cpu_temp\n"
                      "ram\n"),
    }
    _MANGOHUD_MARKER = "# nawaos-preset: "

    def _mangohud_presets_path(self):
        return Path.home() / '.config' / 'MangoHud' / 'presets.conf'

    def _mangohud_current_preset(self):
        """'off' (no file), a known preset key, or 'custom' (foreign file)."""
        try:
            text = self._mangohud_presets_path().read_text()
        except OSError:
            return 'off'
        for line in text.splitlines():
            if line.startswith(self._MANGOHUD_MARKER):
                key = line[len(self._MANGOHUD_MARKER):].strip()
                if key in self.MANGOHUD_PRESETS:
                    return key
        return 'custom'

    def _set_mangohud_status(self, key):
        if key == 'custom':
            text = _("Current: custom (hand-edited presets.conf -- pick a preset to replace it)")
        elif key == 'off':
            text = _("Current: Off -- no presets.conf (F12 still toggles the default overlay)")
        else:
            text = _("Current: %s") % _(self.MANGOHUD_PRESETS[key][0])
        self.mangohud_status.set_markup(
            '<span foreground="#9AA7B8">%s</span>' % GLib.markup_escape_text(text))

    def on_mangohud_preset_toggled(self, button, key):
        if not button.get_active() or getattr(self, '_mangohud_loading', False):
            return
        self._apply_mangohud_preset(key)

    def _apply_mangohud_preset(self, key):
        path = self._mangohud_presets_path()
        try:
            # Never destroy a hand-written presets.conf: preserve it as .bak
            # (same convention as the profiles.json recovery path).
            if path.exists() and self._mangohud_current_preset() == 'custom':
                os.replace(str(path), str(path) + '.bak')
                self.show_notification(
                    _("Existing presets.conf preserved as presets.conf.bak"))
            if key == 'off':
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                body = (
                    "# NawaOS MangoHud presets -- generated by Gaming Center\n"
                    "# Selecting a preset in Gaming Center rewrites this file.\n"
                    + self._MANGOHUD_MARKER + key + "\n"
                    "\n"
                    "[preset 1]\n"
                    + self.MANGOHUD_PRESETS[key][1])
                # Atomic write (temp + os.replace), matching save_profiles().
                tmp = str(path) + '.tmp'
                with open(tmp, 'w') as f:
                    f.write(body)
                os.replace(tmp, str(path))
        except OSError as e:
            self.show_notification(_("Could not write MangoHud preset: %s") % e)
            self._set_mangohud_status(self._mangohud_current_preset())
            return
        self._set_mangohud_status(key)
        if key == 'off':
            self.show_notification(
                _("MangoHud presets removed -- overlay uses its default config"))
        else:
            self.show_notification(
                _("MangoHud preset saved: %s") % _(self.MANGOHUD_PRESETS[key][0]))
    
    # Profile Management
    def load_profiles(self):
        if self.profiles_file.exists():
            try:
                with open(self.profiles_file, 'r') as f:
                    data = json.load(f)
                    return [GameProfile.from_dict(p) for p in data]
            except Exception as e:
                # Don't silently discard the user's profiles: preserve the
                # unparseable file as a .bak (so the next save can't destroy
                # the only copy) and log why, instead of swallowing the error.
                import sys
                print(f"[game-center] Could not read profiles ({e}); "
                      f"preserving as {self.profiles_file}.bak and loading defaults",
                      file=sys.stderr)
                try:
                    os.replace(str(self.profiles_file), str(self.profiles_file) + ".bak")
                except OSError:
                    pass

        # Default profiles
        return [
            GameProfile(_("FPS Games"), "performance", 10, False, False),
            GameProfile(_("General Gaming"), "performance", 20, True, True),
            GameProfile(_("Low Memory"), "schedutil", 30, True, True),
        ]

    def save_profiles(self):
        # Write atomically (temp file + os.replace) so a crash mid-write cannot
        # truncate/corrupt the user's profiles.json.
        tmp = str(self.profiles_file) + ".tmp"
        with open(tmp, 'w') as f:
            json.dump([p.to_dict() for p in self.profiles], f, indent=2)
        os.replace(tmp, str(self.profiles_file))
    
    def on_add_profile(self, button):
        dialog = ProfileDialog(self, None)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            profile = dialog.get_profile()
            self.profiles.append(profile)
            self.save_profiles()
            self.refresh_profiles_list()
        dialog.destroy()
    
    def on_edit_profile(self, button, profile):
        dialog = ProfileDialog(self, profile)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            new_profile = dialog.get_profile()
            idx = self.profiles.index(profile)
            self.profiles[idx] = new_profile
            self.save_profiles()
            self.refresh_profiles_list()
        dialog.destroy()
    
    def on_delete_profile(self, button, profile):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Delete profile '%s'?") % profile.name
        )
        response = dialog.run()
        if response == Gtk.ResponseType.YES:
            self.profiles.remove(profile)
            self.save_profiles()
            self.refresh_profiles_list()
        dialog.destroy()
    
    def on_activate_profile(self, button, profile):
        # Guard the swappiness conversion (a hand-edited profiles.json could
        # hold a non-numeric value -> previously an uncaught ValueError), and
        # run the elevated apply on a worker thread so the polkit prompt does
        # not freeze the UI. Only mark the profile active if it succeeded.
        try:
            swappiness = str(int(profile.swappiness))
        except (TypeError, ValueError):
            self.show_notification(
                _("Profile '%s' has an invalid swappiness value.") % profile.name)
            return

        def worker():
            try:
                result = subprocess.run(
                    ["pkexec", "/usr/local/bin/nawaos-gamemode", "apply-profile",
                     str(profile.cpu_governor), swappiness],
                    capture_output=True)
                ok = result.returncode == 0
            except Exception:
                ok = False
            GLib.idle_add(self._profile_activated, profile, ok)

        threading.Thread(target=worker, daemon=True).start()

    def _profile_activated(self, profile, ok):
        if ok:
            self.current_profile = profile
            self.refresh_profiles_list()
            self.show_notification(_("Profile '%s' activated!") % profile.name)
        else:
            self.show_notification(
                _("Failed to activate '%s' (authentication cancelled or rejected).")
                % profile.name)
        return False
    
    # Callbacks
    def on_quick_gamemode(self, button):
        self.on_enable_gamemode(button)
    
    def on_quick_protonge(self, button):
        self._run_task("Proton-GE", ['/usr/local/bin/nawaos-protonge-install'])

    def on_launch_steam(self, button):
        try:
            subprocess.Popen(["steam"])
            self.show_notification(_("Launching Steam..."))
        except FileNotFoundError:
            self.show_error_dialog(
                _("Steam is not installed"),
                _("Install it from the Launchers page or with:\n"
                  "sudo apt install steam"))
        except OSError as e:
            self.show_error_dialog(_("Could not launch Steam"), str(e))
    
    def on_toggle_gamemode(self, button):
        # Dispatch on the authoritative state file so the session-side
        # compositor toggle and every status widget stay in sync.
        if self.check_gamemode_status():
            self.on_disable_gamemode(button)
        else:
            self.on_enable_gamemode(button)

    def _apply_session_gamemode(self, enabled):
        """Session-level Game Mode bits that must run as the logged-in user.

        These used to live in nawaos-gamemode.sh, but under pkexec they ran
        as root: dconf wrote to root's database (the user's compositor never
        changed) and xprop could not reach the user's display. Failures are
        non-fatal -- not every desktop has dconf/xprop.
        """
        key = '/org/cinnamon/muffin/unredirect-fullscreen-windows'
        if enabled:
            dconf_cmd = ['dconf', 'write', key, 'true']
        else:
            # Reset to the system default NawaOS ships (true) instead of
            # writing "false" into the user's database, which used to make
            # every later disable leave the compositor worse than a fresh
            # install.
            dconf_cmd = ['dconf', 'reset', key]
        try:
            subprocess.run(dconf_cmd, capture_output=True, timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            pass
        if enabled:
            xprop_cmd = ['xprop', '-root', '-f', '_NET_WM_BYPASS_COMPOSITOR', '32c',
                         '-set', '_NET_WM_BYPASS_COMPOSITOR', '1']
        else:
            # Was never removed on disable, so it survived until logout.
            xprop_cmd = ['xprop', '-root', '-remove', '_NET_WM_BYPASS_COMPOSITOR']
        try:
            subprocess.run(xprop_cmd, capture_output=True, timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            pass

    def on_enable_gamemode(self, button):
        """Enable Game Mode with proper error handling and UI feedback"""
        original_label = button.get_label() if button else None
        if button:
            button.set_sensitive(False)
            button.set_label(_("Enabling…"))

        def enable_thread():
            try:
                # NO kill-timeout here: pkexec waits at the polkit password
                # dialog, and a timeout would SIGKILL it while the user is
                # still typing (same fix as the Control Panel power-profile
                # apply).
                result = subprocess.run(
                    ["pkexec", "/usr/local/bin/nawaos-gamemode", "on"],
                    capture_output=True
                )
                success = result.returncode == 0
                if success:
                    # Session-level bits (compositor toggle) run as the user,
                    # not inside the pkexec'd root script.
                    self._apply_session_gamemode(True)
                GLib.idle_add(self._update_gamemode_ui, True, success, button, original_label)
            except Exception as e:
                GLib.idle_add(self._update_gamemode_ui, True, False, button, original_label)
                GLib.idle_add(self.show_notification, _("Error: %s") % str(e))

        threading.Thread(target=enable_thread, daemon=True).start()

    def on_disable_gamemode(self, button):
        """Disable Game Mode with proper error handling and UI feedback"""
        original_label = button.get_label() if button else None
        if button:
            button.set_sensitive(False)
            button.set_label(_("Disabling…"))

        def disable_thread():
            try:
                # NO kill-timeout -- see on_enable_gamemode.
                result = subprocess.run(
                    ["pkexec", "/usr/local/bin/nawaos-gamemode", "off"],
                    capture_output=True
                )
                success = result.returncode == 0
                if success:
                    self._apply_session_gamemode(False)
                GLib.idle_add(self._update_gamemode_ui, False, success, button, original_label)
            except Exception as e:
                GLib.idle_add(self._update_gamemode_ui, False, False, button, original_label)
                GLib.idle_add(self.show_notification, _("Error: %s") % str(e))

        threading.Thread(target=disable_thread, daemon=True).start()

    def _update_gamemode_ui(self, enabled, success, button=None, original_label=None):
        """Update all Game Mode UI elements across the app"""
        # Restore button state (to its own original label -- the same handlers
        # also serve the dashboard quick action and the Tools page buttons).
        if button:
            button.set_sensitive(True)
            if original_label:
                button.set_label(original_label)

        if success:
            # Re-read the authoritative state file rather than trusting the
            # direction we asked for.
            enabled = self.check_gamemode_status()
            if enabled:
                # Update Game Mode page status
                if hasattr(self, 'gamemode_status_label'):
                    self.gamemode_status_label.set_markup(
                        '<span size="large" foreground="#4ADE80"> %s</span>'
                        % GLib.markup_escape_text(_("✓ Enabled")))

                # Update sidebar status
                if hasattr(self, 'gamemode_status'):
                    self.gamemode_status.set_markup(
                        '<span size="small">%s: <span foreground="#4ADE80">%s</span></span>'
                        % (GLib.markup_escape_text(_("Game Mode")),
                           GLib.markup_escape_text(_("ON"))))

                # Update Dashboard card
                if hasattr(self, 'dashboard_gamemode_label'):
                    self.dashboard_gamemode_label.set_markup(
                        '<span size="small" weight="bold" foreground="#4ADE80">%s</span>'
                        % GLib.markup_escape_text(_("Enabled")))

                self.show_notification(
                    _("Game Mode enabled! System optimized for gaming."))
            else:
                # Update Game Mode page status
                if hasattr(self, 'gamemode_status_label'):
                    self.gamemode_status_label.set_markup(
                        '<span size="large" foreground="#9AA7B8"> %s</span>'
                        % GLib.markup_escape_text(_("Disabled")))

                # Update sidebar status
                if hasattr(self, 'gamemode_status'):
                    self.gamemode_status.set_markup(
                        '<span size="small">%s: <span foreground="#9AA7B8">%s</span></span>'
                        % (GLib.markup_escape_text(_("Game Mode")),
                           GLib.markup_escape_text(_("OFF"))))

                # Update Dashboard card
                if hasattr(self, 'dashboard_gamemode_label'):
                    self.dashboard_gamemode_label.set_markup(
                        '<span size="small" weight="bold" foreground="#9AA7B8">%s</span>'
                        % GLib.markup_escape_text(_("Disabled")))

                self.show_notification(
                    _("Game Mode disabled. System restored to normal."))
        else:
            self.show_notification(
                _("Failed to change Game Mode. Check if script exists."))
    
    def on_launch_app(self, button, app, name=None):
        """Launch an application with proper handling for different app types"""
        try:
            # Visual feedback
            original_label = button.get_label()
            button.set_sensitive(False)
            button.set_label(_("Launching…"))
            
            def launch_thread():
                try:
                    if app == "protonge":
                        GLib.idle_add(self.on_quick_protonge, None)
                    elif app.startswith('flatpak run '):
                        # `flatpak run` of a missing app starts fine and then
                        # fails, so check first and offer the Store instead
                        # of reporting a launch.
                        app_id = app.split()[2]
                        info = subprocess.run(['flatpak', 'info', app_id],
                                              capture_output=True, timeout=15)
                        if info.returncode != 0:
                            GLib.idle_add(self._restore_launch_button, button, original_label)
                            GLib.idle_add(self._offer_store, name or app_id)
                            return
                        subprocess.Popen(app.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    elif ' ' in app:
                        # Multi-word commands
                        subprocess.Popen(app.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    else:
                        # Simple app name
                        subprocess.Popen([app], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    
                    GLib.idle_add(self._restore_launch_button, button, original_label)
                    GLib.idle_add(self.show_notification, _("Launched successfully"))

                except FileNotFoundError:
                    GLib.idle_add(self._restore_launch_button, button, original_label)
                    GLib.idle_add(self.show_notification,
                                  _("App not installed: %s")
                                  % (app.split()[0] if ' ' in app else app))
                except Exception as e:
                    GLib.idle_add(self._restore_launch_button, button, original_label)
                    GLib.idle_add(self.show_notification, _("Error: %s") % str(e))
            
            thread = threading.Thread(target=launch_thread)
            thread.daemon = True
            thread.start()
            
        except Exception as e:
            button.set_sensitive(True)
            button.set_label(original_label)
            self.show_notification(_("Error: %s") % str(e))
    
    def _offer_store(self, name):
        """The app is not installed: offer to open the NawaOS Store."""
        dialog = Gtk.MessageDialog(
            transient_for=self, flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=_("%s is not installed") % name)
        dialog.format_secondary_text(
            _("Install it from the NawaOS Store, then launch it again."))
        dialog.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL,
                           _("Open NawaOS Store"), Gtk.ResponseType.OK)
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.OK:
            try:
                subprocess.Popen(["nawaos-store"], stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            except OSError as e:
                self.show_error_dialog(_("Error: %s") % str(e), "")
        return False

    def _restore_launch_button(self, button, original_label):
        """Restore launch button to original state"""
        button.set_sensitive(True)
        button.set_label(original_label)
    
    def show_notification(self, message):
        notify_gaming(_("NawaOS Gaming Center"), message, source="Gaming Center")

    def show_error_dialog(self, title, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
        return False  # allows direct use as a GLib.idle_add callback

    def count_games(self):
        # Count from the shared nawaos_games scanner result (self.games): the
        # old raw listing of steamapps/common counted Proton/runtime dirs and
        # missed Lutris/Flatpak games. The dashboard label is refreshed by
        # _start_game_scan() once the async scan completes.
        return len(self.games)
    
    def check_protonge(self):
        proton_path = Path.home() / '.steam' / 'root' / 'compatibilitytools.d'
        if proton_path.exists() and list(proton_path.glob('GE-Proton*')):
            return "Installed"
        return "Not Installed"
    
    def check_gamemode_status(self):
        """Check if Game Mode is currently enabled.

        /run/nawaos/gamemode-state is written by nawaos-gamemode.sh on every
        on/off and is the authoritative record. Inferring from the CPU
        governor is only a fallback for when the file doesn't exist yet
        (e.g. never toggled since boot): a "performance" governor can also
        come from power profiles, so it would report false positives.
        """
        try:
            with open('/run/nawaos/gamemode-state') as f:
                return f.read().strip() == 'enabled'
        except OSError:
            pass
        try:
            with open('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor') as f:
                return 'performance' in f.read()
        except OSError:
            return False


class ProfileDialog(Gtk.Dialog):
    def __init__(self, parent, profile=None):
        title = _("Edit Profile") if profile else _("New Profile")
        super().__init__(title=title, transient_for=parent, flags=0)
        # Keep the original so get_profile() can preserve fields the dialog
        # does not expose (mouse_accel, custom_env).
        self._orig = profile
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        
        self.set_default_size(400, 300)
        
        box = self.get_content_area()
        box.set_spacing(15)
        box.set_margin_start(20)
        box.set_margin_end(20)
        box.set_margin_top(20)
        box.set_margin_bottom(20)
        
        # Name
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        name_label = Gtk.Label(label=_("Profile Name:"))
        name_label.set_size_request(120, -1)
        name_box.pack_start(name_label, False, False, 0)
        self.name_entry = Gtk.Entry()
        self.name_entry.set_text(profile.name if profile else "")
        name_box.pack_start(self.name_entry, True, True, 0)
        box.pack_start(name_box, False, False, 0)
        
        # CPU Governor
        cpu_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        cpu_label = Gtk.Label(label=_("CPU Governor:"))
        cpu_label.set_size_request(120, -1)
        cpu_box.pack_start(cpu_label, False, False, 0)
        self.cpu_combo = Gtk.ComboBoxText()
        # Match the full set the nawaos-gamemode backend accepts; using only
        # four here made .index() raise (and the Edit dialog never open) for a
        # profile saved with conservative/userspace.
        governors = ["performance", "schedutil", "powersave",
                     "ondemand", "conservative", "userspace"]
        for gov in governors:
            self.cpu_combo.append_text(gov)
        # Fall back to index 0 when the saved governor isn't in the list.
        active = governors.index(profile.cpu_governor) \
            if (profile and profile.cpu_governor in governors) else 0
        self.cpu_combo.set_active(active)
        cpu_box.pack_start(self.cpu_combo, True, True, 0)
        box.pack_start(cpu_box, False, False, 0)
        
        # Swappiness
        swap_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        swap_label = Gtk.Label(label=_("Swappiness:"))
        swap_label.set_size_request(120, -1)
        swap_box.pack_start(swap_label, False, False, 0)
        self.swap_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 10)
        self.swap_scale.set_value(profile.swappiness if profile else 10)
        swap_box.pack_start(self.swap_scale, True, True, 0)
        box.pack_start(swap_box, False, False, 0)

        # 2.3: no "Compositor" switch. It was never applied, and Cinnamon
        # cannot turn compositing off: full-screen games already bypass it
        # (unredirect-fullscreen-windows, on by default in NawaOS).
        
        self.show_all()
    
    def get_profile(self):
        return GameProfile(
            name=self.name_entry.get_text(),
            cpu_governor=self.cpu_combo.get_active_text(),
            swappiness=int(self.swap_scale.get_value()),
            # Preserve fields the dialog doesn't expose so editing a profile
            # doesn't silently reset them.
            compositor=self._orig.compositor if self._orig else False,
            mouse_accel=self._orig.mouse_accel if self._orig else False,
            custom_env=dict(self._orig.custom_env) if self._orig else None,
        )


def main():
    if nawaos_games is None:
        # Hard requirement (see import note at the top of the file): tell the
        # user the install is broken instead of running with an empty library.
        dialog = Gtk.MessageDialog(
            transient_for=None,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=_("NawaOS Gaming Center cannot start")
        )
        dialog.format_secondary_text(
            _("The shared module 'nawaos_games' could not be imported (%s).\n\n"
              "Your NawaOS installation appears incomplete. "
              "Reinstall the NawaOS apps (deployment hook 05) to repair it.")
            % _NAWAOS_GAMES_ERROR)
        dialog.run()
        dialog.destroy()
        print(f"nawaos_games import failed: {_NAWAOS_GAMES_ERROR}",
              file=__import__('sys').stderr)
        return
    try:
        app = NawaOSGameCenter()
        app.connect("destroy", Gtk.main_quit)
        Gtk.main()
    except Exception as e:
        import traceback
        log_path = os.path.expanduser("~/.local/share/nawaos/game-center.log")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a") as f:
            f.write(f"\n--- Crash at {__import__('datetime').datetime.now()} ---\n")
            traceback.print_exc(file=f)
        print(f"NawaOS Gaming Center crashed. See {log_path}", file=__import__('sys').stderr)
        raise


if __name__ == "__main__":
    main()
