#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Store
Curated application store for NawaOS (Debian trixie base).

A lightweight, honest front-end over apt and Flatpak:

  * Home with featured apps, browse by section, search ranked by relevance,
    source filter (APT / Flatpak), installed view.
  * A details page per app: versions, size, license, developer, long
    description and screenshots (Flathub appstream for Flatpak apps,
    ``apt-cache show`` for Debian packages), Install / Remove / Open.
  * A real Updates page: pending apt and Flatpak updates with old and new
    versions, update one or all, refresh the package lists.
  * An activity panel at the bottom: live progress bar parsed from apt's
    status fd and Flatpak's percentages, the command log, Cancel, queue.
  * Every operation is judged by its exit code and the installed state is
    re-read afterwards; failures show the tail of the output.

All package logic lives in the shared ``nawaos_store`` module (unit tested,
no GTK). Fully bilingual (English/Arabic) via nawaos_i18n + per-entry
name_ar / description_ar fields in the catalog.

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import os
import queue
import shutil
import subprocess
import sys
import threading

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, GLib, Pango

# Shared NawaOS modules are installed to dist-packages; from a source
# checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402
import nawaos_notify  # noqa: E402
import nawaos_store as backend  # noqa: E402
import nawaos_taskrunner  # noqa: E402
import nawaos_theme  # noqa: E402

APP_NAME = "nawaos-store"
APP_TITLE = "NawaOS Store"

DEV_CATALOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "store-catalog.json")

SECTION_ICONS = {
    "Gaming": "applications-games-symbolic",
    "Emulators": "input-gaming-symbolic",
    "Streaming/Recording": "camera-video-symbolic",
    "Communication": "user-available-symbolic",
    "Media": "applications-multimedia-symbolic",
    "Productivity": "applications-office-symbolic",
    "System Tools": "applications-utilities-symbolic",
}
GENERIC_ICON = "package-x-generic"

# Pseudo-views shown above the real sections in the sidebar.
VIEW_HOME = "__home__"
VIEW_ALL = "__all__"
VIEW_INSTALLED = "__installed__"
VIEW_UPDATES = "__updates__"

PAGE_BROWSE = "browse"
PAGE_DETAILS = "details"
PAGE_UPDATES = "updates"

AR_STRINGS = {
    "NawaOS Store": "متجر NawaOS",
    "Curated apps for your gaming desktop": "تطبيقات مختارة بعناية لسطح مكتبك",
    "Search apps...": "ابحث عن التطبيقات...",
    "Home": "الرئيسية",
    "All Apps": "كل التطبيقات",
    "Installed": "المثبتة",
    "Updates": "التحديثات",
    "Gaming": "الألعاب",
    "Emulators": "المحاكيات",
    "Streaming/Recording": "البث والتسجيل",
    "Communication": "التواصل",
    "Media": "الوسائط",
    "Productivity": "الإنتاجية",
    "System Tools": "أدوات النظام",
    "All": "الكل",
    "APT": "APT",
    "Flatpak": "فلاتباك",
    "Install": "تثبيت",
    "Remove": "إزالة",
    "Open": "فتح",
    "Update": "تحديث",
    "Not installed": "غير مثبت",
    "Checking...": "جارٍ الفحص...",
    "Queued": "في قائمة الانتظار",
    "Installing %s": "جارٍ تثبيت %s",
    "Removing %s": "جارٍ إزالة %s",
    "Updating %s": "جارٍ تحديث %s",
    "Refreshing package lists": "جارٍ تحديث قوائم الحزم",
    "Updating all apps": "جارٍ تحديث كل البرامج",
    "Website": "الموقع",
    "No apps match your search.": "لا توجد تطبيقات تطابق بحثك.",
    "No apps in this view yet.": "لا توجد تطبيقات في هذا العرض بعد.",
    "Catalog error": "خطأ في الفهرس",
    "The store catalog could not be loaded.": "تعذر تحميل فهرس المتجر.",
    "Install failed": "فشل التثبيت",
    "Removal failed": "فشلت الإزالة",
    "Update failed": "فشل التحديث",
    "Exit code: %d": "رمز الخروج: %d",
    "Command not found: %s": "الأمر غير موجود: %s",
    "%s was installed.": "تم تثبيت %s.",
    "%s was removed.": "تمت إزالة %s.",
    "%s was updated.": "تم تحديث %s.",
    "Package lists refreshed.": "تم تحديث قوائم الحزم.",
    "All apps are up to date.": "كل البرامج محدّثة.",
    "Ready.": "جاهز.",
    "Flatpak is not available on this system.": "فلاتباك غير متوفر على هذا النظام.",
    "_Close": "إ_غلاق",
    "%d apps": "%d تطبيقات",
    "%d app": "%d تطبيق",
    "Details (last lines of output):": "التفاصيل (آخر سطور المخرجات):",
    "The catalog file was not found or contains no valid entries.":
        "ملف الفهرس غير موجود أو لا يحتوي على مدخلات صالحة.",
    "No internet connection": "لا يوجد اتصال بالإنترنت",
    "%s could not be installed because no network is reachable. Connect to "
    "Wi-Fi or plug in a cable, then try again.":
        "تعذّر تثبيت %s لعدم وجود شبكة متاحة. اتصل بشبكة Wi-Fi أو وصّل "
        "كابل الشبكة ثم حاول مرة أخرى.",
    "Updates need a network connection. Connect to Wi-Fi or plug in a "
    "cable, then try again.":
        "تحتاج التحديثات إلى اتصال بالشبكة. اتصل بشبكة Wi-Fi أو وصّل "
        "كابل الشبكة ثم حاول مرة أخرى.",
    "_Cancel": "إل_غاء",
    "_Retry": "إعادة الم_حاولة",
    "Cancel": "إلغاء",
    "Close": "إغلاق",
    "Back": "رجوع",
    "Show log": "إظهار السجل",
    "Hide log": "إخفاء السجل",
    "%d more in queue": "%d أخرى في قائمة الانتظار",
    "Cancelled.": "أُلغيت العملية.",
    "Authentication was cancelled.": "أُلغيت المصادقة.",
    "Completed": "اكتمل",
    "Stopping…": "جارٍ الإيقاف…",
    "This task runs as administrator and cannot be cancelled. Wait for it to finish.":
        "تعمل هذه المهمة بصلاحيات المدير ولا يمكن إلغاؤها. انتظر حتى تنتهي.",
    "An installation or update is running": "يجري الآن تثبيت أو تحديث",
    "Closing the Store now would interrupt it and could leave packages half-installed. "
    "Wait until it finishes, then close the Store.":
        "إغلاق المتجر الآن سيقطع العملية وقد يترك حزمًا مثبتة جزئيًا. "
        "انتظر حتى تنتهي ثم أغلق المتجر.",
    "Opening %s…": "جارٍ فتح %s…",
    "Could not open %s.": "تعذّر فتح %s.",
    "Essentials for your gaming desktop": "أساسيات سطح مكتب الألعاب",
    "Launchers, Proton tools, emulators and the overlay you will want on day one. "
    "Everything installs from Debian or Flathub with one click.":
        "منصّات الإطلاق وأدوات بروتون والمحاكيات والطبقة العلوية التي ستحتاجها من اليوم "
        "الأول. كل شيء يُثبَّت من Debian أو Flathub بنقرة واحدة.",
    "Browse all apps": "تصفّح كل التطبيقات",
    "Featured": "مميّزة",
    "Installed on this PC": "مثبّتة على هذا الجهاز",
    "Installed version": "الإصدار المثبت",
    "Available version": "الإصدار المتاح",
    "Download size": "حجم التنزيل",
    "Installed size": "الحجم بعد التثبيت",
    "Source": "المصدر",
    "License": "الترخيص",
    "Developer": "المطوّر",
    "Debian package": "حزمة Debian",
    "Flathub app": "تطبيق Flathub",
    "Command-line tool": "أداة سطر أوامر",
    "Screenshots": "لقطات الشاشة",
    "About": "حول",
    "Loading details…": "جارٍ تحميل التفاصيل…",
    "Update available: %s": "تحديث متاح: %s",
    "Everything is up to date.": "كل شيء محدّث.",
    "Checking for updates…": "جارٍ التحقق من التحديثات…",
    "%d updates available": "%d تحديثات متاحة",
    "%d update available": "%d تحديث متاح",
    "Check again": "تحقّق مجددًا",
    "Refresh lists": "تحديث القوائم",
    "Update all": "تحديث الكل",
    "Could not check for updates: %s": "تعذّر التحقق من التحديثات: %s",
    "Includes system packages that are not in the store catalog.":
        "يشمل حزم نظام ليست في فهرس المتجر.",
    # Tag vocabulary (catalog "tags")
    "launcher": "منصّة إطلاق", "store": "متجر", "windows-games": "ألعاب ويندوز",
    "proton": "بروتون", "performance": "أداء", "overlay": "طبقة علوية",
    "compositor": "مُركِّب", "gpu": "بطاقة الرسوميات", "open-source-game": "لعبة مفتوحة المصدر",
    "racing": "سباقات", "strategy": "استراتيجية", "emulator": "محاكي",
    "nintendo": "نينتندو", "playstation": "بلايستيشن", "retro": "كلاسيكي",
    "handheld": "محمول", "recording": "تسجيل", "streaming": "بث",
    "video-editing": "مونتاج", "screenshot": "لقطة شاشة", "audio": "صوت",
    "remote-play": "لعب عن بُعد", "chat": "دردشة", "voice": "صوتي",
    "messaging": "مراسلة", "email": "بريد", "player": "مشغّل", "music": "موسيقى",
    "converter": "محوّل", "media-server": "خادم وسائط", "image-editing": "تحرير صور",
    "painting": "رسم", "vector": "رسوم متجهة", "3d": "ثلاثي الأبعاد", "office": "مكتب",
    "browser": "متصفح", "code": "برمجة", "notes": "ملاحظات", "sync": "مزامنة",
    "monitor": "مراقبة", "disks": "أقراص", "backup": "نسخ احتياطي", "cleanup": "تنظيف",
    "permissions": "صلاحيات", "terminal": "طرفية", "file-transfer": "نقل ملفات",
    "privacy": "خصوصية", "gaming": "ألعاب",
}

_, get_language, is_rtl = nawaos_i18n.setup(APP_NAME, AR_STRINGS)


# ---------------------------------------------------------------------------
# App-specific CSS layered on top of the shared NawaOS base theme.
# ---------------------------------------------------------------------------
APP_CSS = """
.store-header-title { font-size: 22px; font-weight: 800; }
.store-header-subtitle { font-size: 12px; }
.store-card { min-width: 250px; padding: 14px 16px; }
.store-card-developer { color: #5A6678; font-size: 11px; }
.badge-apt {
    background-color: rgba(74, 222, 128, 0.12); color: #4ADE80;
    border: 1px solid rgba(74, 222, 128, 0.30); border-radius: 100px;
    padding: 1px 10px; font-size: 10px; font-weight: 700;
}
.badge-flatpak {
    background-color: rgba(55, 188, 224, 0.12); color: #37BCE0;
    border: 1px solid rgba(55, 188, 224, 0.30); border-radius: 100px;
    padding: 1px 10px; font-size: 10px; font-weight: 700;
}
.badge-update {
    background-color: rgba(251, 191, 36, 0.14); color: #FBBF24;
    border: 1px solid rgba(251, 191, 36, 0.35); border-radius: 100px;
    padding: 1px 10px; font-size: 10px; font-weight: 700;
}
.count-pill {
    background-color: rgba(55, 188, 224, 0.18); color: #37BCE0;
    border-radius: 100px; padding: 0 8px; font-size: 11px; font-weight: 700;
}
.section-count { color: #5A6678; font-size: 11px; }
.empty-state { color: #9AA7B8; font-size: 15px; }
.statusbar { border-top: 1px solid rgba(55, 188, 224, 0.15); padding: 6px 14px; font-size: 12px; }
.link-btn { padding: 2px 6px; font-size: 11px; }
.small-btn { padding: 4px 12px; font-size: 12px; }
.chip {
    background-color: rgba(55, 188, 224, 0.10); color: #9AA7B8;
    border: 1px solid rgba(55, 188, 224, 0.18); border-radius: 100px;
    padding: 2px 10px; font-size: 11px;
}
.filter-chip {
    background-color: transparent; color: #9AA7B8; border: 1px solid rgba(55, 188, 224, 0.18);
    border-radius: 100px; padding: 4px 14px; font-size: 12px; font-weight: 600;
}
.filter-chip:checked { background-color: rgba(55, 188, 224, 0.18); color: #37BCE0; }
.hero {
    background: linear-gradient(120deg, rgba(26, 118, 186, 0.55), rgba(55, 188, 224, 0.18) 60%, rgba(11, 15, 26, 0));
    border: 1px solid rgba(55, 188, 224, 0.25); border-radius: 16px; padding: 26px 28px;
}
.hero-title { font-size: 26px; font-weight: 800; }
.hero-text { color: #C7D2E0; font-size: 13px; }
.home-section-title { font-size: 16px; font-weight: 700; margin-top: 6px; }
.details-name { font-size: 26px; font-weight: 800; }
.details-meta-key { color: #5A6678; font-size: 11px; font-weight: 600; }
.details-meta-value { font-size: 13px; }
.details-body { color: #C7D2E0; font-size: 13px; }
.screenshot { border: 1px solid rgba(55, 188, 224, 0.18); border-radius: 10px; }
.activity {
    background-color: #111827; border-top: 1px solid rgba(55, 188, 224, 0.25); padding: 10px 14px;
}
.activity progressbar trough { min-height: 6px; border-radius: 6px; background-color: #1A2332; border: none; }
.activity progressbar progress {
    min-height: 6px; border-radius: 6px; border: none;
    background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2);
}
.update-row { padding: 10px 14px; border-bottom: 1px solid rgba(55, 188, 224, 0.10); }
button.action-btn:disabled, button.action-btn-primary:disabled, button.destructive:disabled {
    background: #1F2A3C; color: #5A6678; border: 1px solid rgba(55, 188, 224, 0.10); box-shadow: none;
}
.version-arrow { color: #5A6678; }
"""


def _label(text="", classes=(), halign=Gtk.Align.START, wrap=False, xalign=0.0,
           ellipsize=None, selectable=False):
    lab = Gtk.Label(label=text)
    lab.set_halign(halign)
    lab.set_xalign(xalign)
    lab.set_selectable(selectable)
    if wrap:
        lab.set_line_wrap(True)
        lab.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
    if ellipsize is not None:
        lab.set_ellipsize(ellipsize)
    for cls in classes:
        lab.get_style_context().add_class(cls)
    return lab


def _badge(entry):
    lab = Gtk.Label(label=_("APT") if entry.source == "apt" else _("Flatpak"))
    lab.get_style_context().add_class("badge-apt" if entry.source == "apt" else "badge-flatpak")
    lab.set_valign(Gtk.Align.CENTER)
    return lab


def _app_icon(entry, px):
    theme = Gtk.IconTheme.get_default()
    for name in (entry.icon, SECTION_ICONS.get(entry.section, ""), GENERIC_ICON):
        if name and theme.has_icon(name):
            break
    else:
        name = GENERIC_ICON
    image = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.DIALOG)
    image.set_pixel_size(px)
    return image


def _count_text(n):
    return _("%d app") % n if n == 1 else _("%d apps") % n


def _ltr(text):
    """Version strings and package ids read left to right even in Arabic."""
    return "\u2066%s\u2069" % text if (text and is_rtl()) else text


# ---------------------------------------------------------------------------
# Store card widget
# ---------------------------------------------------------------------------
class StoreCard(Gtk.FlowBoxChild):
    """A single application card inside a grid."""

    def __init__(self, entry, store):
        super().__init__()
        self.entry = entry
        self.store = store
        self.set_can_focus(False)

        # The whole card opens the details page; the buttons inside consume
        # their own clicks, so they never reach the event box.
        clickable = Gtk.EventBox()
        clickable.set_visible_window(False)
        clickable.connect("button-release-event", self._on_card_clicked)
        self.add(clickable)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        outer.get_style_context().add_class("card")
        outer.get_style_context().add_class("store-card")
        clickable.add(outer)

        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        top.pack_start(_app_icon(entry, 56), False, False, 0)
        top.pack_start(Gtk.Box(), True, True, 0)
        badges = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        badges.set_valign(Gtk.Align.START)
        badges.pack_start(_badge(entry), False, False, 0)
        self.update_badge = Gtk.Label(label=_("Update"))
        self.update_badge.get_style_context().add_class("badge-update")
        self.update_badge.set_no_show_all(True)
        badges.pack_start(self.update_badge, False, False, 0)
        top.pack_start(badges, False, False, 0)
        outer.pack_start(top, False, False, 0)

        name = _label(entry.display_name(), ("card-title",), ellipsize=Pango.EllipsizeMode.END)
        name.set_max_width_chars(24)
        name.set_tooltip_text(entry.display_name())
        outer.pack_start(name, False, False, 0)

        if entry.developer:
            outer.pack_start(_label(entry.developer, ("store-card-developer",),
                                    ellipsize=Pango.EllipsizeMode.END), False, False, 0)

        desc = _label(entry.display_description(), ("card-subtitle",), wrap=True,
                      ellipsize=Pango.EllipsizeMode.END)
        desc.set_lines(2)
        desc.set_max_width_chars(30)
        desc.set_tooltip_text(entry.display_description())
        outer.pack_start(desc, False, False, 0)

        bottom = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bottom.set_margin_top(4)
        self.status_label = _label(_("Checking..."), ("card-subtitle",),
                                   ellipsize=Pango.EllipsizeMode.END)
        bottom.pack_start(self.status_label, True, True, 0)
        self.spinner = Gtk.Spinner()
        bottom.pack_start(self.spinner, False, False, 0)
        self.open_button = Gtk.Button(label=_("Open"))
        self.open_button.get_style_context().add_class("action-btn")
        self.open_button.set_no_show_all(True)
        self.open_button.connect("clicked", lambda _b: self.store.launch(self.entry))
        bottom.pack_start(self.open_button, False, False, 0)
        self.action_button = Gtk.Button(label=_("Install"))
        self.action_button.set_sensitive(False)
        self.action_button.connect("clicked", self._on_action)
        bottom.pack_start(self.action_button, False, False, 0)
        outer.pack_start(bottom, False, False, 0)

        self.show_all()
        self.spinner.hide()
        self.refresh_from_state()

    def _on_card_clicked(self, _widget, event):
        if event.button == 1:
            self.store.show_details(self.entry)
            return True
        return False

    def _on_action(self, _button):
        if self.entry.state == backend.STATE_UNKNOWN:
            return
        self.store.queue_entry(self.entry, "remove" if self.entry.installed else "install")

    def _style_button(self, primary):
        ctx = self.action_button.get_style_context()
        for cls in ("action-btn-primary", "destructive", "action-btn"):
            ctx.remove_class(cls)
        ctx.add_class("action-btn-primary" if primary else "destructive")

    def refresh_from_state(self):
        """Sync widgets with the entry (idle or busy)."""
        entry = self.entry
        status_ctx = self.status_label.get_style_context()
        status_ctx.remove_class("status-ok")
        status_ctx.remove_class("status-warn")
        busy = self.store.busy_text(entry)
        if busy:
            self.status_label.set_text(busy)
            self.action_button.set_sensitive(False)
            self.open_button.hide()
            self.spinner.show()
            self.spinner.start()
            return
        self.spinner.stop()
        self.spinner.hide()
        self.update_badge.set_visible(entry.has_update)
        if entry.installed:
            text = _("Installed")
            if entry.installed_version:
                text += " · " + _ltr(entry.installed_version)
            self.status_label.set_text(text)
            status_ctx.add_class("status-ok")
            self.action_button.set_label(_("Remove"))
            self._style_button(primary=False)
            self.action_button.set_sensitive(True)
            self.open_button.set_visible(entry.is_gui)
        elif entry.state == backend.STATE_ABSENT:
            self.status_label.set_text(_("Not installed"))
            self.action_button.set_label(_("Install"))
            self._style_button(primary=True)
            self.open_button.hide()
            if entry.source == "flatpak" and not self.store.flatpak_available:
                self.action_button.set_sensitive(False)
                self.action_button.set_tooltip_text(_("Flatpak is not available on this system."))
            else:
                self.action_button.set_sensitive(True)
        else:
            self.status_label.set_text(_("Checking..."))
            self.action_button.set_sensitive(False)
            self.open_button.hide()


# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------
class Operation:
    """One queued job: a list of argv steps plus what to refresh afterwards."""

    def __init__(self, kind, title, steps, entry=None, item=None, needs_network=False,
                 root=False):
        self.kind = kind                # entry-install | entry-remove | refresh | update-all | update-item
        self.title = title
        self.steps = steps              # [argv, ...]
        self.entry = entry
        self.item = item
        self.needs_network = needs_network
        self.root = root
        self.rc = 0
        self.log = []
        self.cancelled = False
        self.offline = False


class ActivityPanel(Gtk.Revealer):
    """Bottom panel: current operation, progress, log, Cancel, queue size."""

    def __init__(self, store):
        super().__init__()
        self.store = store
        self.set_transition_type(Gtk.RevealerTransitionType.SLIDE_UP)
        self.set_reveal_child(False)
        self._pulse_id = None
        self._hide_id = None

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.get_style_context().add_class("activity")
        self.add(box)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.spinner = Gtk.Spinner()
        self.spinner.set_size_request(20, 20)
        row.pack_start(self.spinner, False, False, 0)
        self.state_icon = Gtk.Image()
        self.state_icon.set_pixel_size(20)
        self.state_icon.set_no_show_all(True)
        row.pack_start(self.state_icon, False, False, 0)
        self.title = _label("", ("card-title",), ellipsize=Pango.EllipsizeMode.END)
        row.pack_start(self.title, True, True, 0)
        self.queue_label = _label("", ("card-subtitle",))
        row.pack_start(self.queue_label, False, False, 0)
        self.log_button = Gtk.ToggleButton(label=_("Show log"))
        self.log_button.get_style_context().add_class("action-btn")
        self.log_button.get_style_context().add_class("small-btn")
        self.log_button.connect("toggled", self._on_log_toggled)
        row.pack_start(self.log_button, False, False, 0)
        self.cancel_button = Gtk.Button(label=_("Cancel"))
        self.cancel_button.get_style_context().add_class("destructive")
        self.cancel_button.get_style_context().add_class("small-btn")
        self.cancel_button.connect("clicked", lambda _b: self.store.cancel_current())
        row.pack_start(self.cancel_button, False, False, 0)
        self.close_button = Gtk.Button(label=_("Close"))
        self.close_button.get_style_context().add_class("action-btn")
        self.close_button.get_style_context().add_class("small-btn")
        self.close_button.set_no_show_all(True)
        self.close_button.connect("clicked", lambda _b: self.hide_panel())
        row.pack_start(self.close_button, False, False, 0)
        box.pack_start(row, False, False, 0)

        self.progress = Gtk.ProgressBar()
        box.pack_start(self.progress, False, False, 0)

        self.log_scroll = Gtk.ScrolledWindow()
        self.log_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.log_scroll.set_size_request(-1, 170)
        self.log_scroll.set_no_show_all(True)
        self.log_view = Gtk.TextView()
        self.log_view.set_editable(False)
        self.log_view.set_cursor_visible(False)
        self.log_view.set_monospace(True)
        self.log_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.log_view.set_left_margin(8)
        self.log_view.set_right_margin(8)
        self.log_view.set_direction(Gtk.TextDirection.LTR)   # command output is LTR
        self.log_view.get_style_context().add_class("task-log")
        self.log_buf = self.log_view.get_buffer()
        self.log_end = self.log_buf.create_mark("end", self.log_buf.get_end_iter(), False)
        self.log_scroll.add(self.log_view)
        self.log_view.show()
        box.pack_start(self.log_scroll, False, False, 0)
        box.show_all()
        self.state_icon.hide()

    def _on_log_toggled(self, button):
        show = button.get_active()
        self.log_scroll.set_visible(show)
        button.set_label(_("Hide log") if show else _("Show log"))

    def start(self, op, queued):
        self._cancel_timers()
        self.log_buf.set_text("")
        self.title.set_text(op.title)
        self.set_queue(queued)
        self.state_icon.hide()
        self.spinner.show()
        self.spinner.start()
        self.cancel_button.show()
        self.cancel_button.set_sensitive(True)
        self.cancel_button.set_tooltip_text(None)
        self.close_button.hide()
        self.progress.set_fraction(0.0)
        self.progress.show()
        self._pulse_id = GLib.timeout_add(120, self._pulse)
        self._determinate = False
        self.set_reveal_child(True)

    def _pulse(self):
        if not self._determinate:
            self.progress.pulse()
        return True

    def set_queue(self, queued):
        self.queue_label.set_text(_("%d more in queue") % queued if queued else "")

    def append_line(self, line):
        self.log_buf.insert(self.log_buf.get_end_iter(), line)
        self.log_view.scroll_mark_onscreen(self.log_end)

    def set_fraction(self, fraction):
        self._determinate = True
        self.progress.set_fraction(fraction)

    def stopping(self):
        self.title.set_text(_("Stopping…"))
        self.cancel_button.set_sensitive(False)

    def cannot_cancel(self):
        """A root (pkexec) step past the polkit prompt cannot be signalled."""
        text = _("This task runs as administrator and cannot be cancelled. Wait for it to finish.")
        self.cancel_button.set_sensitive(False)
        self.cancel_button.set_tooltip_text(text)
        self.append_line(text + "\n")

    def finish(self, state, message, more_queued):
        """state: 'success' | 'cancelled' (incl. auth cancelled) | 'failed'."""
        self._cancel_timers()
        self.spinner.stop()
        self.spinner.hide()
        ok = state == "success"
        if ok:
            self.progress.set_fraction(1.0)
        icon, cls = {"success": ("emblem-ok-symbolic", "status-ok"),
                     "cancelled": ("dialog-warning-symbolic", "status-warn")}.get(
            state, ("dialog-error-symbolic", "status-err"))
        self.state_icon.set_from_icon_name(icon, Gtk.IconSize.LARGE_TOOLBAR)
        ctx = self.state_icon.get_style_context()
        for c in ("status-ok", "status-warn", "status-err"):
            ctx.remove_class(c)
        ctx.add_class(cls)
        self.state_icon.show()
        self.title.set_text(message)
        self.cancel_button.hide()
        self.close_button.show()
        if ok and not more_queued and not self.log_button.get_active():
            self._hide_id = GLib.timeout_add(4000, self.hide_panel)

    def hide_panel(self):
        self._cancel_timers()
        self.set_reveal_child(False)
        return False

    def _cancel_timers(self):
        for attr in ("_pulse_id", "_hide_id"):
            tid = getattr(self, attr)
            if tid:
                GLib.source_remove(tid)
                setattr(self, attr, None)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class NawaOSStore(Gtk.Window):

    def __init__(self):
        super().__init__(title=_("NawaOS Store"))
        self.set_default_size(1180, 720)
        self.set_position(Gtk.WindowPosition.CENTER)
        try:
            self.set_icon_name("system-software-install")
        except Exception:
            pass
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)
        nawaos_theme.apply_theme(self, APP_CSS)

        # -- data ----------------------------------------------------------
        self.entries, self.sections, self.catalog_error = backend.load_catalog(
            (backend.SYSTEM_CATALOG, DEV_CATALOG))
        self.by_id = {e.id: e for e in self.entries}
        self.cards = {}                      # entry id -> [StoreCard, ...]
        self.current_view = VIEW_HOME
        self.search_text = ""
        self.source_filter = None
        self.flatpak_available = shutil.which("flatpak") is not None
        self.busy = {}                       # entry id -> status text
        self.updates = []                    # [UpdateItem]
        self.updates_checking = False
        self.updates_error = ""
        self.details_entry = None
        self.details_token = 0
        self._details_info = {}

        # -- worker queue (single operation at a time) ---------------------
        self._op_queue = queue.Queue()
        self._pending = []                   # operations not yet started
        self._current = None
        self._proc = None
        threading.Thread(target=self._worker_loop, daemon=True, name="store-ops").start()

        # -- UI -------------------------------------------------------------
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(root)
        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(body, True, True, 0)
        body.pack_start(self._build_sidebar(), False, False, 0)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(180)
        self.stack.add_named(self._build_browse_page(), PAGE_BROWSE)
        self.stack.add_named(self._build_details_page(), PAGE_DETAILS)
        self.stack.add_named(self._build_updates_page(), PAGE_UPDATES)
        body.pack_start(self.stack, True, True, 0)

        self.activity = ActivityPanel(self)
        root.pack_start(self.activity, False, False, 0)
        root.pack_start(self._build_statusbar(), False, False, 0)

        self.connect("key-press-event", self._on_key)
        self.connect("delete-event", self._on_delete)
        self.connect("destroy", Gtk.main_quit)
        self.show_all()

        if self.catalog_error:
            GLib.idle_add(self._show_catalog_error)
        else:
            self._populate_cards()
            self._start_state_detection()
        self._select_view(VIEW_HOME)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def _build_sidebar(self):
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        sidebar.get_style_context().add_class("sidebar")
        sidebar.set_size_request(236, -1)

        brand = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        for m in ("top", "bottom", "start", "end"):
            getattr(brand, "set_margin_" + m)(16)
        logo = Gtk.Label()
        logo.set_markup("<span weight='800' size='large'>%s</span>" %
                        GLib.markup_escape_text(_("NawaOS Store")))
        logo.set_halign(Gtk.Align.START)
        brand.pack_start(logo, False, False, 0)
        brand.pack_start(_label(_("Curated apps for your gaming desktop"), ("card-subtitle",),
                                wrap=True), False, False, 0)
        sidebar.pack_start(brand, False, False, 0)

        self.section_list = Gtk.ListBox()
        self.section_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.section_list.connect("row-selected", self._on_section_selected)
        rows = [(VIEW_HOME, _("Home"), "go-home-symbolic"),
                (VIEW_ALL, _("All Apps"), "view-grid-symbolic"),
                (VIEW_INSTALLED, _("Installed"), "emblem-ok-symbolic"),
                (VIEW_UPDATES, _("Updates"), "software-update-available-symbolic")]
        rows += [(s, _(s), SECTION_ICONS.get(s, GENERIC_ICON)) for s in self.sections]
        self._section_rows = {}
        for key, label, icon_name in rows:
            row = Gtk.ListBoxRow()
            row.filter_key = key
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.get_style_context().add_class("sidebar-row")
            box.pack_start(nawaos_theme.icon(icon_name, 16), False, False, 0)
            box.pack_start(_label(label), True, True, 0)
            count = Gtk.Label(label="")
            count.get_style_context().add_class(
                "count-pill" if key == VIEW_UPDATES else "section-count")
            count.set_no_show_all(key == VIEW_UPDATES)
            box.pack_start(count, False, False, 0)
            row.count_label = count
            row.add(box)
            self.section_list.add(row)
            self._section_rows[key] = row
        # Scrollable, so the window can be shorter than the section list
        # (Arabic rows are taller) without growing past the screen.
        list_scroll = Gtk.ScrolledWindow()
        list_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        list_scroll.add(self.section_list)
        sidebar.pack_start(list_scroll, True, True, 0)
        self._refresh_section_counts()
        return sidebar

    def _build_browse_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class("toolbar")
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.header_title = _label("", ("store-header-title",))
        self.header_subtitle = _label("", ("card-subtitle", "store-header-subtitle"))
        title_box.pack_start(self.header_title, False, False, 0)
        title_box.pack_start(self.header_subtitle, False, False, 0)
        header.pack_start(title_box, False, False, 4)
        header.pack_start(Gtk.Box(), True, True, 0)

        chips = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.source_chips = {}
        first = None
        for key, label in ((None, _("All")), ("apt", _("APT")), ("flatpak", _("Flatpak"))):
            chip = Gtk.RadioButton.new_with_label_from_widget(first, label)
            first = first or chip
            chip.set_mode(False)
            chip.get_style_context().add_class("filter-chip")
            chip.connect("toggled", self._on_source_chip, key)
            chips.pack_start(chip, False, False, 0)
            self.source_chips[key] = chip
        header.pack_start(chips, False, False, 0)

        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Search apps..."))
        self.search_entry.set_size_request(260, -1)
        self.search_entry.connect("search-changed", self._on_search_changed)
        header.pack_start(self.search_entry, False, False, 0)
        page.pack_start(header, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.browse_scroll = scroll
        wrapper = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for m in ("top", "bottom", "start", "end"):
            getattr(wrapper, "set_margin_" + m)(18)

        # Home: hero banner + featured grid (only visible in the Home view).
        self.home_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.home_box.set_no_show_all(True)
        hero = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hero.get_style_context().add_class("hero")
        hero_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        hero_text.pack_start(_label(_("Essentials for your gaming desktop"), ("hero-title",),
                                    wrap=True), False, False, 0)
        hero_text.pack_start(_label(_("Launchers, Proton tools, emulators and the overlay you "
                                      "will want on day one. Everything installs from Debian or "
                                      "Flathub with one click."), ("hero-text",), wrap=True),
                             False, False, 0)
        browse_btn = Gtk.Button(label=_("Browse all apps"))
        browse_btn.get_style_context().add_class("action-btn-primary")
        browse_btn.set_halign(Gtk.Align.START)
        browse_btn.connect("clicked", lambda _b: self._select_view(VIEW_ALL))
        hero_text.pack_start(browse_btn, False, False, 4)
        hero.pack_start(hero_text, True, True, 0)
        hero.pack_start(nawaos_theme.icon("applications-games-symbolic", 96), False, False, 8)
        self.home_box.pack_start(hero, False, False, 0)
        self.home_box.pack_start(_label(_("Featured"), ("home-section-title",)), False, False, 0)
        self.featured_box = self._new_flowbox()
        self.home_box.pack_start(self.featured_box, False, False, 0)
        self.home_installed_title = _label(_("Installed on this PC"), ("home-section-title",))
        self.home_box.pack_start(self.home_installed_title, False, False, 0)
        self.home_installed_box = self._new_flowbox()
        self.home_box.pack_start(self.home_installed_box, False, False, 0)
        hero.show_all()
        self.featured_box.show()
        self.home_installed_box.show()
        for child in self.home_box.get_children():
            child.show()
        wrapper.pack_start(self.home_box, False, False, 0)

        self.flowbox = self._new_flowbox()
        self.flowbox.set_filter_func(self._filter_card)
        self.flowbox.set_sort_func(self._sort_cards)
        wrapper.pack_start(self.flowbox, False, False, 0)

        self.empty_label = _label(_("No apps match your search."), ("empty-state",),
                                  halign=Gtk.Align.CENTER, xalign=0.5)
        self.empty_label.set_margin_top(48)
        self.empty_label.set_no_show_all(True)
        wrapper.pack_start(self.empty_label, False, False, 0)
        scroll.add(wrapper)
        page.pack_start(scroll, True, True, 0)
        return page

    def _new_flowbox(self):
        fb = Gtk.FlowBox()
        fb.set_valign(Gtk.Align.START)
        fb.set_halign(Gtk.Align.FILL)
        fb.set_selection_mode(Gtk.SelectionMode.NONE)
        fb.set_homogeneous(True)
        fb.set_min_children_per_line(1)
        fb.set_max_children_per_line(4)
        fb.set_row_spacing(14)
        fb.set_column_spacing(14)
        return fb

    def _build_details_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class("toolbar")
        back = Gtk.Button()
        back.get_style_context().add_class("action-btn")
        back_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        back_box.pack_start(nawaos_theme.icon(
            "go-previous-rtl-symbolic" if is_rtl() else "go-previous-symbolic", 16), False, False, 0)
        back_box.pack_start(Gtk.Label(label=_("Back")), False, False, 0)
        back.add(back_box)
        back.connect("clicked", lambda _b: self.go_back())
        header.pack_start(back, False, False, 0)
        self.details_header_title = _label("", ("store-header-title",),
                                           ellipsize=Pango.EllipsizeMode.END)
        header.pack_start(self.details_header_title, True, True, 0)
        page.pack_start(header, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.details_scroll = scroll
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        for m in ("top", "bottom", "start", "end"):
            getattr(content, "set_margin_" + m)(24)

        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        self.details_icon_slot = Gtk.Box()
        top.pack_start(self.details_icon_slot, False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.details_name = _label("", ("details-name",), wrap=True, selectable=True)
        text.pack_start(self.details_name, False, False, 0)
        self.details_summary = _label("", ("card-subtitle",), wrap=True)
        text.pack_start(self.details_summary, False, False, 0)
        self.details_chips = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        text.pack_start(self.details_chips, False, False, 4)
        top.pack_start(text, True, True, 0)
        actions = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        actions.set_valign(Gtk.Align.START)
        self.details_action = Gtk.Button(label=_("Install"))
        self.details_action.connect("clicked", self._on_details_action)
        actions.pack_start(self.details_action, False, False, 0)
        self.details_open = Gtk.Button(label=_("Open"))
        self.details_open.get_style_context().add_class("action-btn")
        self.details_open.set_no_show_all(True)
        self.details_open.connect("clicked", lambda _b: self.launch(self.details_entry))
        actions.pack_start(self.details_open, False, False, 0)
        self.details_status = _label("", ("card-subtitle",), halign=Gtk.Align.CENTER, xalign=0.5)
        actions.pack_start(self.details_status, False, False, 0)
        self.details_spinner = Gtk.Spinner()
        self.details_spinner.set_no_show_all(True)
        actions.pack_start(self.details_spinner, False, False, 0)
        top.pack_start(actions, False, False, 0)
        content.pack_start(top, False, False, 0)

        self.details_meta = Gtk.FlowBox()
        self.details_meta.set_selection_mode(Gtk.SelectionMode.NONE)
        self.details_meta.set_min_children_per_line(2)
        self.details_meta.set_max_children_per_line(6)
        self.details_meta.set_homogeneous(True)
        self.details_meta.set_row_spacing(10)
        self.details_meta.set_column_spacing(10)
        content.pack_start(self.details_meta, False, False, 0)

        self.details_shots_title = _label(_("Screenshots"), ("home-section-title",))
        self.details_shots_title.set_no_show_all(True)
        content.pack_start(self.details_shots_title, False, False, 0)
        self.details_shots_scroll = Gtk.ScrolledWindow()
        self.details_shots_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        self.details_shots_scroll.set_no_show_all(True)
        self.details_shots = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.details_shots_scroll.add(self.details_shots)
        self.details_shots.show()
        content.pack_start(self.details_shots_scroll, False, False, 0)

        content.pack_start(_label(_("About"), ("home-section-title",)), False, False, 0)
        self.details_body = _label("", ("details-body",), wrap=True, selectable=True)
        content.pack_start(self.details_body, False, False, 0)
        self.details_links = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        content.pack_start(self.details_links, False, False, 0)
        scroll.add(content)
        page.pack_start(scroll, True, True, 0)
        return page

    def _build_updates_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class("toolbar")
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        title_box.pack_start(_label(_("Updates"), ("store-header-title",)), False, False, 0)
        self.updates_subtitle = _label(_("Checking for updates…"),
                                       ("card-subtitle", "store-header-subtitle"))
        title_box.pack_start(self.updates_subtitle, False, False, 0)
        header.pack_start(title_box, False, False, 4)
        header.pack_start(Gtk.Box(), True, True, 0)
        self.updates_spinner = Gtk.Spinner()
        self.updates_spinner.set_no_show_all(True)
        header.pack_start(self.updates_spinner, False, False, 0)
        self.check_button = Gtk.Button(label=_("Check again"))
        self.check_button.get_style_context().add_class("action-btn")
        self.check_button.connect("clicked", lambda _b: self.check_updates())
        header.pack_start(self.check_button, False, False, 0)
        self.refresh_button = Gtk.Button(label=_("Refresh lists"))
        self.refresh_button.get_style_context().add_class("action-btn")
        self.refresh_button.set_tooltip_text(_("Refreshing package lists"))
        self.refresh_button.connect("clicked", lambda _b: self.queue_refresh())
        header.pack_start(self.refresh_button, False, False, 0)
        self.update_all_button = Gtk.Button(label=_("Update all"))
        self.update_all_button.get_style_context().add_class("action-btn-primary")
        self.update_all_button.connect("clicked", lambda _b: self.queue_update_all())
        self.update_all_button.set_sensitive(False)
        header.pack_start(self.update_all_button, False, False, 0)
        page.pack_start(header, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        wrapper = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for m in ("top", "bottom", "start", "end"):
            getattr(wrapper, "set_margin_" + m)(18)
        self.updates_list = Gtk.ListBox()
        self.updates_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self.updates_list.get_style_context().add_class("card")
        self.updates_list.set_no_show_all(True)
        wrapper.pack_start(self.updates_list, False, False, 0)
        self.updates_note = _label(_("Includes system packages that are not in the store catalog."),
                                   ("card-subtitle",))
        self.updates_note.set_no_show_all(True)
        wrapper.pack_start(self.updates_note, False, False, 0)
        self.updates_empty = _label(_("Checking for updates…"), ("empty-state",),
                                    halign=Gtk.Align.CENTER, xalign=0.5)
        self.updates_empty.set_margin_top(48)
        wrapper.pack_start(self.updates_empty, False, False, 0)
        scroll.add(wrapper)
        page.pack_start(scroll, True, True, 0)
        return page

    def _build_statusbar(self):
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.get_style_context().add_class("statusbar")
        self.status_message = _label(_("Ready."), ("card-subtitle",),
                                     ellipsize=Pango.EllipsizeMode.END)
        bar.pack_start(self.status_message, True, True, 0)
        return bar

    # ------------------------------------------------------------------
    # Cards, filtering, views
    # ------------------------------------------------------------------
    def _add_card(self, entry, flowbox):
        card = StoreCard(entry, self)
        self.cards.setdefault(entry.id, []).append(card)
        flowbox.add(card)
        return card

    def _populate_cards(self):
        for entry in self.entries:
            self._add_card(entry, self.flowbox)
            if entry.featured:
                self._add_card(entry, self.featured_box)
        self.flowbox.show_all()
        self.featured_box.show_all()
        self._refresh_visible_state()

    def _filter_card(self, child):
        entry = child.entry
        if self.current_view == VIEW_INSTALLED:
            if not entry.installed:
                return False
        elif self.current_view not in (VIEW_ALL, VIEW_HOME, VIEW_UPDATES):
            if entry.section != self.current_view:
                return False
        if self.source_filter and entry.source != self.source_filter:
            return False
        return backend.score_entry(entry, self.search_text) > 0

    def _sort_cards(self, child_a, child_b):
        if self.search_text:
            diff = (backend.score_entry(child_b.entry, self.search_text) -
                    backend.score_entry(child_a.entry, self.search_text))
            if diff:
                return diff
            return (child_a.entry.name.lower() > child_b.entry.name.lower()) - \
                   (child_a.entry.name.lower() < child_b.entry.name.lower())
        return self.entries.index(child_a.entry) - self.entries.index(child_b.entry)

    def _refresh_visible_state(self):
        """Re-run the filter and toggle the empty-state label."""
        home = self.current_view == VIEW_HOME and not self.search_text
        self.home_box.set_visible(home)
        self.flowbox.set_visible(not home)
        self.flowbox.invalidate_filter()
        self.flowbox.invalidate_sort()
        visible = sum(1 for c in self.flowbox.get_children() if self._filter_card(c))
        if home:
            self.empty_label.hide()
            self._refresh_home_installed()
        elif visible == 0:
            self.empty_label.set_text(_("No apps match your search.") if self.search_text
                                      else _("No apps in this view yet."))
            self.empty_label.show()
        else:
            self.empty_label.hide()
        self._update_header_labels(len(self.entries) if home else visible)

    def _refresh_home_installed(self):
        for child in self.home_installed_box.get_children():
            self.home_installed_box.remove(child)
            self.cards[child.entry.id].remove(child)
        installed = [e for e in self.entries if e.installed][:8]
        for entry in installed:
            self._add_card(entry, self.home_installed_box)
        self.home_installed_box.show_all()
        self.home_installed_title.set_visible(bool(installed))
        self.home_installed_box.set_visible(bool(installed))

    def _update_header_labels(self, count):
        titles = {VIEW_HOME: _("Home"), VIEW_ALL: _("All Apps"), VIEW_INSTALLED: _("Installed"),
                  VIEW_UPDATES: _("Updates")}
        title = titles.get(self.current_view) or _(self.current_view)
        self.header_title.set_text(title)
        self.header_subtitle.set_text(_count_text(count))

    def _refresh_section_counts(self):
        installed = sum(1 for e in self.entries if e.installed)
        for key, row in self._section_rows.items():
            if key == VIEW_HOME:
                row.count_label.set_text("")
            elif key == VIEW_ALL:
                row.count_label.set_text(str(len(self.entries)))
            elif key == VIEW_INSTALLED:
                row.count_label.set_text(str(installed))
            elif key == VIEW_UPDATES:
                row.count_label.set_text(str(len(self.updates)))
                row.count_label.set_visible(bool(self.updates))
            else:
                row.count_label.set_text(str(sum(1 for e in self.entries if e.section == key)))

    def _refresh_entry_widgets(self, entry):
        for card in self.cards.get(entry.id, ()):
            card.refresh_from_state()
        if self.details_entry is entry:
            self._refresh_details_state()

    def _show_view(self, key):
        self.current_view = key
        if key == VIEW_UPDATES:
            self.stack.set_visible_child_name(PAGE_UPDATES)
        else:
            self.stack.set_visible_child_name(PAGE_BROWSE)
            self._refresh_visible_state()
            self.browse_scroll.get_vadjustment().set_value(0)

    def _select_view(self, key):
        self.section_list.select_row(self._section_rows[key])

    def go_back(self):
        if self.stack.get_visible_child_name() == PAGE_DETAILS:
            self.details_entry = None
            self._show_view(self.current_view)

    # ------------------------------------------------------------------
    # Signal handlers
    # ------------------------------------------------------------------
    def _on_section_selected(self, _listbox, row):
        if row is None or not hasattr(self, "stack"):
            return
        self._show_view(row.filter_key)

    def _on_source_chip(self, chip, key):
        if chip.get_active() and hasattr(self, "flowbox"):
            self.source_filter = key
            self._refresh_visible_state()

    def _on_search_changed(self, entry):
        self.search_text = entry.get_text().strip().lower()
        # Typing anywhere turns the current page into a search over all apps.
        if self.stack.get_visible_child_name() != PAGE_BROWSE:
            self.details_entry = None
            self.stack.set_visible_child_name(PAGE_BROWSE)
        self._refresh_visible_state()

    def _apt_running(self):
        """True while an apt/dpkg operation (a root step) is in progress."""
        op = self._current
        return op is not None and op.root and not op.offline

    def _on_delete(self, *_args):
        # Quitting closes the output pipe: apt/dpkg would die of SIGPIPE in
        # the middle of unpacking. Refuse while a root operation runs.
        if not self._apt_running():
            return False
        dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                   message_type=Gtk.MessageType.WARNING,
                                   buttons=Gtk.ButtonsType.NONE,
                                   text=_("An installation or update is running"))
        dialog.format_secondary_text(
            _("Closing the Store now would interrupt it and could leave packages half-installed. "
              "Wait until it finishes, then close the Store."))
        dialog.add_button(_("_Close"), Gtk.ResponseType.CLOSE)
        dialog.connect("response", lambda d, _r: d.destroy())
        dialog.show_all()
        return True

    def _on_key(self, _widget, event):
        ctrl = event.state & Gdk.ModifierType.CONTROL_MASK
        alt = event.state & Gdk.ModifierType.MOD1_MASK
        if ctrl and event.keyval in (Gdk.KEY_f, Gdk.KEY_F):
            self.stack.set_visible_child_name(PAGE_BROWSE)
            self.search_entry.grab_focus()
            return True
        if event.keyval == Gdk.KEY_Escape:
            if self.stack.get_visible_child_name() == PAGE_DETAILS:
                self.go_back()
                return True
            if self.search_entry.get_text():
                self.search_entry.set_text("")
                return True
        if alt and event.keyval in (Gdk.KEY_Left, Gdk.KEY_Right):
            self.go_back()
            return True
        return False

    # ------------------------------------------------------------------
    # Details page
    # ------------------------------------------------------------------
    def show_details(self, entry):
        self.details_entry = entry
        self.details_token += 1
        self._details_info = {}
        token = self.details_token
        self.details_header_title.set_text(entry.display_name())
        for child in self.details_icon_slot.get_children():
            self.details_icon_slot.remove(child)
        self.details_icon_slot.pack_start(_app_icon(entry, 96), False, False, 0)
        self.details_icon_slot.show_all()
        self.details_name.set_text(entry.display_name())
        self.details_summary.set_text(entry.display_description())
        for child in self.details_chips.get_children():
            self.details_chips.remove(child)
        self.details_chips.pack_start(_badge(entry), False, False, 0)
        if not entry.is_gui:
            chip = Gtk.Label(label=_("Command-line tool"))
            chip.get_style_context().add_class("chip")
            self.details_chips.pack_start(chip, False, False, 0)
        for tag in entry.tags:
            chip = Gtk.Label(label=_(tag))
            chip.get_style_context().add_class("chip")
            self.details_chips.pack_start(chip, False, False, 0)
        self.details_chips.show_all()
        self.details_body.set_text(_("Loading details…"))
        for child in self.details_shots.get_children():
            self.details_shots.remove(child)
        self.details_shots_title.hide()
        self.details_shots_scroll.hide()
        for child in self.details_links.get_children():
            self.details_links.remove(child)
        if entry.homepage:
            link = Gtk.LinkButton.new_with_label(entry.homepage, _("Website"))
            link.get_style_context().add_class("link-btn")
            self.details_links.pack_start(link, False, False, 0)
        self.details_links.show_all()
        self._fill_meta(entry, {})
        self._refresh_details_state()
        self.stack.set_visible_child_name(PAGE_DETAILS)
        self.details_scroll.get_vadjustment().set_value(0)
        threading.Thread(target=self._load_details, args=(entry, token), daemon=True).start()

    def _fill_meta(self, entry, info):
        for child in self.details_meta.get_children():
            self.details_meta.remove(child)
        if entry.source == "apt":
            source = "%s · %s" % (_("Debian package"), _ltr(entry.pkg))
        else:
            source = "%s · %s" % (_("Flathub app"), _ltr(entry.pkg))
        available = entry.candidate_version or info.get("version") or info.get("Version") or ""
        rows = [
            (_("Installed version"), _ltr(entry.installed_version) or _("Not installed")),
            (_("Available version"), _ltr(available) or "—"),
            (_("Download size"), backend.format_size(info.get("download_bytes")) or "—"),
            (_("Installed size"), backend.format_size(info.get("installed_bytes")) or "—"),
            (_("Developer"), info.get("developer") or entry.developer or "—"),
            (_("License"), info.get("license") or entry.license or "—"),
            (_("Source"), source),
        ]
        if entry.source == "flatpak":
            rows = [r for r in rows if r[0] not in (_("Download size"), _("Installed size"))]
        for key, value in rows:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            box.get_style_context().add_class("card")
            box.pack_start(_label(key, ("details-meta-key",)), False, False, 0)
            box.pack_start(_label(value, ("details-meta-value",), wrap=True, selectable=True),
                           False, False, 0)
            child = Gtk.FlowBoxChild()
            child.set_can_focus(False)
            child.add(box)
            self.details_meta.add(child)
        self.details_meta.show_all()

    def _load_details(self, entry, token):
        if entry.source == "apt":
            info = backend.apt_details(entry.pkg)
        else:
            info = backend.flathub_metadata(entry.pkg)
        GLib.idle_add(self._apply_details, entry, token, info)
        for url in info.get("screenshots", [])[:6]:
            path = backend.cached_image(url)
            if path:
                GLib.idle_add(self._add_screenshot, token, path)

    def _apply_details(self, entry, token, info):
        if token != self.details_token:
            return False
        self._details_info = info
        description = info.get("description") or ""
        if not description:
            description = entry.display_description()
        self.details_body.set_text(description)
        if info.get("summary") and get_language() != "ar":
            self.details_summary.set_text(info["summary"])
        self._fill_meta(entry, info)
        return False

    def _add_screenshot(self, token, path):
        if token != self.details_token:
            return False
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 560, 320, True)
        except GLib.GError:
            return False
        image = Gtk.Image.new_from_pixbuf(pixbuf)
        image.get_style_context().add_class("screenshot")
        self.details_shots.pack_start(image, False, False, 0)
        image.show()
        self.details_shots_title.show()
        self.details_shots_scroll.show()
        return False

    def _refresh_details_state(self):
        entry = self.details_entry
        if entry is None:
            return
        ctx = self.details_action.get_style_context()
        for cls in ("action-btn-primary", "destructive"):
            ctx.remove_class(cls)
        busy = self.busy_text(entry)
        if busy:
            self.details_status.set_text(busy)
            self.details_action.set_sensitive(False)
            self.details_open.hide()
            self.details_spinner.show()
            self.details_spinner.start()
            return
        self.details_spinner.stop()
        self.details_spinner.hide()
        if entry.installed:
            self.details_action.set_label(_("Remove"))
            ctx.add_class("destructive")
            self.details_action.set_sensitive(True)
            self.details_open.set_visible(entry.is_gui)
            text = _("Installed")
            if entry.has_update:
                text = _("Update available: %s") % _ltr(entry.update_version)
            self.details_status.set_text(text)
        else:
            self.details_action.set_label(_("Install"))
            ctx.add_class("action-btn-primary")
            self.details_action.set_sensitive(entry.state == backend.STATE_ABSENT and
                                              (entry.source == "apt" or self.flatpak_available))
            self.details_open.hide()
            self.details_status.set_text(_("Not installed") if entry.state == backend.STATE_ABSENT
                                         else _("Checking..."))
        self._fill_meta(entry, self._details_info)

    def _on_details_action(self, _button):
        entry = self.details_entry
        if entry is None or entry.state == backend.STATE_UNKNOWN:
            return
        self.queue_entry(entry, "remove" if entry.installed else "install")

    # ------------------------------------------------------------------
    # Launching
    # ------------------------------------------------------------------
    def launch(self, entry):
        if entry is None:
            return
        self.status_message.set_text(_("Opening %s…") % entry.display_name())

        def worker():
            desktop_id = backend.find_desktop_id(entry)
            argv = backend.build_launch_command(entry, desktop_id)
            ok = False
            if argv:
                try:
                    subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, start_new_session=True)
                    ok = True
                except OSError:
                    ok = False
            if not ok:
                GLib.idle_add(self.status_message.set_text,
                              _("Could not open %s.") % entry.display_name())
        threading.Thread(target=worker, daemon=True).start()

    # ------------------------------------------------------------------
    # Installed-state detection and update checks (background threads)
    # ------------------------------------------------------------------
    def _start_state_detection(self):
        def worker():
            states = backend.detect_installed_bulk(self.entries)
            GLib.idle_add(self._apply_detected_states, states)
            items, errors = backend.list_updates(self.entries)
            GLib.idle_add(self._apply_updates, items, errors)
        self.updates_checking = True
        self.updates_spinner.show()
        self.updates_spinner.start()
        threading.Thread(target=worker, daemon=True, name="store-detect").start()

    def _apply_detected_states(self, states):
        for entry in self.entries:
            state, installed_version, candidate = states.get(
                entry.id, (backend.STATE_ABSENT, "", ""))
            entry.state = state
            entry.installed_version = installed_version
            entry.candidate_version = candidate
            if entry.id not in self.busy:
                self._refresh_entry_widgets(entry)
        self._refresh_section_counts()
        self._refresh_visible_state()
        return False

    def check_updates(self):
        if self.updates_checking:
            return
        self.updates_checking = True
        self.updates_spinner.show()
        self.updates_spinner.start()
        self.check_button.set_sensitive(False)
        self.updates_subtitle.set_text(_("Checking for updates…"))

        def worker():
            items, errors = backend.list_updates(self.entries)
            GLib.idle_add(self._apply_updates, items, errors)
        threading.Thread(target=worker, daemon=True, name="store-updates").start()

    def _apply_updates(self, items, errors):
        self.updates_checking = False
        self.updates_spinner.stop()
        self.updates_spinner.hide()
        self.check_button.set_sensitive(True)
        self.updates = items
        self.updates_error = errors[0][1] if errors else ""
        for entry in self.entries:
            entry.update_version = ""
        for item in items:
            if item.entry is not None:
                item.entry.update_version = item.new or "✓"
        for entry in self.entries:
            if entry.id not in self.busy:
                self._refresh_entry_widgets(entry)
        self._refresh_section_counts()
        self._render_updates()
        return False

    def _render_updates(self):
        for child in self.updates_list.get_children():
            self.updates_list.remove(child)
        n = len(self.updates)
        self.update_all_button.set_sensitive(n > 0 and self._current is None)
        if n == 0:
            self.updates_list.hide()
            self.updates_note.hide()
            if self.updates_error:
                self.updates_empty.set_text(_("Could not check for updates: %s") %
                                            self.updates_error.splitlines()[-1][:120])
                self.updates_subtitle.set_text(_("Update failed"))
            else:
                self.updates_empty.set_text(_("Everything is up to date."))
                self.updates_subtitle.set_text(_("Everything is up to date."))
            self.updates_empty.show()
            return
        self.updates_empty.hide()
        self.updates_subtitle.set_text(_("%d update available") % n if n == 1
                                       else _("%d updates available") % n)
        for item in self.updates:
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            box.get_style_context().add_class("update-row")
            if item.entry is not None:
                box.pack_start(_app_icon(item.entry, 32), False, False, 0)
            else:
                box.pack_start(nawaos_theme.icon("package-x-generic-symbolic", 32), False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            text.pack_start(_label(item.display_name(), ("card-title",),
                                   ellipsize=Pango.EllipsizeMode.END), False, False, 0)
            versions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            if item.old:
                versions.pack_start(_label(_ltr(item.old), ("card-subtitle",)), False, False, 0)
                versions.pack_start(_label("→", ("version-arrow",)), False, False, 0)
            versions.pack_start(_label(_ltr(item.new) or "—", ("status-ok",)), False, False, 0)
            text.pack_start(versions, False, False, 0)
            box.pack_start(text, True, True, 0)
            badge = Gtk.Label(label=_("APT") if item.source == "apt" else _("Flatpak"))
            badge.get_style_context().add_class("badge-apt" if item.source == "apt"
                                                else "badge-flatpak")
            badge.set_valign(Gtk.Align.CENTER)
            box.pack_start(badge, False, False, 0)
            btn = Gtk.Button(label=_("Update"))
            btn.get_style_context().add_class("action-btn")
            btn.get_style_context().add_class("small-btn")
            btn.set_valign(Gtk.Align.CENTER)
            btn.set_sensitive(self._current is None)
            btn.connect("clicked", lambda _b, it=item: self.queue_update_item(it))
            box.pack_start(btn, False, False, 0)
            row.add(box)
            self.updates_list.add(row)
        self.updates_list.show_all()
        self.updates_list.show()
        self.updates_note.set_visible(any(i.entry is None for i in self.updates))

    # ------------------------------------------------------------------
    # Operation queue
    # ------------------------------------------------------------------
    def busy_text(self, entry):
        return self.busy.get(entry.id, "")

    def queue_entry(self, entry, action):
        if entry.id in self.busy:
            return
        name = entry.display_name()
        title = _("Installing %s") % name if action == "install" else _("Removing %s") % name
        op = Operation("entry-" + action, title, [backend.build_action_command(entry, action)],
                       entry=entry, needs_network=(action == "install"),
                       root=(entry.source == "apt"))
        self.busy[entry.id] = _("Queued")
        self._refresh_entry_widgets(entry)
        self._enqueue(op)

    def queue_refresh(self):
        op = Operation("refresh", _("Refreshing package lists"), [backend.build_refresh_command()],
                       needs_network=True, root=True)
        self._enqueue(op)

    def queue_update_all(self):
        steps = [argv for _k, argv in backend.build_update_all_commands(self.flatpak_available)]
        op = Operation("update-all", _("Updating all apps"), steps, needs_network=True, root=True)
        for item in self.updates:
            if item.entry is not None:
                self.busy[item.entry.id] = _("Queued")
                self._refresh_entry_widgets(item.entry)
        self._enqueue(op)

    def queue_update_item(self, item):
        if item.entry is not None and item.entry.id in self.busy:
            return
        op = Operation("update-item", _("Updating %s") % item.display_name(),
                       [backend.build_update_command(item)], entry=item.entry, item=item,
                       needs_network=True, root=(item.source == "apt"))
        if item.entry is not None:
            self.busy[item.entry.id] = _("Queued")
            self._refresh_entry_widgets(item.entry)
        self._enqueue(op)

    def _enqueue(self, op):
        self._pending.append(op)
        self._op_queue.put(op)
        self.update_all_button.set_sensitive(False)
        self.refresh_button.set_sensitive(False)
        if self._current is not None:
            self.activity.set_queue(len(self._pending))

    def _worker_loop(self):
        while True:
            op = self._op_queue.get()
            try:
                self._run_operation(op)
            finally:
                self._op_queue.task_done()

    def _run_operation(self, op):
        GLib.idle_add(self._begin_operation, op)
        if op.needs_network and not backend.is_online():
            op.offline = True
            op.rc = 1
            GLib.idle_add(self._finish_operation, op)
            return
        for argv in op.steps:
            op.log.append("$ " + " ".join(argv) + "\n")
            GLib.idle_add(self.activity.append_line, op.log[-1])
            try:
                self._proc = subprocess.Popen(
                    argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL, text=True, errors="replace", bufsize=1,
                    env=backend.task_env(), start_new_session=True)
            except FileNotFoundError:
                op.log.append(_("Command not found: %s") % argv[0] + "\n")
                op.rc = 127
                break
            except OSError as exc:
                op.log.append("%s\n" % exc)
                op.rc = 1
                break
            for line in self._proc.stdout:
                fraction = backend.progress_fraction(line)
                if fraction is not None:
                    GLib.idle_add(self.activity.set_fraction, fraction)
                if backend.is_status_line(line):
                    continue
                op.log.append(line)
                GLib.idle_add(self.activity.append_line, line)
            op.rc = self._proc.wait()
            self._proc = None
            if op.rc != 0 or op.cancelled:
                break
        if op.entry is not None:
            installed, version = backend.check_entry_installed(op.entry)
            op.entry.state = backend.STATE_INSTALLED if installed else backend.STATE_ABSENT
            op.entry.installed_version = version if installed else ""
        GLib.idle_add(self._finish_operation, op)

    def _begin_operation(self, op):
        self._current = op
        if op in self._pending:
            self._pending.remove(op)
        self.activity.start(op, len(self._pending))
        self.status_message.set_text(op.title)
        if op.entry is not None:
            self.busy[op.entry.id] = op.title
            self._refresh_entry_widgets(op.entry)
        elif op.kind == "update-all":
            for item in self.updates:
                if item.entry is not None:
                    self.busy[item.entry.id] = op.title
                    self._refresh_entry_widgets(item.entry)
        return False

    def cancel_current(self):
        op = self._current
        proc = self._proc
        if op is None or proc is None or proc.poll() is not None:
            return
        # Only report "Cancelled" when the signal was really delivered: once
        # pkexec has authenticated, apt runs as root and killpg gets EPERM.
        result = nawaos_taskrunner.signal_group(proc.pid)
        if result == "sent":
            op.cancelled = True
            self.activity.stopping()
        elif result == "denied":
            self.activity.cannot_cancel()
            self.status_message.set_text(
                _("This task runs as administrator and cannot be cancelled. Wait for it to finish."))

    def _finish_operation(self, op):
        self._current = None
        more = len(self._pending)
        touched = []
        if op.entry is not None:
            touched.append(op.entry)
        if op.kind == "update-all":
            touched.extend(i.entry for i in self.updates if i.entry is not None)
        for entry in touched:
            self.busy.pop(entry.id, None)
            self._refresh_entry_widgets(entry)
        self._refresh_section_counts()
        self._refresh_visible_state()
        if not more:
            self.refresh_button.set_sensitive(True)
            self.update_all_button.set_sensitive(bool(self.updates))

        ok = op.rc == 0 and not op.cancelled and not op.offline
        auth_cancelled = op.root and op.rc in (126, 127) and not op.cancelled
        name = op.entry.display_name() if op.entry is not None else ""
        if ok:
            message = {
                "entry-install": _("%s was installed.") % name,
                "entry-remove": _("%s was removed.") % name,
                "update-item": _("%s was updated.") % (name or (op.item.name if op.item else "")),
                "refresh": _("Package lists refreshed."),
                "update-all": _("All apps are up to date."),
            }.get(op.kind, _("Completed"))
        elif op.cancelled:
            message = _("Cancelled.")
        elif op.offline:
            message = _("No internet connection")
        elif auth_cancelled:
            message = _("Authentication was cancelled.")
        else:
            message = {
                "entry-install": _("Install failed"),
                "entry-remove": _("Removal failed"),
            }.get(op.kind, _("Update failed"))
            if name:
                message = "%s: %s" % (message, name)
        self.status_message.set_text(message)
        self.activity.finish("success" if ok else
                             "cancelled" if (op.cancelled or auth_cancelled) else "failed",
                             message, more)

        if ok and not self.is_active():
            nawaos_notify.notify(_("NawaOS Store"), message, category="update", source="Store")
        if op.offline:
            self._show_offline_dialog(op)
        elif not ok and not op.cancelled and not auth_cancelled:
            tail = backend.output_tail("".join(op.log[-20:]))
            if op.kind == "entry-install" and backend.looks_like_network_error(tail):
                self._show_offline_dialog(op)
            else:
                self._show_failure_dialog(message, op.rc, tail)
            if not self.is_active():
                nawaos_notify.notify(_("NawaOS Store"), message, category="update",
                                     urgency="critical", source="Store")
        if ok and op.kind in ("refresh", "update-all", "update-item"):
            self.check_updates()
        elif ok and op.kind.startswith("entry-") and op.entry is not None and op.entry.has_update:
            self.check_updates()
        return False

    # ------------------------------------------------------------------
    # Dialogs
    # ------------------------------------------------------------------
    def _show_offline_dialog(self, op):
        dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                   message_type=Gtk.MessageType.WARNING,
                                   buttons=Gtk.ButtonsType.NONE,
                                   text=_("No internet connection"))
        if op.kind == "entry-install" and op.entry is not None:
            body = _("%s could not be installed because no network is reachable. Connect to "
                     "Wi-Fi or plug in a cable, then try again.") % op.entry.display_name()
        else:
            body = _("Updates need a network connection. Connect to Wi-Fi or plug in a "
                     "cable, then try again.")
        dialog.format_secondary_text(body)
        dialog.add_button(_("_Cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(_("_Retry"), Gtk.ResponseType.ACCEPT)
        dialog.set_default_response(Gtk.ResponseType.ACCEPT)

        def on_response(d, response):
            d.destroy()
            if response != Gtk.ResponseType.ACCEPT:
                return
            if op.kind == "entry-install":
                self.queue_entry(op.entry, "install")
            elif op.kind == "refresh":
                self.queue_refresh()
            elif op.kind == "update-all":
                self.queue_update_all()
            elif op.kind == "update-item" and op.item is not None:
                self.queue_update_item(op.item)
        dialog.connect("response", on_response)
        dialog.show_all()

    def _show_failure_dialog(self, title, rc, tail):
        dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                   message_type=Gtk.MessageType.ERROR,
                                   buttons=Gtk.ButtonsType.NONE, text=title)
        dialog.add_button(_("_Close"), Gtk.ResponseType.CLOSE)
        body = _("Exit code: %d") % rc
        if tail:
            body += "\n\n%s\n%s" % (_("Details (last lines of output):"), tail)
        dialog.format_secondary_text(body)
        dialog.connect("response", lambda d, _r: d.destroy())
        dialog.show_all()

    def _show_catalog_error(self):
        dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                   message_type=Gtk.MessageType.ERROR,
                                   buttons=Gtk.ButtonsType.CLOSE, text=_("Catalog error"))
        dialog.format_secondary_text(self.catalog_error or _("The store catalog could not be loaded."))
        dialog.connect("response", lambda d, _r: d.destroy())
        dialog.show_all()
        self.status_message.set_text(_("Catalog error"))
        return False


# ---------------------------------------------------------------------------
def main():
    NawaOSStore()
    Gtk.main()


if __name__ == "__main__":
    main()
