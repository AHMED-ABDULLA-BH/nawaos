#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Control Panel
A central hub for system settings and gaming tools
Version 2.0

Developed by: Ahmed Abdulla
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Gio, GdkPixbuf
import subprocess
import os
import sys
import json
import shlex
import shutil
import threading
import urllib.request
from pathlib import Path


# Release info shared by all NawaOS apps (nawaos-common/nawaos_release.py).
try:
    import nawaos_release
except ImportError:
    nawaos_release = None

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402
import nawaos_theme  # noqa: E402
import nawaos_taskrunner  # noqa: E402
from nawaos_notify import notify_system, notify_gaming  # noqa: E402


APP_NAME = "nawaos-control-panel"

# ---------------------------------------------------------------------------
# Built-in Arabic strings. Every user-visible string in this file goes
# through _() with this dictionary as the source for Arabic.
# ---------------------------------------------------------------------------
AR_STRINGS = {
    # -- window chrome / navigation -----------------------------------------
    "NawaOS Control Panel": "\u0644\u0648\u062d\u0629 \u062a\u062d\u0643\u0645 NawaOS",
    "Control Panel": "\u0644\u0648\u062d\u0629 \u0627\u0644\u062a\u062d\u0643\u0645",
    "Search settings\u2026": "\u0627\u0628\u062d\u062b \u0641\u064a \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a\u2026",
    "Gaming": "\u0627\u0644\u0623\u0644\u0639\u0627\u0628",
    "Power": "\u0627\u0644\u0637\u0627\u0642\u0629",
    "Network": "\u0627\u0644\u0634\u0628\u0643\u0629",
    "Security": "\u0627\u0644\u0623\u0645\u0627\u0646",
    "Storage": "\u0627\u0644\u062a\u062e\u0632\u064a\u0646",
    "Peripherals": "\u0627\u0644\u0623\u062c\u0647\u0632\u0629 \u0627\u0644\u0637\u0631\u0641\u064a\u0629",
    "Drivers": "\u0627\u0644\u062a\u0639\u0631\u064a\u0641\u0627\u062a",
    "Startup": "\u0628\u062f\u0621 \u0627\u0644\u062a\u0634\u063a\u064a\u0644",
    "Language": "\u0627\u0644\u0644\u063a\u0629",
    "Monitor": "\u0627\u0644\u0645\u0631\u0627\u0642\u0628\u0629",
    "Backup": "\u0627\u0644\u0646\u0633\u062e \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a",
    "Appearance": "\u0627\u0644\u0645\u0638\u0647\u0631",
    "Updates": "\u0627\u0644\u062a\u062d\u062f\u064a\u062b\u0627\u062a",
    "About": "\u062d\u0648\u0644",

    # -- gaming page ---------------------------------------------------------

    # -- gaming dialogs ------------------------------------------------------

    # -- power page ----------------------------------------------------------
    "Power Profiles": "\u0623\u0648\u0636\u0627\u0639 \u0627\u0644\u0637\u0627\u0642\u0629",
    "Gaming Mode": "\u0648\u0636\u0639 \u0627\u0644\u0623\u0644\u0639\u0627\u0628",
    "Maximum performance for gaming": "\u0623\u0642\u0635\u0649 \u0623\u062f\u0627\u0621 \u0644\u0644\u0623\u0644\u0639\u0627\u0628",
    "Balanced": "\u0645\u062a\u0648\u0627\u0632\u0646",
    "Balance between performance and battery": "\u062a\u0648\u0627\u0632\u0646 \u0628\u064a\u0646 \u0627\u0644\u0623\u062f\u0627\u0621 \u0648\u0639\u0645\u0631 \u0627\u0644\u0628\u0637\u0627\u0631\u064a\u0629",
    "Battery Saver": "\u062a\u0648\u0641\u064a\u0631 \u0627\u0644\u0628\u0637\u0627\u0631\u064a\u0629",
    "Maximum battery life": "\u0623\u0637\u0648\u0644 \u0639\u0645\u0631 \u0644\u0644\u0628\u0637\u0627\u0631\u064a\u0629",
    "Apply": "\u062a\u0637\u0628\u064a\u0642",
    "Current governor: detecting...": "\u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0627\u0644\u062d\u0627\u0644\u064a: \u062c\u0627\u0631\u064d \u0627\u0644\u0643\u0634\u0641...",
    "Current governor:": "\u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0627\u0644\u062d\u0627\u0644\u064a:",
    "Unable to detect power profile": "\u062a\u0639\u0630\u0651\u0631 \u0627\u0644\u0643\u0634\u0641 \u0639\u0646 \u0648\u0636\u0639 \u0627\u0644\u0637\u0627\u0642\u0629",
    "Active:": "\u0627\u0644\u0646\u0634\u0637:",
    "NawaOS Power": "\u0637\u0627\u0642\u0629 NawaOS",
    "%s activated!": "\u062a\u0645 \u062a\u0641\u0639\u064a\u0644 %s!",
    "Failed to apply profile (authentication cancelled or not permitted).":
        "\u0641\u0634\u0644 \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0648\u0636\u0639 (\u0623\u064f\u0644\u063a\u064a\u062a \u0627\u0644\u0645\u0635\u0627\u062f\u0642\u0629 \u0623\u0648 \u063a\u064a\u0631 \u0645\u0633\u0645\u0648\u062d \u0628\u0647\u0627).",

    # -- network page --------------------------------------------------------
    "Network & DNS": "\u0627\u0644\u0634\u0628\u0643\u0629 \u0648DNS",
    "Select the fastest DNS for gaming": "\u0627\u062e\u062a\u0631 \u0623\u0633\u0631\u0639 \u062e\u0627\u062f\u0645 DNS \u0644\u0644\u0623\u0644\u0639\u0627\u0628",
    "Cloudflare Gaming": "Cloudflare \u0644\u0644\u0623\u0644\u0639\u0627\u0628",
    "Fastest for gaming": "\u0627\u0644\u0623\u0633\u0631\u0639 \u0644\u0644\u0623\u0644\u0639\u0627\u0628",
    "Google DNS": "Google DNS",
    "Reliable & fast": "\u0645\u0648\u062b\u0648\u0642 \u0648\u0633\u0631\u064a\u0639",
    "OpenDNS": "OpenDNS",
    "Low latency": "\u0632\u0645\u0646 \u0627\u0633\u062a\u062c\u0627\u0628\u0629 \u0645\u0646\u062e\u0641\u0636",
    "Quad9 Secure": "Quad9 \u0627\u0644\u0622\u0645\u0646",
    "Security focused": "\u064a\u0631\u0643\u0651\u0632 \u0639\u0644\u0649 \u0627\u0644\u0623\u0645\u0627\u0646",
    "AdGuard DNS": "AdGuard DNS",
    "Blocks ads": "\u064a\u062d\u062c\u0628 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
    "System Default": "\u0627\u0641\u062a\u0631\u0627\u0636\u064a \u0627\u0644\u0646\u0638\u0627\u0645",
    "Use DHCP": "\u0627\u0633\u062a\u062e\u062f\u0627\u0645 DHCP",
    "Click 'Test All' to find the fastest DNS":
        "\u0627\u0636\u063a\u0637 \"\u0627\u062e\u062a\u0628\u0627\u0631 \u0627\u0644\u0643\u0644\" \u0644\u0645\u0639\u0631\u0641\u0629 \u0623\u0633\u0631\u0639 \u062e\u0627\u062f\u0645 DNS",
    "Test All": "\u0627\u062e\u062a\u0628\u0627\u0631 \u0627\u0644\u0643\u0644",
    "Apply DNS": "\u062a\u0637\u0628\u064a\u0642 DNS",
    "Selected: %s": "\u0627\u0644\u0645\u062d\u062f\u062f: %s",
    "Testing DNS servers...": "\u062c\u0627\u0631\u064d \u0627\u062e\u062a\u0628\u0627\u0631 \u062e\u0648\u0627\u062f\u0645 DNS...",
    "Auto": "\u062a\u0644\u0642\u0627\u0626\u064a",
    "Error": "\u062e\u0637\u0623",
    "Fastest: %s (%dms)": "\u0627\u0644\u0623\u0633\u0631\u0639: %s (%d ms)",
    "Please select a DNS server first": "\u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u062e\u062a\u064a\u0627\u0631 \u062e\u0627\u062f\u0645 DNS \u0623\u0648\u0644\u0627\u064b",
    "No active network connection found.": "\u0644\u0627 \u064a\u0648\u062c\u062f \u0627\u062a\u0635\u0627\u0644 \u0634\u0628\u0643\u0629 \u0646\u0634\u0637.",
    "DNS reset to automatic (DHCP) on: %s":
        "\u0623\u064f\u0639\u064a\u062f \u0636\u0628\u0637 DNS \u0625\u0644\u0649 \u0627\u0644\u062a\u0644\u0642\u0627\u0626\u064a (DHCP) \u0639\u0644\u0649: %s",
    "DNS changed to %s on: %s\n\nPrimary: %s\nSecondary: %s":
        "\u062a\u0645 \u062a\u063a\u064a\u064a\u0631 DNS \u0625\u0644\u0649 %s \u0639\u0644\u0649: %s\n\n\u0627\u0644\u0623\u0633\u0627\u0633\u064a: %s\n\u0627\u0644\u062b\u0627\u0646\u0648\u064a: %s",
    "DNS change did not fully apply (authentication cancelled, or a "
    "connection failed to reactivate).":
        "\u0644\u0645 \u064a\u064f\u0637\u0628\u0651\u0642 \u062a\u063a\u064a\u064a\u0631 DNS \u0628\u0627\u0644\u0643\u0627\u0645\u0644 (\u0623\u064f\u0644\u063a\u064a\u062a \u0627\u0644\u0645\u0635\u0627\u062f\u0642\u0629 \u0623\u0648 \u062a\u0639\u0630\u0651\u0631 "
        "\u0625\u0639\u0627\u062f\u0629 \u062a\u0641\u0639\u064a\u0644 \u0623\u062d\u062f \u0627\u0644\u0627\u062a\u0635\u0627\u0644\u0627\u062a).",
    "Error: %s": "\u062e\u0637\u0623: %s",

    # -- appearance page -----------------------------------------------------
    "NawaOS Default": "NawaOS \u0627\u0644\u0627\u0641\u062a\u0631\u0627\u0636\u064a",
    "NawaOS Light": "NawaOS \u0627\u0644\u0641\u0627\u062a\u062d",
    "Cyber Neon": "\u0646\u064a\u0648\u0646 \u0633\u064a\u0628\u0631\u0627\u0646\u064a",
    "Matrix Green": "\u0623\u062e\u0636\u0631 \u0645\u0627\u062a\u0631\u064a\u0643\u0633",
    "Blood Red": "\u0623\u062d\u0645\u0631 \u062f\u0645\u0648\u064a",
    "Ocean Blue": "\u0623\u0632\u0631\u0642 \u0645\u062d\u064a\u0637\u064a",
    "Sunset Orange": "\u0628\u0631\u062a\u0642\u0627\u0644\u064a \u0627\u0644\u063a\u0631\u0648\u0628",
    "Click a theme to select, then Apply":
        "\u0627\u0636\u063a\u0637 \u0639\u0644\u0649 \u0633\u0645\u0629 \u0644\u0627\u062e\u062a\u064a\u0627\u0631\u0647\u0627 \u062b\u0645 \u0627\u0636\u063a\u0637 \u062a\u0637\u0628\u064a\u0642",
    "Apply Theme": "\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0633\u0645\u0629",
    "Selected:": "\u0627\u0644\u0645\u062d\u062f\u062f:",
    "Theme": "\u0627\u0644\u0633\u0645\u0629",
    "Please select a theme first": "\u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u062e\u062a\u064a\u0627\u0631 \u0633\u0645\u0629 \u0623\u0648\u0644\u0627\u064b",
    "Theme \"%s\" applied!": "\u062a\u0645 \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0633\u0645\u0629 \"%s\"!",
    "Theme '%s' applied!\nSome changes may need logout.":
        "\u062a\u0645 \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0633\u0645\u0629 '%s'!\n\u0642\u062f \u062a\u062d\u062a\u0627\u062c \u0628\u0639\u0636 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a \u0625\u0644\u0649 \u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062e\u0631\u0648\u062c.",

    # -- drivers page --------------------------------------------------------
    "No GPU detected": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0643\u062a\u0634\u0627\u0641 \u0628\u0637\u0627\u0642\u0629 \u0631\u0633\u0648\u0645\u064a\u0629",
    "GPU Information": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0631\u0633\u0648\u0645\u064a\u0627\u062a",
    "NVIDIA Driver Manager": "\u0645\u062f\u064a\u0631 \u062a\u0639\u0631\u064a\u0641 NVIDIA",
    "Install the proprietary NVIDIA driver for the best gaming performance.\n"
    "NawaOS 2.2 takes it from NVIDIA's own repository (595 branch, open kernel\n"
    "modules), which covers GeForce RTX 20 / GTX 16 and newer. Note: with Secure\n"
    "Boot enabled the DKMS-built module must be signed and its MOK key enrolled.":
        "ثبّت تعريف NVIDIA الاحتكاري للحصول على أفضل أداء في الألعاب.\n"
        "يأخذه NawaOS 2.2 من مستودع NVIDIA نفسها (الفرع 595، وحدات النواة المفتوحة)،\n"
        "ويغطي GeForce RTX 20 / GTX 16 وما بعدها. ملاحظة: مع تفعيل Secure Boot يجب\n"
        "توقيع وحدة DKMS وتسجيل مفتاح MOK الخاص بها.",
    "Install Recommended Driver": "\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u062a\u0639\u0631\u064a\u0641 \u0627\u0644\u0645\u0648\u0635\u0649 \u0628\u0647",
    "Checking installed driver\u2026": "\u062c\u0627\u0631\u064d \u0641\u062d\u0635 \u0627\u0644\u062a\u0639\u0631\u064a\u0641 \u0627\u0644\u0645\u062b\u0628\u0651\u062a\u2026",
    "Checking which NVIDIA driver supports this GPU\u2026":
        "جارٍ التحقق من تعريف NVIDIA الذي يدعم هذه البطاقة\u2026",
    "Checking Secure Boot state\u2026": "\u062c\u0627\u0631\u064d \u0641\u062d\u0635 \u062d\u0627\u0644\u0629 Secure Boot\u2026",
    "AMD / Intel Graphics": "\u0631\u0633\u0648\u0645\u064a\u0627\u062a AMD / Intel",
    "Open-source drivers (Mesa) are included and active -- nothing to install":
        "\u0627\u0644\u062a\u0639\u0631\u064a\u0641\u0627\u062a \u0645\u0641\u062a\u0648\u062d\u0629 \u0627\u0644\u0645\u0635\u062f\u0631 (Mesa) \u0645\u0636\u0645\u0651\u0646\u0629 \u0648\u0641\u0639\u0651\u0627\u0644\u0629 -- \u0644\u0627 \u062d\u0627\u062c\u0629 \u0644\u062a\u062b\u0628\u064a\u062a \u0634\u064a\u0621",
    "Checking Vulkan support\u2026": "\u062c\u0627\u0631\u064d \u0641\u062d\u0635 \u062f\u0639\u0645 Vulkan\u2026",
    "CPU Information": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0645\u0639\u0627\u0644\u062c",
    "WiFi Information": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a Wi-Fi",
    "WiFi Drivers": "\u062a\u0639\u0631\u064a\u0641\u0627\u062a Wi-Fi",
    "Installed: nvidia-driver %s": "\u0645\u062b\u0628\u0651\u062a: nvidia-driver %s",
    "Proprietary driver not installed (using open-source nouveau)":
        "\u0627\u0644\u062a\u0639\u0631\u064a\u0641 \u0627\u0644\u0627\u062d\u062a\u0643\u0627\u0631\u064a \u063a\u064a\u0631 \u0645\u062b\u0628\u0651\u062a (\u064a\u064f\u0633\u062a\u062e\u062f\u0645 nouveau \u0645\u0641\u062a\u0648\u062d \u0627\u0644\u0645\u0635\u062f\u0631)",
    "Could not determine installed driver state":
        "\u062a\u0639\u0630\u0651\u0631 \u062a\u062d\u062f\u064a\u062f \u062d\u0627\u0644\u0629 \u0627\u0644\u062a\u0639\u0631\u064a\u0641 \u0627\u0644\u0645\u062b\u0628\u0651\u062a",
    "Driver packages:": "حزم التعريف:",
    "Supported by NVIDIA's current driver (595 branch, open kernel modules)":
        "مدعومة في تعريف NVIDIA الحالي (الفرع 595، وحدات النواة المفتوحة)",
    "No proprietary driver for this GPU: NVIDIA dropped GeForce GTX 900 / "
    "GTX 10 series and TITAN V (Maxwell, Pascal, Volta) from its Linux drivers "
    "in the 590 branch, and Debian's older 550 driver does not build on the "
    "NawaOS kernel. The open-source nouveau driver with NVIDIA's GSP firmware "
    "is used instead; OpenGL and Vulkan work through Mesa.":
        "لا يوجد تعريف احتكاري لهذه البطاقة: أوقفت NVIDIA دعم GeForce GTX 900 / "
        "GTX 10 وTITAN V (‏Maxwell وPascal وVolta) في تعريفات لينكس بدءًا من الفرع 590، "
        "وتعريف Debian الأقدم 550 لا يُبنى على نواة NawaOS. يُستخدم بدلًا منه تعريف nouveau "
        "مفتوح المصدر مع برمجيات GSP الثابتة من NVIDIA، ويعمل OpenGL وVulkan عبر Mesa.",
    "No proprietary driver available for this GPU (using open-source nouveau)":
        "لا يتوفر تعريف احتكاري لهذه البطاقة (يُستخدم nouveau مفتوح المصدر)",
    "Could not determine whether this GPU is supported":
        "تعذّر تحديد ما إذا كانت هذه البطاقة مدعومة",
    "Secure Boot is ENABLED: the DKMS module must be signed and its "
    "MOK key enrolled (mokutil --import) before the driver can load.":
        "Secure Boot \u0645\u064f\u0641\u0639\u0651\u0644: \u064a\u062c\u0628 \u062a\u0648\u0642\u064a\u0639 \u0648\u062d\u062f\u0629 DKMS \u0648\u062a\u0633\u062c\u064a\u0644 "
        "\u0645\u0641\u062a\u0627\u062d MOK \u0627\u0644\u062e\u0627\u0635 \u0628\u0647\u0627 (mokutil --import) \u0642\u0628\u0644 \u0623\u0646 \u064a\u064f\u062d\u0645\u0651\u0644 \u0627\u0644\u062a\u0639\u0631\u064a\u0641.",
    "Secure Boot is disabled -- no DKMS module signing needed":
        "Secure Boot \u0645\u0639\u0637\u0651\u0644 -- \u0644\u0627 \u062d\u0627\u062c\u0629 \u0644\u062a\u0648\u0642\u064a\u0639 \u0648\u062d\u062f\u0629 DKMS",
    "Checking driver module and signing key…": "جارٍ فحص وحدة التعريف ومفتاح التوقيع…",
    "Enrol signing key for Secure Boot…": "تسجيل مفتاح التوقيع لـ Secure Boot…",
    "Driver module state unavailable": "حالة وحدة التعريف غير متاحة",
    "module: loaded": "الوحدة: محمّلة",
    "module: built, not loaded": "الوحدة: مبنية وغير محمّلة",
    "module: not built": "الوحدة: غير مبنية",
    "signed": "موقّعة",
    "key enrolled: %s": "المفتاح مسجّل: %s",
    "yes": "نعم",
    "no": "لا",
    "unknown": "غير معروف",
    "the driver stays blocked until the key is enrolled": "يبقى التعريف محجوباً حتى يُسجَّل المفتاح",
    "enrolment queued: reboot and confirm in the MOK manager": "التسجيل معلّق: أعد التشغيل وأكّد في MOK manager",
    "Secure Boot driver key": "مفتاح توقيع التعريفات لـ Secure Boot",
    "Secure Boot state unknown (mokutil unavailable)":
        "\u062d\u0627\u0644\u0629 Secure Boot \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641\u0629 (mokutil \u063a\u064a\u0631 \u0645\u062a\u0648\u0641\u0631)",
    "Vulkan ready: %s": "Vulkan \u062c\u0627\u0647\u0632: %s",
    "Vulkan loader present, but no Vulkan device reported":
        "\u0645\u062d\u0645\u0651\u0644 Vulkan \u0645\u0648\u062c\u0648\u062f\u060c \u0644\u0643\u0646 \u0644\u0645 \u064a\u064f\u0628\u0644\u063a \u0639\u0646 \u0623\u064a \u062c\u0647\u0627\u0632 Vulkan",
    "vulkaninfo failed -- Vulkan may not be working on this GPU":
        "\u0641\u0634\u0644 vulkaninfo -- \u0642\u062f \u0644\u0627 \u064a\u0639\u0645\u0644 Vulkan \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0628\u0637\u0627\u0642\u0629",
    "Vulkan check failed or timed out": "\u0641\u0634\u0644 \u0641\u062d\u0635 Vulkan \u0623\u0648 \u0627\u0646\u062a\u0647\u062a \u0645\u0647\u0644\u062a\u0647",
    "vulkaninfo not installed (apt install vulkan-tools to verify Vulkan)":
        "vulkaninfo \u063a\u064a\u0631 \u0645\u062b\u0628\u0651\u062a (\u062b\u0628\u0651\u062a vulkan-tools \u0644\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 Vulkan)",

    # -- updates page --------------------------------------------------------
    "System Updates": "\u062a\u062d\u062f\u064a\u062b\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645",
    "Check for Updates": "\u0627\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0627\u0644\u062a\u062d\u062f\u064a\u062b\u0627\u062a",
    "Update system packages to latest versions":
        "\u062d\u062f\u0651\u062b \u062d\u0632\u0645 \u0627\u0644\u0646\u0638\u0627\u0645 \u0625\u0644\u0649 \u0623\u062d\u062f\u062b \u0627\u0644\u0625\u0635\u062f\u0627\u0631\u0627\u062a",
    "Update System": "\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u0646\u0638\u0627\u0645",
    "Clean System": "\u062a\u0646\u0638\u064a\u0641 \u0627\u0644\u0646\u0638\u0627\u0645",
    "Remove unused packages and clean cache":
        "\u0623\u0632\u0644 \u0627\u0644\u062d\u0632\u0645 \u063a\u064a\u0631 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645\u0629 \u0648\u0646\u0638\u0651\u0641 \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u0645\u0624\u0642\u062a\u0629",
    "Clean Now": "\u0646\u0638\u0651\u0641 \u0627\u0644\u0622\u0646",
    "Update Flatpak Apps": "\u062a\u062d\u062f\u064a\u062b \u062a\u0637\u0628\u064a\u0642\u0627\u062a Flatpak",
    "Update all installed Flatpak applications":
        "\u062d\u062f\u0651\u062b \u062c\u0645\u064a\u0639 \u062a\u0637\u0628\u064a\u0642\u0627\u062a Flatpak \u0627\u0644\u0645\u062b\u0628\u062a\u0629",
    "Update Flatpaks": "\u062a\u062d\u062f\u064a\u062b Flatpak",

    # -- security page -------------------------------------------------------
    "Firewall (UFW)": "\u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a (UFW)",
    "Manage firewall rules to protect your system":
        "\u0623\u062f\u0631 \u0642\u0648\u0627\u0639\u062f \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a \u0644\u062d\u0645\u0627\u064a\u0629 \u0646\u0638\u0627\u0645\u0643",
    "Open Firewall Settings": "\u0641\u062a\u062d \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a",
    "Firewall Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a",
    "Checking firewall status...": "\u062c\u0627\u0631\u064d \u0641\u062d\u0635 \u062d\u0627\u0644\u0629 \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a...",
    "Enable Firewall": "\u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a",
    "Disable Firewall": "\u062a\u0639\u0637\u064a\u0644 \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a",
    "Password Security": "\u0623\u0645\u0627\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
    "Change your user password or configure password policies":
        "\u063a\u064a\u0651\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0623\u0648 \u0627\u0636\u0628\u0637 \u0633\u064a\u0627\u0633\u0627\u062a \u0643\u0644\u0645\u0627\u062a \u0627\u0644\u0645\u0631\u0648\u0631",
    "Change Password": "\u062a\u063a\u064a\u064a\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
    "Security Scan": "\u0641\u062d\u0635 \u0627\u0644\u0623\u0645\u0627\u0646",
    "Check for common security issues and vulnerabilities":
        "\u062a\u062d\u0642\u0642 \u0645\u0646 \u0627\u0644\u0645\u0634\u0643\u0644\u0627\u062a \u0648\u0627\u0644\u062b\u063a\u0631\u0627\u062a \u0627\u0644\u0623\u0645\u0646\u064a\u0629 \u0627\u0644\u0634\u0627\u0626\u0639\u0629",
    "Run Security Check": "\u062a\u0634\u063a\u064a\u0644 \u0641\u062d\u0635 \u0627\u0644\u0623\u0645\u0627\u0646",
    "Firewall: Active": "\u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a: \u0645\u064f\u0641\u0639\u0651\u0644",
    "Firewall: Inactive": "\u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a: \u0645\u0639\u0637\u0651\u0644",
    "Unable to check firewall status": "\u062a\u0639\u0630\u0651\u0631 \u0641\u062d\u0635 \u062d\u0627\u0644\u0629 \u0627\u0644\u062c\u062f\u0627\u0631 \u0627\u0644\u0646\u0627\u0631\u064a",

    # -- storage page --------------------------------------------------------
    "Disk Usage": "\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0627\u0644\u0642\u0631\u0635",
    "Disk Analyzer": "\u0645\u062d\u0644\u0644 \u0627\u0644\u0642\u0631\u0635",
    "Analyze disk usage and find large files":
        "\u062d\u0644\u0651\u0644 \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0627\u0644\u0642\u0631\u0635 \u0648\u0627\u0639\u062b\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0643\u0628\u064a\u0631\u0629",
    "Open Analyzer": "\u0641\u062a\u062d \u0627\u0644\u0645\u062d\u0644\u0644",
    "Clean Cache": "\u062a\u0646\u0638\u064a\u0641 \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u0645\u0624\u0642\u062a\u0629",
    "Remove temporary files and package cache":
        "\u0623\u0632\u0644 \u0627\u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0645\u0624\u0642\u062a\u0629 \u0648\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u062d\u0632\u0645",
    "Disk Health (S.M.A.R.T)": "\u0635\u062d\u0629 \u0627\u0644\u0642\u0631\u0635 (S.M.A.R.T)",
    "Check disk health status using S.M.A.R.T data":
        "\u062a\u062d\u0642\u0642 \u0645\u0646 \u062d\u0627\u0644\u0629 \u0627\u0644\u0642\u0631\u0635 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0628\u064a\u0627\u0646\u0627\u062a S.M.A.R.T",
    "Check Health": "\u0641\u062d\u0635 \u0627\u0644\u0635\u062d\u0629",
    "Disk Health": "\u0635\u062d\u0629 \u0627\u0644\u0642\u0631\u0635",
    "Partition Manager": "\u0645\u062f\u064a\u0631 \u0627\u0644\u0623\u0642\u0633\u0627\u0645",
    "Manage disk partitions with GParted":
        "\u0623\u062f\u0631 \u0623\u0642\u0633\u0627\u0645 \u0627\u0644\u0642\u0631\u0635 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 GParted",
    "Open GParted": "\u0641\u062a\u062d GParted",
    "Root: %s used of %s (%s)": "\u0627\u0644\u062c\u0630\u0631: %s \u0645\u0633\u062a\u062e\u062f\u0645 \u0645\u0646 %s (%s)",
    "Unable to detect disk usage": "\u062a\u0639\u0630\u0651\u0631 \u0627\u0644\u0643\u0634\u0641 \u0639\u0646 \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0627\u0644\u0642\u0631\u0635",
    "Could not launch GParted: %s": "\u062a\u0639\u0630\u0651\u0631 \u062a\u0634\u063a\u064a\u0644 GParted: %s",

    # -- peripherals page ----------------------------------------------------
    "Printers": "\u0627\u0644\u0637\u0627\u0628\u0639\u0627\u062a",
    "Configure and manage printers and scanners":
        "\u0627\u0636\u0628\u0637 \u0648\u0623\u062f\u0631 \u0627\u0644\u0637\u0627\u0628\u0639\u0627\u062a \u0648\u0627\u0644\u0645\u0627\u0633\u062d\u0627\u062a \u0627\u0644\u0636\u0648\u0626\u064a\u0629",
    "Printer Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0637\u0627\u0628\u0639\u0629",
    "Bluetooth": "Bluetooth",
    "Manage Bluetooth devices and connections":
        "\u0623\u062f\u0631 \u0623\u062c\u0647\u0632\u0629 Bluetooth \u0648\u0627\u062a\u0635\u0627\u0644\u0627\u062a\u0647\u0627",
    "Bluetooth Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a Bluetooth",
    "Display": "\u0627\u0644\u0634\u0627\u0634\u0629",
    "Configure multiple monitors and resolution":
        "\u0627\u0636\u0628\u0637 \u0627\u0644\u0634\u0627\u0634\u0627\u062a \u0627\u0644\u0645\u062a\u0639\u062f\u062f\u0629 \u0648\u0627\u0644\u062f\u0642\u0629",
    "Display Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0634\u0627\u0634\u0629",
    "Sound": "\u0627\u0644\u0635\u0648\u062a",
    "Audio input/output and volume settings":
        "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u062f\u062e\u0644 \u0648\u062e\u0631\u062c \u0627\u0644\u0635\u0648\u062a \u0648\u0645\u0633\u062a\u0648\u0627\u0647",
    "Sound Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0635\u0648\u062a",
    "Mouse & Keyboard": "\u0627\u0644\u0641\u0623\u0631\u0629 \u0648\u0644\u0648\u062d\u0629 \u0627\u0644\u0645\u0641\u0627\u062a\u064a\u062d",
    "Configure input devices sensitivity and shortcuts":
        "\u0627\u0636\u0628\u0637 \u062d\u0633\u0627\u0633\u064a\u0629 \u0623\u062c\u0647\u0632\u0629 \u0627\u0644\u0625\u062f\u062e\u0627\u0644 \u0648\u0627\u0644\u0627\u062e\u062a\u0635\u0627\u0631\u0627\u062a",
    "Input Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0625\u062f\u062e\u0627\u0644",
    "Input Devices": "\u0623\u062c\u0647\u0632\u0629 \u0627\u0644\u0625\u062f\u062e\u0627\u0644",

    # -- startup page --------------------------------------------------------
    "Startup & Services": "\u0628\u062f\u0621 \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u0648\u0627\u0644\u062e\u062f\u0645\u0627\u062a",
    "Startup Applications": "\u062a\u0637\u0628\u064a\u0642\u0627\u062a \u0628\u062f\u0621 \u0627\u0644\u062a\u0634\u063a\u064a\u0644",
    "Manage applications that start automatically at login":
        "\u0623\u062f\u0631 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a \u0627\u0644\u062a\u064a \u062a\u0628\u062f\u0623 \u062a\u0644\u0642\u0627\u0626\u064a\u0651\u0627 \u0639\u0646\u062f \u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644",
    "Manage Startup Apps": "\u0625\u062f\u0627\u0631\u0629 \u062a\u0637\u0628\u064a\u0642\u0627\u062a \u0628\u062f\u0621 \u0627\u0644\u062a\u0634\u063a\u064a\u0644",
    "System Services": "\u062e\u062f\u0645\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645",
    "View and manage systemd services": "\u0627\u0639\u0631\u0636 \u0648\u0623\u062f\u0631 \u062e\u062f\u0645\u0627\u062a systemd",
    "View Services": "\u0639\u0631\u0636 \u0627\u0644\u062e\u062f\u0645\u0627\u062a",
    "Scheduled Tasks": "\u0627\u0644\u0645\u0647\u0627\u0645 \u0627\u0644\u0645\u062c\u062f\u0648\u0644\u0629",
    "Manage cron jobs and scheduled tasks":
        "\u0623\u062f\u0631 \u0645\u0647\u0627\u0645 cron \u0648\u0627\u0644\u0645\u0647\u0627\u0645 \u0627\u0644\u0645\u062c\u062f\u0648\u0644\u0629",
    "Manage Tasks": "\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0645\u0647\u0627\u0645",
    "Boot Statistics": "\u0625\u062d\u0635\u0627\u0621\u0627\u062a \u0627\u0644\u0625\u0642\u0644\u0627\u0639",
    "Unable to analyze boot time": "\u062a\u0639\u0630\u0651\u0631 \u062a\u062d\u0644\u064a\u0644 \u0632\u0645\u0646 \u0627\u0644\u0625\u0642\u0644\u0627\u0639",

    # -- language & region page ---------------------------------------------
    "Language & Region": "\u0627\u0644\u0644\u063a\u0629 \u0648\u0627\u0644\u0645\u0646\u0637\u0642\u0629",
    "Keyboard Layout": "\u062a\u062e\u0637\u064a\u0637 \u0644\u0648\u062d\u0629 \u0627\u0644\u0645\u0641\u0627\u062a\u064a\u062d",
    "Configure keyboard layouts and input methods":
        "\u0627\u0636\u0628\u0637 \u062a\u062e\u0637\u064a\u0637\u0627\u062a \u0644\u0648\u062d\u0629 \u0627\u0644\u0645\u0641\u0627\u062a\u064a\u062d \u0648\u0637\u0631\u0642 \u0627\u0644\u0625\u062f\u062e\u0627\u0644",
    "Keyboard Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0644\u0648\u062d\u0629 \u0627\u0644\u0645\u0641\u0627\u062a\u064a\u062d",
    "Time & Date": "\u0627\u0644\u0648\u0642\u062a \u0648\u0627\u0644\u062a\u0627\u0631\u064a\u062e",
    "Set timezone and date/time format":
        "\u0627\u0636\u0628\u0637 \u0627\u0644\u0645\u0646\u0637\u0642\u0629 \u0627\u0644\u0632\u0645\u0646\u064a\u0629 \u0648\u0635\u064a\u063a\u0629 \u0627\u0644\u062a\u0627\u0631\u064a\u062e \u0648\u0627\u0644\u0648\u0642\u062a",
    "Time Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0648\u0642\u062a",
    "Current Settings": "\u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062d\u0627\u0644\u064a\u0629",
    "Language: %s\nTimezone: %s": "\u0627\u0644\u0644\u063a\u0629: %s\n\u0627\u0644\u0645\u0646\u0637\u0642\u0629 \u0627\u0644\u0632\u0645\u0646\u064a\u0629: %s",
    "Unable to detect locale settings": "\u062a\u0639\u0630\u0651\u0631 \u0627\u0644\u0643\u0634\u0641 \u0639\u0646 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0645\u062d\u0644\u064a\u0629",
    "Unknown": "\u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641",

    # -- monitor page --------------------------------------------------------
    "System Monitor": "\u0645\u0631\u0627\u0642\u0628 \u0627\u0644\u0646\u0638\u0627\u0645",
    "System Resources": "\u0645\u0648\u0627\u0631\u062f \u0627\u0644\u0646\u0638\u0627\u0645",
    "Full System Monitor": "\u0645\u0631\u0627\u0642\u0628 \u0627\u0644\u0646\u0638\u0627\u0645 \u0627\u0644\u0643\u0627\u0645\u0644",
    "Open detailed system monitor with processes":
        "\u0627\u0641\u062a\u062d \u0645\u0631\u0627\u0642\u0628 \u0627\u0644\u0646\u0638\u0627\u0645 \u0627\u0644\u062a\u0641\u0635\u064a\u0644\u064a \u0645\u0639 \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a",
    "Open Monitor": "\u0641\u062a\u062d \u0627\u0644\u0645\u0631\u0627\u0642\u0628",
    "GPU Monitor": "\u0645\u0631\u0627\u0642\u0628 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0631\u0633\u0648\u0645\u064a\u0627\u062a",
    "Monitor GPU usage and temperature":
        "\u0631\u0627\u0642\u0628 \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0631\u0633\u0648\u0645\u064a\u0627\u062a \u0648\u062d\u0631\u0627\u0631\u062a\u0647\u0627",
    "Open GPU Monitor": "\u0641\u062a\u062d \u0645\u0631\u0627\u0642\u0628 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0631\u0633\u0648\u0645\u064a\u0627\u062a",
    "CPU Load:": "\u062d\u0645\u0644 \u0627\u0644\u0645\u0639\u0627\u0644\u062c:",
    "RAM:": "\u0627\u0644\u0630\u0627\u0643\u0631\u0629:",
    "Swap:": "\u0627\u0644\u062a\u0628\u062f\u064a\u0644:",
    "Temperature:": "\u0627\u0644\u062d\u0631\u0627\u0631\u0629:",
    "Temperature: N/A": "\u0627\u0644\u062d\u0631\u0627\u0631\u0629: \u063a\u064a\u0631 \u0645\u062a\u0627\u062d\u0629",

    # -- backup page ---------------------------------------------------------
    "Backup & Restore": "\u0627\u0644\u0646\u0633\u062e \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a \u0648\u0627\u0644\u0627\u0633\u062a\u0639\u0627\u062f\u0629",
    "System Snapshots (Timeshift)": "\u0644\u0642\u0637\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645 (Timeshift)",
    "Create and restore system snapshots for easy recovery":
        "\u0623\u0646\u0634\u0626 \u0648\u0627\u0633\u062a\u0639\u062f \u0644\u0642\u0637\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645 \u0644\u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0633\u0647\u0644\u0629",
    "Open Timeshift": "\u0641\u062a\u062d Timeshift",
    "Quick Snapshot": "\u0644\u0642\u0637\u0629 \u0633\u0631\u064a\u0639\u0629",
    "Create a snapshot of current system state now":
        "\u0623\u0646\u0634\u0626 \u0644\u0642\u0637\u0629 \u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0646\u0638\u0627\u0645 \u0627\u0644\u062d\u0627\u0644\u064a\u0629 \u0627\u0644\u0622\u0646",
    "Create Snapshot": "\u0625\u0646\u0634\u0627\u0621 \u0644\u0642\u0637\u0629",
    "Backup Home Folder": "\u0646\u0633\u062e \u0645\u062c\u0644\u062f \u0627\u0644\u0645\u0646\u0632\u0644 \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0651\u0627",
    "Backup Now": "\u0627\u0646\u0633\u062e \u0627\u0644\u0622\u0646",
    "Cloud Backup": "\u0627\u0644\u0646\u0633\u062e \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a \u0627\u0644\u0633\u062d\u0627\u0628\u064a",
    "Backup to Google Drive, Dropbox, or network storage":
        "\u0627\u0646\u0633\u062e \u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0651\u0627 \u0625\u0644\u0649 Google Drive \u0623\u0648 Dropbox \u0623\u0648 \u062a\u062e\u0632\u064a\u0646 \u0627\u0644\u0634\u0628\u0643\u0629",
    "Open Deja Dup": "\u0641\u062a\u062d Deja Dup",
    "Could not launch Timeshift: %s": "\u062a\u0639\u0630\u0651\u0631 \u062a\u0634\u063a\u064a\u0644 Timeshift: %s",

    # -- about page ----------------------------------------------------------
    "Version %s": "\u0627\u0644\u0625\u0635\u062f\u0627\u0631 %s",
    "A lightweight Linux distribution focused on gaming":
        "\u062a\u0648\u0632\u064a\u0639\u0629 Linux \u062e\u0641\u064a\u0641\u0629 \u0645\u062e\u0635\u0635\u0629 \u0644\u0644\u0623\u0644\u0639\u0627\u0628",
    "Developed by:": "\u062a\u0637\u0648\u064a\u0631:",
    "System Information": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0646\u0638\u0627\u0645",
    "NawaOS Release Updates": "\u062a\u062d\u062f\u064a\u062b\u0627\u062a \u0625\u0635\u062f\u0627\u0631\u0627\u062a NawaOS",
    "Check whether a newer NawaOS release is available.":
        "\u062a\u062d\u0642\u0642 \u0645\u0645\u0627 \u0625\u0630\u0627 \u0643\u0627\u0646 \u0647\u0646\u0627\u0643 \u0625\u0635\u062f\u0627\u0631 \u0623\u062d\u062f\u062b \u0645\u0646 NawaOS.",
    "Check for New Release": "\u0627\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0625\u0635\u062f\u0627\u0631 \u062c\u062f\u064a\u062f",
    "Visit NawaOS Website": "\u0632\u064a\u0627\u0631\u0629 \u0645\u0648\u0642\u0639 NawaOS",
    "Checking nawaos.com\u2026": "\u062c\u0627\u0631\u064d \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0640 nawaos.com\u2026",
    "releases.json has an unexpected format": "\u0645\u0644\u0641 releases.json \u0628\u0635\u064a\u063a\u0629 \u063a\u064a\u0631 \u0645\u062a\u0648\u0642\u0639\u0629",
    "Could not check for updates: %s": "\u062a\u0639\u0630\u0651\u0631 \u0627\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0627\u0644\u062a\u062d\u062f\u064a\u062b\u0627\u062a: %s",
    "unknown error": "\u062e\u0637\u0623 \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641",
    "Latest release is %s, but the local version could not be read "
    "from /etc/os-release":
        "\u0623\u062d\u062f\u062b \u0625\u0635\u062f\u0627\u0631 \u0647\u0648 %s\u060c \u0644\u0643\u0646 \u062a\u0639\u0630\u0651\u0631\u062a \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0625\u0635\u062f\u0627\u0631 \u0627\u0644\u0645\u062d\u0644\u064a "
        "\u0645\u0646 /etc/os-release",
    "NawaOS %s is available (you have %s)": "\u064a\u062a\u0648\u0641\u0631 NawaOS %s (\u0644\u062f\u064a\u0643 %s)",
    "NawaOS %s is up to date": "NawaOS %s \u0645\u062d\u062f\u0651\u062b",
    "%s is available": "\u064a\u062a\u0648\u0641\u0631 %s",
    "Installed version: %s\nLatest version: %s":
        "\u0627\u0644\u0625\u0635\u062f\u0627\u0631 \u0627\u0644\u0645\u062b\u0628\u0651\u062a: %s\n\u0623\u062d\u062f\u062b \u0625\u0635\u062f\u0627\u0631: %s",
    "Open Download Page": "\u0641\u062a\u062d \u0635\u0641\u062d\u0629 \u0627\u0644\u062a\u0646\u0632\u064a\u0644",
    "Close": "\u0625\u063a\u0644\u0627\u0642",

    # -- system information rows --------------------------------------------
    "Kernel": "\u0627\u0644\u0646\u0648\u0627\u0629",
    "Architecture": "\u0627\u0644\u0645\u0639\u0645\u0627\u0631\u064a\u0629",
    "Desktop": "\u0633\u0637\u062d \u0627\u0644\u0645\u0643\u062a\u0628",
    "Session": "\u0627\u0644\u062c\u0644\u0633\u0629",
    "Hostname": "\u0627\u0633\u0645 \u0627\u0644\u0645\u0636\u064a\u0641",
    "Uptime": "\u0645\u062f\u0629 \u0627\u0644\u062a\u0634\u063a\u064a\u0644",
    "CPU": "\u0627\u0644\u0645\u0639\u0627\u0644\u062c",
    "Memory": "\u0627\u0644\u0630\u0627\u0643\u0631\u0629",
    "GPU": "\u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0631\u0633\u0648\u0645\u064a\u0627\u062a",
    "Disk (/)": "\u0627\u0644\u0642\u0631\u0635 (/)",
    "N/A": "\u063a\u064a\u0631 \u0645\u062a\u0627\u062d",

    # -- shared helpers ------------------------------------------------------
    "%s is not installed": "%s \u063a\u064a\u0631 \u0645\u062b\u0628\u0651\u062a",
    "Would you like to install it now?": "\u0647\u0644 \u062a\u0631\u064a\u062f \u062a\u062b\u0628\u064a\u062a\u0647 \u0627\u0644\u0622\u0646\u061f",
    "Install via APT (%s)": "\u0627\u0644\u062a\u062b\u0628\u064a\u062a \u0639\u0628\u0631 APT (%s)",
    "Install via Flatpak": "\u0627\u0644\u062a\u062b\u0628\u064a\u062a \u0639\u0628\u0631 Flatpak",
    "Cancel": "\u0625\u0644\u063a\u0627\u0621",
    "Unknown GPU": "\u0628\u0637\u0627\u0642\u0629 \u0631\u0633\u0648\u0645\u064a\u0627\u062a \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641\u0629",
    "Unknown CPU": "\u0645\u0639\u0627\u0644\u062c \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641",
    "No WiFi adapter detected": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0643\u062a\u0634\u0627\u0641 \u0645\u062d\u0648\u0651\u0644 Wi-Fi",
    "Not connected": "\u063a\u064a\u0631 \u0645\u062a\u0635\u0644",
    "Detect the adapter, unblock it, build a bundled driver offline, or "
    "fetch firmware when online.":
        "\u064a\u0643\u062a\u0634\u0641 \u0627\u0644\u0645\u062d\u0648\u0651\u0644 \u0648\u064a\u0644\u063a\u064a \u062d\u0638\u0631\u0647\u060c \u0648\u064a\u0628\u0646\u064a \u062a\u0639\u0631\u064a\u0641\u0627\u064b \u0645\u0636\u0645\u0651\u0646\u0627\u064b \u062f\u0648\u0646 \u0625\u0646\u062a\u0631\u0646\u062a\u060c "
        "\u0623\u0648 \u064a\u062c\u0644\u0628 \u0627\u0644\u0628\u0631\u0627\u0645\u062c \u0627\u0644\u062b\u0627\u0628\u062a\u0629 \u0639\u0646\u062f \u062a\u0648\u0641\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644.",
    "Fix Wi-Fi": "\u0625\u0635\u0644\u0627\u062d Wi-Fi",
    "System report": "\u062a\u0642\u0631\u064a\u0631 \u0627\u0644\u0646\u0638\u0627\u0645",
    "Collect kernel, graphics, Wi-Fi and gaming details into one text you "
    "can paste into a bug report. No personal data is included.":
        "\u064a\u062c\u0645\u0639 \u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0646\u0648\u0627\u0629 \u0648\u0643\u0631\u062a \u0627\u0644\u0634\u0627\u0634\u0629 \u0648Wi-Fi \u0648\u0628\u064a\u0626\u0629 \u0627\u0644\u0623\u0644\u0639\u0627\u0628 \u0641\u064a \u0646\u0635 \u0648\u0627\u062d\u062f "
        "\u062a\u0644\u0635\u0642\u0647 \u0641\u064a \u0628\u0644\u0627\u063a \u0627\u0644\u062e\u0637\u0623. \u0644\u0627 \u064a\u062a\u0636\u0645\u0646 \u0623\u064a \u0628\u064a\u0627\u0646\u0627\u062a \u0634\u062e\u0635\u064a\u0629.",
    "Copy report": "\u0646\u0633\u062e \u0627\u0644\u062a\u0642\u0631\u064a\u0631",
    "The report could not be generated.": "\u062a\u0639\u0630\u0651\u0631 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u062a\u0642\u0631\u064a\u0631.",
    "The report was copied to the clipboard.": "\u0646\u064f\u0633\u062e \u0627\u0644\u062a\u0642\u0631\u064a\u0631 \u0625\u0644\u0649 \u0627\u0644\u062d\u0627\u0641\u0638\u0629.",
    "A copy was saved to %s.": "\u062d\u064f\u0641\u0638\u062a \u0646\u0633\u062e\u0629 \u0641\u064a %s.",
    "Paste it into your bug report at github.com/AHMED-ABDULLA-BH/nawaos/issues.":
        "\u0627\u0644\u0635\u0642\u0647 \u0641\u064a \u0628\u0644\u0627\u063a\u0643 \u0639\u0644\u0649 github.com/AHMED-ABDULLA-BH/nawaos/issues.",

    # -- 2.2: gaming moved to the Gaming Center, tools run in-app -----------
    "NawaOS Gaming Center": "\u0645\u0631\u0643\u0632 \u0623\u0644\u0639\u0627\u0628 NawaOS",
    "Your game library, Game Mode, performance profiles, Proton-GE,\n"
    "MangoHud, launchers and every gaming tool live in the Gaming Center.":
        "\u0645\u0643\u062a\u0628\u0629 \u0623\u0644\u0639\u0627\u0628\u0643 \u0648\u0648\u0636\u0639 \u0627\u0644\u0623\u0644\u0639\u0627\u0628 \u0648\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0623\u062f\u0627\u0621 \u0648Proton-GE\n"
        "\u0648MangoHud \u0648\u0627\u0644\u0645\u0634\u063a\u0644\u0627\u062a \u0648\u0643\u0644 \u0623\u062f\u0648\u0627\u062a \u0627\u0644\u0623\u0644\u0639\u0627\u0628 \u0641\u064a \u0645\u0631\u0643\u0632 \u0627\u0644\u0623\u0644\u0639\u0627\u0628.",
    "Open Gaming Center": "\u0641\u062a\u062d \u0645\u0631\u0643\u0632 \u0627\u0644\u0623\u0644\u0639\u0627\u0628",
    "Install %s": "\u062a\u062b\u0628\u064a\u062a %s",
    "Security Updates Only": "\u0627\u0644\u062a\u062d\u062f\u064a\u062b\u0627\u062a \u0627\u0644\u0623\u0645\u0646\u064a\u0629 \u0641\u0642\u0637",
    "Install only the security patches, with a snapshot first":
        "\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u062a\u0635\u062d\u064a\u062d\u0627\u062a \u0627\u0644\u0623\u0645\u0646\u064a\u0629 \u0641\u0642\u0637\u060c \u0645\u0639 \u0644\u0642\u0637\u0629 \u0644\u0644\u0646\u0638\u0627\u0645 \u0623\u0648\u0644\u064b\u0627",
    "Install Security Updates": "\u062a\u062b\u0628\u064a\u062a \u0627\u0644\u062a\u062d\u062f\u064a\u062b\u0627\u062a \u0627\u0644\u0623\u0645\u0646\u064a\u0629",
    "Windows Partitions (NTFS)": "\u0623\u0642\u0633\u0627\u0645 Windows (NTFS)",
    "Mount Windows and external partitions now, or add them to\n"
    "fstab so they mount at every boot":
        "\u0636\u0645\u0651 \u0623\u0642\u0633\u0627\u0645 Windows \u0648\u0627\u0644\u0623\u0642\u0631\u0627\u0635 \u0627\u0644\u062e\u0627\u0631\u062c\u064a\u0629 \u0627\u0644\u0622\u0646\u060c \u0623\u0648 \u0623\u0636\u0641\u0647\u0627 \u0625\u0644\u0649\n"
        "fstab \u0644\u062a\u064f\u0636\u0645\u0651 \u0639\u0646\u062f \u0643\u0644 \u0625\u0642\u0644\u0627\u0639",
    "Mount Now": "\u0636\u0645\u0651 \u0627\u0644\u0622\u0646",
    "Mount at Boot": "\u0636\u0645\u0651 \u0639\u0646\u062f \u0627\u0644\u0625\u0642\u0644\u0627\u0639",
    "Account Settings": "\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062d\u0633\u0627\u0628",

    # -- 2.3: Cinnamon panels, Store, Backup Manager, language ------------------
    "NawaOS Store": "متجر NawaOS",
    "Open NawaOS Store": "فتح متجر NawaOS",
    "Browse and install apps from Debian and Flathub": "تصفّح التطبيقات من Debian وFlathub وثبّتها",
    "NawaOS Backup Manager": "مدير النسخ الاحتياطي",
    "Open Backup Manager": "فتح مدير النسخ الاحتياطي",
    "Back up game saves and settings, locally or to the cloud": "انسخ حفظ الألعاب والإعدادات احتياطيًا، محليًا أو إلى السحابة",
    "Wi-Fi adapter: %s": "محوّل Wi-Fi: %s",
    "Language of the NawaOS apps and the desktop. NawaOS apps switch the next time you open them; the desktop switches at your next login.": "لغة تطبيقات NawaOS وسطح المكتب. تتبدّل تطبيقات NawaOS عند فتحها في المرة القادمة، ويتبدّل سطح المكتب عند تسجيل دخولك التالي.",
    "Language set to %s": "اللغة الآن: %s",
    "Close and reopen the NawaOS apps to see it. The desktop switches at your next login.": "أغلق تطبيقات NawaOS وأعد فتحها لترى التغيير. يتبدّل سطح المكتب عند تسجيل دخولك التالي.",

    # -- 2.3: home folder backup ------------------------------------------------
    "Copy your personal files and settings to a folder or drive you choose.\nCaches, the Trash and game libraries are left out.": "انسخ ملفاتك الشخصية وإعداداتك إلى مجلد أو قرص تختاره.\nتُستثنى ذاكرة التخزين المؤقت وسلة المهملات ومكتبات الألعاب.",
    "Choose where to save the backup": "اختر مكان حفظ النسخة الاحتياطية",
    "Back Up Here": "انسخ هنا",
    "This folder is on the same disk as your home folder": "هذا المجلد على القرص نفسه الذي يحمل مجلدك الشخصي",
    "A backup there is lost together with your files if the disk fails. An external drive is safer.": "إذا تعطّل القرص ضاعت النسخة مع ملفاتك. القرص الخارجي أكثر أمانًا.",
    "Back Up Anyway": "انسخ على أي حال",

    # -- 2.3: probes off the UI thread ------------------------------------------
    "Checking…": "جارٍ الفحص…",
    "Collecting…": "جارٍ الجمع…",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    return nawaos_i18n.setup(APP_NAME, AR_STRINGS)


_, get_language, is_rtl = _setup_i18n()

# Session locale for each NawaOS language: (LANG, LANGUAGE). Same values as
# the Welcome Wizard; both locales are generated in the image (hook 02).
LOCALE_MAP = {
    "ar": ("ar_BH.UTF-8", "ar_BH:ar:en"),
    "en": ("en_US.UTF-8", "en_US:en"),
}


def _write_text(path, content):
    """Write a small text file atomically (creates the parent folder)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)


def _set_dmrc_language(path, lang):
    """Set Language= in ~/.dmrc (LightDM), keeping Session= and other keys."""
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError:
        lines = []
    lines = [l for l in lines if not l.strip().startswith("Language=")]
    if "[Desktop]" not in (l.strip() for l in lines):
        lines.insert(0, "[Desktop]")
    at = [l.strip() for l in lines].index("[Desktop]")
    lines.insert(at + 1, "Language=%s" % lang)
    _write_text(path, "\n".join(lines) + "\n")


class NawaOSControlPanel(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("NawaOS Control Panel"))

        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)

        self.set_default_size(800, 600)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.get_style_context().add_class("nawaos-window")
        
        # Apply dark theme
        settings = Gtk.Settings.get_default()
        settings.set_property("gtk-application-prefer-dark-theme", True)
        
        # Load CSS
        self.load_css()
        
        # Main container
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_box)
        
        # Sidebar
        self.create_sidebar()
        
        # Content area
        self.content_stack = Gtk.Stack()
        self.content_stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.main_box.pack_start(self.content_stack, True, True, 0)
        
        # Create pages
        self.create_gaming_page()
        self.create_power_page()
        self.create_network_page()
        self.create_security_page()
        self.create_storage_page()
        self.create_peripherals_page()
        self.create_drivers_page()
        self.create_startup_page()
        self.create_localization_page()
        self.create_monitor_page()
        self.create_backup_page()
        self.create_appearance_page()
        self.create_updates_page()
        self.create_about_page()
        
        self.show_all()
    
    def load_css(self):
        # Thin app-specific layer over the shared NawaOS 2.0 design system
        # (nawaos_theme.BASE_CSS provides .nawaos-window, .sidebar, .card,
        # .action-btn/.action-btn-primary, .pill-badge, entry/scrollbar, ...).
        # Brand: ground #0B0F1A / surface #1A2332 / hover #232D3F,
        # gradient #1A76BA -> #37BCE0 -> #50E6E2, text #E8EDF4 / #9AA7B8.
        css = b"""
        /* === NawaOS Control Panel 2.0 - app layer === */
        .logo-box { background: linear-gradient(135deg, #1A76BA 0%, #37BCE0 55%, #50E6E2 100%); border-radius: 16px; padding: 14px 10px; margin-bottom: 14px; }
        .logo-text { color: #ffffff; font-size: 17px; font-weight: 700; }
        .logo-sub { color: rgba(255,255,255,0.85); font-size: 11px; font-weight: 600; }
        .logo-badge { background-color: rgba(11,15,26,0.35); color: #ffffff; border-radius: 100px; padding: 1px 10px; font-size: 11px; font-weight: 700; }

        .sidebar-btn { background: transparent; border: none; border-radius: 100px; color: #9AA7B8; min-height: 40px; padding: 2px 16px; margin: 2px 0; font-size: 13px; font-weight: 600; transition: all 150ms ease; }
        .sidebar-btn:hover { background-color: #232D3F; color: #E8EDF4; }
        .sidebar-btn:checked { background-color: rgba(55,188,224,0.18); color: #50E6E2; }

        .content-area { background-color: #0B0F1A; padding: 32px; }
        .page-title { color: #E8EDF4; font-size: 25px; font-weight: 700; }
        .title-underline { background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2); border-radius: 100px; }
        .section-label { color: #9AA7B8; font-size: 10px; font-weight: 700; letter-spacing: 2px; }
        .card-desc { color: #9AA7B8; font-size: 13px; }

        /* Separation by elevation: cards keep only a whisper border */
        .card { border-color: rgba(55,188,224,0.08); }
        .card.suggested-action { border-color: #37BCE0; background-color: rgba(55,188,224,0.10); }

        .nav-search { background-color: #1A2332; border: 1px solid rgba(55,188,224,0.08); border-radius: 100px; padding: 6px 14px; }
        .nav-search:focus { border-color: #37BCE0; }

        /* Ghost buttons: minor actions, borderless, hover pill */
        .ghost-btn { background: transparent; border: none; border-radius: 100px; color: #37BCE0; padding: 6px 14px; font-weight: 600; transition: all 150ms ease; }
        .ghost-btn:hover { background-color: rgba(55,188,224,0.12); color: #50E6E2; }
        .ghost-danger { background: transparent; border: none; border-radius: 100px; color: #F87171; padding: 6px 14px; font-weight: 600; }
        .ghost-danger:hover { background-color: rgba(248,113,113,0.12); }

        /* Accent / semantic tint pill actions */
        .tint-btn { background-color: rgba(55,188,224,0.15); color: #50E6E2; border: none; border-radius: 100px; padding: 8px 18px; font-weight: 600; transition: all 150ms ease; }
        .tint-btn:hover { background-color: rgba(55,188,224,0.25); }
        .success-btn { background-color: rgba(74,222,128,0.15); color: #4ADE80; border: none; border-radius: 100px; padding: 8px 18px; font-weight: 600; }
        .success-btn:hover { background-color: rgba(74,222,128,0.25); }
        .warning-btn { background-color: rgba(251,191,36,0.15); color: #FBBF24; border: none; border-radius: 100px; padding: 8px 18px; font-weight: 600; }
        .warning-btn:hover { background-color: rgba(251,191,36,0.25); }
        """
        nawaos_theme.apply_theme(self, css)
    
    def _ui_version(self):
        """NawaOS version for UI display ("" when unknown)."""
        return self._get_os_version_id() or ""

    def _make_brand_header(self):
        """Compact 2.0 brand block: logo mark + 'NawaOS' + version pill."""
        logo_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        logo_box.get_style_context().add_class("logo-box")

        brand_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        brand_row.set_halign(Gtk.Align.CENTER)
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_size(
                '/usr/share/pixmaps/nawaos-logo.png', 28, 28)
            brand_row.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        except Exception:
            pass  # logo mark is optional
        brand_label = Gtk.Label(label="NawaOS")
        brand_label.get_style_context().add_class("logo-text")
        brand_row.pack_start(brand_label, False, False, 0)
        badge = Gtk.Label(label=self._ui_version())
        badge.get_style_context().add_class("logo-badge")
        badge.set_valign(Gtk.Align.CENTER)
        brand_row.pack_start(badge, False, False, 0)
        logo_box.pack_start(brand_row, False, False, 0)

        app_label = Gtk.Label(label=_("Control Panel"))
        app_label.get_style_context().add_class("logo-sub")
        logo_box.pack_start(app_label, False, False, 0)
        return logo_box

    def _page_header(self, title, subtitle=None):
        """2.0 page header: 25px/700 title + short brand-gradient underline."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        t = Gtk.Label(label=title)
        t.get_style_context().add_class("page-title")
        t.set_halign(Gtk.Align.START)
        box.pack_start(t, False, False, 0)
        bar = Gtk.Box()
        bar.get_style_context().add_class("title-underline")
        bar.set_size_request(48, 3)
        bar.set_halign(Gtk.Align.START)
        box.pack_start(bar, False, False, 0)
        if subtitle:
            s = Gtk.Label(label=subtitle)
            s.set_halign(Gtk.Align.START)
            s.get_style_context().add_class("card-desc")
            box.pack_start(s, False, False, 0)
        return box

    def _section_label(self, text, margin_top=0):
        """Uppercase letterspaced section label."""
        lbl = Gtk.Label(label=text.upper())
        lbl.get_style_context().add_class("section-label")
        lbl.set_halign(Gtk.Align.START)
        if margin_top:
            lbl.set_margin_top(margin_top)
        return lbl

    def create_sidebar(self):
        # Create scrolled window for sidebar
        sidebar_scroll = Gtk.ScrolledWindow()
        sidebar_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sidebar_scroll.set_size_request(230, -1)
        sidebar_scroll.get_style_context().add_class("sidebar")

        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        sidebar.set_border_width(12)  # 12px outer padding around the rail

        # Brand header (logo mark + NawaOS + version pill)
        sidebar.pack_start(self._make_brand_header(), False, False, 0)

        # Quick search/filter for the (long) settings list
        self.nav_search = Gtk.SearchEntry()
        self.nav_search.set_placeholder_text(_("Search settings…"))
        self.nav_search.get_style_context().add_class("nav-search")
        self.nav_search.connect("search-changed", self.on_nav_search)
        self.nav_search.set_margin_bottom(8)
        sidebar.pack_start(self.nav_search, False, False, 0)

        # Navigation buttons -- 16px symbolic icon + clean text per row.
        self.nav_buttons = []
        # Keyword aliases let search match concepts that aren't in the label
        # text (e.g. "wifi" -> Network, "battery" -> Power).
        nav_items = [
            ("input-gaming-symbolic", _("Gaming"), "gaming", "game performance fps gamemode proton"),
            ("battery-symbolic", _("Power"), "power", "battery cpu governor tdp suspend"),
            ("network-wireless-symbolic", _("Network"), "network", "wifi ethernet dns firewall internet"),
            ("security-high-symbolic", _("Security"), "security", "firewall password privacy"),
            ("drive-harddisk-symbolic", _("Storage"), "storage", "disk cleanup space ssd"),
            ("printer-symbolic", _("Peripherals"), "peripherals", "printer mouse keyboard controller bluetooth"),
            ("video-display-symbolic", _("Drivers"), "drivers", "gpu nvidia amd intel graphics vulkan kernel secure boot wifi"),
            ("alarm-symbolic", _("Startup"), "startup", "autostart boot services"),
            ("preferences-desktop-locale-symbolic", _("Language"), "localization", "locale keyboard timezone region"),
            ("utilities-system-monitor-symbolic", _("Monitor"), "monitor", "system stats cpu ram temperature"),
            ("document-save-symbolic", _("Backup"), "backup", "restore snapshot save"),
            ("preferences-desktop-wallpaper-symbolic", _("Appearance"), "appearance", "theme wallpaper icons font"),
            ("software-update-available-symbolic", _("Updates"), "updates", "upgrade apt packages"),
            ("help-about-symbolic", _("About"), "about", "version info credits release update"),
        ]

        first_button = None
        for icon_name, label, page, keywords in nav_items:
            btn = Gtk.RadioButton.new_from_widget(first_button)
            if first_button is None:
                first_button = btn
            btn.set_mode(False)
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.pack_start(
                Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU),
                False, False, 0)
            lbl = Gtk.Label(label=label)
            lbl.set_halign(Gtk.Align.START)
            row.pack_start(lbl, False, False, 0)
            btn.add(row)
            btn.get_style_context().add_class("sidebar-btn")
            btn.connect("toggled", self.on_nav_toggled, page)
            btn.nawaos_page = page
            # Text searched against (label + alias keywords), lower-cased.
            btn.nawaos_search_text = (label + " " + keywords).lower()
            sidebar.pack_start(btn, False, False, 0)
            self.nav_buttons.append(btn)

        sidebar_scroll.add(sidebar)
        self.main_box.pack_start(sidebar_scroll, False, False, 0)
    
    def on_nav_search(self, entry):
        query = entry.get_text().strip().lower()
        for btn in self.nav_buttons:
            btn.set_visible(query in getattr(btn, "nawaos_search_text", ""))
    
    def on_nav_toggled(self, button, page):
        if button.get_active():
            self.content_stack.set_visible_child_name(page)

    def show_page(self, page):
        """Select a page by name (``--page drivers``); unknown names are ignored."""
        for btn in self.nav_buttons:
            if getattr(btn, "nawaos_page", None) == page:
                btn.set_active(True)
                return True
        return False
    
    def create_gaming_page(self):
        # 2.2: everything about games lives in the Gaming Center; this page
        # only points there (docs/apps-layout-2.2.md has the mapping).
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.get_style_context().add_class("content-area")
        page.pack_start(self._page_header(_("Gaming")), False, False, 0)

        card = self.create_card(
            "input-gaming-symbolic", _("NawaOS Gaming Center"),
            _("Your game library, Game Mode, performance profiles, Proton-GE,\n"
              "MangoHud, launchers and every gaming tool live in the Gaming Center."),
            _("Open Gaming Center"),
            self.on_open_gaming_center,
            "success-btn"
        )
        page.pack_start(card, False, False, 0)

        scroll.add(page)
        self.content_stack.add_named(scroll, "gaming")

    def on_open_gaming_center(self, button):
        self._launch_app([["nawaos-game-center"]], _("NawaOS Gaming Center"))

    def create_power_page(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Power Profiles")), False, False, 0)
        
        self.power_profiles = [
            {"name": _("Gaming Mode"), "icon": "input-gaming-symbolic", "desc": _("Maximum performance for gaming"),
             "governor": "performance", "gpu": "high", "wifi_ps": "off", "usb_suspend": "0"},
            {"name": _("Balanced"), "icon": "power-profile-balanced-symbolic", "desc": _("Balance between performance and battery"),
             "governor": "schedutil", "gpu": "auto", "wifi_ps": "on", "usb_suspend": "1"},
            {"name": _("Battery Saver"), "icon": "battery-good-symbolic", "desc": _("Maximum battery life"),
             "governor": "powersave", "gpu": "low", "wifi_ps": "on", "usb_suspend": "1"},
        ]
        self.power_cards = []
        
        for profile in self.power_profiles:
            card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
            card.get_style_context().add_class("card")
            card.set_margin_start(10)
            card.set_margin_end(10)
            card.profile_data = profile
            
            card.pack_start(nawaos_theme.icon(profile["icon"], 32), False, False, 10)
            
            info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            name_l = Gtk.Label()
            name_l.set_markup(f'<span weight="bold" foreground="#E8EDF4" size="large">{profile["name"]}</span>')
            name_l.set_halign(Gtk.Align.START)
            info.pack_start(name_l, False, False, 0)
            desc_l = Gtk.Label(label=profile["desc"])
            desc_l.get_style_context().add_class("card-desc")
            desc_l.set_halign(Gtk.Align.START)
            info.pack_start(desc_l, False, False, 0)
            card.pack_start(info, True, True, 0)
            
            btn = Gtk.Button(label=_("Apply"))
            btn.get_style_context().add_class("tint-btn")
            btn.connect("clicked", self.on_apply_power_profile, profile, card)
            card.pack_end(btn, False, False, 10)
            
            self.power_cards.append(card)
            page.pack_start(card, False, False, 0)
        
        # Current status
        self.power_status = Gtk.Label()
        self.power_status.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(_("Current governor: detecting...")))
        page.pack_start(self.power_status, False, False, 10)
        GLib.timeout_add(200, self._detect_power_profile)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "power")
    
    def _detect_power_profile(self):
        try:
            with open('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor') as f:
                gov = f.read().strip()
            self.power_status.set_markup(
                '<span foreground="#9AA7B8">%s </span>'
                '<span foreground="#4ADE80" weight="bold">%s</span>'
                % (GLib.markup_escape_text(_("Current governor:")),
                   GLib.markup_escape_text(gov)))
        except:
            self.power_status.set_markup(
                '<span foreground="#FBBF24">%s</span>'
                % GLib.markup_escape_text(_("Unable to detect power profile")))
        return False
    
    def on_apply_power_profile(self, button, profile, card):
        # Route through the single validated backend (nawaos-gamemode
        # apply-power-profile) instead of building a `pkexec bash -c` script by
        # f-string interpolation. The backend whitelists every value, so even a
        # future user-editable profile cannot inject a shell command. Run it on
        # a worker thread so the GTK main loop is not frozen during the polkit
        # password prompt, and with NO kill-timeout (the old timeout=10 started
        # before the password dialog and could SIGKILL the elevated process
        # mid-apply, leaving the system half-tuned).
        governor = profile['governor']
        gpu = profile['gpu']
        wifi = 'on' if profile['wifi_ps'] == 'off' else 'auto'

        def worker():
            try:
                result = subprocess.run(
                    ['pkexec', '/usr/local/bin/nawaos-gamemode',
                     'apply-power-profile', governor, gpu, wifi],
                    capture_output=True, text=True)
                ok = result.returncode == 0
            except Exception:
                ok = False
            GLib.idle_add(self._power_profile_applied, profile, ok)

        threading.Thread(target=worker, daemon=True).start()

    def _power_profile_applied(self, profile, ok):
        if ok:
            self.power_status.set_markup(
                '<span foreground="#9AA7B8">%s </span>'
                '<span foreground="#4ADE80" weight="bold">%s</span>'
                % (GLib.markup_escape_text(_("Active:")),
                   GLib.markup_escape_text(profile["name"])))
            try:
                notify_system(_("NawaOS Power"),
                              _("%s activated!") % profile["name"],
                              source="Control Panel")
            except Exception:
                pass
        else:
            self.show_info_dialog(
                _("Power"),
                _("Failed to apply profile (authentication cancelled or not "
                  "permitted)."))
        return False
    
    def create_network_page(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Network & DNS")), False, False, 0)
        
        subtitle = Gtk.Label()
        subtitle.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(_("Select the fastest DNS for gaming")))
        subtitle.set_halign(Gtk.Align.START)
        page.pack_start(subtitle, False, False, 0)
        
        self.dns_servers = [
            {"name": _("Cloudflare Gaming"), "primary": "1.1.1.1", "secondary": "1.0.0.1", "icon": "power-profile-performance-symbolic", "desc": _("Fastest for gaming")},
            {"name": _("Google DNS"), "primary": "8.8.8.8", "secondary": "8.8.4.4", "icon": "globe-symbolic", "desc": _("Reliable & fast")},
            {"name": _("OpenDNS"), "primary": "208.67.222.222", "secondary": "208.67.220.220", "icon": "network-server-symbolic", "desc": _("Low latency")},
            {"name": _("Quad9 Secure"), "primary": "9.9.9.9", "secondary": "149.112.112.112", "icon": "security-high-symbolic", "desc": _("Security focused")},
            {"name": _("AdGuard DNS"), "primary": "94.140.14.14", "secondary": "94.140.15.15", "icon": "action-unavailable-symbolic", "desc": _("Blocks ads")},
            {"name": _("System Default"), "primary": "auto", "secondary": "auto", "icon": "network-workgroup-symbolic", "desc": _("Use DHCP")},
        ]
        self.dns_cards = []
        self.selected_dns = None
        
        for dns in self.dns_servers:
            card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            card.get_style_context().add_class("card")
            card.set_margin_start(10)
            card.set_margin_end(10)
            card.dns_data = dns
            
            event_box = Gtk.EventBox()
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            
            icon_l = nawaos_theme.icon(dns["icon"], 22)
            inner.pack_start(icon_l, False, False, 5)
            
            info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            name_l = Gtk.Label()
            name_l.set_markup(f'<span weight="bold" foreground="#E8EDF4">{dns["name"]}</span>')
            name_l.set_halign(Gtk.Align.START)
            info.pack_start(name_l, False, False, 0)
            ip_l = Gtk.Label(label=f'{dns["primary"]} / {dns["secondary"]}')
            ip_l.get_style_context().add_class("card-desc")
            ip_l.set_halign(Gtk.Align.START)
            info.pack_start(ip_l, False, False, 0)
            inner.pack_start(info, True, True, 0)
            
            ping_l = Gtk.Label(label="--")
            ping_l.set_size_request(60, -1)
            card.ping_label = ping_l
            inner.pack_end(ping_l, False, False, 10)
            
            event_box.add(inner)
            event_box.connect("button-press-event", self._on_dns_selected, card)
            card.pack_start(event_box, True, True, 0)
            
            self.dns_cards.append(card)
            page.pack_start(card, False, False, 0)
        
        self.dns_status = Gtk.Label(
            label=_("Click 'Test All' to find the fastest DNS"))
        self.dns_status.get_style_context().add_class("card-desc")
        page.pack_start(self.dns_status, False, False, 5)
        
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        btn_box.set_halign(Gtk.Align.CENTER)
        
        test_btn = Gtk.Button(label=_("Test All"))
        test_btn.get_style_context().add_class("ghost-btn")
        test_btn.connect("clicked", self._on_dns_test)
        btn_box.pack_start(test_btn, False, False, 0)

        # The view's single gradient primary action
        apply_btn = Gtk.Button(label=_("Apply DNS"))
        apply_btn.get_style_context().add_class("action-btn-primary")
        apply_btn.connect("clicked", self._on_dns_apply)
        btn_box.pack_start(apply_btn, False, False, 0)
        
        page.pack_start(btn_box, False, False, 10)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "network")
    
    def _on_dns_selected(self, widget, event, card):
        for c in self.dns_cards:
            c.get_style_context().remove_class("suggested-action")
        card.get_style_context().add_class("suggested-action")
        self.selected_dns = card.dns_data
        self.dns_status.set_text(_("Selected: %s") % card.dns_data['name'])
    
    def _on_dns_test(self, button):
        self.dns_status.set_text(_("Testing DNS servers..."))
        threading.Thread(target=self._ping_all_dns, daemon=True).start()
    
    def _ping_all_dns(self):
        results = {}
        for card in self.dns_cards:
            dns = card.dns_data
            if dns["primary"] == "auto":
                GLib.idle_add(card.ping_label.set_text, _("Auto"))
                continue
            try:
                r = subprocess.run(['ping', '-c', '3', '-W', '2', dns["primary"]],
                                 capture_output=True, text=True, timeout=10)
                for line in r.stdout.split('\n'):
                    if 'avg' in line:
                        ms = int(float(line.split('/')[4]))
                        results[dns["name"]] = ms
                        color = "#4ADE80" if ms < 30 else "#FBBF24" if ms < 80 else "#F87171"
                        GLib.idle_add(card.ping_label.set_markup, f'<span foreground="{color}" weight="bold">{ms}ms</span>')
                        break
                else:
                    GLib.idle_add(
                        card.ping_label.set_markup,
                        '<span foreground="#F87171">%s</span>'
                        % GLib.markup_escape_text(_("Error")))
            except:
                GLib.idle_add(
                    card.ping_label.set_markup,
                    '<span foreground="#F87171">%s</span>'
                    % GLib.markup_escape_text(_("Error")))
        
        if results:
            best = min(results.items(), key=lambda x: x[1])
            GLib.idle_add(self.dns_status.set_text,
                          "✓ " + _("Fastest: %s (%dms)") % (best[0], best[1]))
    
    # Fixed shell text run once under pkexec. The script body is a constant:
    # all variable data (DNS servers, connection names) arrives via argv
    # ("$1", "$2", "$@"), so nothing user-influenced is ever interpolated
    # into shell code, and one polkit prompt covers every connection.
    _DNS_APPLY_SCRIPT = '''\
primary="$1"; secondary="$2"; shift 2
fail=0
for conn in "$@"; do
    if [ "$primary" = "auto" ]; then
        nmcli con mod "$conn" ipv4.dns "" && \
        nmcli con mod "$conn" ipv4.ignore-auto-dns no || { fail=1; continue; }
    else
        nmcli con mod "$conn" ipv4.dns "$primary $secondary" && \
        nmcli con mod "$conn" ipv4.ignore-auto-dns yes || { fail=1; continue; }
    fi
    nmcli con down "$conn" || true
    # A just-downed connection can need a moment; retry `up` once, and
    # report a second failure instead of hiding it.
    if ! nmcli con up "$conn"; then
        sleep 2
        nmcli con up "$conn" || { echo "could not reactivate '$conn'" >&2; fail=1; }
    fi
done
exit $fail
'''

    def _active_connections(self):
        """Names of active NetworkManager connections, excluding loopback.

        NM >= 1.42 (Debian Trixie) lists the `lo` loopback connection in
        `con show --active`, so `head -1` could pick it and DNS would land on
        loopback. Filter by TYPE and return every real connection instead.
        """
        conns = []
        try:
            r = subprocess.run(['nmcli', '-t', '-f', 'TYPE,NAME', 'con', 'show', '--active'],
                               capture_output=True, text=True, timeout=10)
        except Exception:
            return conns
        for line in r.stdout.splitlines():
            if ':' not in line:
                continue
            ctype, name = line.split(':', 1)  # TYPE itself never contains ':'
            if ctype == 'loopback' or not name:
                continue
            # nmcli -t escapes ':' and '\' with a backslash; unescape via a
            # sentinel so "\\:" decodes as literal backslash + separator.
            conns.append(name.replace('\\\\', '\x00').replace('\\:', ':')
                         .replace('\x00', '\\'))
        return conns

    def _on_dns_apply(self, button):
        if not self.selected_dns:
            self.show_info_dialog("DNS", _("Please select a DNS server first"))
            return
        dns = self.selected_dns
        # Run on a worker thread with NO aggressive timeout: the old timeout=15
        # had to cover the polkit prompt AND bouncing the connection
        # (nmcli con down/up), and on a timeout the elevated shell was killed --
        # possibly after `con down` but before `con up`, leaving networking
        # down.
        def worker():
            conns = self._active_connections()
            if not conns:
                GLib.idle_add(self.show_info_dialog, "DNS",
                              _("No active network connection found."))
                return
            argv = (['pkexec', 'bash', '-c', self._DNS_APPLY_SCRIPT, 'nawaos-dns',
                     dns['primary'], dns['secondary']] + conns)
            try:
                r = subprocess.run(argv, capture_output=True, text=True)
                names = ", ".join(conns)
                if r.returncode == 0:
                    if dns['primary'] == 'auto':
                        msg = "✓ " + _("DNS reset to automatic (DHCP) on: %s") % names
                    else:
                        msg = "✓ " + _("DNS changed to %s on: %s\n\n"
                                       "Primary: %s\nSecondary: %s") % (
                            dns['name'], names, dns['primary'], dns['secondary'])
                    GLib.idle_add(self.show_info_dialog, "DNS", msg)
                else:
                    detail = (r.stderr or "").strip()
                    GLib.idle_add(
                        self.show_info_dialog, "DNS",
                        _("DNS change did not fully apply (authentication "
                          "cancelled, or a connection failed to reactivate).")
                        + (("\n\n" + detail) if detail else ""))
            except Exception as e:
                GLib.idle_add(self.show_info_dialog, "DNS", _("Error: %s") % e)
        threading.Thread(target=worker, daemon=True).start()
    
    def create_appearance_page(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Appearance")), False, False, 0)
        
        # "gtk" is the GTK widget theme, "cinnamon" the shell theme (defaults to
        # "gtk"), "wm" the window-border theme (defaults to "gtk"); "wallpaper"
        # (optional) is applied when that file exists on the system.
        self.themes = [
            {"name": _("NawaOS Default"), "gtk": "Arc-Dark", "cinnamon": "NawaOS", "icon_theme": "NawaOS-Icons", "cursor": "Adwaita", "accent": "#37BCE0", "dark": True,
             "wallpaper": "/usr/share/backgrounds/nawaos/nawaos-hero.png"},
            {"name": _("NawaOS Light"), "gtk": "Arc", "cinnamon": "NawaOS-Light", "icon_theme": "Papirus-Light", "cursor": "Adwaita", "accent": "#1A76BA", "dark": False,
             "wallpaper": "/usr/share/backgrounds/nawaos/nawaos-hero-light.png"},
            {"name": _("Cyber Neon"), "gtk": "Adwaita-dark", "icon_theme": "Papirus-Dark", "cursor": "Adwaita", "accent": "#bd00ff"},
            {"name": _("Matrix Green"), "gtk": "Adwaita-dark", "icon_theme": "Papirus-Dark", "cursor": "Adwaita", "accent": "#00ff41"},
            {"name": _("Blood Red"), "gtk": "Adwaita-dark", "icon_theme": "Papirus-Dark", "cursor": "Adwaita", "accent": "#ff0040"},
            {"name": _("Ocean Blue"), "gtk": "Adwaita-dark", "icon_theme": "Papirus-Dark", "cursor": "Adwaita", "accent": "#00b4d8"},
            {"name": _("Sunset Orange"), "gtk": "Adwaita-dark", "icon_theme": "Papirus-Dark", "cursor": "Adwaita", "accent": "#ff6b00"},
        ]
        self.theme_cards_list = []
        self.selected_theme = None
        
        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(10)
        grid.set_column_homogeneous(True)
        
        for i, theme in enumerate(self.themes):
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            card.get_style_context().add_class("card")
            card.theme_data = theme
            
            name_l = Gtk.Label()
            name_l.set_markup(f'<span weight="bold" foreground="#E8EDF4">{theme["name"]}</span>')
            card.pack_start(name_l, False, False, 0)
            
            # Color preview
            color_area = Gtk.DrawingArea()
            color_area.set_size_request(60, 12)
            color_area.connect("draw", self._draw_accent, theme["accent"])
            card.pack_start(color_area, False, False, 5)
            
            event_box = Gtk.EventBox()
            event_box.add(card)
            event_box.connect("button-press-event", self._on_theme_selected, card)
            
            self.theme_cards_list.append(card)
            grid.attach(event_box, i % 3, i // 3, 1, 1)
        
        page.pack_start(grid, False, False, 0)
        
        self.theme_status = Gtk.Label()
        self.theme_status.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(_("Click a theme to select, then Apply")))
        page.pack_start(self.theme_status, False, False, 10)
        
        apply_btn = Gtk.Button(label=_("Apply Theme"))
        apply_btn.get_style_context().add_class("action-btn-primary")
        apply_btn.set_halign(Gtk.Align.CENTER)
        apply_btn.connect("clicked", self._on_apply_theme)
        page.pack_start(apply_btn, False, False, 10)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "appearance")
    
    def _draw_accent(self, widget, cr, color):
        w = widget.get_allocated_width()
        h = widget.get_allocated_height()
        r, g, b = int(color[1:3], 16)/255, int(color[3:5], 16)/255, int(color[5:7], 16)/255
        cr.set_source_rgb(r, g, b)
        cr.rectangle(0, 0, w, h)
        cr.fill()
    
    def _on_theme_selected(self, widget, event, card):
        for c in self.theme_cards_list:
            c.get_style_context().remove_class("suggested-action")
        card.get_style_context().add_class("suggested-action")
        self.selected_theme = card.theme_data
        self.theme_status.set_markup(
            '<span foreground="#9AA7B8">%s </span>'
            '<span foreground="#37BCE0" weight="bold">%s</span>'
            % (GLib.markup_escape_text(_("Selected:")),
               GLib.markup_escape_text(card.theme_data["name"])))
    
    def _on_apply_theme(self, button):
        if not self.selected_theme:
            self.show_info_dialog(_("Theme"), _("Please select a theme first"))
            return
        t = self.selected_theme
        cinnamon_theme = t.get("cinnamon", t["gtk"])
        wm_theme = t.get("wm", t["gtk"])
        cmds = [
            ['gsettings', 'set', 'org.gnome.desktop.interface', 'gtk-theme', t["gtk"]],
            ['gsettings', 'set', 'org.gnome.desktop.interface', 'icon-theme', t["icon_theme"]],
            ['gsettings', 'set', 'org.gnome.desktop.interface', 'cursor-theme', t["cursor"]],
            ['gsettings', 'set', 'org.gnome.desktop.interface', 'color-scheme',
             'prefer-dark' if t.get("dark", True) else 'default'],
            ['gsettings', 'set', 'org.cinnamon.desktop.interface', 'gtk-theme', t["gtk"]],
            ['gsettings', 'set', 'org.cinnamon.desktop.interface', 'icon-theme', t["icon_theme"]],
            ['gsettings', 'set', 'org.cinnamon.desktop.wm.preferences', 'theme', wm_theme],
            ['gsettings', 'set', 'org.cinnamon.theme', 'name', cinnamon_theme],
        ]
        if t.get("wallpaper") and os.path.exists(t["wallpaper"]):
            cmds.append(['gsettings', 'set', 'org.cinnamon.desktop.background', 'picture-uri',
                         'file://' + t["wallpaper"]])
        for cmd in cmds:
            subprocess.run(cmd, capture_output=True)
        # Apply accent color via GTK CSS. Write the accent rules to a dedicated
        # file and @import it from gtk.css, so we don't clobber the user's own
        # ~/.config/gtk-3.0/gtk.css customizations (the old code overwrote it).
        css_dir = Path.home() / ".config" / "gtk-3.0"
        css_dir.mkdir(parents=True, exist_ok=True)
        (css_dir / "nawaos-accent.css").write_text(
            f'@define-color accent_color {t["accent"]};\n'
            f'@define-color accent_bg_color {t["accent"]};\n'
            f'selection {{ background-color: {t["accent"]}; }}\n')
        gtk_css = css_dir / "gtk.css"
        import_line = '@import url("nawaos-accent.css");'
        existing = gtk_css.read_text() if gtk_css.exists() else ""
        if import_line not in existing:
            # @import must precede other rules, so prepend while keeping the rest.
            gtk_css.write_text(import_line + "\n" + existing)
        self.theme_status.set_markup(
            '<span foreground="#4ADE80">✓ %s</span>'
            % GLib.markup_escape_text(_('Theme "%s" applied!') % t["name"]))
        self.show_info_dialog(
            _("Theme"),
            _("Theme '%s' applied!\nSome changes may need logout.") % t['name'])
    
    def create_drivers_page(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Drivers")), False, False, 0)

        # GPU list -- every VGA/3D/Display device from lspci, not just the
        # first line, so hybrid (iGPU + dGPU) systems show both adapters.
        gpus = self._list_gpus()
        gpu_text = "\n".join(desc for _vendor, desc in gpus) or _("No GPU detected")
        card1 = self.create_info_card(_("GPU Information"), gpu_text)
        page.pack_start(card1, False, False, 0)

        vendors = {vendor for vendor, _desc in gpus}

        # NVIDIA Driver Manager (only shown when an NVIDIA GPU is present)
        if 'nvidia' in vendors:
            nvidia_card = self.create_card(
                "video-display-symbolic", _("NVIDIA Driver Manager"),
                _("Install the proprietary NVIDIA driver for the best gaming performance.\n"
                  "NawaOS 2.2 takes it from NVIDIA's own repository (595 branch, open kernel\n"
                  "modules), which covers GeForce RTX 20 / GTX 16 and newer. Note: with Secure\n"
                  "Boot enabled the DKMS-built module must be signed and its MOK key enrolled."),
                _("Install Recommended Driver"),
                self.on_nvidia_clicked,
                "success-btn"
            )
            self.nvidia_install_btn = nvidia_card.action_button
            self.nvidia_status_label = Gtk.Label()
            self.nvidia_status_label.set_halign(Gtk.Align.START)
            self.nvidia_status_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Checking installed driver…")))
            nvidia_card.pack_start(self.nvidia_status_label, False, False, 0)

            self.nvidia_recommend_label = Gtk.Label()
            self.nvidia_recommend_label.set_halign(Gtk.Align.START)
            self.nvidia_recommend_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Checking which NVIDIA driver supports this GPU…")))
            nvidia_card.pack_start(self.nvidia_recommend_label, False, False, 0)

            self.secureboot_label = Gtk.Label()
            self.secureboot_label.set_halign(Gtk.Align.START)
            self.secureboot_label.set_line_wrap(True)
            self.secureboot_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Checking Secure Boot state…")))
            nvidia_card.pack_start(self.secureboot_label, False, False, 0)

            # 2.1: DKMS module + signing key state, with the enrolment flow
            # one click away (nawaos-mok-enroll-gui).
            self.mok_label = Gtk.Label()
            self.mok_label.set_halign(Gtk.Align.START)
            self.mok_label.set_line_wrap(True)
            self.mok_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Checking driver module and signing key…")))
            nvidia_card.pack_start(self.mok_label, False, False, 0)
            self.mok_btn = Gtk.Button(label=_("Enrol signing key for Secure Boot…"))
            self.mok_btn.get_style_context().add_class("tint-btn")
            self.mok_btn.set_halign(Gtk.Align.START)
            self.mok_btn.connect("clicked", self.on_mok_enroll_clicked)
            self.mok_btn.set_no_show_all(True)
            nvidia_card.pack_start(self.mok_btn, False, False, 0)

            page.pack_start(nvidia_card, False, False, 0)
            self._refresh_nvidia_status()

        # AMD / Intel: open-source stack ships with NawaOS out of the box
        if 'amd' in vendors or 'intel' in vendors:
            oss_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            oss_card.get_style_context().add_class("card")
            oss_card.set_margin_start(10)
            oss_card.set_margin_end(10)

            oss_title = Gtk.Label()
            oss_title.set_markup(
                '<span size="large" weight="bold" foreground="#37BCE0">%s</span>'
                % GLib.markup_escape_text(_("AMD / Intel Graphics")))
            oss_title.set_halign(Gtk.Align.START)
            oss_card.pack_start(oss_title, False, False, 0)

            oss_ok = Gtk.Label()
            oss_ok.set_markup(
                '<span foreground="#4ADE80">✓ %s</span>'
                % GLib.markup_escape_text(
                    _("Open-source drivers (Mesa) are included and active -- nothing to install")))
            oss_ok.set_halign(Gtk.Align.START)
            oss_ok.set_line_wrap(True)
            oss_card.pack_start(oss_ok, False, False, 0)

            self.vulkan_label = Gtk.Label()
            self.vulkan_label.set_halign(Gtk.Align.START)
            self.vulkan_label.set_line_wrap(True)
            self.vulkan_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Checking Vulkan support…")))
            oss_card.pack_start(self.vulkan_label, False, False, 0)

            page.pack_start(oss_card, False, False, 0)
            self._refresh_vulkan_summary()


        # CPU Info
        cpu_info = self.get_cpu_info()
        card2 = self.create_info_card(_("CPU Information"), cpu_info)
        page.pack_start(card2, False, False, 0)
        
        # WiFi Drivers Section
        wifi_card = self.create_async_info_card(_("WiFi Information"), self.get_wifi_info)
        page.pack_start(wifi_card, False, False, 0)
        
        # WiFi Driver Install
        wifi_install_card = self.create_card(
            "network-wireless-symbolic", _("WiFi Drivers"),
            _("Detect the adapter, unblock it, build a bundled driver "
              "offline, or fetch firmware when online."),
            _("Fix Wi-Fi"),
            self.on_wifi_drivers_clicked,
            "tint-btn"
        )
        page.pack_start(wifi_install_card, False, False, 0)

        # One-click report for bug reports: kernel, GPU, Wi-Fi, gaming stack.
        report_card = self.create_card(
            "text-x-generic-symbolic", _("System report"),
            _("Collect kernel, graphics, Wi-Fi and gaming details into one "
              "text you can paste into a bug report. No personal data is "
              "included."),
            _("Copy report"),
            self.on_copy_report_clicked,
            "tint-btn"
        )
        page.pack_start(report_card, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "drivers")
    
    def create_updates_page(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("System Updates")), False, False, 0)
        
        card1 = self.create_card(
            "software-update-available-symbolic", _("Check for Updates"),
            _("Update system packages to latest versions"),
            _("Update System"),
            self.on_update_clicked,
            "success-btn"
        )
        page.pack_start(card1, False, False, 0)

        card_sec = self.create_card(
            "security-high-symbolic", _("Security Updates Only"),
            _("Install only the security patches, with a snapshot first"),
            _("Install Security Updates"),
            self.on_security_update_clicked
        )
        page.pack_start(card_sec, False, False, 0)
        
        card2 = self.create_card(
            "edit-clear-all-symbolic", _("Clean System"),
            _("Remove unused packages and clean cache"),
            _("Clean Now"),
            self.on_clean_clicked,
            "warning-btn"
        )
        page.pack_start(card2, False, False, 0)
        
        card3 = self.create_card(
            "package-x-generic-symbolic", _("NawaOS Store"),
            _("Browse and install apps from Debian and Flathub"),
            _("Open NawaOS Store"),
            self.on_flatpak_clicked
        )
        page.pack_start(card3, False, False, 0)
        
        card4 = self.create_card(
            "emblem-synchronizing-symbolic", _("Update Flatpak Apps"),
            _("Update all installed Flatpak applications"),
            _("Update Flatpaks"),
            self.on_flatpak_update_clicked,
            "success-btn"
        )
        page.pack_start(card4, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "updates")
    
    def create_security_page(self):
        """Security settings page with UFW firewall and password management"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Security")), False, False, 0)
        
        # Firewall Card
        card1 = self.create_card(
            "security-high-symbolic", _("Firewall (UFW)"),
            _("Manage firewall rules to protect your system"),
            _("Open Firewall Settings"),
            self.on_firewall_clicked
        )
        page.pack_start(card1, False, False, 0)
        
        # Firewall Status
        self.firewall_status = Gtk.Label()
        self.firewall_status.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(_("Checking firewall status...")))
        self.firewall_status.set_halign(Gtk.Align.START)
        page.pack_start(self.firewall_status, False, False, 0)
        GLib.timeout_add(500, self._check_firewall_status)
        
        # Quick Firewall Actions
        fw_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        
        enable_fw = Gtk.Button(label=_("Enable Firewall"))
        enable_fw.get_style_context().add_class("success-btn")
        enable_fw.connect("clicked", self.on_enable_firewall)
        fw_box.pack_start(enable_fw, False, False, 0)

        disable_fw = Gtk.Button(label=_("Disable Firewall"))
        disable_fw.get_style_context().add_class("ghost-danger")
        disable_fw.connect("clicked", self.on_disable_firewall)
        fw_box.pack_start(disable_fw, False, False, 0)
        
        page.pack_start(fw_box, False, False, 0)
        
        # Password Security
        card2 = self.create_card(
            "dialog-password-symbolic", _("Password Security"),
            _("Change your user password or configure password policies"),
            _("Change Password"),
            self.on_change_password
        )
        page.pack_start(card2, False, False, 0)
        
        # Security Scan
        card3 = self.create_card(
            "edit-find-symbolic", _("Security Scan"),
            _("Check for common security issues and vulnerabilities"),
            _("Run Security Check"),
            self.on_security_scan
        )
        page.pack_start(card3, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "security")
    
    def create_storage_page(self):
        """Storage management page with disk analysis and cleanup"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Storage")), False, False, 0)
        
        # Disk Usage Info
        info_card = self.create_async_info_card(_("Disk Usage"), self._get_disk_usage)
        page.pack_start(info_card, False, False, 0)
        
        # Disk Analyzer
        card1 = self.create_card(
            "disk-quota-symbolic", _("Disk Analyzer"),
            _("Analyze disk usage and find large files"),
            _("Open Analyzer"),
            self.on_disk_analyzer
        )
        page.pack_start(card1, False, False, 0)
        
        # Clean Cache
        card2 = self.create_card(
            "edit-clear-all-symbolic", _("Clean Cache"),
            _("Remove temporary files and package cache"),
            _("Clean Now"),
            self.on_clean_cache,
            "warning-btn"
        )
        page.pack_start(card2, False, False, 0)
        
        # Disk Health
        card3 = self.create_card(
            "drive-harddisk-symbolic", _("Disk Health (S.M.A.R.T)"),
            _("Check disk health status using S.M.A.R.T data"),
            _("Check Health"),
            self.on_disk_health
        )
        page.pack_start(card3, False, False, 0)
        
        # Partition Manager
        card4 = self.create_card(
            "drive-multidisk-symbolic", _("Partition Manager"),
            _("Manage disk partitions with GParted"),
            _("Open GParted"),
            self.on_gparted
        )
        page.pack_start(card4, False, False, 0)

        # Windows / external partitions (2.2: moved here from the Gaming
        # Center tools, it is a system task).
        card5 = self.create_card(
            "drive-harddisk-symbolic", _("Windows Partitions (NTFS)"),
            _("Mount Windows and external partitions now, or add them to\n"
              "fstab so they mount at every boot"),
            _("Mount Now"),
            self.on_mount_all,
            "tint-btn",
            extra_buttons=[(_("Mount at Boot"), self.on_automount_setup, "ghost-btn")]
        )
        page.pack_start(card5, False, False, 0)

        scroll.add(page)
        self.content_stack.add_named(scroll, "storage")
    
    def create_peripherals_page(self):
        """Peripherals management page"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Peripherals")), False, False, 0)
        
        # Printers
        card1 = self.create_card(
            "printer-symbolic", _("Printers"),
            _("Configure and manage printers and scanners"),
            _("Printer Settings"),
            self.on_printers
        )
        page.pack_start(card1, False, False, 0)
        
        # Bluetooth
        card2 = self.create_card(
            "bluetooth-active-symbolic", _("Bluetooth"),
            _("Manage Bluetooth devices and connections"),
            _("Bluetooth Settings"),
            self.on_bluetooth
        )
        page.pack_start(card2, False, False, 0)
        
        # Display Settings
        card3 = self.create_card(
            "video-display-symbolic", _("Display"),
            _("Configure multiple monitors and resolution"),
            _("Display Settings"),
            self.on_display
        )
        page.pack_start(card3, False, False, 0)
        
        # Sound Settings
        card4 = self.create_card(
            "audio-speakers-symbolic", _("Sound"),
            _("Audio input/output and volume settings"),
            _("Sound Settings"),
            self.on_sound
        )
        page.pack_start(card4, False, False, 0)
        
        # Mouse & Keyboard
        card5 = self.create_card(
            "input-mouse-symbolic", _("Mouse & Keyboard"),
            _("Configure input devices sensitivity and shortcuts"),
            _("Input Settings"),
            self.on_input_devices
        )
        page.pack_start(card5, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "peripherals")
    
    def create_startup_page(self):
        """Startup applications and services management"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Startup & Services")), False, False, 0)
        
        # Startup Apps
        card1 = self.create_card(
            "system-run-symbolic", _("Startup Applications"),
            _("Manage applications that start automatically at login"),
            _("Manage Startup Apps"),
            self.on_startup_apps
        )
        page.pack_start(card1, False, False, 0)
        
        # System Services
        card2 = self.create_card(
            "emblem-system-symbolic", _("System Services"),
            _("View and manage systemd services"),
            _("View Services"),
            self.on_services
        )
        page.pack_start(card2, False, False, 0)
        
        # Scheduled Tasks
        card3 = self.create_card(
            "x-office-calendar-symbolic", _("Scheduled Tasks"),
            _("Manage cron jobs and scheduled tasks"),
            _("Manage Tasks"),
            self.on_cron
        )
        page.pack_start(card3, False, False, 0)
        
        # Boot Time
        boot_card = self.create_async_info_card(_("Boot Statistics"), self._get_boot_time)
        page.pack_start(boot_card, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "startup")
    
    def create_localization_page(self):
        """Language and regional settings"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Language & Region")), False, False, 0)
        
        # Language: Cinnamon 6.4 on Debian has no language panel (no
        # cs_language module, no mintlocale), so NawaOS sets the user's
        # session locale itself, the same files the Welcome Wizard writes.
        card1 = self.create_card(
            "preferences-desktop-locale-symbolic", _("Language"),
            _("Language of the NawaOS apps and the desktop. NawaOS apps switch the "
              "next time you open them; the desktop switches at your next login."),
            "العربية", lambda _b: self.on_set_language("ar"),
            extra_buttons=[("English", lambda _b: self.on_set_language("en"), "tint-btn")]
        )
        page.pack_start(card1, False, False, 0)
        
        # Keyboard Layout
        card2 = self.create_card(
            "input-keyboard-symbolic", _("Keyboard Layout"),
            _("Configure keyboard layouts and input methods"),
            _("Keyboard Settings"),
            self.on_keyboard
        )
        page.pack_start(card2, False, False, 0)
        
        # Time & Date
        card3 = self.create_card(
            "preferences-system-time-symbolic", _("Time & Date"),
            _("Set timezone and date/time format"),
            _("Time Settings"),
            self.on_time_settings
        )
        page.pack_start(card3, False, False, 0)
        
        # Current Settings Info
        info_card = self.create_async_info_card(_("Current Settings"), self._get_locale_info)
        page.pack_start(info_card, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "localization")
    
    def create_monitor_page(self):
        """System monitoring page with real-time stats"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("System Monitor")), False, False, 0)
        
        # Real-time Stats Card
        stats_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        stats_card.get_style_context().add_class("card")
        
        stats_title = Gtk.Label()
        stats_title.set_markup(
            '<span weight="bold" foreground="#37BCE0">%s</span>'
            % GLib.markup_escape_text(_("System Resources")))
        stats_title.set_halign(Gtk.Align.START)
        stats_card.pack_start(stats_title, False, False, 0)
        
        self.cpu_label = Gtk.Label()
        self.cpu_label.set_halign(Gtk.Align.START)
        stats_card.pack_start(self.cpu_label, False, False, 0)
        
        self.ram_label = Gtk.Label()
        self.ram_label.set_halign(Gtk.Align.START)
        stats_card.pack_start(self.ram_label, False, False, 0)
        
        self.swap_label = Gtk.Label()
        self.swap_label.set_halign(Gtk.Align.START)
        stats_card.pack_start(self.swap_label, False, False, 0)
        
        self.temp_label = Gtk.Label()
        self.temp_label.set_halign(Gtk.Align.START)
        stats_card.pack_start(self.temp_label, False, False, 0)
        
        page.pack_start(stats_card, False, False, 0)
        
        # Start updating stats
        self._update_system_stats()
        GLib.timeout_add(2000, self._update_system_stats)
        
        # System Monitor App
        card1 = self.create_card(
            "utilities-system-monitor-symbolic", _("Full System Monitor"),
            _("Open detailed system monitor with processes"),
            _("Open Monitor"),
            self.on_system_monitor
        )
        page.pack_start(card1, False, False, 0)
        
        # GPU Monitor
        card3 = self.create_card(
            "video-display-symbolic", _("GPU Monitor"),
            _("Monitor GPU usage and temperature"),
            _("Open GPU Monitor"),
            self.on_gpu_monitor
        )
        page.pack_start(card3, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "monitor")
    
    def create_backup_page(self):
        """Backup and restore page with Timeshift integration"""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        page.pack_start(self._page_header(_("Backup & Restore")), False, False, 0)
        
        # Timeshift
        card1 = self.create_card(
            "document-open-recent-symbolic", _("System Snapshots (Timeshift)"),
            _("Create and restore system snapshots for easy recovery"),
            _("Open Timeshift"),
            self.on_timeshift,
            "success-btn"
        )
        page.pack_start(card1, False, False, 0)
        
        # Quick Snapshot
        card2 = self.create_card(
            "camera-photo-symbolic", _("Quick Snapshot"),
            _("Create a snapshot of current system state now"),
            _("Create Snapshot"),
            self.on_create_snapshot
        )
        page.pack_start(card2, False, False, 0)
        
        # Home Backup
        card3 = self.create_card(
            "user-home-symbolic", _("Backup Home Folder"),
            _("Copy your personal files and settings to a folder or drive you choose.\n"
              "Caches, the Trash and game libraries are left out."),
            _("Backup Now"),
            self.on_backup_home
        )
        page.pack_start(card3, False, False, 0)
        
        # NawaOS Backup Manager: game saves and settings, locally or to the
        # cloud (rclone).
        card4 = self.create_card(
            "folder-remote-symbolic", _("NawaOS Backup Manager"),
            _("Back up game saves and settings, locally or to the cloud"),
            _("Open Backup Manager"),
            self.on_backup_manager
        )
        page.pack_start(card4, False, False, 0)

        # Deja Dup is not in the image; show its card only when installed.
        if shutil.which("deja-dup"):
            card5 = self.create_card(
                "folder-remote-symbolic", _("Cloud Backup"),
                _("Backup to Google Drive, Dropbox, or network storage"),
                _("Open Deja Dup"),
                self.on_deja_dup
            )
            page.pack_start(card5, False, False, 0)
        
        scroll.add(page)
        self.content_stack.add_named(scroll, "backup")
    
    def create_about_page(self):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        page.get_style_context().add_class("content-area")
        
        # Logo and title
        title = Gtk.Label()
        title.set_markup('<span size="xx-large" weight="bold" foreground="#37BCE0">NawaOS</span>')
        page.pack_start(title, False, False, 10)

        version = Gtk.Label()
        version.set_markup(
            '<span size="large" foreground="#E8EDF4">%s</span>'
            % GLib.markup_escape_text(_("Version %s") % self._ui_version()))
        page.pack_start(version, False, False, 0)
        
        desc = Gtk.Label()
        desc.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(
                _("A lightweight Linux distribution focused on gaming")))
        page.pack_start(desc, False, False, 5)
        
        developer = Gtk.Label()
        developer.set_markup(
            '<span foreground="#E8EDF4">%s <b>Ahmed Abdulla</b></span>'
            % GLib.markup_escape_text(_("Developed by:")))
        page.pack_start(developer, False, False, 10)
        
        # System Information Card
        sys_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        sys_card.get_style_context().add_class("card")
        sys_card.set_margin_start(10)
        sys_card.set_margin_end(10)
        
        sys_title = Gtk.Label()
        sys_title.set_markup(
            '<span weight="bold" foreground="#37BCE0" size="large">%s</span>'
            % GLib.markup_escape_text(_("System Information")))
        sys_title.set_halign(Gtk.Align.START)
        sys_card.pack_start(sys_title, False, False, 0)
        
        # Filled from a worker thread (uname, lspci, free, df, ...).
        def worker():
            info = self._gather_system_info()
            GLib.idle_add(self._fill_system_info, sys_card, info)
        threading.Thread(target=worker, daemon=True).start()

        page.pack_start(sys_card, False, False, 0)
        self._about_page_rest(page)

        scroll.add(page)
        self.content_stack.add_named(scroll, "about")

    def _fill_system_info(self, sys_card, sys_info):
        for label, value in sys_info:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            key_l = Gtk.Label()
            key_l.set_markup(f'<span foreground="#9AA7B8">{label}:</span>')
            key_l.set_halign(Gtk.Align.START)
            key_l.set_size_request(140, -1)
            row.pack_start(key_l, False, False, 0)
            val_l = Gtk.Label(label=value)
            val_l.set_halign(Gtk.Align.START)
            val_l.set_selectable(True)
            val_l.set_line_wrap(True)
            val_l.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
            row.pack_start(val_l, True, True, 0)
            sys_card.pack_start(row, False, False, 0)
        sys_card.show_all()
        return False

    def _about_page_rest(self, page):
        # NawaOS release check (2.0): compares nawaos.com/releases.json
        # against VERSION_ID from /etc/os-release.
        update_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        update_card.get_style_context().add_class("card")
        update_card.set_margin_start(10)
        update_card.set_margin_end(10)

        update_title = Gtk.Label()
        update_title.set_markup(
            '<span weight="bold" foreground="#37BCE0" size="large">%s</span>'
            % GLib.markup_escape_text(_("NawaOS Release Updates")))
        update_title.set_halign(Gtk.Align.START)
        update_card.pack_start(update_title, False, False, 0)

        self.nawaos_update_status = Gtk.Label()
        self.nawaos_update_status.set_halign(Gtk.Align.START)
        self.nawaos_update_status.set_line_wrap(True)
        self.nawaos_update_status.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(
                _("Check whether a newer NawaOS release is available.")))
        update_card.pack_start(self.nawaos_update_status, False, False, 0)

        check_btn = Gtk.Button(label=_("Check for New Release"))
        check_btn.get_style_context().add_class("action-btn-primary")
        check_btn.set_halign(Gtk.Align.START)
        check_btn.connect("clicked", self.on_check_nawaos_update)
        update_card.pack_start(check_btn, False, False, 5)

        page.pack_start(update_card, False, False, 0)

        website = Gtk.LinkButton.new_with_label(
            "https://nawaos.com", _("Visit NawaOS Website"))
        page.pack_start(website, False, False, 10)

    # ===== ABOUT PAGE: NAWAOS RELEASE CHECK (2.0) =====
    NAWAOS_RELEASES_URL = "https://nawaos.com/releases.json"

    def _get_os_version_id(self):
        """VERSION_ID (nawaos_release), or None when unknown."""
        v = nawaos_release.version() if nawaos_release else ""
        return v or None

    @staticmethod
    def _version_tuple(version):
        """'2.0' -> (2, 0); non-numeric pieces count as 0."""
        parts = []
        for piece in str(version).strip().split('.'):
            digits = ''.join(ch for ch in piece if ch.isdigit())
            parts.append(int(digits) if digits else 0)
        return tuple(parts) if parts else (0,)

    def on_check_nawaos_update(self, button):
        button.set_sensitive(False)
        self.nawaos_update_status.set_markup(
            '<span foreground="#9AA7B8">%s</span>'
            % GLib.markup_escape_text(_("Checking nawaos.com…")))

        def worker():
            data = None
            error = None
            try:
                with urllib.request.urlopen(self.NAWAOS_RELEASES_URL,
                                            timeout=5) as resp:
                    raw = resp.read(65536)
                data = json.loads(raw.decode('utf-8'))
                if not isinstance(data, dict) or not isinstance(data.get('latest'), str):
                    data = None
                    error = _("releases.json has an unexpected format")
            except Exception as e:
                data = None
                error = str(e)
            GLib.idle_add(self._nawaos_update_done, button, data, error)

        threading.Thread(target=worker, daemon=True).start()

    def _nawaos_update_done(self, button, data, error):
        button.set_sensitive(True)
        if data is None:
            # Honest failure: name the reason, do not pretend "up to date".
            self.nawaos_update_status.set_markup(
                '<span foreground="#FBBF24">%s</span>'
                % GLib.markup_escape_text(
                    _("Could not check for updates: %s") % (error or _("unknown error"))))
            return False

        latest = data['latest'].strip()
        current = self._get_os_version_id()
        if current is None:
            self.nawaos_update_status.set_markup(
                '<span foreground="#FBBF24">%s</span>'
                % GLib.markup_escape_text(
                    _("Latest release is %s, but the local version could not be read "
                      "from /etc/os-release") % latest))
            return False

        if self._version_tuple(latest) > self._version_tuple(current):
            self.nawaos_update_status.set_markup(
                '<span foreground="#FBBF24">%s</span>'
                % GLib.markup_escape_text(
                    _("NawaOS %s is available (you have %s)") % (latest, current)))
            self._show_nawaos_update_dialog(data, current)
        else:
            self.nawaos_update_status.set_markup(
                '<span foreground="#4ADE80">✓ %s</span>'
                % GLib.markup_escape_text(
                    _("NawaOS %s is up to date") % current))
        return False

    def _show_nawaos_update_dialog(self, data, current):
        latest = data.get('latest', '?')
        name = data.get('name') if isinstance(data.get('name'), str) else None
        notes = data.get('notes') if isinstance(data.get('notes'), str) else ''
        url = data.get('url')
        if not (isinstance(url, str) and url.startswith(('http://', 'https://'))):
            url = 'https://nawaos.com'

        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.NONE,
            text=_("%s is available") % (name or ("NawaOS " + latest))
        )
        secondary = _("Installed version: %s\nLatest version: %s") % (current, latest)
        if notes:
            secondary += "\n\n" + notes[:600]
        dialog.format_secondary_text(secondary)
        dialog.add_button(_("Open Download Page"), 1)
        dialog.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        response = dialog.run()
        dialog.destroy()
        if response == 1:
            try:
                Gtk.show_uri_on_window(self, url, Gdk.CURRENT_TIME)
            except Exception:
                try:
                    subprocess.Popen(['xdg-open', url])
                except OSError:
                    pass
    
    def _gather_system_info(self):
        """Collect real system information"""
        info = []
        def _cmd(cmd):
            try:
                r = subprocess.run(['bash', '-c', cmd], capture_output=True, text=True, timeout=5)
                return r.stdout.strip()
            except:
                return _("N/A")
        
        info.append((_("Kernel"), _cmd("uname -r")))
        info.append((_("Architecture"), _cmd("uname -m")))
        
        # Desktop Environment
        de = os.environ.get('XDG_CURRENT_DESKTOP',
                            os.environ.get('DESKTOP_SESSION', _("Unknown")))
        info.append((_("Desktop"), de))
        
        # Session type
        session = os.environ.get('XDG_SESSION_TYPE', _("Unknown"))
        info.append((_("Session"), session))
        
        info.append((_("Hostname"), _cmd("hostname")))
        info.append((_("Uptime"), _cmd("uptime -p")))
        
        # CPU
        cpu = self.get_cpu_info()
        info.append((_("CPU"), cpu))
        
        # RAM
        ram = _cmd("free -h | awk '/Mem:/{print $2 \" total, \" $3 \" used, \" $7 \" available\"}'") 
        info.append((_("Memory"), ram))
        
        # GPU
        gpu = self.get_gpu_info()
        info.append((_("GPU"), gpu))
        
        # Disk
        disk = _cmd("df -h / | awk 'NR==2{print $2 \" total, \" $3 \" used, \" $4 \" free (\" $5 \" used)\"}'") 
        info.append((_("Disk (/)"), disk))
        
        return info
    
    def create_card(self, icon, title, description, button_text, callback, btn_class="tint-btn",
                    extra_buttons=()):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.get_style_context().add_class("card")
        card.set_margin_start(10)
        card.set_margin_end(10)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        header.pack_start(nawaos_theme.icon(icon, 22), False, False, 0)
        title_label = Gtk.Label()
        title_label.set_markup(
            f'<span size="large" weight="bold" foreground="#E8EDF4">'
            f'{GLib.markup_escape_text(title)}</span>')
        title_label.set_halign(Gtk.Align.START)
        header.pack_start(title_label, False, False, 0)
        card.pack_start(header, False, False, 0)
        
        desc_label = Gtk.Label(label=description)
        desc_label.set_halign(Gtk.Align.START)
        desc_label.set_line_wrap(True)
        desc_label.get_style_context().add_class("card-desc")
        card.pack_start(desc_label, False, False, 5)
        
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        btn = Gtk.Button(label=button_text)
        btn.get_style_context().add_class(btn_class)
        btn.connect("clicked", callback)
        row.pack_start(btn, False, False, 0)
        for text, cb, cls in extra_buttons:
            extra = Gtk.Button(label=text)
            extra.get_style_context().add_class(cls)
            extra.connect("clicked", cb)
            row.pack_start(extra, False, False, 0)
        row.set_halign(Gtk.Align.START)
        card.pack_start(row, False, False, 10)
        card.action_button = btn       # callers may hide or relabel it

        return card
    
    def create_info_card(self, title, info):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.get_style_context().add_class("card")
        card.set_margin_start(10)
        card.set_margin_end(10)

        title_label = Gtk.Label()
        title_label.set_markup(
            f'<span size="large" weight="bold" foreground="#E8EDF4">'
            f'{GLib.markup_escape_text(title)}</span>')
        title_label.set_halign(Gtk.Align.START)
        card.pack_start(title_label, False, False, 0)

        info_label = Gtk.Label(label=info)
        info_label.set_halign(Gtk.Align.START)
        info_label.set_selectable(True)
        info_label.get_style_context().add_class("card-desc")
        card.pack_start(info_label, False, False, 5)
        card.info_label = info_label

        return card

    def create_async_info_card(self, title, func):
        """Info card whose text comes from ``func`` on a worker thread.

        2.3: the probes behind these cards (systemd-analyze, nmcli, df,
        timedatectl, ...) used to run before the window appeared.
        """
        card = self.create_info_card(title, _("Checking…"))

        def worker():
            try:
                text = func()
            except Exception:
                text = _("N/A")
            GLib.idle_add(card.info_label.set_text, text)
        threading.Thread(target=worker, daemon=True).start()
        return card
    
    def get_gpu_info(self):
        try:
            result = subprocess.run(['lspci'], capture_output=True, text=True, timeout=5)
            for line in result.stdout.split('\n'):
                if 'VGA' in line or 'Display' in line:
                    return line.split(': ')[-1]
        except:
            pass
        return _("Unknown GPU")
    
    def get_cpu_info(self):
        try:
            with open('/proc/cpuinfo', 'r') as f:
                for line in f:
                    if 'model name' in line:
                        return line.split(':')[1].strip()
        except:
            pass
        return _("Unknown CPU")
    
    def get_wifi_info(self):
        # NetworkManager first (iwconfig is not in the image), then the
        # kernel's own list of wireless interfaces when NM is not running.
        try:
            result = subprocess.run(['nmcli', '-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device'],
                                    capture_output=True, text=True, timeout=5)
            for line in result.stdout.splitlines():
                parts = line.split(':', 3)
                if len(parts) == 4 and parts[1] == 'wifi':
                    conn = parts[3].replace('\\:', ':')
                    return "%s: %s" % (parts[0], conn or _("Not connected"))
        except (OSError, subprocess.SubprocessError):
            pass
        try:
            wireless = sorted(d for d in os.listdir('/sys/class/net')
                              if os.path.isdir(os.path.join('/sys/class/net', d, 'wireless')))
        except OSError:
            wireless = []
        if wireless:
            return _("Wi-Fi adapter: %s") % ", ".join(wireless)
        return _("No WiFi adapter detected")
    
    # --- Helper methods for safe launching ---
    def _launch_app(self, commands, name):
        """Try multiple command alternatives to launch an app, offer install if not found"""
        for cmd in commands:
            try:
                subprocess.Popen(cmd)
                return True
            except (FileNotFoundError, OSError):
                continue
        
        # App not found - offer to install
        self._offer_install(name, commands)
        return False
    
    def _offer_install(self, name, commands):
        """Show dialog offering to install the missing application"""
        # Detect package name from commands
        apt_pkg = None
        flatpak_id = None
        
        # Common app to package mappings
        pkg_map = {
            'gufw': ('gufw', None),
            'baobab': ('baobab', 'org.gnome.baobab'),
            'gnome-disks': ('gnome-disk-utility', 'org.gnome.DiskUtility'),
            'gparted': ('gparted', None),
            'pavucontrol': ('pavucontrol', None),
            'blueman-manager': ('blueman', None),
            'arandr': ('arandr', None),
            'gnome-system-monitor': ('gnome-system-monitor', 'org.gnome.SystemMonitor'),
            'timeshift-gtk': ('timeshift', None),
            'deja-dup': ('deja-dup', 'org.gnome.DejaDup'),
            'htop': ('htop', None),
            'gsmartcontrol': ('gsmartcontrol', None),
        }
        
        # Keep the FIRST (primary) command's package: only fill a slot that is
        # still empty, so a later fallback alternative can add e.g. a Flatpak
        # option but never overwrite the primary APT package (previously the
        # last fallback in the list won and the wrong package was offered).
        for cmd in commands:
            if isinstance(cmd, list):
                if 'flatpak' in cmd and 'run' in cmd:
                    if flatpak_id is None:
                        for part in cmd:
                            if '.' in part and part.count('.') >= 2:
                                flatpak_id = part
                                break
                elif cmd and apt_pkg is None:
                    app_name = cmd[0].split('/')[-1]
                    if app_name in pkg_map:
                        apt_pkg, fid = pkg_map[app_name]
                        if fid and flatpak_id is None:
                            flatpak_id = fid
                    else:
                        apt_pkg = app_name
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=_("%s is not installed") % name
        )
        dialog.format_secondary_text(_("Would you like to install it now?"))

        if apt_pkg:
            dialog.add_button(_("Install via APT (%s)") % apt_pkg, 1)
        if flatpak_id:
            dialog.add_button(_("Install via Flatpak"), 2)
        dialog.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        
        response = dialog.run()
        dialog.destroy()
        
        if response == 1 and apt_pkg:
            self._run_task(_("Install %s") % name,
                           nawaos_taskrunner.shell(
                               "apt-get update && apt-get install -y " + shlex.quote(apt_pkg)),
                           root=True)
        elif response == 2 and flatpak_id:
            self._run_task(_("Install %s") % name,
                           ["flatpak", "install", "-y", "flathub", flatpak_id])

    def _run_task(self, title, argv, root=False, on_done=None):
        """Run a tool inside the app with live output (nawaos_taskrunner).

        2.2: replaces the terminal windows every tool button used to open.
        """
        return nawaos_taskrunner.run_task(self, title, argv, root=root, on_done=on_done,
                                          category="system", source=_("Control Panel"))
    
    def on_flatpak_clicked(self, button):
        self._launch_app([["nawaos-store"]], _("NawaOS Store"))
    
    def on_flatpak_update_clicked(self, button):
        self._run_task(_("Update Flatpak Apps"), ["flatpak", "update", "-y"])
    
    def on_update_clicked(self, button):
        # Route through the update manager (run as root by the task runner): it
        # takes a Timeshift snapshot first, disables a third-party repository
        # entry that no longer resolves instead of failing the whole update,
        # and reports the real apt result. The old inline "sudo apt update &&
        # sudo apt upgrade" aborted on the first broken sources entry.
        self._run_task(_("Update System"),
                       ["/usr/local/bin/nawaos-update-manager", "update"], root=True)

    def on_security_update_clicked(self, button):
        self._run_task(_("Security Updates Only"),
                       ["/usr/local/bin/nawaos-update-manager", "security"], root=True)

    def on_clean_clicked(self, button):
        self._run_task(_("Clean System"),
                       nawaos_taskrunner.shell("apt-get autoremove -y && apt-get clean"),
                       root=True)
    
    # ===== DRIVERS PAGE HELPERS (2.0) =====
    def _list_gpus(self):
        """All GPUs from lspci as (vendor, description) tuples.

        vendor is one of 'nvidia', 'amd', 'intel', 'other'.
        """
        gpus = []
        try:
            result = subprocess.run(['lspci'], capture_output=True, text=True, timeout=5)
        except Exception:
            return gpus
        for line in result.stdout.splitlines():
            if ('VGA compatible controller' in line or '3D controller' in line
                    or 'Display controller' in line):
                desc = line.split(': ', 1)[-1].strip()
                low = desc.lower()
                if 'nvidia' in low:
                    vendor = 'nvidia'
                elif 'amd' in low or 'ati ' in low or 'radeon' in low or '[amd' in low:
                    vendor = 'amd'
                elif 'intel' in low:
                    vendor = 'intel'
                else:
                    vendor = 'other'
                gpus.append((vendor, desc))
        return gpus

    def _refresh_nvidia_status(self):
        """Fill the NVIDIA card's status lines on a worker thread."""
        def worker():
            # Installed state via dpkg (authoritative, no root needed)
            installed = None
            version = None
            try:
                r = subprocess.run(['dpkg', '-s', 'nvidia-driver'],
                                   capture_output=True, text=True, timeout=10)
                if r.returncode == 0 and 'Status: install ok installed' in r.stdout:
                    installed = True
                    for line in r.stdout.splitlines():
                        if line.startswith('Version:'):
                            version = line.split(':', 1)[1].strip()
                            break
                else:
                    installed = False
            except Exception:
                installed = None

            # GPU family and the packages to install, from
            # nawaos-nvidia-support (2.2: NVIDIA's 595 branch supports Turing
            # and newer; Maxwell/Pascal/Volta have no proprietary driver).
            support = {}
            if os.path.exists('/usr/local/bin/nawaos-nvidia-support'):
                try:
                    r = subprocess.run(['/usr/local/bin/nawaos-nvidia-support'],
                                       capture_output=True, text=True, timeout=20)
                    for line in r.stdout.splitlines():
                        if '=' in line:
                            k, v = line.split('=', 1)
                            support[k.strip()] = v.strip()
                except Exception:
                    pass

            # Secure Boot state via mokutil (may not be installed / no EFI)
            secureboot = None
            if shutil.which('mokutil'):
                try:
                    r = subprocess.run(['mokutil', '--sb-state'],
                                       capture_output=True, text=True, timeout=10)
                    out = (r.stdout + r.stderr).lower()
                    if 'enabled' in out:
                        secureboot = True
                    elif 'disabled' in out or 'not supported' in out:
                        secureboot = False
                except Exception:
                    pass

            # Module / signing-key verdict from the 2.1 enrolment helper
            mok = {}
            if os.path.exists('/usr/local/bin/nawaos-mok-enroll'):
                try:
                    r = subprocess.run(['/usr/local/bin/nawaos-mok-enroll', 'status'],
                                       capture_output=True, text=True, timeout=30)
                    for line in r.stdout.splitlines():
                        if '=' in line:
                            k, v = line.split('=', 1)
                            mok[k.strip()] = v.strip()
                except Exception:
                    pass

            GLib.idle_add(self._update_nvidia_status, installed, version,
                          support, secureboot, mok)
        threading.Thread(target=worker, daemon=True).start()

    def _update_nvidia_status(self, installed, version, support, secureboot, mok=None):
        if not hasattr(self, 'nvidia_status_label'):
            return False
        self._update_mok_status(mok or {})
        status = (support or {}).get('status', '')
        legacy = status == 'legacy' and installed is not True
        if installed is True:
            text = _("Installed: nvidia-driver %s") % (version or "")
            self.nvidia_status_label.set_markup(
                '<span foreground="#4ADE80">✓ %s</span>'
                % GLib.markup_escape_text(text.strip()))
        elif legacy:
            self.nvidia_status_label.set_markup(
                '<span foreground="#FBBF24">%s</span>'
                % GLib.markup_escape_text(
                    _("No proprietary driver available for this GPU (using open-source nouveau)")))
        elif installed is False:
            self.nvidia_status_label.set_markup(
                '<span foreground="#FBBF24">%s</span>'
                % GLib.markup_escape_text(
                    _("Proprietary driver not installed (using open-source nouveau)")))
        else:
            self.nvidia_status_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Could not determine installed driver state")))

        if legacy:
            self.nvidia_recommend_label.set_line_wrap(True)
            self.nvidia_recommend_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(
                    _("No proprietary driver for this GPU: NVIDIA dropped GeForce GTX 900 / "
                      "GTX 10 series and TITAN V (Maxwell, Pascal, Volta) from its Linux drivers "
                      "in the 590 branch, and Debian's older 550 driver does not build on the "
                      "NawaOS kernel. The open-source nouveau driver with NVIDIA's GSP firmware "
                      "is used instead; OpenGL and Vulkan work through Mesa.")))
        elif status == 'supported':
            self.nvidia_recommend_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>\n<span foreground="#9AA7B8">%s </span>'
                '<span foreground="#37BCE0" weight="bold">%s</span>'
                % (GLib.markup_escape_text(
                       _("Supported by NVIDIA's current driver (595 branch, open kernel modules)")),
                   GLib.markup_escape_text(_("Driver packages:")),
                   GLib.markup_escape_text(support.get('package', 'nvidia-driver'))))
        else:
            self.nvidia_recommend_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Could not determine whether this GPU is supported")))
        # Nothing to install for a legacy GPU: hide the button rather than
        # let it fail.
        if hasattr(self, 'nvidia_install_btn'):
            self.nvidia_install_btn.set_visible(not legacy)

        if secureboot is True:
            self.secureboot_label.set_markup(
                '<span foreground="#FBBF24">⚠ %s</span>'
                % GLib.markup_escape_text(
                    _("Secure Boot is ENABLED: the DKMS module must be signed and its "
                      "MOK key enrolled (mokutil --import) before the driver can load.")))
        elif secureboot is False:
            self.secureboot_label.set_markup(
                '<span foreground="#4ADE80">✓ %s</span>'
                % GLib.markup_escape_text(
                    _("Secure Boot is disabled -- no DKMS module signing needed")))
        else:
            self.secureboot_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(
                    _("Secure Boot state unknown (mokutil unavailable)")))
        return False

    def _update_mok_status(self, mok):
        """Module built/loaded/signed + MOK enrolment line and button."""
        if not hasattr(self, 'mok_label'):
            return
        verdict = mok.get('verdict')
        if not mok or verdict is None:
            self.mok_label.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Driver module state unavailable")))
            self.mok_btn.hide()
            return
        module = mok.get('nvidia_module', 'missing') if mok.get('nvidia_dkms') == 'installed' else 'missing'
        loaded = mok.get('nvidia_loaded') == 'yes'
        enrolled = mok.get('mok_enrolled', 'unknown')
        parts = []
        parts.append(_("module: loaded") if loaded else
                     (_("module: built, not loaded") if module == 'built' else _("module: not built")))
        signer = mok.get('nvidia_signer')
        if signer and signer != 'none':
            parts.append(_("signed"))
        parts.append(_("key enrolled: %s") % {'yes': _("yes"), 'no': _("no")}.get(enrolled, _("unknown")))
        text = " · ".join(parts)
        if verdict == 'needs-enrol':
            self.mok_label.set_markup('<span foreground="#FBBF24">⚠ %s</span>' % GLib.markup_escape_text(
                text + " — " + _("the driver stays blocked until the key is enrolled")))
            self.mok_btn.show()
        elif verdict == 'pending':
            self.mok_label.set_markup('<span foreground="#FBBF24">⚠ %s</span>' % GLib.markup_escape_text(
                text + " — " + _("enrolment queued: reboot and confirm in the MOK manager")))
            self.mok_btn.show()
        elif verdict == 'ok':
            self.mok_label.set_markup('<span foreground="#4ADE80">✓ %s</span>' % GLib.markup_escape_text(text))
            self.mok_btn.hide()
        else:
            self.mok_label.set_markup('<span foreground="#9AA7B8">%s</span>' % GLib.markup_escape_text(text))
            self.mok_btn.hide()

    def on_mok_enroll_clicked(self, button):
        self._launch_app([["nawaos-mok-enroll-gui"]], _("Secure Boot driver key"))
        # Re-read the state when the window is closed (polled once after a delay).
        GLib.timeout_add_seconds(20, lambda: (self._refresh_nvidia_status(), False)[1])

    def _refresh_vulkan_summary(self):
        """Fill the AMD/Intel card's Vulkan line on a worker thread."""
        def worker():
            text = None
            ok = False
            if shutil.which('vulkaninfo'):
                try:
                    r = subprocess.run(['vulkaninfo', '--summary'],
                                       capture_output=True, text=True, timeout=20)
                    if r.returncode == 0:
                        devices = []
                        api = None
                        for line in r.stdout.splitlines():
                            s = line.strip()
                            if s.startswith('deviceName'):
                                devices.append(s.split('=', 1)[-1].strip())
                            elif s.startswith('apiVersion') and api is None:
                                api = s.split('=', 1)[-1].strip()
                        if devices:
                            ok = True
                            text = _("Vulkan ready: %s") % ", ".join(dict.fromkeys(devices))
                            if api:
                                text += " (API %s)" % api.split()[-1].strip('()')
                        else:
                            text = _("Vulkan loader present, but no Vulkan device reported")
                    else:
                        text = _("vulkaninfo failed -- Vulkan may not be working on this GPU")
                except Exception:
                    text = _("Vulkan check failed or timed out")
            else:
                text = _("vulkaninfo not installed (apt install vulkan-tools to verify Vulkan)")
            GLib.idle_add(self._update_vulkan_summary, ok, text)
        threading.Thread(target=worker, daemon=True).start()

    def _update_vulkan_summary(self, ok, text):
        if hasattr(self, 'vulkan_label'):
            color = "#4ADE80" if ok else "#9AA7B8"
            prefix = "✓ " if ok else ""
            self.vulkan_label.set_markup(
                '<span foreground="%s">%s%s</span>'
                % (color, prefix, GLib.markup_escape_text(text)))
        return False

    def on_nvidia_clicked(self, button):
        # Honest installer: refuses legacy GPUs (nawaos-nvidia-support) when
        # available, warns about Secure Boot/DKMS, and reports the REAL
        # apt result instead of always printing success.
        nvidia_script = """
echo "=== NawaOS NVIDIA Driver Installer ==="
echo ""
if ! lspci | grep -qi nvidia; then
    echo "✗ No NVIDIA GPU detected on this system."
    exit 1
fi
echo "✓ NVIDIA GPU detected"
# 2.2: NVIDIA's own repository, 595 branch (Turing and newer). Older GPUs
# (GTX 900 / GTX 10 / TITAN V) have no proprietary driver any more.
if [ -x /usr/local/bin/nawaos-nvidia-support ] && [ "$(/usr/local/bin/nawaos-nvidia-support status)" = legacy ]; then
    echo ""
    echo "✗ No proprietary driver for this GPU."
    echo "  NVIDIA dropped Maxwell, Pascal and Volta (GeForce GTX 900 / GTX 10,"
    echo "  TITAN V) from its Linux drivers in the 590 branch, and Debian's older"
    echo "  550 driver does not build on the NawaOS kernel. The open-source"
    echo "  nouveau driver is used; OpenGL and Vulkan work through Mesa."
    exit 1
fi
PKG="nvidia-driver nvidia-kernel-open-dkms nvidia-driver-libs:i386"
echo "Driver packages: $PKG (NVIDIA repository, 595 branch)"
echo ""
if command -v mokutil >/dev/null 2>&1 && mokutil --sb-state 2>/dev/null | grep -qi 'enabled'; then
    echo "⚠ Secure Boot is ENABLED."
    echo "  The NVIDIA kernel module is built by DKMS and must be signed;"
    echo "  it will NOT load until its MOK key is enrolled (mokutil --import)"
    echo "  or Secure Boot is disabled in firmware setup."
    echo ""
fi
echo "Installing $PKG ..."
if apt-get update && apt-get install -y $PKG nvidia-settings; then
    echo ""
    echo "✓ Driver installed successfully."
    echo "  Please REBOOT to load the new driver."
else
    echo ""
    echo "✗ Installation FAILED -- the driver was NOT installed."
    echo "  Check your internet connection and the apt output above."
    exit 1
fi
"""
        self._run_task(_("NVIDIA Driver Manager"), nawaos_taskrunner.shell(nvidia_script),
                       root=True, on_done=lambda *_a: GLib.idle_add(self._refresh_nvidia_status))
    
    def on_wifi_drivers_clicked(self, button):
        # nawaos-wifi-fix does the work: rfkill, bundled Realtek USB sources
        # built offline with DKMS, Debian firmware when online, NM restart.
        self._run_task(_("Fix Wi-Fi"), ["nawaos-wifi-fix"], root=True)

    def on_copy_report_clicked(self, button):
        """Generate the plain-text system report and put it on the clipboard.

        nawaos-sysinfo can take many seconds; it runs on a worker thread and
        the button waits instead of the whole window.
        """
        original_label = button.get_label()
        button.set_sensitive(False)
        button.set_label(_("Collecting…"))

        def worker():
            try:
                proc = subprocess.run(["nawaos-sysinfo", "report"],
                                      capture_output=True, text=True, timeout=60)
                text, error = proc.stdout or proc.stderr or "", None
            except (OSError, subprocess.SubprocessError) as exc:
                text, error = "", str(exc)
            GLib.idle_add(self._copy_report_done, button, original_label, text, error)
        threading.Thread(target=worker, daemon=True).start()

    def _copy_report_done(self, button, original_label, text, error):
        button.set_sensitive(True)
        button.set_label(original_label)
        if error:
            self.show_info_dialog(_("Error"), error)
            return False
        if not text.strip():
            self.show_info_dialog(_("Error"),
                                  _("The report could not be generated."))
            return False
        path = str(Path.home() / "NawaOS-report.txt")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            path = None
        try:
            clip = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
            clip.set_text(text, -1)
            clip.store()
        except Exception:
            pass
        msg = _("The report was copied to the clipboard.")
        if path:
            msg += "\n" + _("A copy was saved to %s.") % path
        msg += "\n\n" + _("Paste it into your bug report at "
                          "github.com/AHMED-ABDULLA-BH/nawaos/issues.")
        self.show_info_dialog(_("System report"), msg)
        return False
    
    # ===== SECURITY PAGE HELPERS =====
    def _check_firewall_status(self):
        # `ufw status` requires root; calling it via `sudo` from a GUI (no TTY)
        # just fails. Check ufw's own (world-readable) config instead.
        #
        # IMPORTANT: ufw.service is Type=oneshot + RemainAfterExit=yes, so
        # `systemctl is-active ufw` reports "active" whenever the package is
        # installed -- even with the firewall DISABLED (ENABLED=no), and
        # `ufw disable` does not stop the unit. So the ENABLED= flag in
        # ufw.conf is the authoritative signal; the service state is only a
        # fallback used when the config cannot be read.
        try:
            enabled = None
            try:
                with open('/etc/ufw/ufw.conf') as f:
                    enabled = 'ENABLED=yes' in f.read()
            except OSError:
                pass
            if enabled is None:
                result = subprocess.run(['systemctl', 'is-active', 'ufw'],
                                        capture_output=True, text=True, timeout=5)
                enabled = result.stdout.strip() == 'active'
            if enabled:
                self.firewall_status.set_markup('<span foreground="#4ADE80">✓ %s</span>' % GLib.markup_escape_text(_("Firewall: Active")))
            else:
                self.firewall_status.set_markup('<span foreground="#FBBF24">⚠ %s</span>' % GLib.markup_escape_text(_("Firewall: Inactive")))
        except Exception:
            self.firewall_status.set_markup(
                '<span foreground="#9AA7B8">%s</span>'
                % GLib.markup_escape_text(_("Unable to check firewall status")))
        return False
    
    def on_firewall_clicked(self, button):
        self._launch_app([["gufw"], ["ufw-gtk"]], _("Firewall Settings"))
    
    def on_enable_firewall(self, button):
        self._run_task(_("Enable Firewall"), ["ufw", "enable"], root=True,
                       on_done=lambda *_a: GLib.timeout_add(500, self._check_firewall_status))

    def on_disable_firewall(self, button):
        self._run_task(_("Disable Firewall"), ["ufw", "disable"], root=True,
                       on_done=lambda *_a: GLib.timeout_add(500, self._check_firewall_status))

    def on_change_password(self, button):
        # passwd needs a terminal; the desktop's account page has the same
        # "change password" flow in a window.
        self._launch_app([["cinnamon-settings", "user"]], _("Account Settings"))
    
    def on_security_scan(self, button):
        script = '''
echo "=== NawaOS Security Check ==="
echo ""
echo "Checking for security updates..."
apt list --upgradable 2>/dev/null | grep -i security | head -10
echo ""
echo "Checking firewall status..."
ufw status 2>/dev/null || echo "UFW not installed"
echo ""
echo "Checking for users with empty passwords..."
awk -F: '($2 == "") {print $1}' /etc/shadow 2>/dev/null || echo "Check complete"
echo ""
echo "Checking /tmp permissions..."
ls -ld /tmp
echo ""
echo "Security scan complete."
'''
        self._run_task(_("Security Scan"), nawaos_taskrunner.shell(script), root=True)

    # ===== STORAGE PAGE HELPERS =====
    def _get_disk_usage(self):
        try:
            result = subprocess.run(['df', '-h', '/'], capture_output=True, text=True, timeout=5)
            lines = result.stdout.strip().split('\n')
            if len(lines) > 1:
                parts = lines[1].split()
                return _("Root: %s used of %s (%s)") % (
                    parts[2], parts[1], parts[4])
        except:
            pass
        return _("Unable to detect disk usage")
    
    def on_disk_analyzer(self, button):
        self._launch_app([["baobab"], ["gnome-disks"], ["filelight"]], _("Disk Analyzer"))
    
    def on_clean_cache(self, button):
        # Runs as root; the thumbnail cache belongs to the user who clicked,
        # whose home comes from PKEXEC_UID (HOME is root's under pkexec).
        script = '''
echo "=== Cleaning System Cache ==="
echo ""
echo "Cleaning APT cache..."
apt-get clean
echo ""
echo "Removing old packages..."
apt-get autoremove -y
echo ""
USER_HOME=$(getent passwd "${PKEXEC_UID:-$(id -u)}" | cut -d: -f6)
if [ -n "$USER_HOME" ] && [ -d "$USER_HOME/.cache/thumbnails" ]; then
    echo "Cleaning thumbnail cache..."
    rm -rf "$USER_HOME/.cache/thumbnails"/*
    echo ""
fi
echo "Cleaning temporary files (older than 2 days only)..."
find /tmp -mindepth 1 -atime +2 -delete 2>/dev/null
echo ""
echo "Cleanup complete."
'''
        self._run_task(_("Clean Cache"), nawaos_taskrunner.shell(script), root=True)

    def on_mount_all(self, button):
        self._run_task(_("Mount Now"), ["/usr/local/bin/nawaos-automount", "mount"], root=True)

    def on_automount_setup(self, button):
        self._run_task(_("Mount at Boot"), ["/usr/local/bin/nawaos-automount"], root=True)

    def on_disk_health(self, button):
        self._launch_app([["gnome-disks"], ["gsmartcontrol"]], _("Disk Health"))
    
    def on_gparted(self, button):
        # Popen(["pkexec", ...]) starts pkexec fine even when the target app is
        # missing, so a missing gparted was never detected -- check first.
        if shutil.which("gparted") is None:
            self._offer_install("GParted", [["gparted"]])
            return
        try:
            subprocess.Popen(["pkexec", "gparted"])
        except OSError as e:
            self.show_info_dialog("GParted",
                                  _("Could not launch GParted: %s") % e)
    
    # ===== PERIPHERALS PAGE HELPERS =====
    def on_printers(self, button):
        self._launch_app([["system-config-printer"]], _("Printers"))
    
    def on_bluetooth(self, button):
        self._launch_app([["blueman-manager"]], _("Bluetooth"))
    
    def on_display(self, button):
        # Cinnamon's own panels (cinnamon-settings modules = cs_*.py in
        # /usr/share/cinnamon/cinnamon-settings/modules); gnome-control-center
        # is not in the image.
        self._launch_app([["cinnamon-settings", "display"]], _("Display"))
    
    def on_sound(self, button):
        self._launch_app([["pavucontrol"], ["cinnamon-settings", "sound"]], _("Sound"))
    
    def on_input_devices(self, button):
        self._launch_app([["cinnamon-settings", "mouse"]], _("Input Devices"))
    
    # ===== STARTUP PAGE HELPERS =====
    def _get_boot_time(self):
        try:
            result = subprocess.run(['systemd-analyze'], capture_output=True, text=True, timeout=10)
            if result.stdout:
                return result.stdout.strip().split('\n')[0]
            return _("Unable to analyze boot time")
        except:
            return _("Unable to analyze boot time")
    
    def on_startup_apps(self, button):
        self._launch_app([["cinnamon-settings", "startup"]], _("Startup Applications"))
    
    def on_services(self, button):
        self._run_task(_("System Services"),
                       ["systemctl", "list-units", "--type=service", "--state=running",
                        "--no-pager"])

    def on_cron(self, button):
        self._run_task(_("Scheduled Tasks"),
                       nawaos_taskrunner.shell(
                           "crontab -l 2>/dev/null || echo 'No cron jobs'; echo; "
                           "echo 'To edit: crontab -e'"))
    
    # ===== LOCALIZATION PAGE HELPERS =====
    def _get_locale_info(self):
        try:
            lang = os.environ.get('LANG', _("Unknown"))
            tz_result = subprocess.run(['timedatectl', 'show', '-p', 'Timezone', '--value'], capture_output=True, text=True, timeout=5)
            tz = tz_result.stdout.strip() if tz_result.stdout else _("Unknown")
            return _("Language: %s\nTimezone: %s") % (lang, tz)
        except:
            return _("Unable to detect locale settings")
    
    def on_set_language(self, code):
        """Write the NawaOS language and the session locale for ``code``.

        ~/.config/nawaos/language is read by every NawaOS app at start
        (nawaos_i18n); environment.d and ~/.dmrc give the next desktop
        session the same locale. Same files as the Welcome Wizard.
        """
        lang, language = LOCALE_MAP[code]
        home = Path.home()
        try:
            _write_text(home / ".config" / "nawaos" / "language", code + "\n")
            _write_text(home / ".config" / "environment.d" / "50-nawaos-lang.conf",
                        "# Written by the NawaOS Control Panel; applies on next login\n"
                        "LANG=%s\nLANGUAGE=%s\n" % (lang, language))
            _set_dmrc_language(home / ".dmrc", lang)
        except OSError as e:
            self.show_info_dialog(_("Error"), str(e))
            return
        name = "العربية" if code == "ar" else "English"
        self.show_info_dialog(
            _("Language set to %s") % name,
            _("Close and reopen the NawaOS apps to see it. The desktop switches "
              "at your next login."))
    
    def on_keyboard(self, button):
        # Layouts are a tab of Cinnamon's keyboard panel.
        self._launch_app([["cinnamon-settings", "keyboard"]], _("Keyboard Settings"))
    
    def on_time_settings(self, button):
        self._launch_app([["cinnamon-settings", "calendar"]], _("Time Settings"))
    
    # ===== MONITOR PAGE HELPERS =====
    def _update_system_stats(self):
        try:
            # CPU
            with open('/proc/loadavg', 'r') as f:
                load = f.read().split()[0]
            self.cpu_label.set_markup(
                '<span foreground="#E8EDF4">%s </span>'
                '<span foreground="#37BCE0" weight="bold">%s</span>'
                % (GLib.markup_escape_text(_("CPU Load:")),
                   GLib.markup_escape_text(load)))
            
            # RAM -- parse /proc/meminfo by KEY, not by line index. The index of
            # MemAvailable/SwapTotal/SwapFree shifts with kernel build options
            # (CMA, highmem, ...), which made the monitor show wrong numbers.
            meminfo = {}
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        meminfo[parts[0].strip()] = int(parts[1].split()[0])  # kB
            total = meminfo.get('MemTotal', 0) // 1024
            available = meminfo.get('MemAvailable', 0) // 1024
            used = total - available
            ram_pct = (used / total) * 100 if total else 0
            color = "#4ADE80" if ram_pct < 70 else "#FBBF24" if ram_pct < 90 else "#F87171"
            self.ram_label.set_markup(
                '<span foreground="#E8EDF4">%s </span>'
                '<span foreground="%s" weight="bold">%dMB / %dMB (%.1f%%)</span>'
                % (GLib.markup_escape_text(_("RAM:")), color, used, total,
                   ram_pct))

            # Swap
            swap_total = meminfo.get('SwapTotal', 0) // 1024
            swap_free = meminfo.get('SwapFree', 0) // 1024
            swap_used = swap_total - swap_free
            self.swap_label.set_markup(
                '<span foreground="#E8EDF4">%s </span>'
                '<span foreground="#9AA7B8">%dMB / %dMB</span>'
                % (GLib.markup_escape_text(_("Swap:")), swap_used, swap_total))
            
            # Temperature
            try:
                with open('/sys/class/thermal/thermal_zone0/temp') as f:
                    temp = int(f.read().strip()) // 1000
                temp_color = "#4ADE80" if temp < 60 else "#FBBF24" if temp < 80 else "#F87171"
                self.temp_label.set_markup(
                    '<span foreground="#E8EDF4">%s </span>'
                    '<span foreground="%s" weight="bold">%d°C</span>'
                    % (GLib.markup_escape_text(_("Temperature:")), temp_color,
                       temp))
            except:
                self.temp_label.set_markup(
                    '<span foreground="#9AA7B8">%s</span>'
                    % GLib.markup_escape_text(_("Temperature: N/A")))
        except:
            pass
        return True
    
    def on_system_monitor(self, button):
        self._launch_app([["gnome-system-monitor"], ["mate-system-monitor"], ["xfce4-taskmanager"]], _("System Monitor"))
    
    def on_gpu_monitor(self, button):
        # The right tool per vendor: nvidia-settings comes with the NVIDIA
        # driver, CoreCtrl (in the image) shows AMD load and temperature, and
        # nvtop (terminal, all three vendors) covers the rest.
        vendors = {vendor for vendor, _desc in self._list_gpus()}
        if 'nvidia' in vendors and shutil.which("nvidia-settings"):
            self._launch_app([["nvidia-settings"]], _("GPU Monitor"))
        elif 'amd' in vendors and shutil.which("corectrl"):
            self._launch_app([["corectrl"]], _("GPU Monitor"))
        elif shutil.which("nvtop"):
            self._launch_app([["gnome-terminal", "--", "nvtop"],
                              ["x-terminal-emulator", "-e", "nvtop"]], _("GPU Monitor"))
        else:
            self._offer_install("nvtop", [["nvtop"]])
    
    # ===== BACKUP PAGE HELPERS =====
    def on_timeshift(self, button):
        # Same as on_gparted: pkexec launching hides a missing target binary,
        # so check for it before spawning.
        if shutil.which("timeshift-gtk") is None:
            self._offer_install("Timeshift", [["timeshift-gtk"]])
            return
        try:
            subprocess.Popen(["pkexec", "timeshift-gtk"])
        except OSError as e:
            self.show_info_dialog("Timeshift",
                                  _("Could not launch Timeshift: %s") % e)
    
    def on_create_snapshot(self, button):
        self._run_task(_("Quick Snapshot"),
                       ["timeshift", "--create", "--comments", "Manual snapshot"], root=True)
    
    # Home backup (2.3): the user picks the destination (a removable drive by
    # default); caches, game libraries, the Trash and earlier backups are
    # left out, and the copy is refused up front when it would not fit.
    # $1 is the destination folder.
    BACKUP_HOME_SCRIPT = r'''
DEST="$1"
BACKUP_DIR="$DEST/NawaOS-home-$(date +%Y%m%d-%H%M%S)"
EXCL=(--exclude=/.cache --exclude=/.local/share/Trash
      --exclude=/.local/share/Steam --exclude=/.steam
      --exclude='/.var/app/*/cache'
      --exclude=/.var/app/com.valvesoftware.Steam/.local/share/Steam
      --exclude=/Games --exclude=/Backups)
# A destination inside the home folder must not copy itself or the backups
# already there.
case "$DEST/" in
    "$HOME"/*) EXCL+=("--exclude=${DEST#"$HOME"}/NawaOS-home-*") ;;
esac

echo "=== Home Folder Backup ==="
echo "Destination: $BACKUP_DIR"
echo "Left out: caches, Trash, Steam and ~/Games libraries, earlier backups"
echo ""
echo "Measuring what will be copied..."
SIZE=$(rsync -a --dry-run --stats --no-h "${EXCL[@]}" "$HOME/" "$BACKUP_DIR/" 2>/dev/null \
       | sed -n 's/^Total file size: \([0-9,]*\) bytes.*/\1/p' | tr -d ,)
FREE=$(df -B1 --output=avail "$DEST" 2>/dev/null | tail -1 | tr -d ' ')
if [ -z "$SIZE" ] || [ -z "$FREE" ]; then
    echo "✗ Could not measure the home folder or the free space at the destination."
    exit 1
fi
NEED=$((SIZE + SIZE / 20 + 100 * 1024 * 1024))
echo "To copy: $(numfmt --to=iec "$SIZE")   Free at destination: $(numfmt --to=iec "$FREE")"
if [ "$FREE" -lt "$NEED" ]; then
    echo ""
    echo "✗ Not enough free space: $(numfmt --to=iec "$NEED") needed."
    echo "  Choose another drive, or free some space, and try again."
    exit 1
fi

# FAT/exFAT/NTFS drives cannot hold Linux permissions or symlinks.
case "$(stat -f -c %T "$DEST" 2>/dev/null)" in
    msdos|vfat|exfat|fuseblk|ntfs*) OPTS=(-rt --modify-window=2) ;;
    *) OPTS=(-a) ;;
esac
mkdir -p "$BACKUP_DIR" || exit 1
echo ""
echo "Copying..."
rsync "${OPTS[@]}" --stats -h "${EXCL[@]}" "$HOME/" "$BACKUP_DIR/"
rc=$?
echo ""
# 24: some files vanished during the copy (normal for a live home folder).
if [ $rc -eq 0 ] || [ $rc -eq 24 ]; then
    echo "✓ Backup complete: $BACKUP_DIR"
else
    echo "✗ Backup failed (rsync exit $rc). The partial copy is in $BACKUP_DIR"
    exit 1
fi
'''

    def _removable_drive(self):
        """First writable mounted drive under /media/$USER or /run/media/$USER."""
        user = os.environ.get("USER") or Path.home().name
        for base in ("/media/" + user, "/run/media/" + user):
            try:
                entries = sorted(os.listdir(base))
            except OSError:
                continue
            for name in entries:
                path = os.path.join(base, name)
                if os.path.ismount(path) and os.access(path, os.W_OK):
                    return path
        return None

    def on_backup_home(self, button):
        dialog = Gtk.FileChooserDialog(
            title=_("Choose where to save the backup"), transient_for=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER)
        dialog.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL,
                           _("Back Up Here"), Gtk.ResponseType.OK)
        dialog.set_current_folder(self._removable_drive() or str(Path.home()))
        response = dialog.run()
        dest = dialog.get_filename()
        dialog.destroy()
        if response != Gtk.ResponseType.OK or not dest:
            return

        try:
            same_disk = os.stat(dest).st_dev == os.stat(Path.home()).st_dev
        except OSError:
            same_disk = False
        if same_disk:
            confirm = Gtk.MessageDialog(
                transient_for=self, flags=0,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.NONE,
                text=_("This folder is on the same disk as your home folder"))
            confirm.format_secondary_text(
                _("A backup there is lost together with your files if the disk fails. "
                  "An external drive is safer."))
            confirm.add_buttons(_("Cancel"), Gtk.ResponseType.CANCEL,
                                _("Back Up Anyway"), Gtk.ResponseType.OK)
            response = confirm.run()
            confirm.destroy()
            if response != Gtk.ResponseType.OK:
                return

        self._run_task(_("Backup Home Folder"),
                       nawaos_taskrunner.shell(self.BACKUP_HOME_SCRIPT) + ["nawaos-backup", dest])

    def on_deja_dup(self, button):
        self._launch_app([["deja-dup"]], "Deja Dup")

    def on_backup_manager(self, button):
        self._launch_app([["nawaos-backup-manager"]], _("NawaOS Backup Manager"))
    
    def show_info_dialog(self, title, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(prog="nawaos-control-panel")
    parser.add_argument("--page", default=None,
                        help="open this page (gaming, power, network, security, storage, "
                             "peripherals, drivers, startup, localization, monitor, "
                             "backup, appearance, updates, about)")
    args = parser.parse_args(argv)
    app = NawaOSControlPanel()
    if args.page:
        app.show_page(args.page)
    app.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()
