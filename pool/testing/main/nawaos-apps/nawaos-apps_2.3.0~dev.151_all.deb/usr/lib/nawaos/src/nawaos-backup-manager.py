#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Backup Manager
Backup and restore system settings and game saves

Developed by: Ahmed Abdulla
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
import subprocess
import threading
import os
import sys
import re
import json
import signal
import time
import tarfile
import tempfile
import posixpath
from pathlib import Path
from datetime import datetime

try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

# Release info shared by all NawaOS apps (nawaos-common/nawaos_release.py).
try:
    import nawaos_release
except ImportError:
    nawaos_release = None

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402

# Save collection + cloud upload shared with the nawaos-savesync watcher
# (installed to dist-packages; the fallback path is for running from a
# source checkout).
try:
    import nawaos_savesync
except ImportError:
    import sys as _sys
    _sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "nawaos-common"))
    import nawaos_savesync

APP_NAME = "nawaos-backup-manager"

# ---------------------------------------------------------------------------
# Built-in Arabic UI strings. Every user-visible string goes through _()
# with this dictionary; product and tool names stay in Latin script.
# ---------------------------------------------------------------------------
AR_STRINGS = {
    "NawaOS Backup Manager": "مدير النسخ الاحتياطي NawaOS",
    "Backup Manager": "مدير النسخ الاحتياطي",
    "Backup": "النسخ الاحتياطي",
    "Restore": "الاستعادة",
    "Save Games": "حفظ الألعاب",
    "Settings": "الإعدادات",
    "Ready": "جاهز",
    "Cancel": "إلغاء",
    "Cancelling...": "جارٍ الإلغاء...",
    "unknown error": "خطأ غير معروف",
    "command not found: %s": "الأمر غير موجود: %s",
    "What to back up": "ما الذي سيتم نسخه احتياطياً",
    "App Data & Game Saves": "بيانات التطبيقات وحفظ الألعاب",
    "Settings & Configs": "الإعدادات والتكوينات",
    "Wine Prefixes": "بادئات Wine",
    "Steam Games": "ألعاب Steam",
    "Lutris Saves": "حفظ ألعاب Lutris",
    "RetroArch": "RetroArch",
    "DOSBox": "DOSBox",
    "Note: Steam game files (steamapps/common) and the Trash are excluded — "
    "only saves and settings are backed up.":
        "ملاحظة: يتم استثناء ملفات ألعاب Steam (steamapps/common) وسلة المهملات، "
        "ويتم نسخ الحفظ والإعدادات فقط.",
    "Backup name:": "اسم النسخة الاحتياطية:",
    "Create Backup": "إنشاء نسخة احتياطية",
    "Available backups": "النسخ الاحتياطية المتوفرة",
    "Restore Selected": "استعادة المحدد",
    "Delete": "حذف",
    "Refresh": "تحديث",
    "Backup directory": "مجلد النسخ الاحتياطي",
    "Browse…": "استعراض…",
    "Open Backup Folder": "فتح مجلد النسخ الاحتياطي",
    "Sync game saves": "مزامنة حفظ الألعاب",
    "Cloud Sync (rclone)": "مزامنة سحابية (rclone)",
    "Local Sync": "مزامنة محلية",
    "Auto-sync after gaming sessions:": "مزامنة تلقائية بعد جلسات اللعب:",
    "Remote:": "الوجهة البعيدة:",
    "Last auto-sync: …": "آخر مزامنة تلقائية: …",
    "Last auto-sync: %s": "آخر مزامنة تلقائية: %s",
    "Last auto-sync: never": "آخر مزامنة تلقائية: لم تتم بعد",
    "Game save locations": "مواقع حفظ الألعاب",
    "Sync Folder:": "مجلد المزامنة:",
    "Sync Now": "مزامنة الآن",
    "Restore Saves": "استعادة الحفظ",
    "No rclone cloud remotes are configured yet.\n\n"
    "Open a terminal and run:  rclone config\n"
    "to connect Google Drive, Dropbox, OneDrive and many "
    "others, then turn auto-sync on again.":
        "لم يتم إعداد أي وجهة سحابية في rclone بعد.\n\n"
        "افتح الطرفية ونفّذ الأمر:  rclone config\n"
        "لربط Google Drive أو Dropbox أو OneDrive وغيرها، "
        "ثم فعّل المزامنة التلقائية مجدداً.",
    "✓ Auto-sync after gaming sessions enabled":
        "✓ تم تفعيل المزامنة التلقائية بعد جلسات اللعب",
    "Auto-sync after gaming sessions disabled":
        "تم تعطيل المزامنة التلقائية بعد جلسات اللعب",
    "Could not write autostart entry:\n%s": "تعذر كتابة مدخل التشغيل التلقائي:\n%s",
    "Could not remove autostart entry:\n%s": "تعذر إزالة مدخل التشغيل التلقائي:\n%s",
    "Save-sync watcher not found:\n%s\n\n"
    "Auto-sync will start on your next login if it is installed.":
        "مراقب مزامنة الحفظ غير موجود:\n%s\n\n"
        "ستبدأ المزامنة التلقائية عند تسجيل الدخول التالي إذا كان مثبتاً.",
    "Could not start the save-sync watcher:\n%s": "تعذر تشغيل مراقب مزامنة الحفظ:\n%s",
    "No rclone cloud remotes are configured yet.\n\n"
    "Open a terminal and run:  rclone config\n"
    "to connect Google Drive, Dropbox, OneDrive and many others, "
    "then come back and press Cloud Sync again.":
        "لم يتم إعداد أي وجهة سحابية في rclone بعد.\n\n"
        "افتح الطرفية ونفّذ الأمر:  rclone config\n"
        "لربط Google Drive أو Dropbox أو OneDrive وغيرها، "
        "ثم عد واضغط على «مزامنة سحابية» مجدداً.",
    "No game saves selected": "لم يتم تحديد أي حفظ للألعاب",
    "Cloud Sync": "مزامنة سحابية",
    "Sync": "مزامنة",
    "Upload game saves to remote:": "رفع حفظ الألعاب إلى الوجهة البعيدة:",
    "Syncing saves to %s...": "جارٍ مزامنة الحفظ إلى %s...",
    "Uploading to %s...": "جارٍ الرفع إلى %s...",
    "Cloud sync cancelled": "أُلغيت المزامنة السحابية",
    "Cloud sync failed": "فشلت المزامنة السحابية",
    "Cloud upload failed (rclone exit %d):\n%s":
        "فشل الرفع السحابي (رمز خروج rclone %d):\n%s",
    "✓ Saves uploaded to %s": "✓ تم رفع الحفظ إلى %s",
    "Cloud sync complete!\nUploaded to %s":
        "اكتملت المزامنة السحابية!\nتم الرفع إلى %s",
    "No save files were found to upload, so the cloud copy was left unchanged.":
        "لم يُعثر على ملفات حفظ لرفعها، لذلك بقيت النسخة السحابية كما هي.",
    "Not found on this PC: %s": "غير موجود على هذا الجهاز: %s",
    "Cloud sync error: %s": "خطأ في المزامنة السحابية: %s",
    "Syncing saves...": "جارٍ مزامنة الحفظ...",
    "Sync cancelled": "أُلغيت المزامنة",
    "Sync failed": "فشلت المزامنة",
    "Sync failed for %s:\n%s": "فشلت المزامنة لـ %s:\n%s",
    "✓ Synced %d game save locations": "✓ تمت مزامنة %d من مواقع حفظ الألعاب",
    "Sync complete!\nSynced to: %s": "اكتملت المزامنة!\nتمت المزامنة إلى: %s",
    "Sync error: %s": "خطأ في المزامنة: %s",
    "Sync folder not found": "مجلد المزامنة غير موجود",
    "Restore saves?": "هل تريد استعادة الحفظ؟",
    "This will overwrite current saves.": "سيؤدي هذا إلى استبدال الحفظ الحالي.",
    "Restore cancelled": "أُلغيت الاستعادة",
    "Restore failed": "فشلت الاستعادة",
    "Restore failed for %s:\n%s": "فشلت الاستعادة لـ %s:\n%s",
    "✓ Saves restored": "✓ تمت استعادة الحفظ",
    "Game saves restored!": "تمت استعادة حفظ الألعاب!",
    "Restore error: %s": "خطأ في الاستعادة: %s",
    "Size: {size} MB | Date: {date}": "الحجم: {size} م.ب | التاريخ: {date}",
    "Please enter a valid backup name\n"
    "(letters, numbers, dots, dashes, underscores and spaces).":
        "يرجى إدخال اسم صالح للنسخة الاحتياطية\n"
        "(أحرف لاتينية وأرقام ونقاط وشرطات وشرطات سفلية ومسافات).",
    "Please select at least one location to backup":
        "يرجى تحديد موقع واحد على الأقل للنسخ الاحتياطي",
    "Creating backup...": "جارٍ إنشاء النسخة الاحتياطية...",
    "No valid paths to backup": "لا توجد مسارات صالحة للنسخ الاحتياطي",
    "Nothing to back up: all selected locations are outside your home folder,\n"
    "which is not supported for safe (non-root) restore.":
        "لا يوجد ما يُنسخ احتياطياً: جميع المواقع المحددة خارج مجلد المنزل،\n"
        "وهذا غير مدعوم للاستعادة الآمنة (بدون صلاحيات الجذر).",
    "Backup cancelled": "أُلغيت النسخة الاحتياطية",
    "Backup cancelled.": "أُلغيت النسخة الاحتياطية.",
    "\n(Note: some files changed while being read.)":
        "\n(ملاحظة: تغيّرت بعض الملفات أثناء قراءتها.)",
    "Backup failed": "فشل النسخ الاحتياطي",
    "Backup failed (tar exit %d):\n%s": "فشل النسخ الاحتياطي (رمز خروج tar %d):\n%s",
    "✓ Backup created: %s (%s MB)": "✓ تم إنشاء النسخة الاحتياطية: %s (%s م.ب)",
    "Backup '%s' created successfully!\nSize: %s MB%s":
        "تم إنشاء النسخة الاحتياطية '%s' بنجاح!\nالحجم: %s م.ب%s",
    "Backup failed: %s": "فشل النسخ الاحتياطي: %s",
    "Please select a backup to restore": "يرجى تحديد نسخة احتياطية لاستعادتها",
    "Restore Backup?": "هل تريد استعادة النسخة الاحتياطية؟",
    "This will overwrite existing files. Continue?":
        "سيؤدي هذا إلى استبدال الملفات الموجودة. هل تريد المتابعة؟",
    "Restoring backup...": "جارٍ استعادة النسخة الاحتياطية...",
    "Could not read backup archive:\n%s": "تعذر قراءة أرشيف النسخة الاحتياطية:\n%s",
    "Restore refused (unsafe archive)": "رُفضت الاستعادة (أرشيف غير آمن)",
    "Restore refused: this backup contains unsafe paths "
    "(absolute paths, '..' or escaping links) and was not extracted.\n\n"
    "Example: %s":
        "رُفضت الاستعادة: تحتوي هذه النسخة الاحتياطية على مسارات غير آمنة "
        "(مسارات مطلقة أو '..' أو روابط تخرج عن المجلد) ولم يتم استخراجها.\n\n"
        "مثال: %s",
    "Restore cancelled. Some files may already have been restored.":
        "أُلغيت الاستعادة. قد تكون بعض الملفات قد استُعيدت بالفعل.",
    "✓ Backup restored": "✓ تمت استعادة النسخة الاحتياطية",
    "Backup restored successfully!": "تمت استعادة النسخة الاحتياطية بنجاح!",
    "Restore completed with warnings": "اكتملت الاستعادة مع تحذيرات",
    "Restore completed with some warnings (tar exit %d):\n%s":
        "اكتملت الاستعادة مع بعض التحذيرات (رمز خروج tar %d):\n%s",
    "Restore failed: %s": "فشلت الاستعادة: %s",
    "Please select a backup to delete": "يرجى تحديد نسخة احتياطية لحذفها",
    "Delete Backup?": "هل تريد حذف النسخة الاحتياطية؟",
    "Are you sure you want to delete this backup?":
        "هل أنت متأكد من حذف هذه النسخة الاحتياطية؟",
    "Could not delete backup:\n%s": "تعذر حذف النسخة الاحتياطية:\n%s",
    "Backup deleted": "تم حذف النسخة الاحتياطية",
    "Select Backup Directory": "اختر مجلد النسخ الاحتياطي",
    "Could not open folder:\n%s": "تعذر فتح المجلد:\n%s",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    return nawaos_i18n.setup(APP_NAME, AR_STRINGS)


_, get_language, is_rtl = _setup_i18n()

# Paths (relative to $HOME) that are always excluded from backups/sync.
# Steam game binaries (steamapps/common) do not belong in save backups --
# they are huge and re-downloadable from Steam. (M7)
BACKUP_EXCLUDES = [
    ".local/share/Steam/steamapps/common",
    ".local/share/Trash",
]

# Automatic save-sync after gaming sessions: the watcher daemon is
# installed as /usr/local/bin/nawaos-savesync (nawaos-savesync.sh) and
# shares ~/.nawaos/backup-config.json with this app.
SAVESYNC_BIN = "/usr/local/bin/nawaos-savesync"
SAVESYNC_LOG = Path.home() / ".local" / "state" / "nawaos" / "savesync.log"
SAVESYNC_AUTOSTART = Path.home() / ".config" / "autostart" / "nawaos-savesync.desktop"


def get_os_version():
    """NawaOS version (VERSION_ID), via nawaos_release."""
    return nawaos_release.version() if nawaos_release else ""


VERSION = get_os_version()

class BackupManager(Gtk.Window):
    def __init__(self):
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)
        super().__init__(title=_("NawaOS Backup Manager"))
        self.set_default_size(700, 550)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        self.config_file = Path.home() / ".nawaos" / "backup-config.json"
        self.load_config()

        # Backup destination is persisted in the config (M4).
        try:
            self.backup_dir = Path(self.config.get("backup_dir") or
                                   str(Path.home() / ".nawaos" / "backups"))
            self.backup_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            self.backup_dir = Path.home() / ".nawaos" / "backups"
            self.backup_dir.mkdir(parents=True, exist_ok=True)

        # Cancellation support for long-running operations (H5): the worker
        # thread runs subprocesses via Popen and polls this event so the
        # Cancel button can terminate them.
        self.cancel_event = threading.Event()
        self._current_proc = None

        # Guard flag: True while the auto-sync switch/combo are being set
        # programmatically, so their handlers don't re-persist the config.
        self._autosync_updating = False
        
        settings = Gtk.Settings.get_default()
        settings.set_property("gtk-application-prefer-dark-theme", True)
        
        self.load_css()
        self.create_ui()
        self.show_all()
        self.refresh_backups()
    
    def load_config(self):
        # WHY (M7): the old default list also included children of these
        # parents (Steam compatdata / Lutris live under ~/.local/share via
        # symlinks, RetroArch saves under ~/.config), so everything was
        # archived twice. Keep only the parents; Steam game binaries
        # (steamapps/common) are excluded via BACKUP_EXCLUDES.
        defaults = {
            "backup_dir": str(Path.home() / ".nawaos" / "backups"),
            "backup_locations": [
                {"name": "App Data & Game Saves", "path": str(Path.home() / ".local/share"), "enabled": True},
                {"name": "Settings & Configs", "path": str(Path.home() / ".config"), "enabled": True},
                {"name": "Wine Prefixes", "path": str(Path.home() / ".wine/drive_c/users"), "enabled": False},
            ],
            "sync_folder": str(Path.home() / "NawaOS-SaveSync"),
            # Automatic cloud save-sync after gaming sessions (read by
            # /usr/local/bin/nawaos-savesync as well).
            "savesync_enabled": False,
            "savesync_remote": "",
            "game_saves": nawaos_savesync.default_game_saves(),
        }
        # WHY (M3): merge the loaded JSON over the defaults instead of
        # replacing them, so a config written by an older version (missing
        # keys) can never cause a KeyError later.
        self.config = defaults
        if self.config_file.exists():
            try:
                with open(self.config_file) as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    self.config.update(loaded)
            except (OSError, ValueError):
                pass

    def save_config(self):
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except OSError:
            pass
    
    def load_css(self):
        # Thin app layer over the shared NawaOS 2.0 BASE_CSS (nawaos_theme).
        css = b"""
        window { background-color: #0B0F1A; }

        .header-box { background-color: #111827; padding: 14px 24px; }
        .app-title { color: #ffffff; font-size: 20px; font-weight: 700; }

        .page-title { color: #E8EDF4; font-size: 24px; font-weight: 700; }
        .title-underline {
            background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2);
            border-radius: 100px; min-height: 3px;
        }
        .section-label {
            color: #9AA7B8; font-size: 10px; font-weight: 700;
            letter-spacing: 2px;
        }

        notebook header { background-color: transparent; border: none; }
        notebook tab {
            padding: 8px 18px; min-height: 40px;
            border-radius: 100px; margin: 4px;
        }
        notebook tab:checked { background-color: rgba(55, 188, 224, 0.15); }
        notebook tab:checked label, notebook tab:checked image { color: #37BCE0; }

        .backup-item {
            background-color: #1A2332;
            border: 1px solid rgba(55, 188, 224, 0.08);
            border-radius: 12px; padding: 14px; margin: 4px;
            transition: all 150ms ease;
        }
        .backup-item:hover {
            background-color: #232D3F;
            box-shadow: 0 2px 10px rgba(55, 188, 224, 0.10);
        }
        .backup-info { color: #9AA7B8; font-size: 11px; }
        .status-label { color: #9AA7B8; font-size: 12px; }

        .primary-pill {
            background: linear-gradient(135deg, #1A76BA, #37BCE0);
            border: none; border-radius: 100px;
            padding: 10px 26px; min-height: 44px; font-weight: 700;
            transition: all 150ms ease;
        }
        .primary-pill, .primary-pill label { color: #ffffff; }
        .primary-pill:hover {
            background: linear-gradient(135deg, #37BCE0, #50E6E2);
            box-shadow: 0 3px 14px rgba(55, 188, 224, 0.35);
        }
        .ghost-btn {
            background: transparent; border: none; border-radius: 100px;
            padding: 8px 18px; min-height: 40px; font-weight: 600;
            transition: all 150ms ease;
        }
        .ghost-btn, .ghost-btn label, .ghost-btn image { color: #37BCE0; }
        .ghost-btn:hover { background: rgba(55, 188, 224, 0.10); }
        .danger-outline {
            background: transparent;
            border: 1px solid rgba(248, 113, 113, 0.45);
            border-radius: 100px; padding: 8px 20px; min-height: 40px;
            font-weight: 600; transition: all 150ms ease;
        }
        .danger-outline, .danger-outline label { color: #F87171; }
        .danger-outline:hover { background: rgba(248, 113, 113, 0.12); }
        """
        if nawaos_theme is not None:
            nawaos_theme.apply_theme(self, css)
            return
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    # ---------------- Shared NawaOS 2.0 UI helpers (visual only) ----------

    @staticmethod
    def _load_logo(size=28):
        """Brand logo as a Gtk.Image, or None if the asset is missing."""
        for path in ("/usr/share/pixmaps/nawaos-logo.png",
                     "/usr/share/nawaos/logo.png"):
            try:
                if os.path.exists(path):
                    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        path, size, size, True)
                    return Gtk.Image.new_from_pixbuf(pb)
            except Exception:
                pass
        return None

    @staticmethod
    def _page_title(text):
        """24px/700 page title with a short brand-gradient underline."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        lbl = Gtk.Label(label=text)
        lbl.get_style_context().add_class("page-title")
        lbl.set_halign(Gtk.Align.START)
        box.pack_start(lbl, False, False, 0)
        bar = Gtk.Box()
        bar.get_style_context().add_class("title-underline")
        bar.set_size_request(44, 3)
        bar.set_halign(Gtk.Align.START)
        box.pack_start(bar, False, False, 0)
        return box

    @staticmethod
    def _section_label(text):
        lbl = Gtk.Label(label=text.upper())
        lbl.get_style_context().add_class("section-label")
        lbl.set_halign(Gtk.Align.START)
        return lbl

    @staticmethod
    def _tab_label(icon_name, text):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.pack_start(Gtk.Image.new_from_icon_name(
            icon_name, Gtk.IconSize.MENU), False, False, 0)
        box.pack_start(Gtk.Label(label=text), False, False, 0)
        box.show_all()
        return box

    def create_ui(self):
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(main_box)

        # Header: logo + app name + version pill
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class("header-box")

        logo = self._load_logo(28)
        if logo:
            header.pack_start(logo, False, False, 0)

        title = Gtk.Label(label=_("Backup Manager"))
        title.get_style_context().add_class("app-title")
        header.pack_start(title, False, False, 0)

        badge = Gtk.Label(label=VERSION)
        badge.get_style_context().add_class("pill-badge")
        badge.set_valign(Gtk.Align.CENTER)
        header.pack_start(badge, False, False, 0)

        main_box.pack_start(header, False, False, 0)

        # Content with notebook
        notebook = Gtk.Notebook()
        notebook.set_margin_start(10)
        notebook.set_margin_end(10)
        notebook.set_margin_top(10)
        notebook.set_margin_bottom(10)

        # Backup tab
        backup_page = self.create_backup_page()
        notebook.append_page(backup_page,
                             self._tab_label("drive-harddisk-symbolic", _("Backup")))

        # Restore tab
        restore_page = self.create_restore_page()
        notebook.append_page(restore_page,
                             self._tab_label("folder-download-symbolic", _("Restore")))

        # Save Games tab (merged from nawaos-savegame-sync)
        savegames_page = self.create_savegames_page()
        notebook.append_page(savegames_page,
                             self._tab_label("applications-games-symbolic", _("Save Games")))

        # Settings tab
        settings_page = self.create_settings_page()
        notebook.append_page(settings_page,
                             self._tab_label("preferences-system-symbolic", _("Settings")))
        
        main_box.pack_start(notebook, True, True, 0)
        
        # Status bar with global Cancel for long-running operations (H5)
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        status_box.set_margin_bottom(10)
        status_box.set_margin_start(12)
        status_box.set_margin_end(12)
        self.status_label = Gtk.Label(label=_("Ready"))
        self.status_label.get_style_context().add_class("status-label")
        status_box.pack_start(self.status_label, True, True, 0)
        self.cancel_btn = Gtk.Button(label=_("Cancel"))
        self.cancel_btn.get_style_context().add_class("danger-outline")
        self.cancel_btn.set_sensitive(False)
        self.cancel_btn.connect("clicked", self.on_cancel_clicked)
        status_box.pack_end(self.cancel_btn, False, False, 0)
        main_box.pack_start(status_box, False, False, 0)

    def on_cancel_clicked(self, button):
        self.cancel_event.set()
        self.status_label.set_text(_("Cancelling..."))

    def _begin_operation(self):
        self.cancel_event.clear()
        GLib.idle_add(self.cancel_btn.set_sensitive, True)

    def _end_operation(self):
        GLib.idle_add(self.cancel_btn.set_sensitive, False)

    @staticmethod
    def _err_summary(err):
        """Short human-readable tail of a subprocess' stderr."""
        lines = [l for l in (err or "").strip().splitlines() if l.strip()]
        return "\n".join(lines[-5:])[-400:] or _("unknown error")

    def _run_cancellable(self, cmd):
        """Run cmd in this worker thread WITHOUT a timeout (H5).

        Uses Popen + a poll loop so the Cancel button can terminate the
        process. Returns (returncode, stderr_text); returncode is None if
        the operation was cancelled.
        """
        try:
            with tempfile.TemporaryFile(mode='w+', errors='replace') as errf:
                try:
                    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                            stderr=errf)
                except FileNotFoundError:
                    return 127, _("command not found: %s") % cmd[0]
                self._current_proc = proc
                try:
                    while True:
                        rc = proc.poll()
                        if rc is not None:
                            break
                        if self.cancel_event.is_set():
                            proc.terminate()
                            try:
                                proc.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                proc.kill()
                                proc.wait()
                            errf.seek(0)
                            return None, errf.read()
                        time.sleep(0.2)
                finally:
                    self._current_proc = None
                errf.seek(0)
                return rc, errf.read()
        except OSError as e:
            return 1, str(e)
    
    def create_backup_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_margin_top(15)
        page.set_margin_start(10)
        page.set_margin_end(10)

        page.pack_start(self._page_title(_("Backup")), False, False, 0)

        # Backup locations
        page.pack_start(self._section_label(_("What to back up")), False, False, 4)
        
        self.backup_checks = []
        for loc in self.config["backup_locations"]:
            check = Gtk.CheckButton(label=f'{_(loc["name"])} ({loc["path"][:40]}...)')
            check.set_active(loc["enabled"])
            check.location = loc
            self.backup_checks.append(check)
            page.pack_start(check, False, False, 2)

        # Exclusion note (M7)
        note = Gtk.Label(label=_("Note: Steam game files (steamapps/common) and the Trash are excluded — "
                                 "only saves and settings are backed up."))
        note.get_style_context().add_class("status-label")
        note.set_halign(Gtk.Align.START)
        note.set_line_wrap(True)
        page.pack_start(note, False, False, 2)


        # Backup name
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        name_label = Gtk.Label(label=_("Backup name:"))
        name_label.get_style_context().add_class("status-label")
        name_box.pack_start(name_label, False, False, 0)
        
        self.backup_name_entry = Gtk.Entry()
        self.backup_name_entry.set_text(f"backup_{datetime.now().strftime('%Y%m%d_%H%M')}")
        self.backup_name_entry.set_hexpand(True)
        name_box.pack_start(self.backup_name_entry, True, True, 0)
        page.pack_start(name_box, False, False, 10)
        
        # Progress
        self.backup_progress = Gtk.ProgressBar()
        self.backup_progress.set_show_text(True)
        page.pack_start(self.backup_progress, False, False, 5)
        
        # Backup button (single primary action of this view)
        backup_btn = Gtk.Button(label=_("Create Backup"))
        backup_btn.get_style_context().add_class("primary-pill")
        backup_btn.connect("clicked", self.on_backup_clicked)
        page.pack_start(backup_btn, False, False, 10)
        
        return page
    
    def create_restore_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_margin_top(15)
        page.set_margin_start(10)
        page.set_margin_end(10)

        page.pack_start(self._page_title(_("Restore")), False, False, 0)
        page.pack_start(self._section_label(_("Available backups")), False, False, 4)
        
        # Backup list
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(200)
        
        self.backup_list = Gtk.ListBox()
        self.backup_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        scroll.add(self.backup_list)
        page.pack_start(scroll, True, True, 0)
        
        # Buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        btn_box.set_halign(Gtk.Align.CENTER)
        
        restore_btn = Gtk.Button(label=_("Restore Selected"))
        restore_btn.get_style_context().add_class("primary-pill")
        restore_btn.connect("clicked", self.on_restore_clicked)
        btn_box.pack_start(restore_btn, False, False, 0)

        delete_btn = Gtk.Button(label=_("Delete"))
        delete_btn.get_style_context().add_class("danger-outline")
        delete_btn.connect("clicked", self.on_delete_backup)
        btn_box.pack_start(delete_btn, False, False, 0)

        refresh_btn = Gtk.Button(label=_("Refresh"))
        refresh_btn.get_style_context().add_class("ghost-btn")
        refresh_btn.connect("clicked", lambda b: self.refresh_backups())
        btn_box.pack_start(refresh_btn, False, False, 0)
        
        page.pack_start(btn_box, False, False, 10)
        
        return page
    
    def create_settings_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_margin_top(15)
        page.set_margin_start(10)
        page.set_margin_end(10)

        page.pack_start(self._page_title(_("Settings")), False, False, 0)
        page.pack_start(self._section_label(_("Backup directory")), False, False, 4)
        
        dir_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.dir_entry = Gtk.Entry()
        self.dir_entry.set_text(str(self.backup_dir))
        self.dir_entry.set_hexpand(True)
        # Persist a manually typed path (M4)
        self.dir_entry.connect("changed", self.on_backup_dir_changed)
        self.dir_entry.connect("activate", lambda e: self.refresh_backups())
        dir_box.pack_start(self.dir_entry, True, True, 0)
        
        browse_btn = Gtk.Button(label=_("Browse…"))
        browse_btn.get_style_context().add_class("ghost-btn")
        browse_btn.connect("clicked", self.on_browse_clicked)
        dir_box.pack_start(browse_btn, False, False, 0)
        page.pack_start(dir_box, False, False, 0)

        # Open folder button
        open_btn = Gtk.Button(label=_("Open Backup Folder"))
        open_btn.get_style_context().add_class("ghost-btn")
        open_btn.set_halign(Gtk.Align.START)
        open_btn.connect("clicked", self.on_open_folder)
        page.pack_start(open_btn, False, False, 20)

        return page

    def on_backup_dir_changed(self, entry):
        path = entry.get_text().strip()
        if not path:
            return
        self.backup_dir = Path(path)
        self.config["backup_dir"] = path
        self.save_config()

    def on_sync_folder_changed(self, entry):
        folder = entry.get_text().strip()
        if not folder:
            return
        self.config["sync_folder"] = folder
        self.save_config()

    def create_savegames_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page.set_margin_top(15)
        page.set_margin_start(10)
        page.set_margin_end(10)
        
        page.pack_start(self._page_title(_("Save Games")), False, False, 0)

        # Cloud sync buttons
        page.pack_start(self._section_label(_("Sync game saves")), False, False, 4)

        cloud_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        # WHY (M6): cloud sync goes through rclone (shipped on the ISO)
        # instead of guessing at Google Drive/Dropbox client folders that
        # are never present on NawaOS.
        for label_text, callback in [(_("Cloud Sync (rclone)"), self.on_cloud_sync), (_("Local Sync"), self.on_local_sync)]:
            btn = Gtk.Button(label=label_text)
            btn.get_style_context().add_class("ghost-btn")
            btn.connect("clicked", callback)
            cloud_box.pack_start(btn, True, True, 0)
        page.pack_start(cloud_box, False, False, 5)

        # Automatic save-sync after gaming sessions (watcher daemon:
        # /usr/local/bin/nawaos-savesync watch).
        auto_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        auto_label = Gtk.Label(label=_("Auto-sync after gaming sessions:"))
        auto_label.set_halign(Gtk.Align.START)
        auto_row.pack_start(auto_label, False, False, 0)
        self.autosync_switch = Gtk.Switch()
        self.autosync_switch.set_active(bool(self.config.get("savesync_enabled")))
        auto_row.pack_start(self.autosync_switch, False, False, 0)
        auto_row.pack_start(Gtk.Label(label=_("Remote:")), False, False, 0)
        self.autosync_remote_combo = Gtk.ComboBoxText()
        auto_row.pack_start(self.autosync_remote_combo, True, True, 0)
        page.pack_start(auto_row, False, False, 5)

        self.last_sync_label = Gtk.Label(label=_("Last auto-sync: …"))
        self.last_sync_label.get_style_context().add_class("status-label")
        self.last_sync_label.set_halign(Gtk.Align.START)
        page.pack_start(self.last_sync_label, False, False, 0)

        self.autosync_switch.connect("notify::active", self.on_autosync_toggled)
        self.autosync_remote_combo.connect("changed", self.on_autosync_remote_changed)
        # Populate the remote list off the UI thread ('rclone listremotes'
        # can take a moment) and keep the last-sync label fresh.
        threading.Thread(target=self._populate_autosync_remotes, daemon=True).start()
        self._update_last_sync_label()
        GLib.timeout_add_seconds(60, self._update_last_sync_label_tick)

        # Game saves list
        page.pack_start(self._section_label(_("Game save locations")), False, False, 5)
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(150)
        self.games_list = Gtk.ListBox()
        self.games_list.set_selection_mode(Gtk.SelectionMode.NONE)
        scroll.add(self.games_list)
        page.pack_start(scroll, True, True, 0)
        self.refresh_game_saves()
        
        # Sync folder
        folder_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        folder_box.pack_start(Gtk.Label(label=_("Sync Folder:")), False, False, 0)
        self.sync_folder_entry = Gtk.Entry()
        self.sync_folder_entry.set_text(self.config.get("sync_folder", ""))
        self.sync_folder_entry.set_hexpand(True)
        # Persist the sync folder (M4)
        self.sync_folder_entry.connect("changed", self.on_sync_folder_changed)
        folder_box.pack_start(self.sync_folder_entry, True, True, 0)
        page.pack_start(folder_box, False, False, 5)
        
        # Action buttons
        action_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        action_box.set_halign(Gtk.Align.CENTER)
        for label_text, style, callback in [
                (_("Sync Now"), "primary-pill", self.on_sync_saves),
                (_("Restore Saves"), "ghost-btn", self.on_restore_saves)]:
            btn = Gtk.Button(label=label_text)
            btn.get_style_context().add_class(style)
            btn.connect("clicked", callback)
            action_box.pack_start(btn, False, False, 0)
        page.pack_start(action_box, False, False, 10)
        
        self.sync_progress = Gtk.ProgressBar()
        self.sync_progress.set_show_text(True)
        page.pack_start(self.sync_progress, False, False, 0)
        
        return page

    # ---------------- Auto-sync after gaming sessions ----------------

    def _populate_autosync_remotes(self):
        """Worker thread: list rclone remotes, then fill the combo."""
        remotes = self._list_rclone_remotes()
        GLib.idle_add(self._apply_autosync_remotes, remotes)

    def _apply_autosync_remotes(self, remotes):
        self._autosync_updating = True
        try:
            self.autosync_remote_combo.remove_all()
            saved = str(self.config.get("savesync_remote") or "").rstrip(':')
            active = -1
            for idx, r in enumerate(remotes):
                self.autosync_remote_combo.append_text(r)
                if r == saved:
                    active = idx
            if remotes:
                self.autosync_remote_combo.set_active(active if active >= 0 else 0)
        finally:
            self._autosync_updating = False
        return False  # one-shot idle callback

    def on_autosync_toggled(self, switch, _pspec):
        if self._autosync_updating:
            return
        if switch.get_active():
            remote = self.autosync_remote_combo.get_active_text()
            if not remote:
                # Revert the switch without re-entering this handler.
                self._autosync_updating = True
                switch.set_active(False)
                self._autosync_updating = False
                self.show_message(_(
                    "No rclone cloud remotes are configured yet.\n\n"
                    "Open a terminal and run:  rclone config\n"
                    "to connect Google Drive, Dropbox, OneDrive and many "
                    "others, then turn auto-sync on again."))
                return
            self.config["savesync_enabled"] = True
            self.config["savesync_remote"] = remote + ":"
            self.save_config()
            self._write_savesync_autostart()
            self._start_savesync_watcher()
            self.status_label.set_text(_("✓ Auto-sync after gaming sessions enabled"))
        else:
            self.config["savesync_enabled"] = False
            self.save_config()
            self._remove_savesync_autostart()
            self._stop_savesync_watcher()
            self.status_label.set_text(_("Auto-sync after gaming sessions disabled"))

    def on_autosync_remote_changed(self, combo):
        if self._autosync_updating:
            return
        remote = combo.get_active_text()
        if not remote:
            return
        if self.config.get("savesync_enabled"):
            self.config["savesync_remote"] = remote + ":"
            self.save_config()

    def _write_savesync_autostart(self):
        content = ("[Desktop Entry]\n"
                   "Type=Application\n"
                   "Name=NawaOS Save-Sync\n"
                   "Comment=Sync game saves to the cloud after gaming sessions\n"
                   f"Exec={SAVESYNC_BIN} watch\n"
                   "NoDisplay=true\n"
                   "X-GNOME-Autostart-Delay=30\n")
        try:
            SAVESYNC_AUTOSTART.parent.mkdir(parents=True, exist_ok=True)
            SAVESYNC_AUTOSTART.write_text(content)
        except OSError as e:
            self.show_message(_("Could not write autostart entry:\n%s") % e)

    def _remove_savesync_autostart(self):
        try:
            SAVESYNC_AUTOSTART.unlink()
        except FileNotFoundError:
            pass
        except OSError as e:
            self.show_message(_("Could not remove autostart entry:\n%s") % e)

    def _start_savesync_watcher(self):
        # Detached: the watcher must outlive this window. It is
        # single-instance via its own pidfile, so starting it while one
        # is already running is harmless.
        try:
            subprocess.Popen([SAVESYNC_BIN, 'watch'],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except FileNotFoundError:
            self.show_message(
                _("Save-sync watcher not found:\n%s\n\n"
                  "Auto-sync will start on your next login if it is installed.")
                % SAVESYNC_BIN)
        except OSError as e:
            self.show_message(_("Could not start the save-sync watcher:\n%s") % e)

    def _stop_savesync_watcher(self):
        """Terminate only OUR watcher: the PID from its pidfile, and only
        if that process' cmdline really contains the exact watcher path
        (guards against recycled PIDs and unrelated processes)."""
        runtime_dir = os.environ.get('XDG_RUNTIME_DIR') or '/tmp'
        pidfile = Path(runtime_dir) / 'nawaos-savesync.pid'
        try:
            pid = int(pidfile.read_text().split()[0])
        except (OSError, ValueError, IndexError):
            return
        try:
            with open(f'/proc/{pid}/cmdline', 'rb') as f:
                argv = [a.decode('utf-8', 'replace')
                        for a in f.read().split(b'\0') if a]
        except OSError:
            return
        if SAVESYNC_BIN not in argv:
            return
        try:
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            pass

    def _read_last_sync_time(self):
        """Timestamp of the last successful sync, parsed from the tail of
        the watcher's log; None if there was none."""
        try:
            with open(SAVESYNC_LOG, 'rb') as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 65536))
                data = f.read().decode('utf-8', 'replace')
        except OSError:
            return None
        for line in reversed(data.splitlines()):
            if 'sync finished OK' in line:
                parts = line.split()
                if len(parts) >= 2:
                    return f"{parts[0]} {parts[1]}"
                return None
        return None

    def _update_last_sync_label(self):
        t = self._read_last_sync_time()
        self.last_sync_label.set_text(
            _("Last auto-sync: %s") % t if t else _("Last auto-sync: never"))

    def _update_last_sync_label_tick(self):
        self._update_last_sync_label()
        return True  # keep the periodic timer alive

    def refresh_game_saves(self):
        for child in self.games_list.get_children():
            self.games_list.remove(child)
        for game in self.config.get("game_saves", []):
            row = Gtk.ListBoxRow()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.get_style_context().add_class("backup-item")
            box.set_margin_start(5)
            box.set_margin_end(5)
            box.set_margin_top(2)
            box.set_margin_bottom(2)
            check = Gtk.CheckButton()
            check.set_active(game.get("enabled", True))
            check.connect("toggled", lambda c, g=game: self._toggle_game(c, g))
            box.pack_start(check, False, False, 0)
            info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            name_l = Gtk.Label()
            name_l.set_markup(f'<span weight="bold" foreground="#E8EDF4">{_(game["name"])}</span>')
            name_l.set_halign(Gtk.Align.START)
            info.pack_start(name_l, False, False, 0)
            path_l = Gtk.Label(label=game["path"][:50])
            path_l.get_style_context().add_class("backup-info")
            path_l.set_halign(Gtk.Align.START)
            info.pack_start(path_l, False, False, 0)
            box.pack_start(info, True, True, 0)
            exists = os.path.exists(game["path"])
            st = Gtk.Label(label="✓" if exists else "✗")
            st.get_style_context().add_class("status-ok" if exists else "status-err")
            box.pack_end(st, False, False, 10)
            row.add(box)
            self.games_list.add(row)
        self.games_list.show_all()
    
    def _toggle_game(self, check, game):
        game["enabled"] = check.get_active()
        self.save_config()
    
    def _get_sync_folder(self):
        folder = self.sync_folder_entry.get_text().strip()
        if not folder:
            folder = self.config.get("sync_folder", str(Path.home() / "NawaOS-SaveSync"))
        return Path(folder)
    
    def _list_rclone_remotes(self):
        try:
            result = subprocess.run(['rclone', 'listremotes'],
                                    capture_output=True, text=True, timeout=15)
            if result.returncode != 0:
                return []
            return [r.strip().rstrip(':') for r in result.stdout.splitlines()
                    if r.strip()]
        except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
            return []

    def on_cloud_sync(self, button):
        remotes = self._list_rclone_remotes()
        if not remotes:
            self.show_message(_(
                "No rclone cloud remotes are configured yet.\n\n"
                "Open a terminal and run:  rclone config\n"
                "to connect Google Drive, Dropbox, OneDrive and many others, "
                "then come back and press Cloud Sync again."))
            return
        games = [g for g in self.config.get("game_saves", []) if g.get("enabled")]
        if not games:
            self.show_message(_("No game saves selected"))
            return
        dialog = Gtk.Dialog(title=_("Cloud Sync"), transient_for=self, flags=0)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                           _("Sync"), Gtk.ResponseType.OK)
        content = dialog.get_content_area()
        content.set_spacing(8)
        content.add(Gtk.Label(label=_("Upload game saves to remote:")))
        combo = Gtk.ComboBoxText()
        for r in remotes:
            combo.append_text(r)
        combo.set_active(0)
        content.add(combo)
        content.show_all()
        response = dialog.run()
        remote = combo.get_active_text()
        dialog.destroy()
        if response != Gtk.ResponseType.OK or not remote:
            return
        sync_folder = self._get_sync_folder()
        self.status_label.set_text(_("Syncing saves to %s...") % remote)
        threading.Thread(target=self._do_cloud_sync,
                         args=(sync_folder, games, remote), daemon=True).start()

    def _do_cloud_sync(self, sync_folder, games, remote):
        self._begin_operation()
        try:
            # Collect the current saves first, then push the staging folder
            # with rclone -- the same code path and cloud folder as the
            # automatic sync (nawaos_savesync).
            if not self._sync_games_to_folder(sync_folder, games):
                return
            if not nawaos_savesync.has_content(sync_folder):
                GLib.idle_add(self.status_label.set_text, _("Cloud sync failed"))
                GLib.idle_add(self.show_message, _(
                    "No save files were found to upload, so the cloud copy "
                    "was left unchanged."))
                return
            GLib.idle_add(self.status_label.set_text, _("Uploading to %s...") % remote)
            rc, err = self._run_cancellable(
                nawaos_savesync.upload_cmd(sync_folder, remote))
            if rc is None:
                GLib.idle_add(self.status_label.set_text, _("Cloud sync cancelled"))
                return
            if rc != 0:
                GLib.idle_add(self.status_label.set_text, _("Cloud sync failed"))
                GLib.idle_add(self.show_message,
                              _("Cloud upload failed (rclone exit %d):\n%s")
                              % (rc, self._err_summary(err)))
                return
            GLib.idle_add(self.sync_progress.set_fraction, 1.0)
            GLib.idle_add(self.status_label.set_text, _("✓ Saves uploaded to %s") % remote)
            GLib.idle_add(self.show_message,
                          _("Cloud sync complete!\nUploaded to %s")
                          % nawaos_savesync.remote_destination(remote))
        except Exception as e:
            GLib.idle_add(self.show_message, _("Cloud sync error: %s") % e)
        finally:
            self._end_operation()

    def on_local_sync(self, button):
        self.on_sync_saves(button)
    
    def on_sync_saves(self, button):
        sync_folder = self._get_sync_folder()
        games = [g for g in self.config.get("game_saves", []) if g.get("enabled")]
        if not games:
            self.show_message(_("No game saves selected"))
            return
        self.status_label.set_text(_("Syncing saves..."))
        threading.Thread(target=self._do_sync, args=(sync_folder, games), daemon=True).start()
    
    def _rsync(self, src, dest, delete=False):
        """Run rsync without a timeout, cancellable (H5/M2).

        Returns (ok, err): ok is True on success, False on failure,
        None when cancelled. No copytree fallback anymore -- a failed or
        killed rsync is reported, not papered over with an unbounded copy.
        """
        cmd = nawaos_savesync.rsync_cmd(src, dest, delete=delete)
        rc, err = self._run_cancellable(cmd)
        if rc is None:
            return None, err
        if rc in nawaos_savesync.RSYNC_OK:  # 24 = files vanished mid-transfer
            return True, ""
        return False, err

    def _sync_games_to_folder(self, sync_folder, games):
        """Worker-thread helper: collect each enabled save location into
        sync_folder (nawaos_savesync.stage_saves, shared with the automatic
        sync). Returns True on success, False on error/cancel (the error
        dialog is raised here)."""
        def progress(done, total, _game):
            GLib.idle_add(self.sync_progress.set_fraction, (done + 0.5) / max(total, 1))

        result = nawaos_savesync.stage_saves(
            sync_folder, games, run=self._run_cancellable,
            cancelled=self.cancel_event.is_set, progress=progress)
        self._last_stage = result
        if result.cancelled:
            GLib.idle_add(self.status_label.set_text, _("Sync cancelled"))
            return False
        if result.failed:
            name, err = result.failed
            GLib.idle_add(self.status_label.set_text, _("Sync failed"))
            GLib.idle_add(self.show_message,
                          _("Sync failed for %s:\n%s")
                          % (_(name), self._err_summary(err)))
            return False
        return True

    def _missing_note(self):
        """'\n\nNot found on this PC: A, B' for the last staging, or ''."""
        result = getattr(self, "_last_stage", None)
        if not result or not result.missing:
            return ""
        return "\n\n" + _("Not found on this PC: %s") % ", ".join(
            _(n) for n in result.missing)

    def _do_sync(self, sync_folder, games):
        self._begin_operation()
        try:
            if not self._sync_games_to_folder(sync_folder, games):
                return
            GLib.idle_add(self.sync_progress.set_fraction, 1.0)
            GLib.idle_add(self.status_label.set_text,
                          _("✓ Synced %d game save locations")
                          % len(self._last_stage.staged))
            GLib.idle_add(self.show_message,
                          _("Sync complete!\nSynced to: %s") % sync_folder
                          + self._missing_note())
        except Exception as e:
            GLib.idle_add(self.show_message, _("Sync error: %s") % e)
        finally:
            self._end_operation()
    
    def on_restore_saves(self, button):
        sync_folder = self._get_sync_folder()
        if not sync_folder.exists():
            self.show_message(_("Sync folder not found"))
            return
        dialog = Gtk.MessageDialog(transient_for=self, flags=0, message_type=Gtk.MessageType.WARNING, buttons=Gtk.ButtonsType.YES_NO, text=_("Restore saves?"))
        dialog.format_secondary_text(_("This will overwrite current saves."))
        resp = dialog.run()
        dialog.destroy()
        if resp == Gtk.ResponseType.YES:
            threading.Thread(target=self._do_restore_saves, args=(sync_folder,), daemon=True).start()
    
    def _do_restore_saves(self, sync_folder):
        self._begin_operation()
        try:
            games = [g for g in self.config.get("game_saves", []) if g.get("enabled")]
            for i, game in enumerate(games):
                if self.cancel_event.is_set():
                    GLib.idle_add(self.status_label.set_text, _("Restore cancelled"))
                    return
                src = sync_folder / nawaos_savesync.slot_name(game)
                if not src.exists():
                    continue
                dest = Path(game["path"])
                dest.parent.mkdir(parents=True, exist_ok=True)
                ok, err = self._rsync(src, dest, delete=False)
                if ok is None:
                    GLib.idle_add(self.status_label.set_text, _("Restore cancelled"))
                    return
                if not ok:
                    GLib.idle_add(self.status_label.set_text, _("Restore failed"))
                    GLib.idle_add(self.show_message,
                                  _("Restore failed for %s:\n%s")
                                  % (_(game["name"]), self._err_summary(err)))
                    return
                GLib.idle_add(self.sync_progress.set_fraction, (i + 1) / len(games))
            GLib.idle_add(self.status_label.set_text, _("✓ Saves restored"))
            GLib.idle_add(self.show_message, _("Game saves restored!"))
        except Exception as e:
            GLib.idle_add(self.show_message, _("Restore error: %s") % e)
        finally:
            self._end_operation()
    
    def refresh_backups(self):
        # Clear list
        for child in self.backup_list.get_children():
            self.backup_list.remove(child)
        
        # Find backups
        if self.backup_dir.exists():
            backups = sorted(self.backup_dir.glob("*.tar.gz"), key=os.path.getmtime, reverse=True)
            for backup in backups:
                row = Gtk.ListBoxRow()
                box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                box.get_style_context().add_class("backup-item")
                box.set_margin_start(5)
                box.set_margin_end(5)
                box.set_margin_top(3)
                box.set_margin_bottom(3)
                
                info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
                
                name_label = Gtk.Label()
                name_label.set_markup(f'<span weight="bold" foreground="#E8EDF4">{backup.stem}</span>')
                name_label.set_halign(Gtk.Align.START)
                info_box.pack_start(name_label, False, False, 0)
                
                size = backup.stat().st_size / 1024 / 1024
                mtime = datetime.fromtimestamp(backup.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                info_label = Gtk.Label(label=_("Size: {size} MB | Date: {date}").format(
                    size="%.1f" % size, date=mtime))
                info_label.get_style_context().add_class("backup-info")
                info_label.set_halign(Gtk.Align.START)
                info_box.pack_start(info_label, False, False, 0)
                
                box.pack_start(info_box, True, True, 5)
                row.add(box)
                row.backup_path = backup
                self.backup_list.add(row)
        
        self.backup_list.show_all()
    
    @staticmethod
    def _sanitize_backup_name(name):
        """Sanitize a user-supplied backup name (M5): strip any path
        components and leading dots, keep only [A-Za-z0-9._ -].
        Returns '' if nothing safe remains."""
        name = os.path.basename(name.strip().replace('\\', '/'))
        name = re.sub(r'[^A-Za-z0-9._ -]', '', name)
        return name.lstrip('.').strip()

    def on_backup_clicked(self, button):
        raw = self.backup_name_entry.get_text()
        name = self._sanitize_backup_name(raw)
        if not name:
            self.show_message(_("Please enter a valid backup name\n"
                                "(letters, numbers, dots, dashes, underscores and spaces)."))
            return
        if name != raw.strip():
            self.backup_name_entry.set_text(name)

        # Get selected locations
        locations = []
        for check in self.backup_checks:
            if check.get_active():
                locations.append(check.location["path"])
        
        if not locations:
            self.show_message(_("Please select at least one location to backup"))
            return
        
        self.status_label.set_text(_("Creating backup..."))
        threading.Thread(target=self.create_backup, args=(name, locations), daemon=True).start()
    
    def create_backup(self, name, locations):
        self._begin_operation()
        backup_path = None
        try:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            backup_path = self.backup_dir / f"{name}.tar.gz"

            # Filter existing paths
            existing = [p for p in locations if os.path.exists(p)]

            if not existing:
                GLib.idle_add(self.show_message, _("No valid paths to backup"))
                return

            GLib.idle_add(self.backup_progress.set_fraction, 0.1)

            # WHY: Store archive members RELATIVE to $HOME (no leading '/', no -P)
            # so restore can safely extract back into $HOME as a normal user
            # instead of unpacking absolute paths into '/' as root. We tar with
            # '-C $HOME' and pass each location as a path relative to $HOME;
            # any location outside $HOME is skipped (can't be restored safely).
            home = str(Path.home())
            members = []
            skipped = []
            for p in existing:
                try:
                    rel = os.path.relpath(p, home)
                except ValueError:
                    rel = None
                # Reject anything that isn't safely under $HOME.
                if rel is None or rel == os.pardir or rel.startswith(os.pardir + os.sep) or os.path.isabs(rel):
                    skipped.append(p)
                    continue
                members.append(rel)

            if not members:
                GLib.idle_add(self.show_message,
                              _("Nothing to back up: all selected locations are outside your home folder,\n"
                                "which is not supported for safe (non-root) restore."))
                return

            # Create tar archive (members are relative to $HOME).
            cmd = ['tar', '--no-same-owner', '-C', home, '-czf', str(backup_path)]
            # Standing exclusions (M7): game binaries etc.
            for exc in BACKUP_EXCLUDES:
                cmd.append('--exclude=' + exc)
            # Never archive the backup destination into itself.
            try:
                rel_dest = self.backup_dir.resolve().relative_to(Path(home).resolve())
                cmd.append('--exclude=' + rel_dest.as_posix())
            except (ValueError, OSError):
                pass
            cmd += members

            # No timeout (H5): run cancellable in this worker thread and
            # report real completion.
            rc, err = self._run_cancellable(cmd)

            if rc is None:
                if backup_path.exists():
                    backup_path.unlink()
                GLib.idle_add(self.status_label.set_text, _("Backup cancelled"))
                GLib.idle_add(self.show_message, _("Backup cancelled."))
                return

            warn_note = ""
            if rc == 1 and backup_path.exists():
                # GNU tar exit 1 = "some files differ/changed while reading";
                # the archive itself is complete.
                warn_note = _("\n(Note: some files changed while being read.)")
            elif rc != 0:
                if backup_path.exists():
                    backup_path.unlink()
                GLib.idle_add(self.status_label.set_text, _("Backup failed"))
                GLib.idle_add(self.show_message,
                              _("Backup failed (tar exit %d):\n%s") % (rc, self._err_summary(err)))
                return

            size_mb = backup_path.stat().st_size / 1024 / 1024
            GLib.idle_add(self.backup_progress.set_fraction, 1.0)
            GLib.idle_add(self.status_label.set_text,
                          _("✓ Backup created: %s (%s MB)") % (name, "%.1f" % size_mb))
            GLib.idle_add(self.refresh_backups)
            GLib.idle_add(self.show_message,
                          _("Backup '%s' created successfully!\nSize: %s MB%s")
                          % (name, "%.1f" % size_mb, warn_note))
        except Exception as e:
            try:
                if backup_path is not None and backup_path.exists():
                    backup_path.unlink()
            except OSError:
                pass
            GLib.idle_add(self.show_message, _("Backup failed: %s") % e)
            GLib.idle_add(self.status_label.set_text, _("Backup failed"))
        finally:
            self._end_operation()
    
    def on_restore_clicked(self, button):
        row = self.backup_list.get_selected_row()
        if not row:
            self.show_message(_("Please select a backup to restore"))
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Restore Backup?")
        )
        dialog.format_secondary_text(_("This will overwrite existing files. Continue?"))
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            threading.Thread(target=self.restore_backup, args=(row.backup_path,), daemon=True).start()
    
    @staticmethod
    def _is_unsafe_path(path):
        # WHY: Refuse absolute paths and any '..' traversal so a tampered or
        # attacker-supplied archive cannot escape $HOME and overwrite files
        # elsewhere (path-traversal / Zip-Slip style). Also reject leading-'/'
        # and Windows-style drive/UNC forms defensively.
        m = path.strip()
        if not m:
            return False
        if m.startswith('/') or m.startswith('\\'):
            return True
        # Normalize separators and inspect each path component.
        parts = m.replace('\\', '/').split('/')
        if '..' in parts:
            return True
        # Drive-letter (e.g. C:) or UNC-ish prefixes.
        if len(m) >= 2 and m[1] == ':':
            return True
        return False

    def _is_unsafe_member(self, member):
        """Check a tarfile.TarInfo member for path traversal, including
        symlink/hardlink targets that would escape the extraction dir (L4)."""
        name = member.name
        if self._is_unsafe_path(name):
            return True
        if member.issym() or member.islnk():
            link = (member.linkname or '').strip()
            if not link:
                return True
            if link.startswith('/') or link.startswith('\\'):
                return True
            if len(link) >= 2 and link[1] == ':':
                return True
            link_norm = link.replace('\\', '/')
            if member.issym():
                # Symlink targets are relative to the member's directory.
                base = posixpath.dirname(name.replace('\\', '/'))
                target = posixpath.normpath(posixpath.join(base, link_norm))
            else:
                # Hardlink targets are relative to the extraction root.
                target = posixpath.normpath(link_norm)
            if target == '..' or target.startswith('../'):
                return True
        return False

    def restore_backup(self, backup_path):
        self._begin_operation()
        try:
            GLib.idle_add(self.status_label.set_text, _("Restoring backup..."))

            # WHY: NEVER extract into '/' as root anymore. List the archive
            # first (via the tarfile module so we can also inspect symlink /
            # hardlink targets) and refuse any member with an absolute path,
            # '..' traversal or an escaping link target; then extract
            # RELATIVE TO $HOME as the normal user.
            home = str(Path.home())

            unsafe = []
            try:
                with tarfile.open(str(backup_path), mode='r|gz') as tf:
                    for m in tf:
                        if self._is_unsafe_member(m):
                            unsafe.append(m.name)
            except (tarfile.TarError, OSError, EOFError) as e:
                GLib.idle_add(self.status_label.set_text, _("Restore failed"))
                GLib.idle_add(self.show_message,
                              _("Could not read backup archive:\n%s") % str(e)[:200])
                return

            if unsafe:
                GLib.idle_add(self.status_label.set_text, _("Restore refused (unsafe archive)"))
                GLib.idle_add(
                    self.show_message,
                    _("Restore refused: this backup contains unsafe paths "
                      "(absolute paths, '..' or escaping links) and was not extracted.\n\n"
                      "Example: %s") % unsafe[0][:120]
                )
                return

            if self.cancel_event.is_set():
                GLib.idle_add(self.status_label.set_text, _("Restore cancelled"))
                return

            # Safe extraction into $HOME, never as root. No timeout (H5):
            # runs cancellable in this worker thread.
            #   --no-same-owner: don't try to restore numeric uid/gid (avoids needing root)
            #   --no-overwrite-dir: don't replace existing directory metadata
            rc, err = self._run_cancellable(
                ['tar', '-xzf', str(backup_path), '-C', home,
                 '--no-same-owner', '--no-overwrite-dir'])

            if rc is None:
                GLib.idle_add(self.status_label.set_text, _("Restore cancelled"))
                GLib.idle_add(self.show_message,
                              _("Restore cancelled. Some files may already have "
                                "been restored."))
            elif rc == 0:
                GLib.idle_add(self.status_label.set_text, _("✓ Backup restored"))
                GLib.idle_add(self.show_message, _("Backup restored successfully!"))
            else:
                GLib.idle_add(self.status_label.set_text, _("Restore completed with warnings"))
                GLib.idle_add(self.show_message,
                              _("Restore completed with some warnings (tar exit %d):\n%s")
                              % (rc, self._err_summary(err)))
        except Exception as e:
            GLib.idle_add(self.show_message, _("Restore failed: %s") % e)
        finally:
            self._end_operation()
    
    def on_delete_backup(self, button):
        row = self.backup_list.get_selected_row()
        if not row:
            self.show_message(_("Please select a backup to delete"))
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Delete Backup?")
        )
        dialog.format_secondary_text(_("Are you sure you want to delete this backup?"))
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            try:
                row.backup_path.unlink()
            except FileNotFoundError:
                pass  # already gone -- refreshing the list is enough (L5)
            except OSError as e:
                self.show_message(_("Could not delete backup:\n%s") % e)
            self.refresh_backups()
            self.status_label.set_text(_("Backup deleted"))
    
    def on_browse_clicked(self, button):
        dialog = Gtk.FileChooserDialog(
            title=_("Select Backup Directory"),
            parent=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER
        )
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            chosen = dialog.get_filename()
            # Setting the entry triggers on_backup_dir_changed, which
            # updates self.backup_dir and persists the config (M4).
            self.dir_entry.set_text(chosen)
            self.refresh_backups()
        dialog.destroy()
    
    def on_open_folder(self, button):
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        try:
            subprocess.Popen(['xdg-open', str(self.backup_dir)])
        except Exception:
            self.show_message(_("Could not open folder:\n%s") % self.backup_dir)
    
    def show_message(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=_("Backup Manager")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()


def main():
    app = BackupManager()
    app.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()
