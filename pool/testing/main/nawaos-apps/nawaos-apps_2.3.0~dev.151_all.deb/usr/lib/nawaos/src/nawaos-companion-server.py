#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Companion Server
Remote control your NawaOS from mobile app or web browser
Version 2.0

Developed by: Ahmed Abdulla
"""

import asyncio
import json
import shutil
import socket
import ssl
import subprocess
import os
import base64
import hmac
import tempfile
import threading
import time
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from io import BytesIO
from datetime import datetime

# Shared helpers (pairing token, local IP, TLS certs, config), also used by
# the Companion GUI. Installed system-wide as the module
# ``nawaos_companion_common``; on dev runs it sits next to this script, which
# is on sys.path automatically.
from nawaos_companion_common import (
    TOKEN_PATH, CONFIG_PATH, CERT_PATH, KEY_PATH,
    get_pairing_token, get_local_ip, load_server_config,
    ensure_certificates, get_cert_fingerprint, build_connection_uri,
    TokenError, EXIT_TLS_FAILED, write_server_state, clear_server_state,
)

# ========================================
# SERVER CONFIG
# ========================================
# Optional JSON config: {"host": "0.0.0.0", "port": 9876, "tls": true}
# The default host stays 0.0.0.0 so the mobile app can reach the server over
# the LAN out of the box; set "host" to "127.0.0.1" to disable LAN access.
# "tls" defaults to true (wss:// + https:// with a self-signed cert); set it
# to false to force the legacy plain ws:// behaviour.
# When "tls" is true and the certificate cannot be created or loaded, the
# server refuses to start (exit code 3) instead of silently serving plain
# ws://. Set "allow_plaintext": true to accept that fallback explicitly.
# CONFIG_PATH / load_server_config live in nawaos_companion_common (shared
# with the GUI, which needs the same "tls" setting for the pairing QR).

# Web client (single-file PWA). Installed system-wide; the dev fallback lets
# `python3 nawaos-companion-server.py` from a source checkout serve the page
# straight from the repo's webclient/ directory.
WEB_ROOT_SYSTEM = "/usr/share/nawaos/companion-web"
WEB_ROOT_DEV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "webclient")

try:
    import websockets
except ImportError:
    print("ERROR: 'websockets' module not found. Install with: pip3 install websockets")
    import sys
    sys.exit(1)

try:
    import qrcode
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False

def resolve_web_root():
    """Directory the web client is served from, or None if unavailable."""
    if os.path.isdir(WEB_ROOT_SYSTEM):
        return WEB_ROOT_SYSTEM
    if os.path.isdir(WEB_ROOT_DEV):
        return WEB_ROOT_DEV
    return None


class CompanionWebServer(ThreadingHTTPServer):
    """ThreadingHTTPServer with quiet per-connection error handling."""

    daemon_threads = True

    def handle_error(self, request, client_address):
        # TLS port scans / bad handshakes are routine on a LAN; one terse
        # line instead of a full traceback (which could also leak paths).
        ip = client_address[0] if client_address else "?"
        print(f"[web] dropped connection from {ip}")


class CompanionWebHandler(SimpleHTTPRequestHandler):
    """Static file handler for the companion web client.

    Hardened: serves ONLY files under ``web_root`` (realpath + prefix check,
    so neither ../ tricks nor symlinks planted inside the web root can escape
    it), and directory listings are disabled outright -- "/" maps to
    index.html and any other directory request is refused.
    """

    web_root = None  # set (to a realpath) before the server starts
    timeout = 30     # per-connection socket timeout (slow-client bound)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=self.web_root, **kwargs)

    def setup(self):
        super().setup()  # applies self.timeout to the connection
        # The listening socket is wrapped with do_handshake_on_connect=False
        # so the TLS handshake happens HERE, in this connection's own thread
        # and bounded by the timeout above -- never in the accept loop, where
        # a stalled client could freeze the whole web server.
        if isinstance(self.connection, ssl.SSLSocket):
            self.connection.do_handshake()

    def translate_path(self, path):
        resolved = os.path.realpath(super().translate_path(path))
        root = self.web_root  # already a realpath
        if resolved != root and not resolved.startswith(root + os.sep):
            # Path-traversal / symlink escape attempt: map to a nonexistent
            # name inside the root -> clean 404, nothing disclosed. (Must be a
            # valid filename: a NUL byte would raise ValueError in open() and
            # 500 instead.)
            return os.path.join(root, ".traversal-denied")
        return resolved

    def list_directory(self, path):
        # No directory listings, ever. "/" is rewritten to index.html by
        # SimpleHTTPRequestHandler before this is reached; anything else
        # asking for a directory gets a 403.
        self.send_error(403, "Directory listing disabled")
        return None

    def log_message(self, format, *args):
        # Keep access logs terse and never echo query strings (defence in
        # depth: the web client never puts the token in a URL, but a broken
        # client might).
        try:
            path = self.path.split("?", 1)[0]
        except Exception:
            path = "?"
        print("[web] {} {}".format(self.command, path))


class SystemMonitor:
    """System monitoring utilities"""
    
    @staticmethod
    def run_command(cmd):
        """Run shell command and return output"""
        try:
            result = subprocess.run(
                ['bash', '-c', cmd],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.stdout.strip()
        except:
            return ""
    
    def get_cpu_info(self):
        """Get CPU information"""
        try:
            # CPU name
            name = self.run_command("cat /proc/cpuinfo | grep 'model name' | head -1 | cut -d ':' -f2").strip()
            
            # CPU usage using top
            top_output = self.run_command("top -bn1 | grep 'Cpu(s)' | awk '{print $2}'")
            try:
                usage = int(float(top_output.replace(',', '.')))
            except:
                usage = 0
            
            # CPU temperature
            temp = 0
            for zone in range(10):
                temp_str = self.run_command(f"cat /sys/class/thermal/thermal_zone{zone}/temp 2>/dev/null")
                if temp_str and temp_str.isdigit():
                    temp = int(temp_str) // 1000
                    break
            
            return {"name": name or "Unknown CPU", "usage": usage, "temperature": temp}
        except:
            return {"name": "Unknown CPU", "usage": 0, "temperature": 0}
    
    def get_ram_info(self):
        """Get RAM information"""
        try:
            mem_output = self.run_command("free -b | grep Mem")
            parts = mem_output.split()
            if len(parts) >= 3:
                total = float(parts[1]) / 1024 / 1024 / 1024
                used = float(parts[2]) / 1024 / 1024 / 1024
                return {
                    "total": round(total, 1),
                    "used": round(used, 1),
                    "available": round(total - used, 1),
                    "percentage": int((used / total) * 100) if total > 0 else 0
                }
        except:
            pass
        return {"total": 0, "used": 0, "available": 0, "percentage": 0}
    
    def get_gpu_info(self):
        """Get GPU information"""
        try:
            # Try NVIDIA
            nvidia = self.run_command("nvidia-smi --query-gpu=name,utilization.gpu,temperature.gpu --format=csv,noheader,nounits 2>/dev/null")
            if nvidia and "command not found" not in nvidia:
                parts = nvidia.split(',')
                return {
                    "name": parts[0].strip() if len(parts) > 0 else "Unknown GPU",
                    "usage": int(parts[1].strip()) if len(parts) > 1 and parts[1].strip().isdigit() else 0,
                    "temperature": int(parts[2].strip()) if len(parts) > 2 and parts[2].strip().isdigit() else 0
                }
            
            # Fallback to lspci
            lspci = self.run_command("lspci | grep -i 'vga\\|3d\\|display' | head -1 | cut -d ':' -f3")
            return {"name": lspci.strip() or "Unknown GPU", "usage": 0, "temperature": 0}
        except:
            return {"name": "Unknown GPU", "usage": 0, "temperature": 0}
    
    def get_system_info(self):
        """Get all system information (format for Android app)"""
        cpu = self.get_cpu_info()
        ram = self.get_ram_info()
        gpu = self.get_gpu_info()
        return {
            "Cpu": {
                "Name": cpu["name"],
                "Usage": cpu["usage"],
                "Temperature": cpu["temperature"]
            },
            "Ram": {
                "Total": ram["total"],
                "Used": ram["used"],
                "Available": ram["available"],
                "Percentage": ram["percentage"]
            },
            "Gpu": {
                "Name": gpu["name"],
                "Usage": gpu["usage"],
                "Temperature": gpu["temperature"],
                "Vram": {"Used": 0, "Total": 0}
            },
            "timestamp": int(datetime.now().timestamp() * 1000)
        }
    
    def get_processes(self):
        """Get top processes by memory (format for Android app)"""
        processes = []
        try:
            ps_output = self.run_command("ps aux --sort=-%mem | head -21 | tail -20")
            for line in ps_output.split('\n'):
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    pid = int(parts[1]) if parts[1].isdigit() else 0
                    mem_percent = float(parts[3]) if parts[3].replace('.', '').isdigit() else 0
                    cmd = parts[10].split('/')[-1][:30]  # Get short name
                    # Estimate memory in MB (from percentage)
                    total_ram = self.get_ram_info()["total"] * 1024  # GB to MB
                    mem_mb = int((mem_percent / 100) * total_ram)
                    processes.append({
                        "Pid": pid,
                        "Name": cmd,
                        "Title": cmd,
                        "MemoryMB": mem_mb,
                        "IsGame": any(g in cmd.lower() for g in ['game', 'steam', 'proton', 'wine', 'lutris', 'retro'])
                    })
        except:
            pass
        return processes
    
    def get_audio_sessions(self):
        """Get audio sessions/applications"""
        sessions = []
        try:
            # Get sink inputs (applications playing audio)
            output = self.run_command("pactl list sink-inputs")
            current = {}
            for line in output.split('\n'):
                if line.startswith('Sink Input'):
                    if current:
                        sessions.append(current)
                    current = {"Pid": 0, "Name": "Unknown", "Title": "Unknown", "Volume": 100, "Muted": False}
                elif 'application.process.id' in line:
                    try:
                        current["Pid"] = int(line.split('=')[1].strip().strip('"'))
                    except:
                        pass
                elif 'application.name' in line:
                    current["Name"] = line.split('=')[1].strip().strip('"')
                    current["Title"] = current["Name"]
                elif 'Volume:' in line and 'Base' not in line:
                    try:
                        vol = line.split('/')[1].strip().replace('%', '')
                        current["Volume"] = int(vol)
                    except:
                        pass
                elif 'Mute:' in line:
                    current["Muted"] = 'yes' in line.lower()
            if current and current.get("Name") != "Unknown":
                sessions.append(current)
        except:
            pass
        
        # Add master volume as first item
        master_vol = self.get_volume()
        master_muted = self.get_mute_status()
        sessions.insert(0, {
            "Pid": 0,
            "Name": "Master Volume",
            "Title": "System Audio",
            "Volume": master_vol,
            "Muted": master_muted
        })
        return sessions
    
    def set_app_volume(self, pid, volume):
        """Set volume for specific application"""
        try:
            if pid == 0:  # Master volume
                return self.set_volume(int(volume))
            # Find sink-input by PID and set volume
            output = self.run_command("pactl list sink-inputs")
            sink_input = None
            current_pid = None
            for line in output.split('\n'):
                if line.startswith('Sink Input #'):
                    sink_input = line.split('#')[1].strip()
                elif 'application.process.id' in line:
                    try:
                        current_pid = int(line.split('=')[1].strip().strip('"'))
                        if current_pid == pid and sink_input:
                            self.run_command(f"pactl set-sink-input-volume {sink_input} {int(volume)}%")
                            return True
                    except:
                        pass
        except:
            pass
        return False
    
    def mute_mic(self, muted):
        """Mute/unmute microphone"""
        try:
            state = "1" if muted else "0"
            self.run_command(f"pactl set-source-mute @DEFAULT_SOURCE@ {state}")
            return True
        except:
            return False
    
    # pkexec may pop up a polkit password prompt, so allow generous time for
    # the user to type it -- but never wait forever: a hung/ignored prompt
    # would otherwise pin the worker thread for good.
    PKEXEC_TIMEOUT = 120

    def set_performance_mode(self, mode):
        """Set performance mode"""
        try:
            if mode == "performance":
                result = subprocess.run(['pkexec', '/usr/local/bin/nawaos-gamemode', 'on'],
                                        capture_output=True, timeout=self.PKEXEC_TIMEOUT)
                return result.returncode == 0
            elif mode == "balanced" or mode == "powersave":
                result = subprocess.run(['pkexec', '/usr/local/bin/nawaos-gamemode', 'off'],
                                        capture_output=True, timeout=self.PKEXEC_TIMEOUT)
                return result.returncode == 0
            return False
        except:
            return False
    
    def force_quit(self, pid):
        """Kill a process"""
        try:
            # Require a positive integer PID. A negative value makes os.kill
            # signal an entire process group (e.g. -1 = every process the user
            # can reach), turning this into a one-call remote DoS.
            pid = int(pid)
            if pid <= 1:
                return False
            os.kill(pid, 9)
            return True
        except (TypeError, ValueError, ProcessLookupError, PermissionError):
            return False
    
    def take_screenshot(self):
        """Take screenshot and return base64"""
        # A predictable /tmp/nawaos_screenshot_<timestamp>.png is symlink-attackable:
        # a local attacker can pre-create the path as a symlink so the screenshot
        # tool clobbers an arbitrary file the server user can write. mkstemp atomically
        # creates a private 0600 file with an unguessable name instead.
        fd, temp_path = tempfile.mkstemp(suffix=".png", prefix="nawaos_screenshot_")
        os.close(fd)  # the screenshot tool writes to the path itself
        try:
            self.run_command(f"gnome-screenshot -f '{temp_path}' 2>/dev/null || scrot '{temp_path}' 2>/dev/null || import -window root '{temp_path}' 2>/dev/null")

            if os.path.exists(temp_path):
                with open(temp_path, 'rb') as f:
                    data = base64.b64encode(f.read()).decode()
                return data
        except:
            pass
        finally:
            # Always unlink the temp file, even on error/early return.
            try:
                os.remove(temp_path)
            except OSError:
                pass
        return None
    
    def enable_gamemode(self):
        """Enable game mode"""
        try:
            result = subprocess.run(['pkexec', '/usr/local/bin/nawaos-gamemode', 'on'],
                                    capture_output=True, timeout=self.PKEXEC_TIMEOUT)
            return result.returncode == 0
        except:
            return False

    def disable_gamemode(self):
        """Disable game mode"""
        try:
            result = subprocess.run(['pkexec', '/usr/local/bin/nawaos-gamemode', 'off'],
                                    capture_output=True, timeout=self.PKEXEC_TIMEOUT)
            return result.returncode == 0
        except:
            return False
    
    def set_volume(self, level):
        """Set system volume (0-100)"""
        try:
            # Coerce to a clamped integer FIRST. run_command runs its argument
            # through `bash -c`, so an authenticated client sending a string
            # level like "0; rm -rf ~ #" would otherwise be shell-injected here.
            # Sanitising at the source covers every caller (set_volume and
            # set_master_volume).
            try:
                level = int(level)
            except (TypeError, ValueError):
                return False
            level = max(0, min(100, level))
            # Try pactl first
            result = self.run_command(f"pactl set-sink-volume @DEFAULT_SINK@ {level}%")
            if result is not None:
                return True
            # Fallback to amixer
            self.run_command(f"amixer set Master {level}%")
            return True
        except:
            return False
    
    def toggle_mute(self):
        """Toggle mute"""
        try:
            self.run_command("pactl set-sink-mute @DEFAULT_SINK@ toggle")
            return True
        except:
            return False
    
    def get_volume(self):
        """Get current volume level"""
        try:
            output = self.run_command("pactl get-sink-volume @DEFAULT_SINK@ | grep -oP '\\d+%' | head -1")
            if output:
                return int(output.replace('%', ''))
            # Fallback
            output = self.run_command("amixer get Master | grep -oP '\\d+%' | head -1")
            if output:
                return int(output.replace('%', ''))
        except:
            pass
        return 50
    
    def get_mute_status(self):
        """Get mute status"""
        try:
            output = self.run_command("pactl get-sink-mute @DEFAULT_SINK@")
            return "yes" in output.lower()
        except:
            return False


class NawaOSCompanionServer:
    """WebSocket server for mobile companion app"""
    
    def __init__(self, port=9876, host="0.0.0.0", tls=True, allow_plaintext=False):
        self.port = port
        self.host = host
        self.tls = tls                 # config wish ("tls" key, default true)
        self.allow_plaintext = allow_plaintext  # explicit opt-in to ws:// fallback
        self.tls_error = None          # why TLS could not be set up
        self.ssl_context = None        # set by _setup_tls() when TLS is live
        self.fingerprint = None        # SHA-256 hex of the cert (TLS only)
        self.mdns_proc = None          # avahi-publish-service child process
        self.web_httpd = None          # ThreadingHTTPServer for the web client
        self.monitor = SystemMonitor()
        self.clients = set()
        self.authed = set()        # websockets that passed authentication
        # websocket -> the token it logged in with. "Reset pairing" in the
        # GUI rotates the token file; enforce_pairing() then disconnects
        # every client whose token is no longer the stored one.
        self.auth_tokens = {}
        self.state = None          # what the state file says (see start())
        # At most ONE system-info streaming task per websocket (see
        # subscribe_system_info): websocket -> asyncio.Task.
        self.stream_tasks = {}
        # Brute-force lockout keyed by CLIENT IP (not the websocket object).
        # Keying by websocket let an attacker reset the counter just by
        # reconnecting, giving unlimited guesses. Per-IP with a time-based
        # lockout actually throttles guessing across reconnects.
        # ip -> (fail_count, lockout_until_monotonic). 0.0 means not locked.
        self.auth_fails = {}
        self.MAX_AUTH_FAILS = 3
        self.LOCKOUT_SECONDS = 60
        self.token = get_pairing_token()   # TokenError is handled in main()
        self.running = False

    def _current_token(self):
        """The token as stored on disk right now. Re-read on every login
        attempt so the server and the GUI's QR code can never disagree
        (e.g. after the token file was rotated)."""
        try:
            self.token = get_pairing_token()
        except TokenError as e:
            print(f"[!] {e}; using the token loaded at startup")
        return self.token

    def _publish_state(self):
        """Rewrite the state file with the number of logged-in clients (the
        GUI's "CONNECTED" counter reads it)."""
        if self.state is not None:
            self.state["clients"] = len(self.authed)
            write_server_state(self.state)

    async def enforce_pairing(self):
        """Disconnect clients that logged in with a token other than the
        stored one, i.e. after the GUI's "Reset pairing". Returns how many."""
        token = self._current_token()
        stale = [ws for ws, used in self.auth_tokens.items()
                 if not hmac.compare_digest(used, token)]
        for ws in stale:
            self.authed.discard(ws)
            self.auth_tokens.pop(ws, None)
            try:
                await ws.close(code=4003, reason="Pairing was reset")
            except Exception:
                pass
        if stale:
            print(f"[i] Pairing reset: {len(stale)} client(s) disconnected")
            self._publish_state()
        return len(stale)

    async def _watch_pairing(self, interval=2.0):
        while True:
            await asyncio.sleep(interval)
            await self.enforce_pairing()

    def _prune_auth_fails(self, now):
        """Drop entries whose lockout has expired (keeps the dict bounded)."""
        for ip in [ip for ip, (_, until) in self.auth_fails.items()
                   if until and until <= now]:
            self.auth_fails.pop(ip, None)

    def _is_locked_out(self, client_ip):
        """True if this IP is currently within its lockout window."""
        entry = self.auth_fails.get(client_ip)
        if not entry:
            return False
        _, until = entry
        return bool(until) and time.monotonic() < until

    def _record_auth_fail(self, client_ip):
        """Increment failure count for an IP and arm lockout after MAX_AUTH_FAILS."""
        count, _ = self.auth_fails.get(client_ip, (0, 0.0))
        count += 1
        until = time.monotonic() + self.LOCKOUT_SECONDS if count >= self.MAX_AUTH_FAILS else 0.0
        self.auth_fails[client_ip] = (count, until)
        return count
    
    # ---- TLS / mDNS / web client plumbing (v2.0) ----

    def _setup_tls(self):
        """Build the shared SSL context. True when wss/https are active.

        Never raises: any failure (openssl CLI missing, cert generation or
        loading error) is recorded in self.tls_error and leaves
        self.ssl_context = None. start() then refuses to serve unless
        plaintext was explicitly allowed.
        """
        if not self.tls:
            return False
        if not ensure_certificates():
            self.tls_error = ("certificate generation failed "
                              "(is the 'openssl' CLI installed?)")
            print(f"[!] TLS requested but {self.tls_error}")
            return False
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(CERT_PATH, KEY_PATH)
        except (ssl.SSLError, OSError) as e:
            self.tls_error = f"the certificate could not be loaded ({e})"
            print(f"[!] TLS setup failed: {self.tls_error}")
            return False
        fingerprint = get_cert_fingerprint()
        if not fingerprint:
            self.tls_error = "the certificate could not be fingerprinted"
            print(f"[!] TLS setup failed: {self.tls_error}")
            return False
        self.ssl_context = ctx
        self.fingerprint = fingerprint
        return True

    def _start_web_server(self):
        """Serve the single-file web client on port+1 (same TLS context).

        NOTE: the browser's one-time "accept this self-signed certificate"
        exception for https://<ip>:<port+1> also covers the wss:// WebSocket
        to the same host, because both servers present the exact same cert.
        """
        web_root = resolve_web_root()
        if web_root is None:
            print("[i] Web client files not found; web UI disabled "
                  f"(expected {WEB_ROOT_SYSTEM} or a local webclient/ dir)")
            return
        CompanionWebHandler.web_root = os.path.realpath(web_root)
        try:
            httpd = CompanionWebServer((self.host, self.port + 1),
                                       CompanionWebHandler)
            if self.ssl_context is not None:
                # Deferred handshake: completed per-connection (with timeout)
                # in CompanionWebHandler.setup, not in the accept loop.
                httpd.socket = self.ssl_context.wrap_socket(
                    httpd.socket, server_side=True,
                    do_handshake_on_connect=False)
        except (OSError, ssl.SSLError) as e:
            print(f"[!] Web client server failed to start on port {self.port + 1}: {e}")
            return
        threading.Thread(target=httpd.serve_forever,
                         name="companion-web", daemon=True).start()
        self.web_httpd = httpd

    def _stop_web_server(self):
        if self.web_httpd is not None:
            try:
                self.web_httpd.shutdown()      # called from the main thread,
                self.web_httpd.server_close()  # serve_forever runs elsewhere
            except Exception:
                pass
            self.web_httpd = None

    def _start_mdns(self):
        """Advertise _nawaos-companion._tcp via avahi-publish-service.

        The TXT record carries only tls/fp -- NEVER the pairing token.
        Missing avahi-utils is fine: one info line and we move on.
        """
        if shutil.which("avahi-publish-service") is None:
            print("[i] avahi-publish-service not found; mDNS discovery disabled")
            return
        try:
            hostname = socket.gethostname() or "NawaOS"
        except Exception:
            hostname = "NawaOS"
        cmd = ["avahi-publish-service",
               f"NawaOS Companion on {hostname}",
               "_nawaos-companion._tcp", str(self.port),
               f"tls={'1' if self.ssl_context else '0'}"]
        if self.fingerprint:
            cmd.append(f"fp={self.fingerprint}")
        try:
            self.mdns_proc = subprocess.Popen(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as e:
            print(f"[i] mDNS advertisement failed to start: {e}")
            self.mdns_proc = None

    def _stop_mdns(self):
        if self.mdns_proc is not None:
            try:
                self.mdns_proc.terminate()
                try:
                    self.mdns_proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.mdns_proc.kill()
            except Exception:
                pass
            self.mdns_proc = None

    def generate_qr_code(self):
        """Generate QR code for connection"""
        if not HAS_QRCODE:
            return None
        ip = get_local_ip()
        # Pairing URI: embeds the token (auth) and, in TLS mode, the cert
        # fingerprint so the mobile app can pin the self-signed cert.
        connection_url = build_connection_uri(
            ip, self.port, self.token,
            fingerprint=self.fingerprint,
            tls=self.ssl_context is not None)

        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(connection_url)
        qr.make(fit=True)
        
        # Return as base64 PNG
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        return base64.b64encode(buffer.getvalue()).decode()
    
    async def handle_message(self, websocket, message):
        """Handle incoming message"""
        try:
            data = json.loads(message)
            msg_type = data.get('type', '')
            
            response = {"type": "error", "message": "Unknown command"}

            # ---- Commands allowed BEFORE authentication ----
            if msg_type == "ping":
                await websocket.send(json.dumps(
                    {"type": "pong", "timestamp": int(datetime.now().timestamp() * 1000)}))
                return

            if msg_type == "auth":
                client_ip = websocket.remote_address[0] if websocket.remote_address else "unknown"
                provided = str(data.get("token", ""))
                if hmac.compare_digest(provided, self._current_token()):
                    self.authed.add(websocket)
                    self.auth_tokens[websocket] = provided
                    # Successful auth clears the IP's failure record.
                    self.auth_fails.pop(client_ip, None)
                    self._publish_state()
                    await websocket.send(json.dumps({"type": "auth_ok"}))
                else:
                    fails = self._record_auth_fail(client_ip)
                    await websocket.send(json.dumps(
                        {"type": "auth_failed", "attempts": fails}))
                    if fails >= self.MAX_AUTH_FAILS:
                        await websocket.close(code=4001, reason="Too many failed auth attempts")
                return

            # ---- Everything else REQUIRES authentication ----
            if websocket not in self.authed:
                await websocket.send(json.dumps(
                    {"type": "auth_required",
                     "message": "Send an 'auth' message with the pairing token first"}))
                return

            # NOTE: every SystemMonitor call below shells out via blocking
            # subprocess.run (pkexec can even sit on a polkit password prompt
            # for up to 2 minutes). Running them inline would freeze the whole
            # event loop -- and thus EVERY connected client -- so they are all
            # pushed to a worker thread with asyncio.to_thread().
            if msg_type == "get_system_info":
                info = await asyncio.to_thread(self.monitor.get_system_info)
                response = {"type": "system_info", "data": info}

            elif msg_type == "get_processes":
                processes = await asyncio.to_thread(self.monitor.get_processes)
                response = {"type": "processes", "data": processes}

            elif msg_type == "force_quit":
                pid = data.get('pid', 0)
                success = self.monitor.force_quit(pid)
                response = {"type": "process_killed", "success": success, "pid": pid}

            elif msg_type == "take_screenshot":
                screenshot = await asyncio.to_thread(self.monitor.take_screenshot)
                if screenshot:
                    response = {"type": "screenshot", "data": screenshot}
                else:
                    response = {"type": "error", "message": "Failed to capture screenshot"}

            elif msg_type == "gamemode_on":
                success = await asyncio.to_thread(self.monitor.enable_gamemode)
                response = {"type": "gamemode", "enabled": success, "success": success}

            elif msg_type == "gamemode_off":
                success = await asyncio.to_thread(self.monitor.disable_gamemode)
                # Report the REAL outcome: on success game mode is now off; on
                # failure it is still on (don't hardcode enabled=False).
                response = {"type": "gamemode", "enabled": not success, "success": success}

            elif msg_type == "set_volume":
                level = data.get('level', 50)
                success = await asyncio.to_thread(self.monitor.set_volume, level)
                response = {"type": "volume", "success": success, "level": level}

            elif msg_type == "toggle_mute":
                success = await asyncio.to_thread(self.monitor.toggle_mute)
                response = {"type": "mute", "success": success}

            elif msg_type == "get_volume":
                level = await asyncio.to_thread(self.monitor.get_volume)
                muted = await asyncio.to_thread(self.monitor.get_mute_status)
                response = {"type": "volume_info", "level": level, "muted": muted}

            elif msg_type == "subscribe_system_info":
                # Clamp the interval to >= 250ms so a buggy/hostile client
                # can't make the server busy-loop collecting system info.
                try:
                    interval_ms = float(data.get('interval', 1000))
                except (TypeError, ValueError):
                    interval_ms = 1000.0
                interval = max(interval_ms, 250.0) / 1000.0
                # Keep at most ONE streaming task per websocket: a re-subscribe
                # replaces the previous stream instead of stacking another one.
                old_task = self.stream_tasks.pop(websocket, None)
                if old_task is not None:
                    old_task.cancel()
                self.stream_tasks[websocket] = asyncio.create_task(
                    self.stream_system_info(websocket, interval))
                response = {"type": "subscribed", "interval": interval}

            # Android app commands
            elif msg_type == "get_audio_sessions":
                sessions = await asyncio.to_thread(self.monitor.get_audio_sessions)
                response = {"type": "audio_sessions", "data": sessions}

            elif msg_type == "set_master_volume":
                volume = data.get('volume', 50)
                success = await asyncio.to_thread(self.monitor.set_volume, int(volume))
                response = {"type": "volume", "success": success, "level": int(volume)}

            elif msg_type == "mute_mic":
                muted = data.get('muted', False)
                success = await asyncio.to_thread(self.monitor.mute_mic, muted)
                response = {"type": "mic_muted", "success": success, "muted": muted}

            elif msg_type == "set_performance_mode":
                mode = data.get('mode', 'balanced')
                success = await asyncio.to_thread(self.monitor.set_performance_mode, mode)
                response = {"type": "performance_mode", "success": success, "mode": mode}
            
            await websocket.send(json.dumps(response))
            
        except json.JSONDecodeError:
            await websocket.send(json.dumps({"type": "error", "message": "Invalid JSON"}))
        except Exception as e:
            await websocket.send(json.dumps({"type": "error", "message": str(e)}))
    
    async def stream_system_info(self, websocket, interval):
        """Stream system info at interval"""
        try:
            while websocket in self.clients and websocket in self.authed:
                # Collected in a worker thread: get_system_info shells out and
                # must not block the event loop (see handle_message).
                info = await asyncio.to_thread(self.monitor.get_system_info)
                await websocket.send(json.dumps({"type": "system_info", "data": info}))
                await asyncio.sleep(interval)
        except:
            pass

    async def handler(self, websocket, path=None):
        """Handle WebSocket connection.

        Compatible with both websockets APIs: the new asyncio API
        (websockets >= 14, e.g. Debian Trixie) invokes the handler with a
        single connection argument, while the legacy API also passes the
        request path -- hence the optional, unused ``path`` parameter.
        """
        client_ip = websocket.remote_address[0] if websocket.remote_address else "unknown"

        # Reject connections from IPs in their lockout window BEFORE doing any
        # work, so a brute-forcer can't keep reconnecting to reset its counter.
        # Prune expired entries here so the dict can't grow without bound.
        self._prune_auth_fails(time.monotonic())
        if self._is_locked_out(client_ip):
            print(f"[!] Rejected locked-out client: {client_ip}")
            await websocket.close(code=4001, reason="Too many failed auth attempts")
            return

        self.clients.add(websocket)
        print(f"[+] Client connected: {client_ip}")

        try:
            # Send welcome message
            await websocket.send(json.dumps({
                "type": "welcome",
                "message": "Welcome to NawaOS Companion",
                "version": "2.0",
                "tls": self.ssl_context is not None,
                "auth_required": True
            }))
            
            async for message in websocket:
                await self.handle_message(websocket, message)
                
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.discard(websocket)
            self.authed.discard(websocket)
            self.auth_tokens.pop(websocket, None)
            self._publish_state()
            # Stop this connection's system-info stream (if any) so the task
            # doesn't linger after disconnect.
            stream_task = self.stream_tasks.pop(websocket, None)
            if stream_task is not None:
                stream_task.cancel()
            # NOTE: auth_fails is keyed by IP (not the websocket) and is
            # deliberately NOT cleared on disconnect, otherwise the lockout
            # would reset on every reconnect. It is pruned by time instead.
            print(f"[-] Client disconnected: {client_ip}")
    
    async def start(self):
        """Start the server"""
        self.running = True
        ip = get_local_ip()

        tls_on = self._setup_tls()
        if self.tls and not tls_on and not self.allow_plaintext:
            # Never downgrade silently: the GUI and the paired phones expect
            # an encrypted endpoint.
            print("[!] TLS is required but could not be set up: "
                  f"{self.tls_error}.")
            print("    The server was NOT started unencrypted. Install the")
            print("    'openssl' package, or set \"allow_plaintext\": true in")
            print(f"    {CONFIG_PATH} to accept plain ws:// on trusted networks.")
            raise SystemExit(EXIT_TLS_FAILED)
        self._start_web_server()        # https(/http) on port+1, same cert

        scheme = "wss" if tls_on else "ws"
        web_scheme = "https" if tls_on else "http"

        print("=" * 50)
        print("  NawaOS Companion Server v2.0")
        print("=" * 50)
        print(f"\n  Server: {scheme}://{ip}:{self.port} (bound to {self.host})")
        if self.web_httpd is not None:
            print(f"  Web client: {web_scheme}://{ip}:{self.port + 1}")
        # SECURITY: never print the pairing token -- stdout may be captured
        # into a log file that is easier to read than the 0600 token file.
        print(f"  Pairing token: see the Companion GUI (stored in {TOKEN_PATH})")
        print(f"  Scan QR code with NawaOS Mobile App")
        print()
        if tls_on:
            print("  TLS: self-signed certificate (pin this fingerprint)")
            print(f"  SHA-256: {self.fingerprint}")
            if self.web_httpd is not None:
                print("  Your browser will warn about the self-signed cert;")
                print(f"  verify the fingerprint above, then accept it once at")
                print(f"  {web_scheme}://{ip}:{self.port + 1} -- that exception")
                print("  also covers the wss:// connection on the same host.")
        else:
            print("  " + "!" * 46)
            print("  !! WARNING: traffic is UNENCRYPTED (plain ws://).")
            print("  !! Anyone on the local network can read it.")
            print("  !! Only run this on networks you trust. To restrict")
            print("  !! the server to this machine, set \"host\" to")
            print(f"  !! \"127.0.0.1\" in {CONFIG_PATH}")
            print("  " + "!" * 46)
        print("\n" + "=" * 50)

        async with websockets.serve(self.handler, self.host, self.port,
                                    ssl=self.ssl_context):
            self._start_mdns()          # advertise only once we're serving
            # Tell the GUI what is really being served (and, from then on,
            # how many clients are logged in).
            self.state = {
                "pid": os.getpid(),
                "port": self.port,
                "tls": tls_on,
                "fingerprint": self.fingerprint if tls_on else None,
                "tls_error": self.tls_error,
                "web": self.web_httpd is not None,
            }
            self._publish_state()
            watcher = asyncio.create_task(self._watch_pairing())
            try:
                await asyncio.Future()  # Run forever
            finally:
                watcher.cancel()
                clear_server_state(os.getpid())
                self._stop_mdns()
                self._stop_web_server()


def main():
    import sys

    # Optional config file can set the bind host (and default port); the
    # command line still overrides the port. Default host stays 0.0.0.0 so
    # the mobile app keeps working over the LAN.
    config = load_server_config()
    host = str(config.get("host", "0.0.0.0"))
    tls = bool(config.get("tls", True))
    allow_plaintext = bool(config.get("allow_plaintext", False))

    port = 9876
    try:
        port = int(config.get("port", port))
    except (TypeError, ValueError):
        pass
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except:
            pass

    try:
        server = NawaOSCompanionServer(port, host, tls, allow_plaintext)
    except TokenError as e:
        print(f"[!] Cannot start: {e}")
        sys.exit(1)
    
    try:
        asyncio.run(server.start())
    except KeyboardInterrupt:
        print("\nServer stopped.")


if __name__ == "__main__":
    main()
