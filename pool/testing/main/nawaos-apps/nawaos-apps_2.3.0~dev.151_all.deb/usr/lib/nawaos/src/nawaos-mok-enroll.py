#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NawaOS Secure Boot driver key enrolment (GUI).

Front end for /usr/local/bin/nawaos-mok-enroll. With Secure Boot enabled the
kernel refuses the DKMS-built NVIDIA module until the key DKMS signed it with
is enrolled in the firmware. This window explains the situation, makes the
signing key machine-specific if it is still the image-wide one, asks for the
one-time password the MOK manager will request, queues the enrolment and
tells the user exactly what to do on the next reboot.

Launched from the Setup Wizard's readiness page and the Control Panel's
Drivers page (`nawaos-mok-enroll-gui`).

Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import os
import subprocess
import sys
import threading

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib  # noqa: E402

sys.path.insert(0, "/usr/lib/nawaos/src")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common"))
# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402
try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

APP_NAME = "nawaos-mok-enroll"
HELPER = "/usr/local/bin/nawaos-mok-enroll"

AR_STRINGS = {
    "Secure Boot driver key": "مفتاح توقيع التعريفات لـ Secure Boot",
    "Checking Secure Boot state…": "جارٍ فحص حالة Secure Boot…",
    "Secure Boot is enabled and the NVIDIA driver is blocked.":
        "Secure Boot مفعّل والتعريف NVIDIA محجوب.",
    "The kernel only loads driver modules signed with a key the firmware trusts. "
    "NawaOS signs the NVIDIA module automatically; the key just has to be enrolled once.":
        "النواة لا تحمّل وحدات التعريف إلا إذا كانت موقّعة بمفتاح تثق به البرامج الثابتة. "
        "يوقّع NawaOS وحدة NVIDIA تلقائياً، ويكفي تسجيل المفتاح مرة واحدة.",
    "Choose a one-time password (8–16 characters). You will type it once more "
    "on the blue MOK Manager screen after the reboot.":
        "اختر كلمة مرور لمرة واحدة (8 إلى 16 حرفاً). ستكتبها مرة أخرى في شاشة MOK Manager الزرقاء بعد إعادة التشغيل.",
    "Password": "كلمة المرور",
    "Confirm password": "تأكيد كلمة المرور",
    "Enrol key": "تسجيل المفتاح",
    "Cancel queued enrolment": "إلغاء التسجيل المعلّق",
    "Reboot now": "إعادة التشغيل الآن",
    "Close": "إغلاق",
    "The passwords do not match.": "كلمتا المرور غير متطابقتين.",
    "The password must be 8 to 16 characters long.": "يجب أن تكون كلمة المرور بين 8 و16 حرفاً.",
    "Making the signing key specific to this computer… (a few minutes)":
        "جارٍ جعل مفتاح التوقيع خاصاً بهذا الجهاز… (بضع دقائق)",
    "Queuing the enrolment…": "جارٍ تجهيز التسجيل…",
    "The signing key could not be made specific to this computer, "
    "so nothing was enrolled. The shared NawaOS image key is never enrolled.":
        "تعذّر جعل مفتاح التوقيع خاصاً بهذا الجهاز، لذلك لم يُسجَّل شيء. "
        "لا يُسجَّل مفتاح صورة NawaOS المشترك أبداً.",
    "Enrolment queued. On the next reboot:": "تم تجهيز التسجيل. عند إعادة التشغيل التالية:",
    "1. A blue screen titled “Perform MOK management” appears.\n"
    "2. Choose “Enroll MOK”, then “Continue”, then “Yes”.\n"
    "3. Enter the password you just chose.\n"
    "4. Choose “Reboot”. The NVIDIA driver loads from then on.":
        "1. تظهر شاشة زرقاء بعنوان “Perform MOK management”.\n"
        "2. اختر “Enroll MOK” ثم “Continue” ثم “Yes”.\n"
        "3. أدخل كلمة المرور التي اخترتها للتو.\n"
        "4. اختر “Reboot”. بعدها يعمل تعريف NVIDIA.",
    "The key is already enrolled and the driver loads. Nothing to do.":
        "المفتاح مسجّل أصلاً والتعريف يعمل. لا شيء مطلوب.",
    "An enrolment is already queued. Reboot to finish it.":
        "هناك تسجيل معلّق أصلاً. أعد التشغيل لإتمامه.",
    "Secure Boot is disabled on this computer; no key enrolment is needed.":
        "Secure Boot معطّل على هذا الجهاز؛ لا حاجة لتسجيل مفتاح.",
    "The NVIDIA driver module has not been built yet. Install the driver first "
    "(Control Panel → Drivers), then come back here.":
        "لم تُبنَ وحدة تعريف NVIDIA بعد. ثبّت التعريف أولاً (لوحة التحكم ← التعريفات) ثم عد إلى هنا.",
    "No NVIDIA driver package is installed; this tool is only needed for the proprietary NVIDIA driver.":
        "لا توجد حزمة تعريف NVIDIA مثبتة؛ هذه الأداة مطلوبة فقط لتعريف NVIDIA الاحتكاري.",
    "Failed: %s": "فشل: %s",
    "Cancelled.": "أُلغي.",
    "Secure Boot: %s": "Secure Boot: %s",
    "Signing key enrolled: %s": "مفتاح التوقيع مسجّل: %s",
    "NVIDIA module: %s": "وحدة NVIDIA: %s",
    "yes": "نعم", "no": "لا", "unknown": "غير معروف", "enabled": "مفعّل",
    "disabled": "معطّل", "unsupported": "غير مدعوم", "built": "مبنية",
    "missing": "غير موجودة", "loaded": "محمّلة",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    gettext, _get_language, is_rtl = nawaos_i18n.setup(APP_NAME, AR_STRINGS)
    return gettext, is_rtl


_, is_rtl = _setup_i18n()


def read_status():
    """Run `nawaos-mok-enroll status` and return its key=value pairs."""
    status = {}
    try:
        out = subprocess.run([HELPER, "status"], capture_output=True, text=True, timeout=30).stdout
    except (OSError, subprocess.SubprocessError):
        return status
    for line in out.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            status[k.strip()] = v.strip()
    return status


class EnrolWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("Secure Boot driver key"))
        self.set_default_size(560, 420)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(0)
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)
        if nawaos_theme is not None:
            try:
                nawaos_theme.apply_theme(self, "")
            except Exception:
                pass

        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for side in ("start", "end", "top", "bottom"):
            getattr(self.box, "set_margin_" + side)(24)
        self.add(self.box)

        title = Gtk.Label()
        title.set_markup('<span size="x-large" weight="bold">%s</span>'
                         % GLib.markup_escape_text(_("Secure Boot driver key")))
        title.set_halign(Gtk.Align.START)
        self.box.pack_start(title, False, False, 0)

        self.status_label = Gtk.Label(label=_("Checking Secure Boot state…"))
        self.status_label.set_halign(Gtk.Align.START)
        self.status_label.set_line_wrap(True)
        self.box.pack_start(self.status_label, False, False, 0)

        self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.box.pack_start(self.body, True, True, 0)

        self.spinner = Gtk.Spinner()
        self.box.pack_start(self.spinner, False, False, 0)

        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btns.set_halign(Gtk.Align.END)
        close = Gtk.Button(label=_("Close"))
        close.connect("clicked", lambda *_a: Gtk.main_quit())
        btns.pack_end(close, False, False, 0)
        self.box.pack_end(btns, False, False, 0)

        self.connect("destroy", Gtk.main_quit)
        self.refresh()

    # ---------------------------------------------------------------- status
    def refresh(self):
        self.spinner.start(); self.spinner.show()

        def worker():
            st = read_status()
            GLib.idle_add(self.render, st)
        threading.Thread(target=worker, daemon=True).start()

    def _clear_body(self):
        for child in self.body.get_children():
            self.body.remove(child)

    def render(self, st):
        self.spinner.stop(); self.spinner.hide()
        self._clear_body()
        sb = st.get("secure_boot", "unknown")
        enrolled = st.get("mok_enrolled", "unknown")
        module = st.get("nvidia_module", "missing") if st.get("nvidia_dkms") == "installed" else "missing"
        if st.get("nvidia_loaded") == "yes":
            module = "loaded"
        self.status_label.set_text("%s   ·   %s   ·   %s" % (
            _("Secure Boot: %s") % _(sb),
            _("Signing key enrolled: %s") % _(enrolled),
            _("NVIDIA module: %s") % _(module)))

        verdict = st.get("verdict", "n/a")
        note = Gtk.Label()
        note.set_line_wrap(True)
        note.set_halign(Gtk.Align.START)
        note.set_xalign(0)
        if verdict == "needs-enrol":
            self._render_enrol_form(st)
            return
        elif verdict == "pending":
            note.set_text(_("An enrolment is already queued. Reboot to finish it."))
            self.body.pack_start(note, False, False, 0)
            self._render_reboot_steps()
            cancel = Gtk.Button(label=_("Cancel queued enrolment"))
            cancel.connect("clicked", self.on_cancel)
            self.body.pack_start(cancel, False, False, 0)
        elif verdict == "ok":
            note.set_text(_("The key is already enrolled and the driver loads. Nothing to do.")
                          if sb == "enabled" else
                          _("Secure Boot is disabled on this computer; no key enrolment is needed."))
            self.body.pack_start(note, False, False, 0)
        elif verdict == "no-module":
            note.set_text(_("The NVIDIA driver module has not been built yet. Install the driver first "
                            "(Control Panel → Drivers), then come back here."))
            self.body.pack_start(note, False, False, 0)
        else:
            note.set_text(_("No NVIDIA driver package is installed; this tool is only needed for the proprietary NVIDIA driver."))
            self.body.pack_start(note, False, False, 0)
        self.body.show_all()
        return False

    def _render_enrol_form(self, st):
        head = Gtk.Label(label=_("Secure Boot is enabled and the NVIDIA driver is blocked."))
        head.get_style_context().add_class("status-warn")
        head.set_halign(Gtk.Align.START); head.set_xalign(0); head.set_line_wrap(True)
        self.body.pack_start(head, False, False, 0)
        expl = Gtk.Label(label=_(
            "The kernel only loads driver modules signed with a key the firmware trusts. "
            "NawaOS signs the NVIDIA module automatically; the key just has to be enrolled once."))
        expl.set_line_wrap(True); expl.set_xalign(0)
        self.body.pack_start(expl, False, False, 0)
        hint = Gtk.Label(label=_(
            "Choose a one-time password (8–16 characters). You will type it once more "
            "on the blue MOK Manager screen after the reboot."))
        hint.set_line_wrap(True); hint.set_xalign(0)
        self.body.pack_start(hint, False, False, 0)

        grid = Gtk.Grid(column_spacing=10, row_spacing=8)
        self.pw1 = Gtk.Entry(); self.pw1.set_visibility(False); self.pw1.set_max_length(16)
        self.pw2 = Gtk.Entry(); self.pw2.set_visibility(False); self.pw2.set_max_length(16)
        for row, (label, entry) in enumerate(((_("Password"), self.pw1), (_("Confirm password"), self.pw2))):
            lab = Gtk.Label(label=label); lab.set_halign(Gtk.Align.START)
            grid.attach(lab, 0, row, 1, 1)
            entry.set_hexpand(True)
            grid.attach(entry, 1, row, 1, 1)
        self.body.pack_start(grid, False, False, 0)

        self.error_label = Gtk.Label(); self.error_label.set_xalign(0)
        self.error_label.get_style_context().add_class("status-err")
        self.body.pack_start(self.error_label, False, False, 0)

        self.enrol_btn = Gtk.Button(label=_("Enrol key"))
        self.enrol_btn.get_style_context().add_class("suggested-action")
        self.enrol_btn.connect("clicked", self.on_enrol, st)
        self.body.pack_start(self.enrol_btn, False, False, 0)
        self.body.show_all()

    def _render_reboot_steps(self):
        steps = Gtk.Label(label=_(
            "1. A blue screen titled “Perform MOK management” appears.\n"
            "2. Choose “Enroll MOK”, then “Continue”, then “Yes”.\n"
            "3. Enter the password you just chose.\n"
            "4. Choose “Reboot”. The NVIDIA driver loads from then on."))
        steps.set_xalign(0); steps.set_line_wrap(True)
        self.body.pack_start(steps, False, False, 0)
        reboot = Gtk.Button(label=_("Reboot now"))
        reboot.connect("clicked", lambda *_a: subprocess.Popen(["systemctl", "reboot"]))
        self.body.pack_start(reboot, False, False, 0)

    # --------------------------------------------------------------- actions
    def on_enrol(self, _btn, st):
        pw1, pw2 = self.pw1.get_text(), self.pw2.get_text()
        if not 8 <= len(pw1) <= 16:
            self.error_label.set_text(_("The password must be 8 to 16 characters long.")); return
        if pw1 != pw2:
            self.error_label.set_text(_("The passwords do not match.")); return
        self.error_label.set_text("")
        self.enrol_btn.set_sensitive(False)
        self.spinner.start(); self.spinner.show()
        needs_regen = st.get("mok_key_machine_specific") != "yes"

        def worker():
            try:
                if needs_regen:
                    GLib.idle_add(self.status_label.set_text,
                                  _("Making the signing key specific to this computer… (a few minutes)"))
                    r = subprocess.run(["pkexec", HELPER, "regen-key"], capture_output=True, text=True, timeout=1800)
                    # Anything but 0 is a failure. Exit 2 used to be accepted,
                    # and it meant the image-wide key (whose private half is
                    # in every NawaOS ISO) was still in place -- enrolling it
                    # would let anyone sign modules this firmware trusts.
                    if r.returncode != 0:
                        detail = (r.stderr or r.stdout).strip()[-300:]
                        raise RuntimeError("%s\n%s" % (_(
                            "The signing key could not be made specific to this computer, "
                            "so nothing was enrolled. The shared NawaOS image key is never enrolled."),
                            detail))
                GLib.idle_add(self.status_label.set_text, _("Queuing the enrolment…"))
                r = subprocess.run(["pkexec", HELPER, "import"], input="%s\n%s\n" % (pw1, pw2),
                                   capture_output=True, text=True, timeout=300)
                if r.returncode != 0:
                    raise RuntimeError((r.stderr or r.stdout).strip()[-300:])
                GLib.idle_add(self.on_enrol_done, None)
            except Exception as exc:  # noqa: BLE001
                GLib.idle_add(self.on_enrol_done, str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def on_enrol_done(self, error):
        self.spinner.stop(); self.spinner.hide()
        if error:
            self.enrol_btn.set_sensitive(True)
            self.error_label.set_text(_("Failed: %s") % error)
            return False
        self._clear_body()
        done = Gtk.Label(label=_("Enrolment queued. On the next reboot:"))
        done.get_style_context().add_class("status-ok"); done.set_xalign(0)
        self.body.pack_start(done, False, False, 0)
        self._render_reboot_steps()
        self.body.show_all()
        return False

    def on_cancel(self, _btn):
        try:
            subprocess.run(["pkexec", HELPER, "cancel"], capture_output=True, text=True, timeout=120)
        except (OSError, subprocess.SubprocessError):
            pass
        self.status_label.set_text(_("Cancelled."))
        self.refresh()


def main():
    win = EnrolWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
