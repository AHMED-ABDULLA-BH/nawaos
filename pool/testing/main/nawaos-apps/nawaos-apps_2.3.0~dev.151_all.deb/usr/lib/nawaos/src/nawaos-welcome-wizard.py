#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Welcome Wizard — first-login setup for NawaOS 2.0

A polished, fully bilingual (Arabic/English) first-boot wizard shown on the
first login of a fresh install. It lets the user:

  1. Pick a language (applies immediately in the wizard, session-wide on the
     next login via ~/.config/environment.d/50-nawaos-lang.conf).
  2. Review the detected GPU and optionally install the NVIDIA driver.
  3. Choose gaming platforms / emulators to install (Flatpak, installed in
     the background by /usr/local/bin/nawaos-gaming-setup after finish).
  4. On handheld devices only: enable Console Mode (Gamescope session) as
     the default boot target.
  5. Review a summary and opt IN (default: off) to the anonymous install
     census (version number only).

On finish it writes ~/.config/nawaos/setup-selection.json, creates
~/.config/nawaos/wizard-done, removes its own autostart entry and launches
the gaming-setup installer detached. Every failure path is logged to
~/.local/share/nawaos/wizard.log and the wizard always exits cleanly — a
broken wizard must never block login.

Deployed to /usr/lib/nawaos/src/ next to the nawaos-common modules
(nawaos_i18n.py, nawaos_theme.py, nawaos_handheld.py).

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import traceback

# The wizard is deployed flat into /usr/lib/nawaos/src together with the
# shared nawaos-common modules; make both the script directory and the
# system location importable (the latter helps ad-hoc dev runs).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
if os.path.isdir("/usr/lib/nawaos/src"):
    sys.path.insert(1, "/usr/lib/nawaos/src")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
HOME = os.path.expanduser("~")
CONFIG_DIR = os.path.join(HOME, ".config", "nawaos")
LANG_FILE = os.path.join(CONFIG_DIR, "language")
SELECTION_FILE = os.path.join(CONFIG_DIR, "setup-selection.json")
WIZARD_DONE_FILE = os.path.join(CONFIG_DIR, "wizard-done")
ENVD_DIR = os.path.join(HOME, ".config", "environment.d")
ENVD_LANG_FILE = os.path.join(ENVD_DIR, "50-nawaos-lang.conf")
AUTOSTART_FILE = os.path.join(
    HOME, ".config", "autostart", "nawaos-welcome-wizard.desktop")
DMRC_FILE = os.path.join(HOME, ".dmrc")
LOG_DIR = os.path.join(HOME, ".local", "share", "nawaos")
LOG_FILE = os.path.join(LOG_DIR, "wizard.log")
LOGO_PATH = "/usr/share/pixmaps/nawaos-logo.png"
GAMING_SETUP = "/usr/local/bin/nawaos-gaming-setup"

log = logging.getLogger("nawaos-welcome-wizard")


def _setup_logging():
    """Log to ~/.local/share/nawaos/wizard.log; never raise."""
    handlers = []
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        handlers.append(logging.FileHandler(LOG_FILE, encoding="utf-8"))
    except OSError:
        pass
    handlers.append(logging.StreamHandler(sys.stderr))
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
    )


# ---------------------------------------------------------------------------
# GTK — guarded so a broken desktop stack can never block login
# ---------------------------------------------------------------------------
try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib, GdkPixbuf, Pango  # noqa: F401
except Exception as exc:  # pragma: no cover
    _setup_logging()
    log.error("GTK unavailable, wizard cannot run: %s", exc)
    sys.exit(0)

# Shared NawaOS modules (all optional — the wizard degrades gracefully).
try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

try:
    import nawaos_handheld
except ImportError:
    nawaos_handheld = None

try:
    import nawaos_i18n
except ImportError:
    nawaos_i18n = None

try:
    import nawaos_notify
except ImportError:
    nawaos_notify = None

try:
    import nawaos_taskrunner
except ImportError:
    nawaos_taskrunner = None


# ---------------------------------------------------------------------------
# Translations — complete built-in Arabic catalog
# ---------------------------------------------------------------------------
AR_TRANSLATIONS = {
    # Window / navigation
    "NawaOS Setup": "إعداد NawaOS",
    "Back": "رجوع",
    "Next": "التالي",
    "Skip": "تخطي",
    "Finish": "إنهاء",
    "Cancel": "إلغاء",
    "Step {} of {}": "الخطوة {} من {}",

    # Page 1 — Welcome + language
    "Welcome to NawaOS": "مرحباً بك في NawaOS",
    "The Ultimate Gaming Experience": "تجربة الألعاب المطلقة",
    "Choose your language": "اختر لغتك",
    "NawaOS tools switch right away. The rest of the desktop follows at "
    "your next login.":
        "تتبدّل أدوات NawaOS فوراً، ويتبعها بقية سطح المكتب عند تسجيل "
        "الدخول التالي.",
    "Apply to the whole desktop now": "طبّق على سطح المكتب كله الآن",
    "Signs you out and back in with the new language. Nothing has been set "
    "up yet, so nothing is lost.":
        "يسجّل خروجك ثم دخولك باللغة الجديدة. لم يُعدّ شيء بعد، فلن يضيع شيء.",
    "Setup has already been completed on this system. Running it again "
    "will replace your previous choices.":
        "اكتمل الإعداد مسبقاً على هذا النظام. إعادة تشغيله ستستبدل "
        "اختياراتك السابقة.",

    # Page 2 — GPU
    "Graphics Card": "بطاقة الرسوميات",
    "Let's check your graphics hardware.":
        "لنتحقق من عتاد الرسوميات لديك.",
    "Detecting your graphics hardware…":
        "جارٍ التعرف على عتاد الرسوميات…",
    "No graphics card information available.":
        "لا تتوفر معلومات عن بطاقة الرسوميات.",
    "Drivers included ✓": "التعريفات مضمّنة ✓",
    "AMD and Intel graphics drivers are already part of NawaOS — "
    "no action needed.":
        "تعريفات رسوميات AMD وIntel مضمّنة بالفعل في NawaOS — "
        "لا حاجة لأي إجراء.",
    "NVIDIA graphics detected.": "تم اكتشاف رسوميات NVIDIA.",
    "Recommended driver package: {}": "حزمة التعريف المُوصى بها: {}",
    "NVIDIA driver is already installed ✓":
        "تعريف NVIDIA مثبّت بالفعل ✓",
    "Install NVIDIA driver (recommended)":
        "تثبيت تعريف NVIDIA (مُوصى به)",
    "The driver will be installed when you finish this wizard. "
    "Administrator permission and an internet connection are required.":
        "سيتم تثبيت التعريف عند إنهاء هذا المعالج. يتطلب ذلك صلاحية "
        "المسؤول واتصالاً بالإنترنت.",
    "Installing NVIDIA driver… this may take several minutes.":
        "جارٍ تثبيت تعريف NVIDIA… قد يستغرق ذلك عدة دقائق.",
    "NVIDIA driver installed successfully ✓":
        "تم تثبيت تعريف NVIDIA بنجاح ✓",
    "NVIDIA driver installation failed. You can install it later from "
    "a terminal: sudo apt install nvidia-driver":
        "فشل تثبيت تعريف NVIDIA. يمكنك تثبيته لاحقاً من الطرفية: "
        "sudo apt install nvidia-driver",
    "No proprietary driver for this GPU. NVIDIA dropped GeForce GTX 900 / "
    "GTX 10 series and TITAN V from its Linux drivers; NawaOS uses the "
    "open-source nouveau driver for it, with OpenGL and Vulkan through Mesa.":
        "لا يوجد تعريف احتكاري لهذه البطاقة. أوقفت NVIDIA دعم GeForce GTX 900 / "
        "GTX 10 وTITAN V في تعريفات لينكس؛ يستخدم NawaOS لها تعريف nouveau "
        "مفتوح المصدر، ويعمل OpenGL وVulkan عبر Mesa.",

    # Page 3 — Gaming platforms
    "Gaming Platforms": "منصات الألعاب",
    "Choose the gaming apps to install:":
        "اختر تطبيقات الألعاب المراد تثبيتها:",
    "Launchers": "منصات التشغيل",
    "Emulators & Tools": "المحاكيات والأدوات",
    "Run Windows apps and games": "تشغيل تطبيقات وألعاب ويندوز",
    "Epic Games & GOG launcher": "منصة تشغيل Epic Games وGOG",
    "Manage Proton-GE compatibility tools":
        "إدارة أدوات التوافق Proton-GE",
    "Original Xbox emulator": "محاكي إكس بوكس الأصلي",
    "PlayStation 2 emulator": "محاكي بلايستيشن 2",
    "PlayStation 1 emulator": "محاكي بلايستيشن 1",
    "PSP emulator": "محاكي PSP",
    "Performance overlay manager (MangoHud)":
        "مدير عرض الأداء على الشاشة (MangoHud)",
    "Selected apps are installed in the background after you finish. "
    "An internet connection is required.":
        "تُثبَّت التطبيقات المحددة في الخلفية بعد الإنهاء. "
        "يتطلب ذلك اتصالاً بالإنترنت.",

    # Page 4 — Handheld
    "Handheld Mode": "وضع الأجهزة المحمولة",
    "Handheld device detected: {}": "تم اكتشاف جهاز محمول: {}",
    "Boot into Console Mode by default":
        "الإقلاع إلى وضع الكونسول افتراضياً",
    "Console Mode starts a full-screen, controller-friendly game "
    "interface (Gamescope). This takes effect from your next login.":
        "يبدأ وضع الكونسول واجهة ألعاب بملء الشاشة مناسبة ليد التحكم "
        "(Gamescope). يسري هذا اعتباراً من تسجيل الدخول التالي.",
    "You can switch between Desktop and Console Mode at any time from "
    "the login screen.":
        "يمكنك التبديل بين وضع سطح المكتب ووضع الكونسول في أي وقت من "
        "شاشة تسجيل الدخول.",

    # Page 5 — Summary
    "Summary": "الملخص",
    "Review your choices, then press Finish.":
        "راجع اختياراتك ثم اضغط إنهاء.",
    "Language": "اللغة",
    "Arabic": "العربية",
    "English": "الإنجليزية",
    "Apps to install": "التطبيقات المراد تثبيتها",
    "None": "لا شيء",
    "NVIDIA driver": "تعريف NVIDIA",
    "Will be installed": "سيتم تثبيته",
    "Console Mode by default": "وضع الكونسول افتراضياً",
    "Enabled": "مفعّل",
    "Disabled": "معطّل",
    "Help NawaOS by counting this install (sends only the version "
    "number, nothing else)":
        "ساعد NawaOS بإحصاء هذا التثبيت (يُرسل رقم الإصدار فقط، "
        "لا شيء آخر)",
    "You can change all of these later in the NawaOS Control Panel.":
        "يمكنك تغيير كل هذه الخيارات لاحقاً من لوحة تحكم NawaOS.",

    # Skip confirmation
    "Skip setup?": "تخطي الإعداد؟",
    "Default gaming apps will be installed in the background, and you "
    "can run this wizard again later from the menu (NawaOS Setup).":
        "سيتم تثبيت تطبيقات الألعاب الافتراضية في الخلفية، ويمكنك "
        "تشغيل هذا المعالج مرة أخرى لاحقاً من القائمة (إعداد NawaOS).",
    "Use defaults & skip": "استخدام الافتراضيات والتخطي",
    "Handheld image": "صورة الأجهزة المحمولة",

    # Page — Readiness check (2.1)
    "System check": "فحص النظام",
    "A quick look at the things that most often go wrong on a fresh install.":
        "نظرة سريعة على الأمور التي تتعطل غالباً بعد تثبيت جديد.",
    "Checking…": "جارٍ الفحص…",
    "Check again": "إعادة الفحص",
    "Network": "الشبكة",
    "Connected": "متصل",
    "Not connected": "غير متصل",
    "Open network settings": "فتح إعدادات الشبكة",
    "Fix Wi-Fi": "إصلاح Wi-Fi",
    "Audio": "الصوت",
    "Output device ready: {}": "جهاز الإخراج جاهز: {}",
    "No audio output device detected": "لم يُكتشف أي جهاز إخراج صوت",
    "Restart audio": "إعادة تشغيل الصوت",
    "Open sound settings": "فتح إعدادات الصوت",
    "Graphics driver": "تعريف الرسوميات",
    "NVIDIA driver loaded": "تعريف NVIDIA محمّل",
    "NVIDIA driver blocked by Secure Boot — enrol the signing key":
        "تعريف NVIDIA محجوب بسبب Secure Boot — سجّل مفتاح التوقيع",
    "NVIDIA driver module not built — install it from the Control Panel":
        "وحدة تعريف NVIDIA غير مبنية — ثبّتها من لوحة التحكم",
    "NVIDIA driver could not load — using the open-source driver":
        "تعذّر تحميل تعريف NVIDIA — يُستخدم التعريف المفتوح",
    "Open-source driver active ({})": "التعريف المفتوح نشط ({})",
    "Enrol key": "تسجيل المفتاح",
    "Open Control Panel": "فتح لوحة التحكم",
    "Secure Boot": "Secure Boot",
    "Not available (legacy BIOS)": "غير متاح (BIOS تقليدي)",
    "Disk space": "مساحة القرص",
    "{} GB free on the system disk": "{} غيغابايت متاحة على قرص النظام",
    "Live session — checked after installation": "جلسة حية — يُفحص بعد التثبيت",
    "Only {} GB free — games need room": "بقي {} غيغابايت فقط — الألعاب تحتاج مساحة",
    "Everything looks good.": "كل شيء على ما يرام.",
    "{} item(s) need attention.": "{} بند/بنود تحتاج انتباهاً.",
    "Setup complete": "اكتمل الإعداد",
    "System check: {}. Open NawaOS Setup from the menu to fix them.":
        "فحص النظام: {}. افتح إعداد NawaOS من القائمة لإصلاحها.",

    # -- 2.3: first-login summary -----------------------------------------------
    "System check: all good.": "فحص النظام: كل شيء سليم.",
    "System check: all good. The apps you selected download in the background over the internet, which can take a while; a notification reports the result.": "فحص النظام: كل شيء سليم. تُنزَّل التطبيقات التي اخترتها في الخلفية عبر الإنترنت وقد يستغرق ذلك بعض الوقت؛ سيُعلمك إشعار بالنتيجة.",
}


def _identity(msgid):
    return msgid


if nawaos_i18n is not None:
    nawaos_i18n.register("ar", AR_TRANSLATIONS)
    nawaos_i18n.init("nawaos-welcome-wizard")
    _ = nawaos_i18n.gettext
else:  # minimal shim — English-only, but the wizard still works
    _ = _identity


# ---------------------------------------------------------------------------
# Flatpak catalog: (app_id, display_name, description_msgid, default, group)
# ---------------------------------------------------------------------------
FLATPAK_APPS = [
    ("com.usebottles.bottles", "Bottles",
     "Run Windows apps and games", True, "launchers"),
    ("com.heroicgameslauncher.hgl", "Heroic Games Launcher",
     "Epic Games & GOG launcher", True, "launchers"),
    ("net.davidotek.pupgui2", "ProtonUp-Qt",
     "Manage Proton-GE compatibility tools", True, "launchers"),
    ("app.xemu.xemu", "xemu",
     "Original Xbox emulator", False, "emulators"),
    ("net.pcsx2.PCSX2", "PCSX2",
     "PlayStation 2 emulator", False, "emulators"),
    ("org.duckstation.DuckStation", "DuckStation",
     "PlayStation 1 emulator", False, "emulators"),
    ("org.ppsspp.PPSSPP", "PPSSPP",
     "PSP emulator", False, "emulators"),
    ("io.github.benjamimgois.goverlay", "GOverlay",
     "Performance overlay manager (MangoHud)", False, "emulators"),
]

# Session locale written for each wizard language: (LANG, LANGUAGE)
LOCALE_MAP = {
    "ar": ("ar_BH.UTF-8", "ar_BH:ar:en"),
    "en": ("en_US.UTF-8", "en_US:en"),
}


def _session_language():
    """Language the running desktop session was started with ('ar' or 'en')."""
    for var in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG"):
        val = (os.environ.get(var) or "").strip().lower()
        if val:
            return "ar" if val.startswith("ar") else "en"
    return "en"

APP_CSS = """
.wizard-hero-title { font-size: 26px; font-weight: 700; }
.wizard-hero-subtitle { font-size: 14px; color: #9AA7B8; }
.wizard-page-title { font-size: 20px; font-weight: 700; }
.wizard-page-subtitle { font-size: 13px; color: #9AA7B8; }
.wizard-lang-btn { font-size: 18px; font-weight: 700; padding: 18px 40px; }
.wizard-note { font-size: 12px; color: #9AA7B8; }
.wizard-group-title { font-size: 13px; font-weight: 700; color: #37BCE0; }
.wizard-summary-key { font-weight: 600; color: #9AA7B8; }
"""


# ---------------------------------------------------------------------------
# Small helpers (all failure-safe)
# ---------------------------------------------------------------------------
def _run(cmd, timeout=20):
    """Run a command, return (returncode, stdout_text). Never raises."""
    try:
        result = subprocess.run(
            cmd, capture_output=True, timeout=timeout)
        out = result.stdout.decode("utf-8", errors="replace")
        return result.returncode, out
    except (OSError, subprocess.SubprocessError):
        return -1, ""


def detect_gpus():
    """Parse lspci for display controllers. Returns a list of GPU names."""
    rc, out = _run(["lspci"])
    gpus = []
    if rc != 0:
        return gpus
    for line in out.splitlines():
        low = line.lower()
        if ("vga compatible controller" in low
                or "3d controller" in low
                or "display controller" in low):
            # "01:00.0 VGA compatible controller: NVIDIA ... [rev a1]"
            parts = line.split(": ", 1)
            gpus.append(parts[1].strip() if len(parts) == 2 else line.strip())
    return gpus


NVIDIA_SUPPORT = "/usr/local/bin/nawaos-nvidia-support"
NVIDIA_PACKAGES = "nvidia-driver nvidia-kernel-open-dkms nvidia-driver-libs:i386"


def nvidia_support():
    """(status, packages) from nawaos-nvidia-support.

    2.2: the driver comes from NVIDIA's repository (595 branch), which covers
    Turing and newer; "legacy" means a GTX 900 / GTX 10 / TITAN V class GPU
    that has no proprietary driver any more. ("unknown", default packages)
    when the helper is missing, so the wizard still offers the install.
    """
    if not os.path.exists(NVIDIA_SUPPORT):
        return "unknown", NVIDIA_PACKAGES
    rc, out = _run([NVIDIA_SUPPORT], timeout=30)
    if rc < 0:
        return "unknown", NVIDIA_PACKAGES
    info = {}
    for line in out.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            info[k.strip()] = v.strip()
    return info.get("status", "unknown"), info.get("package", NVIDIA_PACKAGES)


def package_installed(name):
    """True when the Debian package is in 'install ok installed' state."""
    rc, out = _run(["dpkg", "-s", name])
    return rc == 0 and "Status: install ok installed" in out


def run_readiness_checks():
    """The 2.1 first-boot readiness check: network, audio, graphics driver,
    Secure Boot, disk space. Returns a list of dicts
    {title, status: ok|warn|err|info, detail, fixes: [(label, argv[, root])]};
    a fix with root=True runs in the task dialog through pkexec.
    Every probe is failure-safe; a failing probe reports 'info'."""
    checks = []

    # --- Network -------------------------------------------------------
    rc, out = _run(["nmcli", "-t", "-f", "STATE", "general"])
    connected = rc == 0 and "connected" in out and "disconnected" not in out
    if not connected:
        # nmcli missing or NM down: fall back to a routed interface
        rc, out = _run(["ip", "-br", "addr"])
        connected = any(" UP " in line and "." in line
                        for line in out.splitlines() if not line.startswith("lo"))
    checks.append({
        "title": _("Network"),
        "status": "ok" if connected else "warn",
        "detail": _("Connected") if connected else _("Not connected"),
        "fixes": [] if connected else [
            (_("Open network settings"), ["cinnamon-settings", "network"]),
            (_("Fix Wi-Fi"), ["nawaos-wifi-fix"], True),
        ],
    })

    # --- Audio ---------------------------------------------------------
    sink = None
    rc, out = _run(["wpctl", "status"])
    if rc == 0:
        in_sinks = False
        for line in out.splitlines():
            if "Sinks:" in line:
                in_sinks = True
                continue
            if in_sinks:
                if "Sources:" in line or not line.strip(" │├─"):
                    break
                text = line.strip(" │├─*").strip()
                if "." in text:
                    sink = text.split(".", 1)[1].strip()
                    sink = sink.split("[")[0].strip()
                    break
    checks.append({
        "title": _("Audio"),
        "status": "ok" if sink else "warn",
        "detail": _("Output device ready: {}").format(sink) if sink
                  else _("No audio output device detected"),
        "fixes": [] if sink else [
            (_("Restart audio"), ["systemctl", "--user", "restart",
                                   "pipewire", "pipewire-pulse", "wireplumber"]),
            (_("Open sound settings"), ["cinnamon-settings", "sound"]),
        ],
    })

    # --- Graphics driver ----------------------------------------------
    fallback = ""
    try:
        with open("/run/nawaos/gpu-fallback", encoding="utf-8") as f:
            fallback = f.read().strip()
    except OSError:
        pass
    rc, lsmod = _run(["lsmod"])
    loaded = {line.split()[0] for line in lsmod.splitlines() if line.strip()}
    gpu_fixes = []
    if fallback == "nvidia" or "nvidia" in loaded:
        status, detail = "ok", _("NVIDIA driver loaded")
    elif fallback.startswith("secure-boot"):
        status, detail = "warn", _("NVIDIA driver blocked by Secure Boot — enrol the signing key")
        gpu_fixes = [(_("Enrol key"), ["nawaos-mok-enroll-gui"])]
    elif fallback.startswith("module-missing"):
        status, detail = "warn", _("NVIDIA driver module not built — install it from the Control Panel")
        gpu_fixes = [(_("Open Control Panel"), ["nawaos-control-panel"])]
    elif fallback.startswith("load-failed"):
        status, detail = "warn", _("NVIDIA driver could not load — using the open-source driver")
        gpu_fixes = [(_("Open Control Panel"), ["nawaos-control-panel"])]
    else:
        drv = next((d for d in ("amdgpu", "i915", "xe", "nouveau", "radeon",
                                 "virtio_gpu", "vmwgfx", "qxl", "bochs") if d in loaded), None)
        status = "ok" if drv else "info"
        detail = _("Open-source driver active ({})").format(drv) if drv else _("Drivers included ✓")
    checks.append({"title": _("Graphics driver"), "status": status,
                   "detail": detail, "fixes": gpu_fixes})

    # --- Secure Boot ---------------------------------------------------
    if os.path.isdir("/sys/firmware/efi") and shutil.which("mokutil"):
        rc, out = _run(["mokutil", "--sb-state"])
        sb = _("Enabled") if "enabled" in out.lower() else _("Disabled")
    else:
        sb = _("Not available (legacy BIOS)")
    checks.append({"title": _("Secure Boot"), "status": "info",
                   "detail": sb, "fixes": []})

    # --- Disk space ----------------------------------------------------
    # The live session runs on a RAM overlay, so free space there says
    # nothing about the machine; report it as such instead of a warning.
    live = False
    try:
        with open("/proc/cmdline", encoding="utf-8") as f:
            live = "boot=live" in f.read()
    except OSError:
        pass
    if live:
        checks.append({"title": _("Disk space"), "status": "info",
                       "detail": _("Live session — checked after installation"), "fixes": []})
        return checks
    try:
        st = os.statvfs("/")
        free_gb = st.f_bavail * st.f_frsize / (1024 ** 3)
        low = free_gb < 10
        checks.append({
            "title": _("Disk space"),
            "status": "warn" if low else "ok",
            "detail": (_("Only {} GB free — games need room") if low
                       else _("{} GB free on the system disk")).format(int(free_gb)),
            "fixes": [],
        })
    except OSError:
        pass

    return checks


def _atomic_write(path, content):
    """Write a small text file atomically; raises OSError on failure."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(content)
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Wizard window
# ---------------------------------------------------------------------------
class WelcomeWizard(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("NawaOS Setup"))
        self.set_default_size(760, 620)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_icon_name("preferences-system")
        self.connect("destroy", Gtk.main_quit)

        if nawaos_theme:
            try:
                nawaos_theme.apply_theme(self, APP_CSS)
            except Exception:
                log.warning("apply_theme failed:\n%s", traceback.format_exc())

        # ----- model state (survives full UI re-renders) -----
        self.state = {
            "language": (nawaos_i18n.get_language()
                         if nawaos_i18n else "en"),
            "flatpaks": {app_id: default
                         for app_id, _n, _d, default, _g in FLATPAK_APPS},
            "nvidia_install": False,
            "console_mode": False,
            "census": False,
        }
        self.rerun = os.path.exists(WIZARD_DONE_FILE)
        self.finishing = False

        # GPU probe results (filled asynchronously)
        self.gpu_ready = False
        self.gpu_names = []
        self.nvidia_pkg = None
        self.nvidia_installed = False
        self.nvidia_legacy = False
        self.nvidia_choice_made = False   # user touched the driver checkbox

        # Handheld detection (cheap, synchronous, guarded)
        self.is_handheld = False
        self.handheld_name = ""
        if nawaos_handheld:
            try:
                self.is_handheld, self.handheld_name, _prof = \
                    nawaos_handheld.detect()
            except Exception:
                log.warning("handheld detect failed:\n%s",
                            traceback.format_exc())
        # 2.1 handheld image: always offer Console Mode, on by default, even
        # when the device is not in the DMI table yet.
        self.build_variant = "full"
        try:
            with open("/etc/nawaos/build-variant", encoding="utf-8") as f:
                self.build_variant = f.read().strip() or "full"
        except OSError:
            pass
        if self.build_variant == "handheld":
            if not self.is_handheld:
                self.is_handheld = True
                self.handheld_name = self.handheld_name or _("Handheld image")
            if not self.rerun:
                self.state["console_mode"] = True

        self.page_names = self._page_list()
        self.current = 0

        if nawaos_i18n and nawaos_i18n.is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)

        self.readiness = None          # list of check dicts, None = not probed
        self.readiness_card = None
        self._build_ui()
        threading.Thread(target=self._probe_gpu_thread, daemon=True).start()
        threading.Thread(target=self._probe_readiness_thread, daemon=True).start()

    # ------------------------------------------------------------------
    # Page plumbing
    # ------------------------------------------------------------------
    def _page_list(self):
        pages = ["welcome", "gpu", "readiness", "platforms"]
        if self.is_handheld:
            pages.append("handheld")
        pages.append("summary")
        return pages

    def _build_ui(self):
        """(Re)build the whole UI from self.state — used on language switch."""
        old = self.get_child()
        if old is not None:
            self.remove(old)
            old.destroy()

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(outer)

        # Header: step indicator
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        header.get_style_context().add_class("toolbar")
        header.set_margin_top(0)
        self.step_label = Gtk.Label(label="")
        self.step_label.get_style_context().add_class("wizard-note")
        self.step_label.set_margin_start(12)
        self.step_label.set_margin_end(12)
        self.step_label.set_margin_top(8)
        self.step_label.set_margin_bottom(8)
        header.pack_start(self.step_label, False, False, 0)
        outer.pack_start(header, False, False, 0)

        # Content stack
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(
            Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(200)
        outer.pack_start(self.stack, True, True, 0)

        builders = {
            "welcome": self._build_welcome_page,
            "gpu": self._build_gpu_page,
            "readiness": self._build_readiness_page,
            "platforms": self._build_platforms_page,
            "handheld": self._build_handheld_page,
            "summary": self._build_summary_page,
        }
        for name in self.page_names:
            self.stack.add_named(builders[name](), name)

        # Bottom navigation bar
        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        nav.set_margin_start(16)
        nav.set_margin_end(16)
        nav.set_margin_top(10)
        nav.set_margin_bottom(14)

        self.back_btn = Gtk.Button(label=_("Back"))
        self.back_btn.get_style_context().add_class("action-btn")
        self.back_btn.connect("clicked", self._on_back)
        nav.pack_start(self.back_btn, False, False, 0)

        self.skip_btn = Gtk.Button(label=_("Skip"))
        self.skip_btn.get_style_context().add_class("action-btn")
        self.skip_btn.connect("clicked", self._on_skip)
        nav.pack_start(self.skip_btn, False, False, 0)

        self.next_btn = Gtk.Button(label=_("Next"))
        self.next_btn.get_style_context().add_class("action-btn-primary")
        self.next_btn.connect("clicked", self._on_next)
        nav.pack_end(self.next_btn, False, False, 0)

        outer.pack_end(nav, False, False, 0)
        self._show_page(self.current)
        self.show_all()

    def _on_back(self, _btn):
        self._show_page(self.current - 1)

    def _on_next(self, _btn):
        if self.current == len(self.page_names) - 1:
            self._start_finish()
        else:
            self._show_page(self.current + 1)

    # ------------------------------------------------------------------
    # Language handling
    # ------------------------------------------------------------------
    def _on_language_chosen(self, _btn, code):
        self.state["language"] = code
        self._persist_language(code)
        if nawaos_i18n:
            nawaos_i18n.set_language(code)
            global _
            _ = nawaos_i18n.gettext
        Gtk.Widget.set_default_direction(
            Gtk.TextDirection.RTL if code == "ar" else Gtk.TextDirection.LTR)
        self.set_title(_("NawaOS Setup"))
        self._build_ui()  # full re-render in the new language/direction

    def _on_apply_language_now(self, _btn):
        """Restart the desktop session so Cinnamon itself picks up the language.

        Safe on the first page: the choice is already on disk and the wizard's
        autostart entry is still in place, so it reopens after login. On the
        live session and on first boot the login is automatic.
        """
        self._persist_language(self.state["language"])
        attempts = [
            ["cinnamon-session-quit", "--logout", "--no-prompt"],
            ["cinnamon-session-quit", "--logout", "--force"],
        ]
        session_id = os.environ.get("XDG_SESSION_ID", "")
        if session_id:
            attempts.append(["loginctl", "terminate-session", session_id])
        for cmd in attempts:
            try:
                rc = subprocess.run(
                    cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    timeout=15).returncode
            except (OSError, subprocess.TimeoutExpired):
                continue
            if rc == 0:
                log.info("session restart requested via %s", " ".join(cmd))
                return
        log.warning("could not restart the session; the language applies "
                    "at the next login")

    def _persist_language(self, code):
        """Write the NawaOS language choice + session environment locale."""
        try:
            _atomic_write(LANG_FILE, code + "\n")
        except OSError:
            log.warning("could not write %s:\n%s", LANG_FILE,
                        traceback.format_exc())
        lang, language = LOCALE_MAP.get(code, LOCALE_MAP["en"])
        content = (
            "# Written by the NawaOS Welcome Wizard — applies on next login\n"
            "LANG=%s\nLANGUAGE=%s\n" % (lang, language))
        try:
            _atomic_write(ENVD_LANG_FILE, content)
        except OSError:
            log.warning("could not write %s:\n%s", ENVD_LANG_FILE,
                        traceback.format_exc())
        # LightDM reads ~/.dmrc as well, so the greeter starts the next
        # session in the chosen language regardless of environment.d.
        self._write_dmrc_language(lang)

    def _write_dmrc_language(self, lang):
        """Set Language= under [Desktop] in ~/.dmrc, keeping other keys."""
        try:
            with open(DMRC_FILE, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
        except OSError:
            lines = []
        out = []
        section_at = None
        wrote = False
        for line in lines:
            if line.strip() == "[Desktop]":
                section_at = len(out)
            if section_at is not None and line.strip().startswith("Language="):
                if not wrote:
                    out.append("Language=%s" % lang)
                    wrote = True
                continue
            out.append(line)
        if section_at is None:
            out.insert(0, "[Desktop]")
            section_at = 0
        if not wrote:
            out.insert(section_at + 1, "Language=%s" % lang)
        try:
            _atomic_write(DMRC_FILE, "\n".join(out) + "\n")
        except OSError:
            log.warning("could not write %s:\n%s", DMRC_FILE,
                        traceback.format_exc())

    def _dmrc_session(self):
        """Session= from ~/.dmrc ('' when unset)."""
        try:
            with open(DMRC_FILE, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip().startswith("Session="):
                        return line.strip().split("=", 1)[1]
        except OSError:
            pass
        return ""

    def _write_dmrc_session(self, session):
        """Write ~/.dmrc like nawaos-session-select: Session= plus the
        chosen Language=, and the console-session marker the tools read."""
        lang_code, _language = LOCALE_MAP.get(
            self.state["language"], LOCALE_MAP["en"])
        marker = os.path.join(CONFIG_DIR, "console-session")
        try:
            _atomic_write(DMRC_FILE, "[Desktop]\nSession=%s\nLanguage=%s\n"
                          % (session, lang_code))
            if session.startswith("nawaos-gamescope"):
                _atomic_write(marker, session + "\n")
            elif os.path.exists(marker):
                os.remove(marker)
        except OSError:
            log.error("could not write %s:\n%s", DMRC_FILE,
                      traceback.format_exc())

    # ------------------------------------------------------------------
    # Page 1: Welcome + language
    # ------------------------------------------------------------------
    def _page_box(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        box.set_margin_top(28)
        box.set_margin_bottom(16)
        box.set_margin_start(40)
        box.set_margin_end(40)
        return box

    def _build_welcome_page(self):
        box = self._page_box()
        box.set_valign(Gtk.Align.CENTER)

        if os.path.exists(LOGO_PATH):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    LOGO_PATH, 128, 128, True)
                box.pack_start(Gtk.Image.new_from_pixbuf(pixbuf),
                               False, False, 0)
            except Exception:
                log.warning("could not load logo:\n%s",
                            traceback.format_exc())

        title = Gtk.Label(label=_("Welcome to NawaOS"))
        title.get_style_context().add_class("wizard-hero-title")
        box.pack_start(title, False, False, 0)

        subtitle = Gtk.Label(label=_("The Ultimate Gaming Experience"))
        subtitle.get_style_context().add_class("wizard-hero-subtitle")
        box.pack_start(subtitle, False, False, 0)

        if self.rerun:
            note = Gtk.Label(label=_(
                "Setup has already been completed on this system. Running "
                "it again will replace your previous choices."))
            note.set_line_wrap(True)
            note.set_justify(Gtk.Justification.CENTER)
            note.get_style_context().add_class("status-warn")
            box.pack_start(note, False, False, 4)

        choose = Gtk.Label(label=_("Choose your language"))
        choose.get_style_context().add_class("wizard-page-subtitle")
        choose.set_margin_top(16)
        box.pack_start(choose, False, False, 0)

        lang_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        lang_row.set_halign(Gtk.Align.CENTER)
        # Native names on purpose: each reader must recognise their own.
        for code, label in (("en", "English"), ("ar", "العربية")):
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("wizard-lang-btn")
            if self.state["language"] == code:
                btn.get_style_context().add_class("action-btn-primary")
            else:
                btn.get_style_context().add_class("action-btn")
            btn.connect("clicked", self._on_language_chosen, code)
            lang_row.pack_start(btn, False, False, 0)
        box.pack_start(lang_row, False, False, 8)

        note = Gtk.Label(label=_(
            "NawaOS tools switch right away. The rest of the desktop "
            "follows at your next login."))
        note.get_style_context().add_class("wizard-note")
        box.pack_start(note, False, False, 0)

        # Offer an immediate restart only when the running session is in a
        # different language than the one just chosen.
        if self.state["language"] != _session_language():
            apply_btn = Gtk.Button(label=_("Apply to the whole desktop now"))
            apply_btn.get_style_context().add_class("action-btn")
            apply_btn.set_halign(Gtk.Align.CENTER)
            apply_btn.set_tooltip_text(_(
                "Signs you out and back in with the new language. Nothing "
                "has been set up yet, so nothing is lost."))
            apply_btn.connect("clicked", self._on_apply_language_now)
            box.pack_start(apply_btn, False, False, 4)
        return box

    # ------------------------------------------------------------------
    # Page 2: GPU
    # ------------------------------------------------------------------
    def _build_gpu_page(self):
        box = self._page_box()

        title = Gtk.Label(label=_("Graphics Card"), xalign=0)
        title.get_style_context().add_class("wizard-page-title")
        box.pack_start(title, False, False, 0)

        subtitle = Gtk.Label(
            label=_("Let's check your graphics hardware."), xalign=0)
        subtitle.get_style_context().add_class("wizard-page-subtitle")
        box.pack_start(subtitle, False, False, 0)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.get_style_context().add_class("card")
        card.set_margin_top(10)
        box.pack_start(card, False, False, 0)
        self.gpu_card = card
        self._populate_gpu_card()
        return box

    def _populate_gpu_card(self):
        for child in self.gpu_card.get_children():
            self.gpu_card.remove(child)

        if not self.gpu_ready:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            spinner = Gtk.Spinner()
            spinner.start()
            row.pack_start(spinner, False, False, 0)
            row.pack_start(Gtk.Label(
                label=_("Detecting your graphics hardware…"), xalign=0),
                False, False, 0)
            self.gpu_card.pack_start(row, False, False, 0)
            self.gpu_card.show_all()
            return

        if self.gpu_names:
            for name in self.gpu_names:
                lbl = Gtk.Label(label=name, xalign=0)
                lbl.set_line_wrap(True)
                lbl.get_style_context().add_class("card-title")
                self.gpu_card.pack_start(lbl, False, False, 0)
        else:
            self.gpu_card.pack_start(Gtk.Label(
                label=_("No graphics card information available."), xalign=0),
                False, False, 0)

        has_nvidia = any("nvidia" in n.lower() for n in self.gpu_names)

        if has_nvidia:
            nv = Gtk.Label(label=_("NVIDIA graphics detected."), xalign=0)
            nv.get_style_context().add_class("card-subtitle")
            self.gpu_card.pack_start(nv, False, False, 0)

            if self.nvidia_installed:
                ok = Gtk.Label(
                    label=_("NVIDIA driver is already installed ✓"), xalign=0)
                ok.get_style_context().add_class("status-ok")
                self.gpu_card.pack_start(ok, False, False, 0)
            elif self.nvidia_legacy:
                note = Gtk.Label(label=_(
                    "No proprietary driver for this GPU. NVIDIA dropped GeForce GTX 900 / "
                    "GTX 10 series and TITAN V from its Linux drivers; NawaOS uses the "
                    "open-source nouveau driver for it, with OpenGL and Vulkan through Mesa."),
                    xalign=0)
                note.set_line_wrap(True)
                note.get_style_context().add_class("wizard-note")
                self.gpu_card.pack_start(note, False, False, 0)
            elif self.nvidia_pkg:
                rec = Gtk.Label(
                    label=_("Recommended driver package: {}").format(
                        self.nvidia_pkg),
                    xalign=0)
                rec.get_style_context().add_class("card-subtitle")
                self.gpu_card.pack_start(rec, False, False, 0)

                check = Gtk.CheckButton(
                    label=_("Install NVIDIA driver (recommended)"))
                check.set_active(self.state["nvidia_install"])
                check.connect("toggled", self._on_nvidia_toggled)
                self.gpu_card.pack_start(check, False, False, 4)

                note = Gtk.Label(label=_(
                    "The driver will be installed when you finish this "
                    "wizard. Administrator permission and an internet "
                    "connection are required."), xalign=0)
                note.set_line_wrap(True)
                note.get_style_context().add_class("wizard-note")
                self.gpu_card.pack_start(note, False, False, 0)
        else:
            ok = Gtk.Label(label=_("Drivers included ✓"), xalign=0)
            ok.get_style_context().add_class("status-ok")
            self.gpu_card.pack_start(ok, False, False, 4)
            note = Gtk.Label(label=_(
                "AMD and Intel graphics drivers are already part of "
                "NawaOS — no action needed."), xalign=0)
            note.set_line_wrap(True)
            note.get_style_context().add_class("card-subtitle")
            self.gpu_card.pack_start(note, False, False, 0)

        self.gpu_card.show_all()

    def _on_nvidia_toggled(self, check):
        self.state["nvidia_install"] = check.get_active()
        self.nvidia_choice_made = True

    def _probe_gpu_thread(self):
        """Background hardware probe; results applied on the main loop."""
        try:
            gpus = detect_gpus()
            nvidia_pkg = None
            nvidia_installed = False
            nvidia_legacy = False
            nvidia_supported = False
            if any("nvidia" in n.lower() for n in gpus):
                status, packages = nvidia_support()
                nvidia_legacy = status == "legacy"
                nvidia_supported = status == "supported"
                nvidia_pkg = None if nvidia_legacy else packages
                nvidia_installed = package_installed("nvidia-driver")
        except Exception:
            log.warning("GPU probe failed:\n%s", traceback.format_exc())
            gpus, nvidia_pkg, nvidia_installed, nvidia_legacy = [], None, False, False
            nvidia_supported = False

        def apply_results():
            self.gpu_names = gpus
            self.nvidia_pkg = nvidia_pkg
            self.nvidia_installed = nvidia_installed
            self.nvidia_legacy = nvidia_legacy
            # Recommended means checked: a GPU the 595 driver supports
            # (nawaos-nvidia-support says "supported") and no driver yet.
            if (nvidia_supported and not nvidia_installed
                    and not self.nvidia_choice_made):
                self.state["nvidia_install"] = True
            self.gpu_ready = True
            try:
                self._populate_gpu_card()
            except Exception:
                log.warning("GPU card update failed:\n%s",
                            traceback.format_exc())
            return False

        GLib.idle_add(apply_results)

    # ------------------------------------------------------------------
    # Page: System readiness check (2.1)
    # ------------------------------------------------------------------
    def _build_readiness_page(self):
        box = self._page_box()

        title = Gtk.Label(label=_("System check"), xalign=0)
        title.get_style_context().add_class("wizard-page-title")
        box.pack_start(title, False, False, 0)

        subtitle = Gtk.Label(label=_(
            "A quick look at the things that most often go wrong on a "
            "fresh install."), xalign=0)
        subtitle.get_style_context().add_class("wizard-page-subtitle")
        box.pack_start(subtitle, False, False, 0)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.get_style_context().add_class("card")
        card.set_margin_top(10)
        box.pack_start(card, False, False, 0)
        self.readiness_card = card

        again = Gtk.Button(label=_("Check again"))
        again.set_halign(Gtk.Align.START)
        again.connect("clicked", self._on_readiness_recheck)
        box.pack_start(again, False, False, 4)

        self._populate_readiness_card()
        return box

    def _on_readiness_recheck(self, _btn):
        self.readiness = None
        self._populate_readiness_card()
        threading.Thread(target=self._probe_readiness_thread,
                         daemon=True).start()

    def _populate_readiness_card(self):
        card = self.readiness_card
        if card is None:
            return
        for child in card.get_children():
            card.remove(child)

        if self.readiness is None:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            spinner = Gtk.Spinner()
            spinner.start()
            row.pack_start(spinner, False, False, 0)
            row.pack_start(Gtk.Label(label=_("Checking…"), xalign=0),
                           False, False, 0)
            card.pack_start(row, False, False, 0)
            card.show_all()
            return

        icons = {"ok": "✓", "warn": "⚠", "err": "✗", "info": "•"}
        classes = {"ok": "status-ok", "warn": "status-warn",
                   "err": "status-err", "info": "card-subtitle"}
        for chk in self.readiness:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            name = Gtk.Label(label=chk["title"], xalign=0)
            name.get_style_context().add_class("card-title")
            name.set_size_request(150, -1)
            row.pack_start(name, False, False, 0)
            detail = Gtk.Label(
                label="%s %s" % (icons.get(chk["status"], "•"), chk["detail"]),
                xalign=0)
            detail.set_line_wrap(True)
            detail.get_style_context().add_class(
                classes.get(chk["status"], "card-subtitle"))
            row.pack_start(detail, True, True, 0)
            for fix in chk.get("fixes", []):
                btn = Gtk.Button(label=fix[0])
                btn.connect("clicked", self._on_readiness_fix, fix)
                row.pack_end(btn, False, False, 0)
            card.pack_start(row, False, False, 0)

        problems = [c for c in self.readiness if c["status"] in ("warn", "err")]
        summary = Gtk.Label(xalign=0)
        if problems:
            summary.set_text(_("{} item(s) need attention.").format(len(problems)))
            summary.get_style_context().add_class("status-warn")
        else:
            summary.set_text(_("Everything looks good."))
            summary.get_style_context().add_class("status-ok")
        summary.set_margin_top(6)
        card.pack_start(summary, False, False, 0)
        card.show_all()

    def _on_readiness_fix(self, _btn, fix):
        label, argv = fix[0], list(fix[1])
        root = len(fix) > 2 and fix[2]
        if root and nawaos_taskrunner is not None:
            # Same in-app task dialog as the Control Panel's "Fix Wi-Fi":
            # pkexec, live output, an honest result; then check again.
            nawaos_taskrunner.run_task(
                self, label, argv, root=True, category="system",
                source=_("NawaOS Setup"),
                on_done=lambda *_a: GLib.idle_add(self._on_readiness_recheck, None))
            return
        if root:
            argv = ["pkexec"] + argv
        try:
            subprocess.Popen(argv, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                             start_new_session=True)
        except OSError:
            log.warning("could not launch %s:\n%s", argv, traceback.format_exc())

    def _probe_readiness_thread(self):
        """Run the readiness checks off the main loop."""
        try:
            checks = run_readiness_checks()
        except Exception:
            log.warning("readiness probe failed:\n%s", traceback.format_exc())
            checks = []

        def apply_results():
            self.readiness = checks
            try:
                self._populate_readiness_card()
            except Exception:
                log.warning("readiness card update failed:\n%s",
                            traceback.format_exc())
            return False

        GLib.idle_add(apply_results)

    def readiness_summary_text(self):
        """One line for the first-login notification (may be None)."""
        if not self.readiness:
            return None
        problems = [c["title"] for c in self.readiness
                    if c["status"] in ("warn", "err")]
        if not problems:
            # The apps are not installed yet: nawaos-gaming-setup downloads
            # them after the wizard closes, and only with a connection.
            if any(self.state["flatpaks"].values()):
                return _("System check: all good. The apps you selected download "
                         "in the background over the internet, which can take a "
                         "while; a notification reports the result.")
            return _("System check: all good.")
        return _("System check: {}. Open NawaOS Setup from the menu to fix "
                 "them.").format(", ".join(problems))

    # ------------------------------------------------------------------
    # Page 3: Gaming platforms
    # ------------------------------------------------------------------
    def _build_platforms_page(self):
        box = self._page_box()

        title = Gtk.Label(label=_("Gaming Platforms"), xalign=0)
        title.get_style_context().add_class("wizard-page-title")
        box.pack_start(title, False, False, 0)

        subtitle = Gtk.Label(
            label=_("Choose the gaming apps to install:"), xalign=0)
        subtitle.get_style_context().add_class("wizard-page-subtitle")
        box.pack_start(subtitle, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        box.pack_start(scroller, True, True, 0)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        scroller.add(inner)

        groups = (("launchers", _("Launchers")),
                  ("emulators", _("Emulators & Tools")))
        for group_key, group_title in groups:
            head = Gtk.Label(label=group_title, xalign=0)
            head.get_style_context().add_class("wizard-group-title")
            head.set_margin_top(8)
            inner.pack_start(head, False, False, 0)

            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            card.get_style_context().add_class("card")
            inner.pack_start(card, False, False, 0)

            for app_id, name, desc, _default, group in FLATPAK_APPS:
                if group != group_key:
                    continue
                check = Gtk.CheckButton()
                row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
                name_lbl = Gtk.Label(label=name, xalign=0)
                name_lbl.get_style_context().add_class("card-title")
                desc_lbl = Gtk.Label(label=_(desc), xalign=0)
                desc_lbl.get_style_context().add_class("card-subtitle")
                row.pack_start(name_lbl, False, False, 0)
                row.pack_start(desc_lbl, False, False, 0)
                check.add(row)
                check.set_active(self.state["flatpaks"].get(app_id, False))
                check.connect("toggled", self._on_flatpak_toggled, app_id)
                card.pack_start(check, False, False, 2)

        note = Gtk.Label(label=_(
            "Selected apps are installed in the background after you "
            "finish. An internet connection is required."), xalign=0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("wizard-note")
        box.pack_start(note, False, False, 0)
        return box

    def _on_flatpak_toggled(self, check, app_id):
        self.state["flatpaks"][app_id] = check.get_active()

    # ------------------------------------------------------------------
    # Page 4: Handheld (only on detected handheld devices)
    # ------------------------------------------------------------------
    def _build_handheld_page(self):
        box = self._page_box()

        title = Gtk.Label(label=_("Handheld Mode"), xalign=0)
        title.get_style_context().add_class("wizard-page-title")
        box.pack_start(title, False, False, 0)

        subtitle = Gtk.Label(
            label=_("Handheld device detected: {}").format(
                self.handheld_name),
            xalign=0)
        subtitle.get_style_context().add_class("wizard-page-subtitle")
        box.pack_start(subtitle, False, False, 0)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.get_style_context().add_class("card")
        card.set_margin_top(10)
        box.pack_start(card, False, False, 0)

        toggle_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                             spacing=12)
        toggle_lbl = Gtk.Label(
            label=_("Boot into Console Mode by default"), xalign=0)
        toggle_lbl.get_style_context().add_class("card-title")
        toggle_row.pack_start(toggle_lbl, True, True, 0)
        switch = Gtk.Switch()
        switch.set_active(self.state["console_mode"])
        switch.connect("notify::active", self._on_console_toggled)
        switch.set_valign(Gtk.Align.CENTER)
        toggle_row.pack_end(switch, False, False, 0)
        card.pack_start(toggle_row, False, False, 0)

        desc = Gtk.Label(label=_(
            "Console Mode starts a full-screen, controller-friendly game "
            "interface (Gamescope). This takes effect from your next "
            "login."), xalign=0)
        desc.set_line_wrap(True)
        desc.get_style_context().add_class("card-subtitle")
        card.pack_start(desc, False, False, 0)

        note = Gtk.Label(label=_(
            "You can switch between Desktop and Console Mode at any time "
            "from the login screen."), xalign=0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("wizard-note")
        box.pack_start(note, False, False, 0)
        return box

    def _on_console_toggled(self, switch, _pspec):
        self.state["console_mode"] = switch.get_active()

    # ------------------------------------------------------------------
    # Page 5: Summary + Finish
    # ------------------------------------------------------------------
    def _build_summary_page(self):
        box = self._page_box()

        title = Gtk.Label(label=_("Summary"), xalign=0)
        title.get_style_context().add_class("wizard-page-title")
        box.pack_start(title, False, False, 0)

        subtitle = Gtk.Label(
            label=_("Review your choices, then press Finish."), xalign=0)
        subtitle.get_style_context().add_class("wizard-page-subtitle")
        box.pack_start(subtitle, False, False, 0)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.get_style_context().add_class("card")
        card.set_margin_top(10)
        box.pack_start(card, False, False, 0)
        self.summary_card = card
        self._populate_summary_card()

        census = Gtk.CheckButton(label=_(
            "Help NawaOS by counting this install (sends only the version "
            "number, nothing else)"))
        # Privacy: strictly opt-in — default is unchecked.
        census.set_active(self.state["census"])
        census.get_child().set_line_wrap(True)
        census.connect("toggled", self._on_census_toggled)
        census.set_margin_top(8)
        box.pack_start(census, False, False, 0)

        note = Gtk.Label(label=_(
            "You can change all of these later in the NawaOS Control "
            "Panel."), xalign=0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("wizard-note")
        box.pack_start(note, False, False, 0)

        # NVIDIA install progress area (used during finish)
        progress = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.finish_spinner = Gtk.Spinner()
        progress.pack_start(self.finish_spinner, False, False, 0)
        self.finish_status = Gtk.Label(label="", xalign=0)
        self.finish_status.set_line_wrap(True)
        progress.pack_start(self.finish_status, True, True, 0)
        box.pack_end(progress, False, False, 0)
        return box

    def _summary_rows(self):
        lang_name = _("Arabic") if self.state["language"] == "ar" \
            else _("English")
        selected = [name for app_id, name, _d, _def, _g in FLATPAK_APPS
                    if self.state["flatpaks"].get(app_id)]
        rows = [
            (_("Language"), lang_name),
            (_("Apps to install"),
             ", ".join(selected) if selected else _("None")),
        ]
        if self.state["nvidia_install"]:
            rows.append((_("NVIDIA driver"), _("Will be installed")))
        if self.is_handheld:
            rows.append((_("Console Mode by default"),
                         _("Enabled") if self.state["console_mode"]
                         else _("Disabled")))
        return rows

    def _populate_summary_card(self):
        for child in self.summary_card.get_children():
            self.summary_card.remove(child)
        for key, value in self._summary_rows():
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            key_lbl = Gtk.Label(label=key + ":", xalign=0)
            key_lbl.get_style_context().add_class("wizard-summary-key")
            val_lbl = Gtk.Label(label=value, xalign=0)
            val_lbl.set_line_wrap(True)
            row.pack_start(key_lbl, False, False, 0)
            row.pack_start(val_lbl, True, True, 0)
            self.summary_card.pack_start(row, False, False, 0)
        self.summary_card.show_all()

    def _on_census_toggled(self, check):
        self.state["census"] = check.get_active()

    # ------------------------------------------------------------------
    # Navigation state
    # ------------------------------------------------------------------
    def _show_page(self, index):
        index = max(0, min(index, len(self.page_names) - 1))
        self.current = index
        self.stack.set_visible_child_name(self.page_names[index])
        self.step_label.set_text(
            _("Step {} of {}").format(index + 1, len(self.page_names)))
        last = index == len(self.page_names) - 1
        if last:
            self._populate_summary_card()
        self.back_btn.set_sensitive(index > 0 and not self.finishing)
        self.skip_btn.set_visible(not last)
        self.skip_btn.set_no_show_all(last)
        self.next_btn.set_label(_("Finish") if last else _("Next"))
        self.next_btn.set_sensitive(not self.finishing)

    # ------------------------------------------------------------------
    # Skip
    # ------------------------------------------------------------------
    def _on_skip(self, _btn):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            text=_("Skip setup?"),
        )
        dialog.format_secondary_text(_(
            "Default gaming apps will be installed in the background, and "
            "you can run this wizard again later from the menu (NawaOS "
            "Setup)."))
        dialog.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(_("Use defaults & skip"), Gtk.ResponseType.OK)
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.OK:
            return
        # Defaults: default-checked flatpaks only; everything else off.
        self.state["flatpaks"] = {
            app_id: default
            for app_id, _n, _d, default, _g in FLATPAK_APPS}
        self.state["nvidia_install"] = False
        # Skipping leaves the login session as it is (finish would otherwise
        # turn an existing Console Mode back into the desktop).
        self.state["console_mode"] = self._dmrc_session().startswith("nawaos-gamescope")
        self.state["census"] = False
        self._start_finish()

    # ------------------------------------------------------------------
    # Finish flow
    # ------------------------------------------------------------------
    def _start_finish(self):
        if self.finishing:
            return
        self.finishing = True
        self.back_btn.set_sensitive(False)
        self.skip_btn.set_sensitive(False)
        self.next_btn.set_sensitive(False)

        wants_nvidia = (self.state["nvidia_install"]
                        and not self.nvidia_installed)
        if wants_nvidia:
            # Run the NVIDIA install first, with visible progress and an
            # honest result, then complete the rest of the finish flow.
            try:
                self.finish_spinner.start()
                self.finish_spinner.show()
                self.finish_status.set_text(_(
                    "Installing NVIDIA driver… this may take several "
                    "minutes."))
                self.finish_status.show()
            except Exception:
                pass
            threading.Thread(
                target=self._nvidia_install_thread, daemon=True).start()
        else:
            self._complete_finish()

    def _nvidia_install_thread(self):
        pkg = self.nvidia_pkg or NVIDIA_PACKAGES
        rc, out = -1, ""
        try:
            result = subprocess.run(
                ["pkexec", "apt-get", "install", "-y"] + pkg.split(),
                capture_output=True, timeout=1800)
            rc = result.returncode
            out = (result.stdout + result.stderr).decode(
                "utf-8", errors="replace")
        except (OSError, subprocess.SubprocessError) as exc:
            out = str(exc)
        success = rc == 0 and package_installed("nvidia-driver")
        log.info("nvidia install (%s) rc=%s success=%s", pkg, rc, success)
        if not success and out:
            log.info("nvidia install output tail: %s", out[-2000:])
        GLib.idle_add(self._nvidia_install_done, success)

    def _nvidia_install_done(self, success):
        try:
            self.finish_spinner.stop()
            self.finish_spinner.hide()
            if success:
                self.finish_status.set_text(
                    _("NVIDIA driver installed successfully ✓"))
                self.finish_status.get_style_context().add_class("status-ok")
            else:
                self.finish_status.set_text(_(
                    "NVIDIA driver installation failed. You can install "
                    "it later from a terminal: sudo apt install "
                    "nvidia-driver"))
                self.finish_status.get_style_context().add_class(
                    "status-warn")
        except Exception:
            pass
        # Record the honest outcome, then let the user read the message
        # for a moment before the wizard closes.
        self.state["nvidia_install"] = bool(success)
        GLib.timeout_add(2500 if success else 6000,
                         self._complete_finish_idle)
        return False

    def _complete_finish_idle(self):
        self._complete_finish()
        return False

    def _complete_finish(self):
        """Persist all choices and hand over to nawaos-gaming-setup."""
        # 1. Language files (re-written for safety; language page already
        #    persists on click).
        self._persist_language(self.state["language"])

        # 2. Selection JSON read by /usr/local/bin/nawaos-gaming-setup.
        selection = {
            "language": self.state["language"],
            "flatpaks": [app_id for app_id, _n, _d, _def, _g in FLATPAK_APPS
                         if self.state["flatpaks"].get(app_id)],
            "console_mode": bool(self.state["console_mode"]),
            "nvidia_driver": bool(self.state["nvidia_install"]),
            "census": bool(self.state["census"]),
        }
        try:
            _atomic_write(
                SELECTION_FILE,
                json.dumps(selection, indent=2, ensure_ascii=False) + "\n")
        except OSError:
            log.error("could not write %s:\n%s", SELECTION_FILE,
                      traceback.format_exc())

        # 3. Console Mode default session (handheld only). Native (DRM)
        #    GameScope session; it steps down to the nested session, then
        #    the desktop, on its own if it cannot start. With the switch off,
        #    a console session left by an earlier run goes back to Cinnamon.
        if self.is_handheld:
            if self.state["console_mode"]:
                self._write_dmrc_session("nawaos-gamescope-native")
            elif self._dmrc_session().startswith("nawaos-gamescope"):
                self._write_dmrc_session("cinnamon")

        # 4. Mark the wizard as done (gaming-setup defers until this exists).
        try:
            _atomic_write(WIZARD_DONE_FILE, "done\n")
        except OSError:
            log.error("could not write %s:\n%s", WIZARD_DONE_FILE,
                      traceback.format_exc())

        # 5. Remove the per-user autostart entry (the skel copy). Guarded:
        #    on re-runs it is usually already gone.
        try:
            if os.path.exists(AUTOSTART_FILE):
                os.remove(AUTOSTART_FILE)
        except OSError:
            log.warning("could not remove %s:\n%s", AUTOSTART_FILE,
                        traceback.format_exc())

        # 6. Launch the background installer, fully detached.
        if os.path.exists(GAMING_SETUP):
            try:
                subprocess.Popen(
                    [GAMING_SETUP],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True)
                log.info("launched %s", GAMING_SETUP)
            except OSError:
                log.error("could not launch %s:\n%s", GAMING_SETUP,
                          traceback.format_exc())
        else:
            log.warning("%s not found; skipping launch", GAMING_SETUP)

        # 7. One first-login summary instead of the user discovering problems
        #    one by one (stays in the panel's notification history too).
        summary = self.readiness_summary_text()
        if summary and nawaos_notify is not None:
            try:
                nawaos_notify.notify(_("Setup complete"), summary,
                                     category="system", source="NawaOS Setup")
            except Exception:
                log.warning("summary notification failed:\n%s",
                            traceback.format_exc())

        log.info("wizard finished: %s", selection)
        self.destroy()


# ---------------------------------------------------------------------------
# Entry point — must never block login, whatever happens
# ---------------------------------------------------------------------------
def main():
    _setup_logging()
    try:
        log.info("nawaos-welcome-wizard starting (rerun=%s)",
                 os.path.exists(WIZARD_DONE_FILE))
        win = WelcomeWizard()
        win.show_all()
        Gtk.main()
    except Exception:
        log.error("wizard crashed:\n%s", traceback.format_exc())
    return 0


if __name__ == "__main__":
    sys.exit(main())
