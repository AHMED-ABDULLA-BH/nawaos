#!/bin/bash
# NawaOS Mode Switch
# Quick toggle between Desktop Mode and Game Mode
# Usage: nawaos-mode-switch [desktop|gamemode|toggle]

CONFIG_DIR="$HOME/.config/nawaos/handheld"
STATE_FILE="$CONFIG_DIR/state.json"

get_current_mode() {
    if [ -f "$STATE_FILE" ]; then
        # WHY: pass the path as argv instead of interpolating it into the
        # Python source, so paths with quotes/specials can't break (or
        # inject into) the one-liner.
        mode=$(python3 -c "import json, sys; print(json.load(open(sys.argv[1])).get('mode','desktop'))" "$STATE_FILE" 2>/dev/null)
        echo "${mode:-desktop}"
    else
        echo "desktop"
    fi
}

switch_to_gamemode() {
    echo "Switching to Game Mode..."
    mkdir -p "$CONFIG_DIR"
    echo '{"mode": "gamemode"}' > "$STATE_FILE"

    # Apply performance tweaks
    if command -v nawaos-gamemode &>/dev/null; then
        pkexec /usr/local/bin/nawaos-gamemode on 2>/dev/null
    fi

    # Launch Game Mode UI
    if command -v nawaos-gamemode-ui &>/dev/null; then
        nawaos-gamemode-ui &
    fi

    if command -v nawaos-notify &>/dev/null; then
        nawaos-notify "Game Mode" "Switched to Game Mode" -c gaming -s "Mode Switch"
    else
        notify-send "Game Mode" "Switched to Game Mode" 2>/dev/null
    fi
}

switch_to_desktop() {
    echo "Switching to Desktop Mode..."
    mkdir -p "$CONFIG_DIR"
    echo '{"mode": "desktop"}' > "$STATE_FILE"

    # Kill Game Mode UI if running.
    # WHY: match the exact runpy wrapper path anchored at end-of-cmdline, so
    # arbitrary processes whose command line merely contains the substring
    # "nawaos-gamemode-ui" (editors, greps, ...) are never killed.
    pkill -f '/usr/local/bin/nawaos-gamemode-ui$' 2>/dev/null

    # Restore balanced settings
    if command -v nawaos-gamemode &>/dev/null; then
        pkexec /usr/local/bin/nawaos-gamemode off 2>/dev/null
    fi

    if command -v nawaos-notify &>/dev/null; then
        nawaos-notify "Desktop Mode" "Switched to Desktop Mode" -c system -s "Mode Switch"
    else
        notify-send "Desktop Mode" "Switched to Desktop Mode" 2>/dev/null
    fi
}

case "${1:-toggle}" in
    desktop)
        switch_to_desktop
        ;;
    gamemode|game)
        switch_to_gamemode
        ;;
    toggle)
        current=$(get_current_mode)
        if [ "$current" = "gamemode" ]; then
            switch_to_desktop
        else
            switch_to_gamemode
        fi
        ;;
    status)
        current=$(get_current_mode)
        echo "Current mode: $current"
        ;;
    *)
        echo "NawaOS Mode Switch"
        echo "Usage: nawaos-mode-switch [desktop|gamemode|toggle|status]"
        ;;
esac
