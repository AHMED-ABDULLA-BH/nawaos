#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Waydroid Manager
Run Android apps on NawaOS with Waydroid + F-Droid

Developed by: Ahmed Abdulla
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
import subprocess
import threading
import socket
import os
import sys
import shutil
import tempfile

try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

# Release info shared by all NawaOS apps (nawaos-common/nawaos_release.py).
try:
    import nawaos_release
except ImportError:
    nawaos_release = None

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402


APP_NAME = "nawaos-waydroid"

# ---------------------------------------------------------------------------
# Built-in Arabic UI strings. Everything user-visible goes through _() with
# this dictionary; product names (NawaOS, Waydroid, Android, F-Droid, Wayland,
# X11, Cinnamon) stay in Latin script.
# ---------------------------------------------------------------------------
AR_STRINGS = {
    "NawaOS Android Apps": "تطبيقات Android على NawaOS",
    "Android Apps": "تطبيقات Android",
    "Run Android apps with Waydroid + F-Droid":
        "شغّل تطبيقات Android عبر Waydroid و F-Droid",
    "Status": "الحالة",
    "Waydroid:": "Waydroid:",
    "Ready": "جاهز",
    "Needs Init": "يحتاج إلى تهيئة",
    "Not Installed": "غير مثبت",
    "Waydroid requires a Wayland session.\nYou are currently on X11. "
    "Log out and select \"Cinnamon (Wayland)\" at login.":
        "يتطلب Waydroid جلسة Wayland.\nأنت تستخدم X11 حاليًا. "
        "سجّل الخروج واختر \"Cinnamon (Wayland)\" عند تسجيل الدخول.",
    "Features": "المزايا",
    "Waydroid": "Waydroid",
    "F-Droid": "F-Droid",
    "Gaming": "الألعاب",
    "Multi-window": "تعدد النوافذ",
    "Full Android system in a container": "نظام Android كامل داخل حاوية",
    "Open source app store": "متجر تطبيقات مفتوح المصدر",
    "Play Android games": "العب ألعاب Android",
    "Android apps as Linux windows": "تطبيقات Android كنوافذ Linux",
    "Run any Android app": "شغّل أي تطبيق Android",
    "1000+ free apps": "أكثر من 1000 تطبيق مجاني",
    "With controller support": "مع دعم أذرع التحكم",
    "Seamless integration": "تكامل سلس",
    "Install Waydroid + F-Droid": "تثبيت Waydroid و F-Droid",
    "Initialize Waydroid": "تهيئة Waydroid",
    "Start Waydroid": "تشغيل Waydroid",
    "Open F-Droid": "فتح F-Droid",
    "Stop": "إيقاف",
    "Installing Waydroid...": "جارٍ تثبيت Waydroid...",
    "Opening terminal for installation...": "جارٍ فتح الطرفية للتثبيت...",
    "No terminal found. Please install manually:\n\n"
    "1. Add the official Waydroid repository key:\n"
    "   sudo curl -fsSL https://repo.waydro.id/waydroid.gpg \\\n"
    "        -o /usr/share/keyrings/waydroid.gpg\n"
    "2. Register the repository (NawaOS 2.x is based on Debian trixie):\n"
    "   echo 'deb [signed-by=/usr/share/keyrings/waydroid.gpg] "
    "https://repo.waydro.id/ trixie main' | \\\n"
    "        sudo tee /etc/apt/sources.list.d/waydroid.list\n"
    "3. Install:\n"
    "   sudo apt update && sudo apt install waydroid":
        "لم يُعثر على طرفية. يرجى التثبيت يدويًا:\n\n"
        "1. أضف مفتاح مستودع Waydroid الرسمي:\n"
        "   sudo curl -fsSL https://repo.waydro.id/waydroid.gpg \\\n"
        "        -o /usr/share/keyrings/waydroid.gpg\n"
        "2. سجّل المستودع (NawaOS 2.x مبني على Debian trixie):\n"
        "   echo 'deb [signed-by=/usr/share/keyrings/waydroid.gpg] "
        "https://repo.waydro.id/ trixie main' | \\\n"
        "        sudo tee /etc/apt/sources.list.d/waydroid.list\n"
        "3. ثبّت:\n"
        "   sudo apt update && sudo apt install waydroid",
    "Installation started in terminal window...":
        "بدأ التثبيت في نافذة الطرفية...",
    "Installation started in terminal.\n\n"
    "After it completes, click 'Initialize Waydroid'.":
        "بدأ التثبيت في الطرفية.\n\nبعد اكتماله، انقر على 'تهيئة Waydroid'.",
    "Error: %s": "خطأ: %s",
    "No internet connection!\n\n"
    "Waydroid needs to download Android files (~800MB).\n"
    "Please check your internet connection and try again.":
        "لا يوجد اتصال بالإنترنت!\n\n"
        "يحتاج Waydroid إلى تنزيل ملفات Android (نحو 800 ميغابايت).\n"
        "يرجى التحقق من اتصالك بالإنترنت والمحاولة مجددًا.",
    "Downloading Android image (this may take a while)...":
        "جارٍ تنزيل صورة Android (قد يستغرق ذلك بعض الوقت)...",
    "Starting initialization...": "جارٍ بدء التهيئة...",
    "Downloading system image...": "جارٍ تنزيل صورة النظام...",
    "Extracting images...": "جارٍ استخراج الصور...",
    "Verifying downloaded files...": "جارٍ التحقق من الملفات المنزّلة...",
    "Unknown error. Check %s": "خطأ غير معروف. راجع %s",
    "Initialization failed:": "فشلت التهيئة:",
    "Downloading F-Droid app store...": "جارٍ تنزيل متجر F-Droid...",
    "Installing F-Droid...": "جارٍ تثبيت F-Droid...",
    "✓ Waydroid initialized with F-Droid!\n\n"
    "You can now run Android apps.\n\n"
    "Note: the F-Droid APK was downloaded from f-droid.org over "
    "HTTPS but is not independently verified. If in doubt, "
    "reinstall it from https://f-droid.org and check its "
    "signature yourself.":
        "✓ تمت تهيئة Waydroid مع F-Droid!\n\n"
        "يمكنك الآن تشغيل تطبيقات Android.\n\n"
        "ملاحظة: نُزّل ملف APK الخاص بـ F-Droid من f-droid.org عبر HTTPS "
        "لكن لم يُتحقق منه بشكل مستقل. إن ساورك الشك، أعد تثبيته من "
        "https://f-droid.org وتحقق من توقيعه بنفسك.",
    "✓ Waydroid initialized!\n\n"
    "F-Droid download failed - you can install it manually later.":
        "✓ تمت تهيئة Waydroid!\n\nفشل تنزيل F-Droid، ويمكنك تثبيته يدويًا لاحقًا.",
    "Initialization timed out.\n"
    "Please check your internet connection and try again.":
        "انتهت مهلة التهيئة.\nيرجى التحقق من اتصالك بالإنترنت والمحاولة مجددًا.",
    "Waydroid requires a Wayland session.\n\n"
    "Please log out and select 'Cinnamon (Wayland)' at the login screen.":
        "يتطلب Waydroid جلسة Wayland.\n\n"
        "يرجى تسجيل الخروج واختيار 'Cinnamon (Wayland)' في شاشة تسجيل الدخول.",
    "Starting Waydroid...": "جارٍ تشغيل Waydroid...",
    "Waydroid started": "تم تشغيل Waydroid",
    "Waydroid is not installed.\nPlease install it first.":
        "Waydroid غير مثبت.\nيرجى تثبيته أولًا.",
    "Error starting Waydroid: %s": "خطأ في تشغيل Waydroid: %s",
    "Waydroid requires a Wayland session.": "يتطلب Waydroid جلسة Wayland.",
    "Opening F-Droid...": "جارٍ فتح F-Droid...",
    "F-Droid launched": "تم تشغيل F-Droid",
    "Error opening F-Droid: %s\n\nF-Droid may not be installed yet.":
        "خطأ في فتح F-Droid: %s\n\nقد لا يكون F-Droid مثبتًا بعد.",
    "Stopping Waydroid...": "جارٍ إيقاف Waydroid...",
    "Waydroid stopped": "تم إيقاف Waydroid",
    "Error stopping Waydroid: %s": "خطأ في إيقاف Waydroid: %s",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    return nawaos_i18n.setup(APP_NAME, AR_STRINGS)


_, get_language, is_rtl = _setup_i18n()


def get_os_version():
    """NawaOS version (VERSION_ID), via nawaos_release."""
    return nawaos_release.version() if nawaos_release else ""


VERSION = get_os_version()

class WaydroidManager(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("NawaOS Android Apps"))
        self.set_default_size(550, 500)
        self.set_position(Gtk.WindowPosition.CENTER)
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)
        
        self.waydroid_installed = self.check_waydroid()
        self.waydroid_initialized = self.check_waydroid_init()
        self.is_wayland = self.check_wayland()
        
        settings = Gtk.Settings.get_default()
        settings.set_property("gtk-application-prefer-dark-theme", True)
        
        self.load_css()
        self.create_ui()
        self.show_all()
    
    def check_waydroid(self):
        """Check if waydroid is installed and functional"""
        try:
            result = subprocess.run(['waydroid', '--help'], capture_output=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    
    def check_waydroid_init(self):
        """Check if waydroid has been initialized (has images)"""
        return os.path.exists('/var/lib/waydroid/images') and \
               os.path.exists('/var/lib/waydroid/images/system.img')
    
    def check_wayland(self):
        """Check if running under Wayland session"""
        session = os.environ.get('XDG_SESSION_TYPE', '').lower()
        wayland_display = os.environ.get('WAYLAND_DISPLAY', '')
        return session == 'wayland' or bool(wayland_display)
    
    def check_internet(self):
        """Check if internet connection is available.

        Uses a TCP connection to a well-known host instead of ICMP ping, so it
        still works on networks that block ping (a common case).
        """
        for host in ("f-droid.org", "1.1.1.1"):
            try:
                with socket.create_connection((host, 443), timeout=4):
                    return True
            except OSError:
                continue
        return False
    
    def load_css(self):
        # Thin app layer over the shared NawaOS 2.0 BASE_CSS (nawaos_theme).
        css = b"""
        window { background-color: #0B0F1A; }

        .header-box { background-color: #111827; padding: 16px 24px; }
        .app-title { color: #ffffff; font-size: 20px; font-weight: 700; }
        .header-subtitle { color: #9AA7B8; font-size: 12px; }

        .title-underline {
            background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2);
            border-radius: 100px; min-height: 3px;
        }
        .section-label {
            color: #9AA7B8; font-size: 10px; font-weight: 700;
            letter-spacing: 2px;
        }

        .card {
            background-color: #1A2332;
            border: 1px solid rgba(55, 188, 224, 0.08);
            border-radius: 12px; padding: 14px; margin: 8px 0;
            transition: all 200ms ease;
        }
        .card:hover { box-shadow: 0 2px 12px rgba(55, 188, 224, 0.10); }

        .feature-card {
            background-color: #1A2332;
            border: 1px solid rgba(55, 188, 224, 0.08);
            border-radius: 12px; padding: 14px; margin: 5px;
            transition: all 200ms ease;
        }
        .feature-card:hover {
            background-color: #232D3F;
            box-shadow: 0 2px 12px rgba(55, 188, 224, 0.10);
        }
        .feature-desc { color: #9AA7B8; font-size: 11px; }
        .status-label { color: #9AA7B8; font-size: 12px; }

        .primary-pill {
            background: linear-gradient(135deg, #1A76BA, #37BCE0);
            border: none; border-radius: 100px;
            padding: 10px 28px; min-height: 44px;
            font-weight: 700; font-size: 14px;
            transition: all 150ms ease;
        }
        .primary-pill, .primary-pill label { color: #ffffff; }
        .primary-pill:hover {
            background: linear-gradient(135deg, #37BCE0, #50E6E2);
            box-shadow: 0 3px 14px rgba(55, 188, 224, 0.35);
        }
        .ghost-btn {
            background: transparent; border: none; border-radius: 100px;
            padding: 8px 20px; min-height: 40px; font-weight: 600;
            transition: all 150ms ease;
        }
        .ghost-btn, .ghost-btn label { color: #37BCE0; }
        .ghost-btn:hover { background: rgba(55, 188, 224, 0.10); }
        .danger-outline {
            background: transparent;
            border: 1px solid rgba(248, 113, 113, 0.45);
            border-radius: 100px; padding: 8px 20px; min-height: 40px;
            font-weight: 600; transition: all 150ms ease;
        }
        .danger-outline, .danger-outline label { color: #F87171; }
        .danger-outline:hover { background: rgba(248, 113, 113, 0.12); }
        """
        if nawaos_theme is not None:
            nawaos_theme.apply_theme(self, css)
            return
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    @staticmethod
    def _load_logo(size=28):
        """Brand logo as a Gtk.Image, or None if the asset is missing."""
        for path in ("/usr/share/pixmaps/nawaos-logo.png",
                     "/usr/share/nawaos/logo.png"):
            try:
                if os.path.exists(path):
                    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        path, size, size, True)
                    return Gtk.Image.new_from_pixbuf(pb)
            except Exception:
                pass
        return None

    @staticmethod
    def _section_label(text):
        lbl = Gtk.Label(label=text.upper())
        lbl.get_style_context().add_class("section-label")
        lbl.set_halign(Gtk.Align.START)
        return lbl

    def create_ui(self):
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(main_box)

        # Header: logo + app name + version pill, subtitle beneath
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        header.get_style_context().add_class("header-box")

        brand_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        logo = self._load_logo(28)
        if logo:
            brand_row.pack_start(logo, False, False, 0)

        title = Gtk.Label(label=_("Android Apps"))
        title.get_style_context().add_class("app-title")
        brand_row.pack_start(title, False, False, 0)

        badge = Gtk.Label(label=VERSION)
        badge.get_style_context().add_class("pill-badge")
        badge.set_valign(Gtk.Align.CENTER)
        brand_row.pack_start(badge, False, False, 0)
        header.pack_start(brand_row, False, False, 0)

        subtitle = Gtk.Label(label=_("Run Android apps with Waydroid + F-Droid"))
        subtitle.get_style_context().add_class("header-subtitle")
        subtitle.set_halign(Gtk.Align.START)
        header.pack_start(subtitle, False, False, 0)

        main_box.pack_start(header, False, False, 0)
        
        # Content
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        content.set_margin_start(15)
        content.set_margin_end(15)
        content.set_margin_top(15)
        content.set_margin_bottom(15)
        
        # Status Card
        status_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        status_card.get_style_context().add_class("card")
        
        status_card.pack_start(self._section_label(_("Status")), False, False, 0)
        
        # Waydroid status
        waydroid_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        waydroid_label = Gtk.Label(label=_("Waydroid:"))
        waydroid_label.get_style_context().add_class("status-label")
        waydroid_box.pack_start(waydroid_label, False, False, 0)
        
        self.waydroid_status = Gtk.Label()
        if self.waydroid_installed:
            if self.waydroid_initialized:
                self.waydroid_status.set_markup('<span foreground="#4ADE80">✓ %s</span>' % _("Ready"))
            else:
                self.waydroid_status.set_markup('<span foreground="#FBBF24">⚠ %s</span>' % _("Needs Init"))
        else:
            self.waydroid_status.set_markup('<span foreground="#F87171">✗ %s</span>' % _("Not Installed"))
        waydroid_box.pack_start(self.waydroid_status, False, False, 0)
        status_card.pack_start(waydroid_box, False, False, 0)
        
        content.pack_start(status_card, False, False, 0)
        
        # Wayland warning
        if not self.is_wayland:
            warn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            warn_box.get_style_context().add_class("card")
            warn_icon = Gtk.Label()
            warn_icon.set_markup('<span foreground="#FBBF24" size="large">⚠</span>')
            warn_box.pack_start(warn_icon, False, False, 5)
            warn_label = Gtk.Label()
            warn_label.set_markup('<span foreground="#FBBF24">%s</span>' % _(
                "Waydroid requires a Wayland session.\nYou are currently on X11. "
                "Log out and select \"Cinnamon (Wayland)\" at login."))
            warn_label.set_line_wrap(True)
            warn_box.pack_start(warn_label, True, True, 0)
            content.pack_start(warn_box, False, False, 0)
        
        # Features
        content.pack_start(self._section_label(_("Features")), False, False, 5)

        features = [
            (_("Waydroid"), _("Full Android system in a container"), _("Run any Android app")),
            (_("F-Droid"), _("Open source app store"), _("1000+ free apps")),
            (_("Gaming"), _("Play Android games"), _("With controller support")),
            (_("Multi-window"), _("Android apps as Linux windows"), _("Seamless integration")),
        ]
        
        features_grid = Gtk.Grid()
        features_grid.set_column_spacing(10)
        features_grid.set_row_spacing(10)
        features_grid.set_column_homogeneous(True)
        
        for i, (title, desc, extra) in enumerate(features):
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            card.get_style_context().add_class("feature-card")
            
            title_lbl = Gtk.Label()
            title_lbl.set_markup(f'<span weight="bold" foreground="#E8EDF4">{title}</span>')
            title_lbl.set_halign(Gtk.Align.START)
            card.pack_start(title_lbl, False, False, 0)
            
            desc_lbl = Gtk.Label(label=desc)
            desc_lbl.get_style_context().add_class("feature-desc")
            desc_lbl.set_halign(Gtk.Align.START)
            card.pack_start(desc_lbl, False, False, 0)
            
            features_grid.attach(card, i % 2, i // 2, 1, 1)
        
        content.pack_start(features_grid, False, False, 0)
        
        # Progress
        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(True)
        self.progress.set_no_show_all(True)
        content.pack_start(self.progress, False, False, 5)
        
        # Status label
        self.status_label = Gtk.Label(label="")
        self.status_label.get_style_context().add_class("status-label")
        content.pack_start(self.status_label, False, False, 0)
        
        # Buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        btn_box.set_margin_top(10)
        
        if not self.waydroid_installed:
            install_btn = Gtk.Button(label=_("Install Waydroid + F-Droid"))
            install_btn.get_style_context().add_class("primary-pill")
            install_btn.connect("clicked", self.on_install_clicked)
            btn_box.pack_start(install_btn, False, False, 0)
        else:
            if not self.waydroid_initialized:
                init_btn = Gtk.Button(label=_("Initialize Waydroid"))
                init_btn.get_style_context().add_class("primary-pill")
                init_btn.connect("clicked", self.on_init_clicked)
                btn_box.pack_start(init_btn, False, False, 0)
            else:
                # Control buttons: one gradient primary, ghost + outlined rest
                control_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                control_box.set_halign(Gtk.Align.CENTER)

                start_btn = Gtk.Button(label=_("Start Waydroid"))
                start_btn.get_style_context().add_class("primary-pill")
                start_btn.connect("clicked", self.on_start_clicked)
                control_box.pack_start(start_btn, False, False, 0)

                fdroid_btn = Gtk.Button(label=_("Open F-Droid"))
                fdroid_btn.get_style_context().add_class("ghost-btn")
                fdroid_btn.connect("clicked", self.on_fdroid_clicked)
                control_box.pack_start(fdroid_btn, False, False, 0)

                stop_btn = Gtk.Button(label=_("Stop"))
                stop_btn.get_style_context().add_class("danger-outline")
                stop_btn.connect("clicked", self.on_stop_clicked)
                control_box.pack_start(stop_btn, False, False, 0)

                btn_box.pack_start(control_box, False, False, 0)
        
        content.pack_start(btn_box, False, False, 0)
        
        main_box.pack_start(content, True, True, 0)
    
    def on_install_clicked(self, button):
        self.progress.show()
        self.progress.set_fraction(0)
        self.status_label.set_text(_("Installing Waydroid..."))
        threading.Thread(target=self.install_waydroid, daemon=True).start()
    
    def install_waydroid(self):
        """Install Waydroid from the official apt repository (repo.waydro.id).

        WHY: the previous from-source path cloned unpinned git master and
        left a half-install (no container service / LXC configs), and even
        built an unverified CPython from source. The official apt repository
        ships a complete, dependency-resolved, GPG-signed package instead.
        """
        try:
            GLib.idle_add(self.progress.set_fraction, 0.3)
            GLib.idle_add(self.status_label.set_text, _("Opening terminal for installation..."))

            # Use terminal for installation with clean user-friendly output
            install_script = '''
clear
echo ""
echo "  +==========================================+"
echo "  |     NawaOS Waydroid Installation        |"
echo "  +==========================================+"
echo ""
echo "  This will install Android app support from"
echo "  the official Waydroid repository."
echo ""

# Get sudo password upfront
sudo -v
if [ $? -ne 0 ]; then
    echo "  [X] Admin password required. Exiting."
    read
    exit 1
fi

# Keep sudo alive
while true; do sudo -n true; sleep 60; kill -0 "$$" || exit; done 2>/dev/null &

# Progress bar function (ASCII)
show_bar() {
    local pct=$1
    local filled=$((pct * 30 / 100))
    local empty=$((30 - filled))
    printf "  ["
    for i in $(seq 1 $filled); do printf "#"; done
    for i in $(seq 1 $empty); do printf "-"; done
    printf "] %d%%" $pct
    echo ""
}

# WHY: private, unpredictable working directory (0700, created by mktemp)
# instead of fixed world-readable /tmp paths, since we install as root.
WORKDIR=$(mktemp -d "${TMPDIR:-/tmp}/nawaos-waydroid.XXXXXX")
trap 'rm -rf "$WORKDIR"' EXIT
LOG="$WORKDIR/waydroid_install.log"
> $LOG
INSTALL_OK=0

echo "  [1/4] Detecting distribution..."
show_bar 25
# WHY: NawaOS ships its own /etc/os-release (ID=nawaos). Releases before 2.0.2
# had no VERSION_CODENAME, so this fell back to "bookworm" -- whose
# python3-gbinder is built for Python 3.11 and cannot install on Debian 13
# (Python 3.13). apt then failed and the user saw "distribution not
# supported". Resolve the Debian suite the base system actually is, and
# verify repo.waydro.id publishes it before writing the sources entry.
SUITE=""
if [ -r /etc/os-release ]; then
    . /etc/os-release
    SUITE="${DEBIAN_CODENAME:-${VERSION_CODENAME:-}}"
fi
if [ -z "$SUITE" ] && [ -r /etc/debian_version ]; then
    case "$(cut -d. -f1 /etc/debian_version)" in
        12) SUITE=bookworm ;;
        13) SUITE=trixie ;;
        14) SUITE=forky ;;
        *)  SUITE=trixie ;;
    esac
fi
[ -n "$SUITE" ] || SUITE="trixie"
echo "        Suite: $SUITE"

KEYRING=/usr/share/keyrings/waydroid.gpg
LIST=/etc/apt/sources.list.d/waydroid.list
# WHY: a sources entry that apt cannot fetch breaks EVERY later "apt update"
# (Control Panel updates, the Store, unattended-upgrades, the kernel
# installer). Never leave one behind: only write it once the suite is
# confirmed to exist, and remove it again if the install does not succeed.
cleanup_repo() {
    sudo rm -f "$LIST" "$KEYRING"
    sudo rm -f /var/lib/apt/lists/repo.waydro.id_* 2>/dev/null
}
# A stale entry from an earlier NawaOS (bookworm suite) is removed first.
cleanup_repo

echo ""
echo "  [2/4] Installing Waydroid from Debian ($SUITE-backports)..."
show_bar 50
# Debian ships waydroid in trixie-backports (1.6.x), signed with Debian's own
# keys and built against this release's Python. Prefer it; the upstream
# repository is only a fallback.
sudo apt-get update >> $LOG 2>&1 \
    || echo "        (apt update reported errors from another repository; continuing)"
if sudo apt-get install -y -t "$SUITE-backports" waydroid >> $LOG 2>&1; then
    INSTALL_OK=1
    echo "        Done"
else
    echo "        Not available from Debian backports, trying repo.waydro.id"
    echo ""
    echo "  [3/4] Adding the official Waydroid repository..."
    show_bar 75
    sudo apt-get install -y -qq curl ca-certificates >> $LOG 2>&1
    if ! curl -fsSIL "https://repo.waydro.id/dists/$SUITE/Release" -o /dev/null >> $LOG 2>&1; then
        echo "        [X] repo.waydro.id does not publish '$SUITE' (or the network is down)"
    elif ! curl -fsSL https://repo.waydro.id/waydroid.gpg -o "$WORKDIR/waydroid.gpg" >> $LOG 2>&1; then
        echo "        [X] Could not download the repository key"
    else
        sudo install -m 0644 "$WORKDIR/waydroid.gpg" "$KEYRING"
        echo "deb [signed-by=$KEYRING] https://repo.waydro.id/ $SUITE main" \
            | sudo tee "$LIST" > /dev/null
        # An unrelated broken repository must not block this install: ignore
        # the overall apt-get update status and check that OUR index arrived.
        sudo apt-get update >> $LOG 2>&1 \
            || echo "        (apt update reported errors from other repositories; continuing)"
        if ls /var/lib/apt/lists/repo.waydro.id_*_Packages >/dev/null 2>&1 \
            && sudo apt-get install -y waydroid >> $LOG 2>&1; then
            INSTALL_OK=1
            echo "        Done"
        else
            echo "        [X] apt failed (last lines of the log):"
            tail -n 8 "$LOG" | sed 's/^/          /'
            cleanup_repo
        fi
    fi
fi

echo ""
echo "  [4/4] Verifying..."
show_bar 100
if [ "$INSTALL_OK" -eq 1 ] && command -v waydroid >/dev/null 2>&1; then
    echo "        Done"
else
    INSTALL_OK=0
fi

echo ""
echo ""

if [ "$INSTALL_OK" -eq 1 ]; then
    echo "  +==========================================+"
    echo "  |     [OK] Installation Complete!         |"
    echo "  +==========================================+"
    echo ""
    echo "  Click 'Initialize Waydroid' to continue."
else
    echo "  +==========================================+"
    echo "  |     [X] Installation Failed             |"
    echo "  +==========================================+"
    echo ""
    # Keep the log for a bug report (the private workdir is wiped on exit).
    KEPT_LOG=/tmp/nawaos-waydroid-install.log
    cp "$LOG" "$KEPT_LOG" 2>/dev/null && chmod 0644 "$KEPT_LOG" 2>/dev/null
    echo "  Suite used: $SUITE. The network may be unreachable,"
    echo "  or apt could not resolve the Waydroid dependencies."
    echo "  Full log saved to: $KEPT_LOG"
fi
echo ""
echo "  Press Enter to close..."
read
'''
            
            # Try gnome-terminal first
            try:
                subprocess.Popen(
                    ['gnome-terminal', '--', 'bash', '-c', install_script],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            except (FileNotFoundError, OSError):
                # Fallback to xterm
                try:
                    subprocess.Popen(['xterm', '-e', 'bash', '-c', install_script])
                except:
                    # WHY: Do NOT recommend piping a remote script straight into
                    # 'sudo bash' (curl | sudo bash) -- that runs unverified remote
                    # code as root. Recommend the official apt repository steps.
                    GLib.idle_add(self.show_message, _(
                                  "No terminal found. Please install manually:\n\n"
                                  "1. Add the official Waydroid repository key:\n"
                                  "   sudo curl -fsSL https://repo.waydro.id/waydroid.gpg \\\n"
                                  "        -o /usr/share/keyrings/waydroid.gpg\n"
                                  "2. Register the repository (NawaOS 2.x is based on Debian trixie):\n"
                                  "   echo 'deb [signed-by=/usr/share/keyrings/waydroid.gpg] "
                                  "https://repo.waydro.id/ trixie main' | \\\n"
                                  "        sudo tee /etc/apt/sources.list.d/waydroid.list\n"
                                  "3. Install:\n"
                                  "   sudo apt update && sudo apt install waydroid"))
                    return
            
            GLib.idle_add(self.progress.set_fraction, 1.0)
            GLib.idle_add(self.status_label.set_text, _("Installation started in terminal window..."))
            
            # Wait a bit then refresh
            import time
            time.sleep(3)
            GLib.idle_add(self.show_message, _(
                "Installation started in terminal.\n\n"
                "After it completes, click 'Initialize Waydroid'."))
            GLib.idle_add(self.refresh_ui)
            
        except Exception as e:
            GLib.idle_add(self.show_message, _("Error: %s") % str(e))
        finally:
            GLib.idle_add(self.progress.hide)
    
    def on_init_clicked(self, button):
        # Check internet first
        if not self.check_internet():
            self.show_message(_(
                "No internet connection!\n\n"
                "Waydroid needs to download Android files (~800MB).\n"
                "Please check your internet connection and try again."))
            return
        
        self.progress.show()
        self.progress.set_fraction(0)
        self.status_label.set_text(_("Downloading Android image (this may take a while)..."))
        threading.Thread(target=self.init_waydroid, daemon=True).start()
    
    def init_waydroid(self):
        import time
        # WHY: Use a private, unpredictable temp dir (0700, created by mkdtemp)
        # for the init log and the downloaded F-Droid APK instead of fixed,
        # world-predictable /tmp paths (/tmp/waydroid_init.log, /tmp/F-Droid.apk)
        # that other local users could pre-create as symlinks or read/replace.
        workdir = tempfile.mkdtemp(prefix="nawaos-waydroid-init-")
        init_log = os.path.join(workdir, "waydroid_init.log")
        fdroid_apk = os.path.join(workdir, "F-Droid.apk")
        try:
            GLib.idle_add(self.progress.set_fraction, 0.1)
            GLib.idle_add(self.status_label.set_text, _("Starting initialization..."))

            # Initialize with vanilla image (no Google) - use Popen to read output in real-time
            # pkexec is required because waydroid init needs root access
            process = subprocess.Popen(['pkexec', 'waydroid', 'init'],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)

            with open(init_log, 'w') as log_file:
                while True:
                    line = process.stdout.readline()
                    if not line and process.poll() is not None:
                        break
                    
                    if line:
                        log_file.write(line)
                        log_file.flush()
                        line = line.strip()
                        if "Downloading" in line:
                             GLib.idle_add(self.progress.set_fraction, 0.2)
                             GLib.idle_add(self.status_label.set_text, _("Downloading system image...") + "\n" + line[-40:])
                        elif "Extracting" in line:
                             GLib.idle_add(self.progress.set_fraction, 0.6)
                             GLib.idle_add(self.status_label.set_text, _("Extracting images..."))
                        elif "Verifying" in line:
                             GLib.idle_add(self.progress.set_fraction, 0.5)
                             GLib.idle_add(self.status_label.set_text, _("Verifying downloaded files..."))
            
            if process.returncode != 0:
                # Read the last few lines of the log for the error message
                try:
                    with open(init_log, 'r') as f:
                        lines = f.readlines()
                        error_msg = "".join(lines[-10:])
                except:
                    error_msg = _("Unknown error. Check %s") % init_log
                
                GLib.idle_add(self.show_message, _("Initialization failed:") + "\n" + error_msg)
                return
            
            GLib.idle_add(self.progress.set_fraction, 0.7)
            GLib.idle_add(self.status_label.set_text, _("Downloading F-Droid app store..."))
            
            # Download F-Droid into the private workdir (not a fixed /tmp path).
            # WARNING(security): the downloaded F-Droid.apk is NOT integrity-
            # checked -- it is fetched over HTTPS from f-droid.org but nothing
            # verifies the file beyond TLS. F-Droid does not publish a stable
            # pinned SHA-256 for this rolling "latest" URL, so a known-good hash
            # cannot be embedded here. Before installing, this APK SHOULD be
            # verified -- e.g. pin the expected SHA-256 of a specific F-Droid
            # release and compare, and/or verify the APK signing certificate
            # fingerprint -- to prevent installing a tampered package. Until
            # then the download is UNVERIFIED and the user-facing success
            # message below says so.
            dl_result = subprocess.run(['wget', '-q', 'https://f-droid.org/F-Droid.apk', '-O', fdroid_apk],
                                      capture_output=True, timeout=60)

            if dl_result.returncode == 0 and os.path.exists(fdroid_apk):
                GLib.idle_add(self.progress.set_fraction, 0.8)
                GLib.idle_add(self.status_label.set_text, _("Installing F-Droid..."))

                # Start session briefly to install F-Droid
                subprocess.Popen(['waydroid', 'session', 'start'],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                time.sleep(15) # Wait for container to be ready
                subprocess.run(['waydroid', 'app', 'install', fdroid_apk],
                             capture_output=True, timeout=45)
                subprocess.run(['waydroid', 'session', 'stop'], capture_output=True, timeout=10)
                
                GLib.idle_add(self.progress.set_fraction, 1.0)
                GLib.idle_add(self.show_message, _(
                              "✓ Waydroid initialized with F-Droid!\n\n"
                              "You can now run Android apps.\n\n"
                              "Note: the F-Droid APK was downloaded from f-droid.org over "
                              "HTTPS but is not independently verified. If in doubt, "
                              "reinstall it from https://f-droid.org and check its "
                              "signature yourself."))
            else:
                GLib.idle_add(self.progress.set_fraction, 1.0)
                GLib.idle_add(self.show_message, _(
                    "✓ Waydroid initialized!\n\n"
                    "F-Droid download failed - you can install it manually later."))
            
            GLib.idle_add(self.refresh_ui)
        except subprocess.TimeoutExpired:
            GLib.idle_add(self.show_message, _(
                "Initialization timed out.\n"
                "Please check your internet connection and try again."))
        except Exception as e:
            GLib.idle_add(self.show_message, _("Error: %s") % str(e))
        finally:
            # WHY: remove the private temp dir (and its APK/log) once we're done.
            shutil.rmtree(workdir, ignore_errors=True)
            GLib.idle_add(self.progress.hide)
            GLib.idle_add(self.status_label.set_text, "")
    
    def on_start_clicked(self, button):
        if not self.is_wayland:
            self.show_message(_(
                "Waydroid requires a Wayland session.\n\n"
                "Please log out and select 'Cinnamon (Wayland)' at the login screen."))
            return
        self.status_label.set_text(_("Starting Waydroid..."))
        try:
            subprocess.Popen(['waydroid', 'show-full-ui'])
            GLib.timeout_add(2000, lambda: self.status_label.set_text(_("Waydroid started")) or False)
        except FileNotFoundError:
            self.show_message(_("Waydroid is not installed.\nPlease install it first."))
        except Exception as e:
            self.show_message(_("Error starting Waydroid: %s") % e)
    
    def on_fdroid_clicked(self, button):
        if not self.is_wayland:
            self.show_message(_("Waydroid requires a Wayland session."))
            return
        self.status_label.set_text(_("Opening F-Droid..."))
        try:
            subprocess.Popen(['waydroid', 'app', 'launch', 'org.fdroid.fdroid'])
            GLib.timeout_add(2000, lambda: self.status_label.set_text(_("F-Droid launched")) or False)
        except Exception as e:
            self.show_message(_("Error opening F-Droid: %s\n\nF-Droid may not be installed yet.") % e)
    
    def on_stop_clicked(self, button):
        self.status_label.set_text(_("Stopping Waydroid..."))
        try:
            subprocess.run(['waydroid', 'session', 'stop'], capture_output=True, timeout=10)
            self.status_label.set_text(_("Waydroid stopped"))
        except Exception as e:
            self.show_message(_("Error stopping Waydroid: %s") % e)
    
    def refresh_ui(self):
        self.waydroid_installed = self.check_waydroid()
        self.waydroid_initialized = self.check_waydroid_init()
        # Recreate window
        for child in self.get_children():
            child.destroy()
        self.create_ui()
        self.show_all()
    
    def show_message(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=_("Waydroid")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()


def main():
    app = WaydroidManager()
    app.connect("destroy", Gtk.main_quit)
    Gtk.main()


if __name__ == "__main__":
    main()
