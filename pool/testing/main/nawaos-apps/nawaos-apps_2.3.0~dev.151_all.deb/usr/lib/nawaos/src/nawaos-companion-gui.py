#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Companion GUI
Control panel for the companion server
Version 2.0

Developed by: Ahmed Abdulla
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
import subprocess
import threading
import os
import sys
import stat
import time

try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402
from nawaos_notify import notify_companion  # noqa: E402

# Shared helpers (pairing token, local IP, TLS certs, config), kept in sync
# with the server via the common module ``nawaos_companion_common`` (installed
# system-wide; on dev runs it sits next to this script, which is on sys.path
# automatically).
from nawaos_companion_common import (
    get_pairing_token, rotate_pairing_token, get_local_ip, load_server_config,
    ensure_certificates, get_cert_fingerprint, build_connection_uri,
    TokenError, EXIT_TLS_FAILED, read_server_state, CONFIG_PATH,
)


# Add the current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

APP_NAME = "nawaos-companion-gui"

# Built-in Arabic strings. Every user-visible string goes through _() with
# this dictionary; packagers can override entries via /usr/share/nawaos/i18n.
AR_STRINGS = {
    "NawaOS Companion": "مرافق NawaOS",
    "Control your PC from mobile": "تحكم في حاسوبك من هاتفك",
    "SERVER STATUS": "حالة الخادم",
    "Offline": "غير متصل",
    "Online": "متصل",
    "Crashed": "تعطّل",
    "IP ADDRESS": "عنوان IP",
    "PORT": "المنفذ",
    "CONNECTED": "الأجهزة المتصلة",
    "Start": "بدء",
    "Stop": "إيقاف",
    "Scan with NawaOS Mobile App": "امسح الرمز بتطبيق NawaOS للهاتف",
    "Start server to show QR": "ابدأ الخادم لعرض رمز QR",
    "Pairing code (enter manually if needed):":
        "رمز الاقتران (أدخله يدوياً عند الحاجة):",
    "Web client (open in your phone's browser):":
        "عميل الويب (افتحه في متصفح هاتفك):",
    "Encrypted (wss:// + https://, self-signed cert)\n"
    "SHA-256 fingerprint: %s…\n"
    "Your browser will warn once — accepting the\n"
    "certificate for the web client also covers wss://":
        "الاتصال مشفّر (wss:// + https://، شهادة موقّعة ذاتياً)\n"
        "بصمة SHA-256: %s…\n"
        "سيحذّرك المتصفح مرة واحدة، وقبول الشهادة\n"
        "لعميل الويب يشمل wss:// أيضاً",
    "Traffic is unencrypted (plain ws://) —\n"
    "use only on local networks you trust":
        "حركة البيانات غير مشفّرة (ws:// عادي)،\n"
        "استخدمه فقط على الشبكات المحلية الموثوقة",
    "Server started!": "بدأ الخادم!",
    "Failed to start server: %s": "فشل بدء الخادم: %s",
    "Server stopped": "توقف الخادم",
    "Server stopped unexpectedly": "توقف الخادم بشكل غير متوقع",
    "Error": "خطأ",
    "Starting…": "جارٍ البدء…",
    "The pairing code could not be created: %s":
        "تعذّر إنشاء رمز الاقتران: %s",
    "Encryption could not be set up, so the server was not started.\n\n"
    "Install the openssl package and try again. To run unencrypted on a "
    "network you trust, set \"allow_plaintext\": true in %s.":
        "تعذّر إعداد التشفير، لذلك لم يبدأ الخادم.\n\n"
        "ثبّت حزمة openssl ثم أعد المحاولة. وللتشغيل دون تشفير على شبكة "
        "تثق بها، اضبط \"allow_plaintext\": true في %s.",
    "The server did not report that it is ready.":
        "لم يُبلغ الخادم بأنه أصبح جاهزاً.",
    "Reset pairing": "إعادة تعيين الاقتران",
    "Reset pairing?": "إعادة تعيين الاقتران؟",
    "A new pairing code is created. Every paired phone and browser is "
    "disconnected and has to scan the new QR code to connect again.":
        "سيُنشأ رمز اقتران جديد. ستُفصل كل الهواتف والمتصفحات المقترنة، "
        "وعليها مسح رمز QR الجديد للاتصال مرة أخرى.",
    "Pairing reset. Scan the new code on your devices.":
        "أُعيد تعيين الاقتران. امسح الرمز الجديد على أجهزتك.",
    "The pairing code could not be reset: %s":
        "تعذّرت إعادة تعيين رمز الاقتران: %s",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    return nawaos_i18n.setup(APP_NAME, AR_STRINGS)


_, get_language, is_rtl = _setup_i18n()


class NawaOSCompanionGUI(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("NawaOS Companion"))
        self.set_default_size(700, 400)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_resizable(True)
        
        self.server_process = None
        self.port = 9876
        self.qr_replaced = False
        self.health_timer = None
        self.token_error = None
        try:
            self.token = get_pairing_token()
        except TokenError as e:
            self.token = ""
            self.token_error = str(e)

        # TLS state must mirror the server exactly: same config key ("tls",
        # default true), same cert files, same graceful fallback to plain
        # ws:// when the openssl CLI is unavailable -- so the QR payload and
        # the security notice always describe what the server will really do.
        config = load_server_config()
        self.tls_active = bool(config.get("tls", True))
        self.fingerprint = None
        if self.tls_active:
            if ensure_certificates():
                self.fingerprint = get_cert_fingerprint()
            if not self.fingerprint:
                self.tls_active = False  # same fallback path as the server


        # Apply dark theme
        settings = Gtk.Settings.get_default()
        settings.set_property("gtk-application-prefer-dark-theme", True)
        
        self.load_css()
        # Mirror the layout for right-to-left languages before building widgets.
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)
        self.create_ui()
        self.show_all()
    
    def load_css(self):
        # Thin app-specific layer over the shared NawaOS 2.0 design system
        # (nawaos_theme.BASE_CSS supplies .card, .action-btn-primary, window
        # background, scrollbars, fonts...). Brand tokens only — no legacy
        # palette colors here.
        css = b"""
        /* Hero: brand gradient + subtle dark overlay for text legibility */
        .header-box {
            background-image: linear-gradient(rgba(11, 15, 26, 0.22), rgba(11, 15, 26, 0.22)),
                              linear-gradient(160deg, #1A76BA 0%, #37BCE0 55%, #50E6E2 100%);
            border-radius: 0 0 16px 16px;
            padding: 28px 24px;
        }
        .title-label { color: #ffffff; font-size: 24px; font-weight: 700; }
        .subtitle-label { color: rgba(232, 237, 244, 0.8); font-size: 12px; }

        /* Status card rows (card itself comes from BASE .card) */
        .status-row { min-height: 44px; }
        .status-label { color: #9AA7B8; font-size: 10px; font-weight: 600; letter-spacing: 1.5px; }
        .status-value { color: #E8EDF4; font-size: 15px; font-weight: 700; }
        .status-pill { border-radius: 100px; padding: 3px 14px; font-size: 12px; font-weight: 700; }
        .pill-ok  { background-color: rgba(74, 222, 128, 0.15); color: #4ADE80; }
        .pill-err { background-color: rgba(248, 113, 113, 0.15); color: #F87171; }

        /* QR: white inner tile (QR needs white) framed on an elevated card */
        .qr-card  { padding: 12px; border-radius: 16px; }
        .qr-frame { background: #ffffff; border: none; border-radius: 6px; padding: 12px; }
        .qr-frame label { color: #9AA7B8; }

        /* Pairing code / web-client URL: readable chips on elevated surface */
        .code-chip, .url-chip {
            background-color: #1A2332;
            border: 1px solid rgba(55, 188, 224, 0.35);
            border-radius: 10px;
            font-family: monospace;
        }
        .code-chip { color: #50E6E2; font-size: 22px; font-weight: 700; padding: 10px 20px; }
        .url-chip  { color: #37BCE0; font-size: 14px; font-weight: 600; padding: 8px 14px;
                     border-color: rgba(55, 188, 224, 0.15); }

        .info-text { color: #9AA7B8; font-size: 12px; }
        .warn-text { color: #FBBF24; font-size: 12px; font-weight: 600; }

        /* Buttons: Start = BASE gradient, pill-shaped; Stop = outlined danger pill */
        .action-btn-primary { border-radius: 100px; min-height: 44px; padding: 6px 20px; }
        .stop-btn {
            background: transparent;
            color: #F87171;
            border: 1px solid rgba(248, 113, 113, 0.45);
            border-radius: 100px;
            min-height: 44px;
            padding: 6px 20px;
            font-weight: 600;
            transition: all 150ms ease;
        }
        .stop-btn:hover { background: rgba(248, 113, 113, 0.15); }
        .stop-btn:disabled {
            color: rgba(248, 113, 113, 0.45);
            border-color: rgba(248, 113, 113, 0.2);
        }
        """
        if nawaos_theme is not None:
            nawaos_theme.apply_theme(self, css)
            return
        # Minimal stand-in for BASE_CSS when the shared theme module is absent.
        css += b"""
        window { background-color: #0B0F1A; }
        .card {
            background-color: #1A2332;
            border: 1px solid rgba(55, 188, 224, 0.15);
            border-radius: 10px;
            padding: 16px;
        }
        .action-btn-primary {
            background: linear-gradient(135deg, #1A76BA, #37BCE0);
            color: #ffffff;
            border: none;
            border-radius: 10px;
            padding: 8px 16px;
            font-weight: 600;
        }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def create_ui(self):
        main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(main_box)
        
        # Left Panel - Header/Info
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(280, -1)
        
        # Header — composed brand hero: NawaOS logo + wordmark on the gradient
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        header.get_style_context().add_class("header-box")

        brand_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        brand_row.set_halign(Gtk.Align.CENTER)
        logo_path = "/usr/share/pixmaps/nawaos-logo.png"
        if os.path.exists(logo_path):
            try:
                logo_pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    logo_path, 32, 32, True)
                logo_img = Gtk.Image.new_from_pixbuf(logo_pb)
                logo_img.set_valign(Gtk.Align.CENTER)
                brand_row.pack_start(logo_img, False, False, 0)
            except Exception:
                pass  # missing/corrupt logo: wordmark alone still reads

        title = Gtk.Label(label=_("NawaOS Companion"))
        title.get_style_context().add_class("title-label")
        brand_row.pack_start(title, False, False, 0)
        header.pack_start(brand_row, False, False, 0)

        subtitle = Gtk.Label(label=_("Control your PC from mobile"))
        subtitle.get_style_context().add_class("subtitle-label")
        header.pack_start(subtitle, False, False, 0)

        left_panel.pack_start(header, False, False, 0)

        # Status card in left panel (BASE .card = elevated surface)
        status_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        status_card.get_style_context().add_class("card")
        status_card.set_margin_start(10)
        status_card.set_margin_end(10)
        status_card.set_margin_top(15)
        status_card.set_margin_bottom(10)

        def _status_row(caption):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            row.get_style_context().add_class("status-row")
            lbl = Gtk.Label(label=caption)
            lbl.get_style_context().add_class("status-label")
            lbl.set_halign(Gtk.Align.START)
            lbl.set_valign(Gtk.Align.CENTER)
            row.pack_start(lbl, True, True, 0)
            status_card.pack_start(row, False, False, 0)
            return row

        status_row = _status_row(_("SERVER STATUS"))
        self.status_value = Gtk.Label(label=_("Offline"))
        self.status_value.get_style_context().add_class("status-pill")
        self.status_value.get_style_context().add_class("pill-err")
        self.status_value.set_valign(Gtk.Align.CENTER)
        status_row.pack_end(self.status_value, False, False, 0)

        ip_row = _status_row(_("IP ADDRESS"))
        self.ip_value = Gtk.Label(label=get_local_ip())
        self.ip_value.get_style_context().add_class("status-value")
        self.ip_value.set_halign(Gtk.Align.END)
        self.ip_value.set_valign(Gtk.Align.CENTER)
        ip_row.pack_end(self.ip_value, False, False, 0)

        port_row = _status_row(_("PORT"))
        self.port_value = Gtk.Label(label=str(self.port))
        self.port_value.get_style_context().add_class("status-value")
        self.port_value.set_valign(Gtk.Align.CENTER)
        port_row.pack_end(self.port_value, False, False, 0)

        clients_row = _status_row(_("CONNECTED"))
        # Number of logged-in phones/browsers, from the server's state file
        # (updated by _check_server_health).
        self.clients_value = Gtk.Label(label="0")
        self.clients_value.get_style_context().add_class("status-value")
        self.clients_value.set_valign(Gtk.Align.CENTER)
        clients_row.pack_end(self.clients_value, False, False, 0)

        left_panel.pack_start(status_card, False, False, 0)

        # Buttons in left panel: Start = gradient pill, Stop = danger outline pill
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        btn_box.set_halign(Gtk.Align.CENTER)
        btn_box.set_margin_start(10)
        btn_box.set_margin_end(10)
        btn_box.set_margin_bottom(15)

        self.start_btn = Gtk.Button(label=_("Start"))
        self.start_btn.get_style_context().add_class("action-btn-primary")
        self.start_btn.connect("clicked", self.on_start_clicked)
        btn_box.pack_start(self.start_btn, True, True, 0)

        self.stop_btn = Gtk.Button(label=_("Stop"))
        self.stop_btn.get_style_context().add_class("stop-btn")
        self.stop_btn.connect("clicked", self.on_stop_clicked)
        self.stop_btn.set_sensitive(False)
        btn_box.pack_start(self.stop_btn, True, True, 0)
        
        left_panel.pack_end(btn_box, False, False, 0)
        
        main_box.pack_start(left_panel, False, False, 0)
        
        # Right Panel - QR Code
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        right_panel.set_margin_start(20)
        right_panel.set_margin_end(20)
        right_panel.set_margin_top(20)
        right_panel.set_margin_bottom(20)
        
        # QR Code area
        qr_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        qr_box.set_halign(Gtk.Align.CENTER)
        qr_box.set_valign(Gtk.Align.CENTER)
        
        qr_label = Gtk.Label(label=_("Scan with NawaOS Mobile App"))
        qr_label.get_style_context().add_class("info-text")
        qr_box.pack_start(qr_label, False, False, 0)
        
        # White QR tile (QR needs white) framed on an elevated brand card
        self.qr_frame = Gtk.Frame()
        self.qr_frame.get_style_context().add_class("qr-frame")
        self.qr_placeholder = Gtk.Label(label=_("Start server to show QR"))
        self.qr_placeholder.set_size_request(200, 200)
        self.qr_frame.add(self.qr_placeholder)

        qr_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        qr_card.get_style_context().add_class("card")
        qr_card.get_style_context().add_class("qr-card")
        qr_card.set_halign(Gtk.Align.CENTER)
        qr_card.add(self.qr_frame)
        qr_box.pack_start(qr_card, False, False, 0)

        # Pairing token (manual-entry fallback if the QR cannot be scanned)
        token_caption = Gtk.Label(label=_("Pairing code (enter manually if needed):"))
        token_caption.get_style_context().add_class("info-text")
        token_caption.set_margin_top(10)
        qr_box.pack_start(token_caption, False, False, 0)

        self.token_value = Gtk.Label(label=self.token)
        self.token_value.get_style_context().add_class("code-chip")
        self.token_value.set_selectable(True)
        self.token_value.set_halign(Gtk.Align.CENTER)
        qr_box.pack_start(self.token_value, False, False, 0)

        # Reset pairing: new token, every paired device is disconnected.
        reset_btn = Gtk.Button(label=_("Reset pairing"))
        reset_btn.set_relief(Gtk.ReliefStyle.NONE)
        reset_btn.set_halign(Gtk.Align.CENTER)
        reset_btn.connect("clicked", self.on_reset_pairing_clicked)
        qr_box.pack_start(reset_btn, False, False, 0)

        # Web client URL (served by the companion server on port+1, using the
        # same self-signed certificate as the wss:// endpoint).
        web_caption = Gtk.Label(label=_("Web client (open in your phone's browser):"))
        web_caption.get_style_context().add_class("info-text")
        web_caption.set_margin_top(10)
        qr_box.pack_start(web_caption, False, False, 0)

        web_scheme = "https" if self.tls_active else "http"
        self.web_url_label = Gtk.Label(
            label=f"{web_scheme}://{get_local_ip()}:{self.port + 1}")
        self.web_url_label.get_style_context().add_class("url-chip")
        self.web_url_label.set_selectable(True)
        self.web_url_label.set_halign(Gtk.Align.CENTER)
        qr_box.pack_start(self.web_url_label, False, False, 0)

        # Security notice: with TLS active traffic is encrypted (wss/https,
        # self-signed cert pinned via the fingerprint in the QR); without it
        # the legacy plain-ws warning applies.
        self.warn_label = Gtk.Label()
        self.warn_label.set_justify(Gtk.Justification.CENTER)
        self.warn_label.set_margin_top(10)
        qr_box.pack_start(self.warn_label, False, False, 0)
        self._update_transport_labels()

        right_panel.pack_start(qr_box, True, True, 0)
        
        main_box.pack_start(right_panel, True, True, 0)
    
    def _update_transport_labels(self):
        """Web URL + security notice for self.tls_active/self.fingerprint.
        Before the server starts they describe the configuration; once it
        runs they describe what the server reported (read_server_state)."""
        web_scheme = "https" if self.tls_active else "http"
        self.web_url_label.set_text(
            f"{web_scheme}://{get_local_ip()}:{self.port + 1}")
        if self.tls_active and self.fingerprint:
            warn_text = _("Encrypted (wss:// + https://, self-signed cert)\n"
                          "SHA-256 fingerprint: %s…\n"
                          "Your browser will warn once — accepting the\n"
                          "certificate for the web client also covers wss://"
                          ) % self.fingerprint[:16]
        else:
            warn_text = _("Traffic is unencrypted (plain ws://) —\n"
                          "use only on local networks you trust")
        self.warn_label.set_text(warn_text)
        ctx = self.warn_label.get_style_context()
        ctx.remove_class("info-text")
        ctx.remove_class("warn-text")
        ctx.add_class("info-text" if self.tls_active else "warn-text")

    def on_start_clicked(self, button):
        """Start the server"""
        if self.token_error:
            self.show_error(_("The pairing code could not be created: %s")
                            % self.token_error)
            return
        try:
            # Start server as subprocess
            server_script = "/usr/local/bin/nawaos-companion-server"
            # WHY not stdout/stderr=PIPE: nothing ever drained those pipes, so
            # once the ~64KB pipe buffer filled the server blocked on print()
            # and froze. Send output to a small log file instead (DEVNULL if
            # the log file can't be created).
            log_handle = None
            try:
                log_dir = os.path.join(
                    os.environ.get("XDG_STATE_HOME",
                                   os.path.expanduser("~/.local/state")),
                    "nawaos")
                os.makedirs(log_dir, exist_ok=True)
                log_handle = open(os.path.join(log_dir, "companion-server.log"), "w")
            except OSError:
                log_handle = None
            try:
                self.server_process = subprocess.Popen(
                    ['python3', server_script, str(self.port)],
                    stdout=log_handle if log_handle else subprocess.DEVNULL,
                    stderr=subprocess.STDOUT if log_handle else subprocess.DEVNULL
                )
            finally:
                if log_handle:
                    log_handle.close()  # the child keeps its own duplicate fd
            
            self.status_value.set_text(_("Starting…"))
            self.start_btn.set_sensitive(False)
            self.stop_btn.set_sensitive(True)

            # The QR code and the security notice are shown only once the
            # server reports what it actually serves (TLS or not).
            self._ready_deadline = time.monotonic() + 20
            self.health_timer = GLib.timeout_add(250, self._wait_for_server_ready)

        except Exception as e:
            self.show_error(_("Failed to start server: %s") % e)

    def _server_failed(self, rc):
        self.server_process = None
        self.health_timer = None
        self.status_value.set_text(_("Offline"))
        self.status_value.get_style_context().remove_class("pill-ok")
        self.status_value.get_style_context().add_class("pill-err")
        self.clients_value.set_text("0")
        self.start_btn.set_sensitive(True)
        self.stop_btn.set_sensitive(False)
        self._set_qr_text(_("Start server to show QR"))
        if rc == EXIT_TLS_FAILED:
            self.show_error(_(
                "Encryption could not be set up, so the server was not started.\n\n"
                "Install the openssl package and try again. To run unencrypted on a "
                "network you trust, set \"allow_plaintext\": true in %s.")
                % CONFIG_PATH)
        else:
            self.show_notification(_("Server stopped unexpectedly"))

    def _wait_for_server_ready(self):
        if not self.server_process:
            self.health_timer = None
            return False
        rc = self.server_process.poll()
        if rc is not None:
            self._server_failed(rc)
            return False
        state = read_server_state(pid=self.server_process.pid)
        if state is None:
            if time.monotonic() < self._ready_deadline:
                return True
            self.health_timer = None
            self.on_stop_clicked(None)
            self.show_error(_("The server did not report that it is ready."))
            return False
        self.tls_active = bool(state.get("tls"))
        self.fingerprint = state.get("fingerprint") if self.tls_active else None
        self._update_transport_labels()
        self.status_value.set_text(_("Online"))
        self.status_value.get_style_context().remove_class("pill-err")
        self.status_value.get_style_context().add_class("pill-ok")
        self.generate_qr_code()
        self.show_notification(_("Server started!"))
        self.health_timer = GLib.timeout_add(2000, self._check_server_health)
        return False
    
    def generate_qr_code(self):
        """Generate QR code image"""
        try:
            import qrcode

            ip = get_local_ip()
            # v2.0 pairing URI: nawaos-companion://<ip>:<port>?token=...&fp=<sha256>&tls=1
            # The fp parameter lets the mobile app pin the self-signed cert.
            qr_data = build_connection_uri(
                ip, self.port, self.token,
                fingerprint=self.fingerprint, tls=self.tls_active)

            qr = qrcode.QRCode(version=1, box_size=5, border=2)
            qr.add_data(qr_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")

            # The QR PNG embeds the live auth token. A fixed, world-readable
            # /tmp/nawaos-companion-qr.png lets ANY local user read and decode
            # it, defeating authentication. Write to a per-user, 0600 file under
            # $XDG_RUNTIME_DIR (already user-private) or a uid-qualified /tmp
            # path as a fallback.
            temp_path = os.path.join(
                os.environ.get("XDG_RUNTIME_DIR") or "/tmp",
                f"nawaos-companion-qr-{os.getuid()}.png",
            )
            img.save(temp_path)
            try:
                os.chmod(temp_path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
            except OSError:
                pass

            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(temp_path, 180, 180, True)
            
            # Replace placeholder with QR image
            child = self.qr_frame.get_child()
            if child:
                self.qr_frame.remove(child)
            qr_image = Gtk.Image.new_from_pixbuf(pixbuf)
            self.qr_frame.add(qr_image)
            qr_image.show()
            self.qr_replaced = True
            
        except Exception as e:
            # Fallback to text if QR generation fails: show the same pairing
            # URI the QR would have carried, so manual entry still works.
            self._set_qr_text(build_connection_uri(
                get_local_ip(), self.port, self.token,
                fingerprint=self.fingerprint, tls=self.tls_active))
    
    def _set_qr_text(self, text):
        """Safely set text in QR frame"""
        child = self.qr_frame.get_child()
        if child:
            self.qr_frame.remove(child)
        label = Gtk.Label(label=text)
        label.set_size_request(200, 200)
        label.set_selectable(True)
        # Pairing URIs are long: wrap anywhere so the window doesn't explode.
        label.set_line_wrap(True)
        label.set_line_wrap_mode(2)  # Pango.WrapMode.WORD_CHAR
        label.set_max_width_chars(30)
        self.qr_frame.add(label)
        label.show()
        self.qr_replaced = False
    
    def on_stop_clicked(self, button):
        """Stop the server"""
        if self.health_timer:
            GLib.source_remove(self.health_timer)
            self.health_timer = None
        
        if self.server_process:
            self.server_process.terminate()
            try:
                self.server_process.wait(timeout=3)
            except:
                self.server_process.kill()
            self.server_process = None
        
        self.status_value.set_text(_("Offline"))
        self.status_value.get_style_context().remove_class("pill-ok")
        self.status_value.get_style_context().add_class("pill-err")
        self.clients_value.set_text("0")

        self.start_btn.set_sensitive(True)
        self.stop_btn.set_sensitive(False)
        
        self._set_qr_text(_("Start server to show QR"))
        
        self.show_notification(_("Server stopped"))
    
    def _check_server_health(self):
        """Periodically check if the server process is still alive"""
        if self.server_process:
            ret = self.server_process.poll()
            if ret is not None:
                # Server died unexpectedly
                self._server_failed(ret)
                self.status_value.set_text(_("Crashed"))
                return False
            state = read_server_state(pid=self.server_process.pid) or {}
            self.clients_value.set_text(str(int(state.get("clients", 0) or 0)))
            return True
        self.health_timer = None
        return False

    def on_reset_pairing_clicked(self, _button):
        """Rotate the pairing token after a confirmation. The running server
        notices the new token within a few seconds and disconnects every
        client that logged in with the old one."""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=_("Reset pairing?")
        )
        dialog.format_secondary_text(_(
            "A new pairing code is created. Every paired phone and browser is "
            "disconnected and has to scan the new QR code to connect again."))
        answer = dialog.run()
        dialog.destroy()
        if answer != Gtk.ResponseType.OK:
            return
        try:
            self.token = rotate_pairing_token()
        except TokenError as e:
            self.show_error(_("The pairing code could not be reset: %s") % e)
            return
        self.token_error = None
        self.token_value.set_text(self.token)
        # The QR is shown once the server reported that it is ready; before
        # that, _wait_for_server_ready draws it with the new token anyway.
        if self.server_process and read_server_state(pid=self.server_process.pid):
            self.generate_qr_code()
        self.show_notification(_("Pairing reset. Scan the new code on your devices."))
    
    def show_notification(self, message):
        try:
            notify_companion(_("NawaOS Companion"), message, source="Companion")
        except:
            pass  # Ignore if notification system not available
    
    def show_error(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=_("Error")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def on_destroy(self, widget):
        if self.health_timer:
            GLib.source_remove(self.health_timer)
            self.health_timer = None
        if self.server_process:
            # terminate -> wait -> kill, so closing the window never leaves a
            # zombie/orphaned server process behind.
            self.server_process.terminate()
            try:
                self.server_process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.server_process.kill()
                try:
                    self.server_process.wait(timeout=1)
                except Exception:
                    pass
            self.server_process = None
        Gtk.main_quit()


def main():
    app = NawaOSCompanionGUI()
    app.connect("destroy", app.on_destroy)
    Gtk.main()


if __name__ == "__main__":
    main()
