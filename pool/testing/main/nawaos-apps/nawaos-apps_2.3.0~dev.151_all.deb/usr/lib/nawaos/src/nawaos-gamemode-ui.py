#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NawaOS Game Mode UI
Full-screen controller-first interface inspired by console-style gaming
Designed for handheld gaming PCs (ROG Ally, Legion Go, Steam Deck, etc.)

Developed by: Ahmed Abdulla
Copyright (c) 2025-2026 Ahmed Abdulla - All rights reserved
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Pango
import subprocess
import os
import sys
import json
import glob
import shlex
import shutil
import threading
import time
import struct
from pathlib import Path


try:
    import nawaos_theme
except ImportError:
    nawaos_theme = None

# Release info shared by all NawaOS apps (nawaos-common/nawaos_release.py).
try:
    import nawaos_release
except ImportError:
    nawaos_release = None

# Shared NawaOS modules (nawaos_i18n, nawaos_notify, ...) are installed to
# dist-packages; from a source checkout they are in ../nawaos-common.
_NAWAOS_COMMON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "nawaos-common")
if os.path.isdir(_NAWAOS_COMMON) and _NAWAOS_COMMON not in sys.path:
    sys.path.append(_NAWAOS_COMMON)
import nawaos_i18n  # noqa: E402
from nawaos_notify import notify_gaming  # noqa: E402

try:
    import nawaos_games
except ImportError:
    nawaos_games = None

# Shared handheld knowledge (device detection, js->evdev button mapping).
try:
    import nawaos_handheld
except ImportError:
    nawaos_handheld = None

# ========================================
# CONSTANTS
# ========================================
APP_NAME = "NawaOS Game Mode"
CONFIG_DIR = os.path.expanduser("~/.config/nawaos/gamemode")
RECENT_FILE = os.path.join(CONFIG_DIR, "recent.json")


def get_os_version():
    """NawaOS version (VERSION_ID), via nawaos_release."""
    return nawaos_release.version() if nawaos_release else ""


VERSION = get_os_version()

# The handheld daemon keeps its own config; some Game Mode settings must be
# mirrored there so toggling them actually changes the daemon's behaviour.
HANDHELD_CONFIG_DIR = os.path.expanduser("~/.config/nawaos/handheld")
HANDHELD_CONFIG_FILE = os.path.join(HANDHELD_CONFIG_DIR, "config.json")
# Game Mode setting key -> handheld daemon config key.
DAEMON_SETTING_MAP = {
    "auto_gamemode": "auto_gamemode_on_boot",
    "auto_tdp": "auto_tdp",
}

# Controller input event codes (evdev)
BTN_A = 304      # Confirm / Select
BTN_B = 305      # Back / Cancel
BTN_X = 307      # Quick Action
BTN_Y = 308      # Menu
BTN_LB = 310      # Left bumper (BTN_TL)
BTN_RB = 311      # Right bumper (BTN_TR)
BTN_START = 315   # Menu / Options
BTN_SELECT = 314  # View
BTN_GUIDE = 316   # Home / Steam button (BTN_MODE)
DPAD_UP = -2
DPAD_DOWN = -3
DPAD_LEFT = -4
DPAD_RIGHT = -5
DPAD_DIRECTIONS = {
    DPAD_UP: Gtk.DirectionType.UP,
    DPAD_DOWN: Gtk.DirectionType.DOWN,
    DPAD_LEFT: Gtk.DirectionType.LEFT,
    DPAD_RIGHT: Gtk.DirectionType.RIGHT,
}

# A held Guide belongs to the handheld daemon (switch modes); this UI acts on
# a shorter press only, on release.
GUIDE_HOLD_SECONDS = nawaos_handheld.GUIDE_HOLD_SECONDS if nawaos_handheld is not None else 1.0

# Joystick-API button index -> evdev code for the standard Xbox xpad layout.
# WHY: js indices are NOT evdev codes; the old `number + 304` arithmetic
# mapped Guide (js index 8) to 312 instead of BTN_MODE (316) so exit-to-
# desktop never fired, and X/Y/LB/RB were misassigned (evdev skips codes
# 306/309/312/313 in this range).
if nawaos_handheld is not None:
    XPAD_JS_BUTTONS = nawaos_handheld.XPAD_JS_BUTTONS
else:
    XPAD_JS_BUTTONS = {
        0: BTN_A,
        1: BTN_B,
        2: BTN_X,
        3: BTN_Y,
        4: BTN_LB,
        5: BTN_RB,
        6: BTN_SELECT,   # Back / View
        7: BTN_START,
        8: BTN_GUIDE,
        9: 317,          # BTN_THUMBL
        10: 318,         # BTN_THUMBR
    }

# ========================================
# I18N
# ========================================
I18N_APP_NAME = "nawaos-gamemode-ui"

# Built-in Arabic strings. Every user-visible string goes through _() with
# this dictionary; packagers can override entries via /usr/share/nawaos/i18n.
AR_STRINGS = {
    "NawaOS Game Mode": "وضع الألعاب NawaOS",
    "Game Mode": "وضع الألعاب",
    "Library": "المكتبة",
    "Quick Launch": "التشغيل السريع",
    "Performance": "الأداء",
    "Settings": "الإعدادات",
    "Exit to Desktop": "الخروج إلى سطح المكتب",
    "Select": "اختيار",
    "Back": "رجوع",
    "Switch Tab": "تبديل التبويب",
    "Scanning for games...": "جارٍ البحث عن الألعاب...",
    "No games found": "لم يُعثر على ألعاب",
    "Install Steam, Lutris, or Flatpak games to see them here":
        "ثبّت ألعاب Steam أو Lutris أو فلاتباك لتظهر هنا",
    "Recent": "الأخيرة",
    "Steam Games": "ألعاب Steam",
    "Lutris Games": "ألعاب Lutris",
    "Flatpak Apps": "تطبيقات فلاتباك",
    "Native Games": "الألعاب الأصلية",
    "%d games": "%d ألعاب",
    "Launch apps and tools with one button press":
        "شغّل التطبيقات والأدوات بضغطة زر واحدة",
    "Steam client": "عميل Steam",
    "Game manager": "مدير الألعاب",
    "Retro emulator": "محاكي الألعاب الكلاسيكية",
    "Windows apps": "تطبيقات Windows",
    "Desktop Mode": "وضع سطح المكتب",
    "Switch to desktop": "التبديل إلى سطح المكتب",
    "Toggle overlay": "تبديل الطبقة العلوية",
    "Control Panel": "لوحة التحكم",
    "System settings": "إعدادات النظام",
    "Game Mode On": "تشغيل وضع الألعاب",
    "Max performance": "أقصى أداء",
    "Game Mode Off": "إيقاف وضع الألعاب",
    "Balanced mode": "الوضع المتوازن",
    "Controller mapping": "تعيين أزرار وحدة التحكم",
    "Companion": "المرافق",
    "Phone control": "التحكم من الهاتف",
    "CPU Temp": "حرارة المعالج",
    "GPU Temp": "حرارة بطاقة الرسوميات",
    "CPU Usage": "استخدام المعالج",
    "RAM": "الذاكرة",
    "TDP Control": "التحكم في TDP",
    "Handheld detected: %s": "تم اكتشاف جهاز محمول: %s",
    "Adjust power limit for battery vs performance trade-off":
        "اضبط حد الطاقة للموازنة بين البطارية والأداء",
    "Silent": "صامت",
    "Minimal fan noise": "أقل ضجيج للمروحة",
    "Battery": "البطارية",
    "Max battery life": "أطول عمر للبطارية",
    "Balanced": "متوازن",
    "Good performance": "أداء جيد",
    "Maximum FPS": "أقصى FPS",
    "Boost": "تعزيز",
    "Short burst": "دفعة قصيرة",
    "Performance Profile": "ملف الأداء",
    "Power Saver": "توفير الطاقة",
    "Default balanced mode": "الوضع المتوازن الافتراضي",
    "Gaming": "الألعاب",
    "Max CPU/GPU performance": "أقصى أداء للمعالج وبطاقة الرسوميات",
    "Auto-start Game Mode": "بدء وضع الألعاب تلقائياً",
    "Start in Game Mode on handheld devices":
        "البدء في وضع الألعاب على الأجهزة المحمولة",
    "MangoHud Overlay": "طبقة MangoHud",
    "Show FPS and performance overlay in games":
        "إظهار طبقة FPS والأداء داخل الألعاب",
    "GameScope Compositor": "مؤلّف GameScope",
    "Use Valve's gaming compositor for better scaling":
        "استخدم مؤلّف Valve للألعاب لتحجيم أفضل",
    "Auto TDP": "TDP تلقائي",
    "Automatically adjust TDP based on game demand":
        "ضبط TDP تلقائياً حسب متطلبات اللعبة",
    "Switch to Desktop Mode": "التبديل إلى وضع سطح المكتب",
    "Shutdown": "إيقاف التشغيل",
    "Reboot": "إعادة التشغيل",
    "Launching": "جارٍ التشغيل",
    "Launch Failed": "فشل التشغيل",
    "Toggle via MANGOHUD=1 when launching games":
        "فعّلها عبر MANGOHUD=1 عند تشغيل الألعاب",
    "Performance mode enabled": "تم تفعيل وضع الأداء",
    "Balanced mode restored": "تمت استعادة الوضع المتوازن",
    "Power limit set to %dW": "تم ضبط حد الطاقة على %dW",
    "Failed to set TDP (not applied).": "فشل ضبط TDP (لم يُطبَّق).",
    "Switched to %s profile": "تم التبديل إلى ملف %s",
    "N/A": "غير متاح",
    "%s%% (charging)": "%s%% (قيد الشحن)",
    "{used}/{total} GB": "{used}/{total} GB",
    "Shut down the device?": "هل تريد إيقاف تشغيل الجهاز؟",
    "Restart the device?": "هل تريد إعادة تشغيل الجهاز؟",
    "Unsaved progress in open games will be lost.":
        "سيضيع أي تقدّم غير محفوظ في الألعاب المفتوحة.",
    "D-pad: choose, A: confirm, B: cancel":
        "أزرار الاتجاه: اختيار، A: تأكيد، B: إلغاء",
    "Cancel": "إلغاء",
}


def _setup_i18n():
    """Arabic/English through the shared nawaos_i18n module."""
    return nawaos_i18n.setup(I18N_APP_NAME, AR_STRINGS)


_, get_language, is_rtl = _setup_i18n()

# ========================================
# CSS THEME - Dark Gaming UI
# ========================================
CSS = """
/* NawaOS Game Mode - thin brand console layer over the shared BASE_CSS */
window.gamemode-window, .gm-content { background-color: #0B0F1A; }

.gm-header {
    background: linear-gradient(180deg, rgba(17,24,39,0.95) 0%, rgba(11,15,26,0.9) 100%);
    padding: 16px 32px;
}
.gm-clock { color: #E8EDF4; font-size: 28px; font-weight: bold; font-family: monospace; }
.gm-status-text, .gm-section-desc { color: #9AA7B8; font-size: 13px; }
.gm-game-source { color: #9AA7B8; font-size: 11px; }
.gm-perf-label, .gm-hint-text { color: #9AA7B8; font-size: 12px; }
.gm-empty-text { color: #9AA7B8; font-size: 16px; }

.gm-nav-bar { background-color: rgba(17,24,39,0.7); padding: 0; }
.gm-nav-btn {
    background: transparent; border: none;
    border-bottom: 3px solid transparent; border-radius: 0;
    font-size: 15px; font-weight: 600;
    padding: 12px 28px; min-width: 120px; min-height: 44px;
}
.gm-nav-btn, .gm-nav-btn label, .gm-nav-btn image { color: #9AA7B8; }
.gm-nav-btn:hover { background: rgba(55, 188, 224, 0.06); }
.gm-nav-btn:hover label, .gm-nav-btn:hover image { color: #E8EDF4; }
.gm-nav-btn.active-tab {
    border-bottom: 3px solid #37BCE0;
    background: rgba(55, 188, 224, 0.10);
}
.gm-nav-btn.active-tab label, .gm-nav-btn.active-tab image { color: #37BCE0; }

.gm-title-underline { background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2); border-radius: 100px; min-height: 3px; }

.gm-game-card {
    background: #1A2332; border-radius: 12px;
    border: 2px solid rgba(55, 188, 224, 0.08);
    padding: 0; min-width: 200px; min-height: 260px;
}
.gm-game-card:hover, .gm-game-card:focus, flowboxchild:focus > .gm-game-card {
    border-color: #37BCE0; box-shadow: 0 0 20px rgba(55, 188, 224, 0.15);
}
.gm-game-card.selected {
    border-color: #37BCE0; background: #232D3F;
    box-shadow: 0 0 25px rgba(55, 188, 224, 0.20);
}
.gm-game-cover { border-radius: 12px 12px 0 0; }
.gm-game-title { color: #E8EDF4; font-size: 13px; font-weight: bold; }
.gm-section-title { color: #E8EDF4; font-size: 24px; font-weight: 700; }

.gm-quick-btn, .gm-profile-btn {
    background: #1A2332; border: 1px solid rgba(55, 188, 224, 0.08);
    border-radius: 12px; font-size: 14px;
}
.gm-quick-btn { padding: 20px; min-width: 160px; min-height: 100px; }
.gm-profile-btn { padding: 16px 24px; }
.gm-quick-btn label, .gm-profile-btn label,
.gm-quick-btn image, .gm-profile-btn image { color: #E8EDF4; }
.gm-quick-btn:hover, .gm-quick-btn:focus, .gm-quick-btn.selected,
flowboxchild:focus > .gm-quick-btn,
.gm-profile-btn:hover, .gm-profile-btn:focus {
    background: #232D3F; border-color: #37BCE0;
    box-shadow: 0 0 14px rgba(55, 188, 224, 0.12);
}
.gm-profile-btn.active-profile {
    border-color: #4ADE80; background: rgba(74, 222, 128, 0.10);
}

.gm-performance-card {
    background: #1A2332; border-radius: 12px;
    border: 1px solid rgba(55, 188, 224, 0.08); padding: 20px;
}
.gm-perf-value { color: #37BCE0; font-size: 28px; font-weight: bold; }

.gm-tdp-slider trough { background-color: #111827; min-height: 8px; border-radius: 100px; }
.gm-tdp-slider highlight { background: linear-gradient(90deg, #1A76BA, #37BCE0, #50E6E2); border-radius: 100px; }
.gm-tdp-slider slider { background-color: #37BCE0; min-width: 20px; min-height: 20px; border-radius: 100px; }

.gm-footer { background: rgba(17,24,39,0.85); padding: 8px 32px; }
.gm-hint-key { color: #37BCE0; font-size: 12px; font-weight: bold; }

.gm-exit-btn {
    background: transparent; border: none; border-radius: 100px;
    font-size: 18px; font-weight: bold;
    padding: 6px 14px; min-width: 36px; min-height: 36px;
}
.gm-exit-btn, .gm-exit-btn label { color: #F87171; }
.gm-exit-btn:hover { background: rgba(248, 113, 113, 0.15); }
"""


# ========================================
# GAME SCANNER
# ========================================
class GameScanner:
    """Scans for installed games.

    Discovery logic now lives in the shared ``nawaos_games`` module so it stays
    in sync with the Gaming Center. The ``scan_*`` methods below are kept only as
    a fallback for the (deployment-guaranteed but defensive) case where the
    shared module is unavailable.
    """

    @staticmethod
    def scan_all():
        if nawaos_games is not None:
            # Shared scanner returns rich Game objects; adapt to the dict shape
            # this UI consumes (name/source/app_id/launch/icon/cover).
            return [g.as_dict() for g in nawaos_games.scan_all(include_desktop=True)]
        # --- Fallback: local scanners (only if shared module is missing) ---
        games = []
        games.extend(GameScanner.scan_steam())
        games.extend(GameScanner.scan_lutris())
        games.extend(GameScanner.scan_flatpak_games())
        games.extend(GameScanner.scan_desktop_games())
        return games

    # Steam library roots used both for manifests and cached cover art.
    STEAM_ROOTS = [
        Path.home() / '.steam' / 'steam',
        Path.home() / '.local' / 'share' / 'Steam',
    ]

    @staticmethod
    def _find_steam_cover(appid):
        """Locate Steam's cached vertical cover art for an app id, if present.

        Handles both the modern per-appid sub-folder layout and the older
        flat ``<appid>_library_600x900.jpg`` naming.
        """
        if not appid:
            return None
        for root in GameScanner.STEAM_ROOTS:
            cache = root / 'appcache' / 'librarycache'
            candidates = [
                cache / appid / 'library_600x900.jpg',
                cache / f'{appid}_library_600x900.jpg',
                cache / appid / 'logo.png',
                cache / f'{appid}_header.jpg',
            ]
            for c in candidates:
                if c.exists():
                    return str(c)
        return None

    @staticmethod
    def scan_steam():
        games = []
        steam_paths = [root / 'steamapps' for root in GameScanner.STEAM_ROOTS]
        for sp in steam_paths:
            if not sp.exists():
                continue
            for manifest in sp.glob('appmanifest_*.acf'):
                try:
                    text = manifest.read_text()
                    name = ""
                    appid = ""
                    for line in text.split('\n'):
                        if '"name"' in line:
                            name = line.split('"')[3]
                        if '"appid"' in line:
                            appid = line.split('"')[3]
                    if name and 'Proton' not in name and 'Steamworks' not in name:
                        games.append({
                            "name": name,
                            "source": "steam",
                            "app_id": appid,
                            "launch": f"steam steam://rungameid/{appid}",
                            "icon": "steam",
                            "cover": GameScanner._find_steam_cover(appid),
                        })
                except:
                    pass
        return games

    @staticmethod
    def scan_lutris():
        games = []
        db_path = Path.home() / '.local' / 'share' / 'lutris' / 'pga.db'
        if db_path.exists():
            try:
                import sqlite3
                conn = sqlite3.connect(str(db_path))
                cursor = conn.execute("SELECT name, slug, runner FROM games WHERE installed=1")
                for row in cursor:
                    games.append({
                        "name": row[0],
                        "source": "lutris",
                        "app_id": row[1],
                        "launch": f"lutris lutris:rungame/{row[1]}",
                        "icon": "lutris",
                    })
                conn.close()
            except:
                pass
        return games

    @staticmethod
    def scan_flatpak_games():
        games = []
        try:
            result = subprocess.run(
                ['flatpak', 'list', '--app', '--columns=application,name'],
                capture_output=True, text=True, timeout=10
            )
            gaming_ids = ['game', 'emulator', 'retroarch', 'pcsx2', 'dolphin',
                          'duckstation', 'ppsspp', 'rpcs3',
                          'xemu', 'bottles', 'heroic', 'lutris']
            for line in result.stdout.strip().split('\n'):
                parts = line.split('\t')
                if len(parts) >= 2:
                    app_id = parts[0].strip()
                    name = parts[1].strip()
                    if any(g in app_id.lower() for g in gaming_ids):
                        games.append({
                            "name": name,
                            "source": "flatpak",
                            "app_id": app_id,
                            "launch": f"flatpak run {app_id}",
                            "icon": "flatpak",
                        })
        except:
            pass
        return games

    @staticmethod
    def scan_desktop_games():
        games = []
        dirs = [
            '/usr/share/applications',
            os.path.expanduser('~/.local/share/applications'),
        ]
        game_categories = ['Game', 'ActionGame', 'AdventureGame', 'ArcadeGame',
                           'BoardGame', 'Emulator', 'RolePlaying', 'Simulation',
                           'SportsGame', 'StrategyGame']
        # Exclude NawaOS system apps and non-game utilities
        exclude_names = [
            'nawaos', 'game center', 'game mode', 'control panel',
            'lxterminal', 'terminal', 'goverlay', 'mangohud',
            'file manager', 'text editor', 'settings', 'system monitor',
            'task manager', 'software', 'update', 'installer',
        ]
        exclude_files = [
            'nawaos-', 'org.gnome.', 'org.xfce.', 'lxterminal',
            'nemo.desktop', 'cinnamon-settings', 'synaptic',
        ]
        for d in dirs:
            if not os.path.isdir(d):
                continue
            for f in os.listdir(d):
                if not f.endswith('.desktop'):
                    continue
                # Skip known non-game desktop files
                if any(ex in f.lower() for ex in exclude_files):
                    continue
                try:
                    filepath = os.path.join(d, f)
                    name = ""
                    exe = ""
                    cats = ""
                    with open(filepath, 'r', errors='ignore') as df:
                        for line in df:
                            if line.startswith('Name=') and not name:
                                name = line.strip().split('=', 1)[1]
                            elif line.startswith('Exec='):
                                exe = line.strip().split('=', 1)[1]
                            elif line.startswith('Categories='):
                                cats = line.strip().split('=', 1)[1]
                    if name and exe and any(c in cats for c in game_categories):
                        # Skip if already found via Steam/Lutris
                        if 'steam' in exe.lower() or 'lutris' in exe.lower():
                            continue
                        # Skip NawaOS system apps and utilities
                        if any(ex in name.lower() for ex in exclude_names):
                            continue
                        games.append({
                            "name": name,
                            "source": "native",
                            "app_id": f,
                            "launch": exe.split('%')[0].strip(),
                            "icon": "applications-games",
                        })
                except:
                    pass
        return games


# ========================================
# CONTROLLER INPUT HANDLER
# ========================================
class ControllerInput:
    """Reads gamepad input via /dev/input/js* for controller-first navigation."""

    def __init__(self, callback):
        self.callback = callback
        self.running = False
        self.thread = None
        # Edge-trigger state for the left analog stick so a held direction
        # does not flood the UI with repeated navigation events.
        self._stick_x_latched = False
        self._stick_y_latched = False
        self._guide_down_at = None  # js timestamp (ms) of the Guide press

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._read_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def _find_joystick(self):
        devices = sorted(glob.glob('/dev/input/js*'))
        return devices[0] if devices else None

    def _read_loop(self):
        while self.running:
            dev = self._find_joystick()
            if not dev:
                time.sleep(2)
                continue
            try:
                with open(dev, 'rb') as f:
                    while self.running:
                        data = f.read(8)
                        if len(data) < 8:
                            break
                        timestamp, value, evt_type, number = struct.unpack('IhBB', data)

                        # WHY: JS_EVENT_INIT (0x80) marks synthetic initial-
                        # state events emitted on open; treating them as real
                        # presses fired phantom actions the moment the UI
                        # (re)opened the device.
                        if evt_type & 0x80:
                            continue

                        # Button press (type 1), translated through the xpad
                        # mapping table (js index -> evdev button code).
                        code = XPAD_JS_BUTTONS.get(number) if evt_type == 0x01 else None
                        if code == BTN_GUIDE:
                            # Short press only (on release): a hold switches
                            # modes in the handheld daemon instead.
                            if value == 1:
                                self._guide_down_at = timestamp
                            elif self._guide_down_at is not None:
                                held = ((timestamp - self._guide_down_at) & 0xFFFFFFFF) / 1000.0
                                self._guide_down_at = None
                                if held < GUIDE_HOLD_SECONDS:
                                    GLib.idle_add(self.callback, code)
                        elif code is not None and value == 1:
                            GLib.idle_add(self.callback, code)

                        # Axis (type 2) - D-pad and left analog stick
                        if evt_type == 0x02:
                            if number == 6:  # D-pad horizontal
                                if value < -16000:
                                    GLib.idle_add(self.callback, DPAD_LEFT)
                                elif value > 16000:
                                    GLib.idle_add(self.callback, DPAD_RIGHT)
                            elif number == 7:  # D-pad vertical
                                if value < -16000:
                                    GLib.idle_add(self.callback, DPAD_UP)
                                elif value > 16000:
                                    GLib.idle_add(self.callback, DPAD_DOWN)
                            elif number == 0:  # Left stick horizontal
                                if value < -24000 and not self._stick_x_latched:
                                    self._stick_x_latched = True
                                    GLib.idle_add(self.callback, DPAD_LEFT)
                                elif value > 24000 and not self._stick_x_latched:
                                    self._stick_x_latched = True
                                    GLib.idle_add(self.callback, DPAD_RIGHT)
                                elif -8000 < value < 8000:
                                    self._stick_x_latched = False
                            elif number == 1:  # Left stick vertical
                                if value < -24000 and not self._stick_y_latched:
                                    self._stick_y_latched = True
                                    GLib.idle_add(self.callback, DPAD_UP)
                                elif value > 24000 and not self._stick_y_latched:
                                    self._stick_y_latched = True
                                    GLib.idle_add(self.callback, DPAD_DOWN)
                                elif -8000 < value < 8000:
                                    self._stick_y_latched = False
            except (IOError, OSError):
                time.sleep(2)


# ========================================
# SYSTEM INFO HELPER
# ========================================
class SystemInfo:
    """Reads system performance info."""

    @staticmethod
    def get_cpu_temp():
        try:
            for path in glob.glob('/sys/class/thermal/thermal_zone*/temp'):
                with open(path) as f:
                    temp = int(f.read().strip()) / 1000
                    if temp > 0:
                        return f"{temp:.0f}°C"
        except:
            pass
        return _("N/A")

    @staticmethod
    def get_gpu_temp():
        try:
            # AMD
            for path in glob.glob('/sys/class/drm/card*/device/hwmon/hwmon*/temp1_input'):
                with open(path) as f:
                    return f"{int(f.read().strip()) / 1000:.0f}°C"
        except:
            pass
        try:
            result = subprocess.run(['nvidia-smi', '--query-gpu=temperature.gpu',
                                     '--format=csv,noheader'], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                return f"{result.stdout.strip()}°C"
        except:
            pass
        return _("N/A")

    @staticmethod
    def get_battery():
        try:
            for bat in glob.glob('/sys/class/power_supply/BAT*'):
                cap_file = os.path.join(bat, 'capacity')
                status_file = os.path.join(bat, 'status')
                if os.path.exists(cap_file):
                    with open(cap_file) as f:
                        cap = f.read().strip()
                    status = ""
                    if os.path.exists(status_file):
                        with open(status_file) as f:
                            status = f.read().strip()
                    if status == "Charging":
                        return _("%s%% (charging)") % cap
                    return f"{cap}%"
        except:
            pass
        return None

    @staticmethod
    def get_cpu_usage():
        try:
            with open('/proc/stat') as f:
                parts = f.readline().split()
                idle = int(parts[4])
                total = sum(int(x) for x in parts[1:])
            time.sleep(0.1)
            with open('/proc/stat') as f:
                parts = f.readline().split()
                idle2 = int(parts[4])
                total2 = sum(int(x) for x in parts[1:])
            usage = 100 * (1 - (idle2 - idle) / max(1, total2 - total))
            return f"{usage:.0f}%"
        except:
            return _("N/A")

    @staticmethod
    def get_ram_usage():
        try:
            with open('/proc/meminfo') as f:
                lines = f.readlines()
            mem = {}
            for line in lines:
                parts = line.split(':')
                if len(parts) == 2:
                    mem[parts[0].strip()] = int(parts[1].strip().split()[0])
            total = mem.get('MemTotal', 0) / 1024 / 1024
            avail = mem.get('MemAvailable', 0) / 1024 / 1024
            used = total - avail
            return _("{used}/{total} GB").format(
                used=f"{used:.1f}", total=f"{total:.1f}")
        except:
            return _("N/A")

    @staticmethod
    def get_current_tdp():
        try:
            for path in glob.glob('/sys/class/powercap/intel-rapl:0/constraint_0_power_limit_uw'):
                with open(path) as f:
                    return int(f.read().strip()) / 1000000
        except:
            pass
        try:
            for path in glob.glob('/sys/devices/platform/asus-nb-wmi/ppt_*'):
                with open(path) as f:
                    return int(f.read().strip())
        except:
            pass
        return None

    @staticmethod
    def is_handheld():
        """Detect if running on a known handheld device.

        Canonical detection (device table incl. product_family checks) lives
        in the shared nawaos_handheld module; the inline list below is only a
        minimal fallback for dev runs without it.
        """
        if nawaos_handheld is not None:
            detected, name, _profile = nawaos_handheld.detect()
            return detected, name
        known_handhelds = [
            'ROG Ally', 'Legion Go', 'Steam Deck', 'AYANEO', 'GPD',
            'ONEXPLAYER', 'AYA NEO', 'AOKZOE', 'Lenovo Legion Go',
            'ASUS ROG Ally', 'MSI Claw',
        ]
        try:
            for path in ['/sys/class/dmi/id/product_name', '/sys/class/dmi/id/board_name',
                         '/sys/class/dmi/id/product_family']:
                if os.path.exists(path):
                    with open(path) as f:
                        name = f.read().strip()
                        for h in known_handhelds:
                            if h.lower() in name.lower():
                                return True, name
        except:
            pass
        return False, "Desktop"


# ========================================
# GAME MODE WINDOW
# ========================================
class GameModeWindow(Gtk.Window):

    def __init__(self):
        super().__init__(title=_(APP_NAME))
        self.set_default_size(1280, 800)
        self.fullscreen()
        self.get_style_context().add_class("gamemode-window")

        # Apply CSS via the shared NawaOS theme (fallback to local provider).
        if nawaos_theme is not None:
            nawaos_theme.apply_theme(self, CSS)
        else:
            css_provider = Gtk.CssProvider()
            css_provider.load_from_data(CSS.encode())
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

        os.makedirs(CONFIG_DIR, exist_ok=True)

        # State
        self.current_tab = 0
        self.tabs = [_("Library"), _("Quick Launch"), _("Performance"), _("Settings")]
        self.tab_buttons = []
        self.games = []
        self.selected_game_idx = 0
        self.selected_quick_idx = 0
        self.recent_games = self._load_recent()
        self.is_handheld, self.device_name = SystemInfo.is_handheld()
        self._confirm_dialog = None  # open Shutdown/Reboot confirmation
        self._last_launch = (None, 0.0)  # (app_id, time.monotonic())

        # Controller input
        self.controller = ControllerInput(self.on_controller_input)
        self.controller.start()

        # Keyboard navigation
        self.connect("key-press-event", self.on_key_press)

        # WHY: track fullscreen state with a boolean fed by window-state-event;
        # is_maximized() reports maximization, not fullscreen, so the F11
        # toggle used to get the state wrong.
        self._is_fullscreen = False
        self.connect("window-state-event", self.on_window_state)

        # Mirror the layout for right-to-left languages before building widgets.
        if is_rtl():
            Gtk.Widget.set_default_direction(Gtk.TextDirection.RTL)

        self._build_ui()
        self._scan_games_async()
        self._start_clock()

    def _build_ui(self):
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(self.main_box)

        # --- Header bar ---
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        header.get_style_context().add_class("gm-header")

        # Logo + version pill
        logo_label = Gtk.Label()
        logo_label.set_markup('<span foreground="#37BCE0" font="20" weight="bold">NawaOS</span>'
                              '<span foreground="#9AA7B8" font="14">  %s</span>' % _("Game Mode"))
        header.pack_start(logo_label, False, False, 0)

        version_badge = Gtk.Label(label=VERSION)
        version_badge.get_style_context().add_class("pill-badge")
        version_badge.set_valign(Gtk.Align.CENTER)
        header.pack_start(version_badge, False, False, 10)

        # Spacer
        header.pack_start(Gtk.Box(), True, True, 0)

        # Status area
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)

        # Battery (if handheld)
        self.battery_label = Gtk.Label()
        self.battery_label.get_style_context().add_class("gm-status-text")
        status_box.pack_start(self.battery_label, False, False, 0)

        # Device
        if self.is_handheld:
            dev_label = Gtk.Label()
            dev_label.set_markup(f'<span foreground="#4ADE80" font="12">{self.device_name}</span>')
            status_box.pack_start(dev_label, False, False, 0)

        # Clock
        self.clock_label = Gtk.Label()
        self.clock_label.get_style_context().add_class("gm-clock")
        status_box.pack_start(self.clock_label, False, False, 0)

        header.pack_end(status_box, False, False, 0)

        # Close / Exit button
        exit_btn = Gtk.Button(label="✕")
        exit_btn.get_style_context().add_class("gm-exit-btn")
        exit_btn.set_can_focus(False)
        exit_btn.connect("clicked", self.on_switch_desktop)
        exit_btn.set_tooltip_text(_("Exit to Desktop"))
        header.pack_end(exit_btn, False, False, 12)

        self.main_box.pack_start(header, False, False, 0)

        # --- Navigation bar ---
        nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        nav.get_style_context().add_class("gm-nav-bar")

        tab_icons = ["view-grid-symbolic", "media-playback-start-symbolic",
                     "utilities-system-monitor-symbolic", "preferences-system-symbolic"]
        for i, tab in enumerate(self.tabs):
            btn = Gtk.Button()
            tab_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            tab_box.set_halign(Gtk.Align.CENTER)
            icon = Gtk.Image.new_from_icon_name(tab_icons[i], Gtk.IconSize.MENU)
            tab_box.pack_start(icon, False, False, 0)
            tab_box.pack_start(Gtk.Label(label=tab), False, False, 0)
            btn.add(tab_box)
            btn.get_style_context().add_class("gm-nav-btn")
            if i == 0:
                btn.get_style_context().add_class("active-tab")
            btn.connect("clicked", self.on_tab_clicked, i)
            btn.set_can_focus(False)
            nav.pack_start(btn, False, False, 0)
            self.tab_buttons.append(btn)

        self.main_box.pack_start(nav, False, False, 0)

        # --- Content stack ---
        self.content_stack = Gtk.Stack()
        self.content_stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.content_stack.set_transition_duration(200)
        self.content_stack.get_style_context().add_class("gm-content")

        self.content_stack.add_named(self._build_library_page(), "library")
        self.content_stack.add_named(self._build_quick_launch_page(), "quick")
        self.content_stack.add_named(self._build_performance_page(), "performance")
        self.content_stack.add_named(self._build_settings_page(), "settings")

        self.main_box.pack_start(self.content_stack, True, True, 0)

        # --- Footer hints ---
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        footer.get_style_context().add_class("gm-footer")

        hints = [
            ("A / Enter", _("Select")),
            ("B / Esc", _("Back")),
            ("LB/RB", _("Switch Tab")),
            ("Guide", _("Exit to Desktop")),
        ]
        for key, action in hints:
            hint_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            k = Gtk.Label(label=key)
            k.get_style_context().add_class("gm-hint-key")
            hint_box.pack_start(k, False, False, 0)
            a = Gtk.Label(label=action)
            a.get_style_context().add_class("gm-hint-text")
            hint_box.pack_start(a, False, False, 0)
            footer.pack_start(hint_box, False, False, 0)

        self.main_box.pack_start(footer, False, False, 0)

    # ========================================
    # SHARED VISUAL HELPERS
    # ========================================
    @staticmethod
    def _section_title(text):
        """24px/700 section title with a short brand-gradient underline."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        lbl = Gtk.Label(label=text)
        lbl.get_style_context().add_class("gm-section-title")
        lbl.set_halign(Gtk.Align.START)
        box.pack_start(lbl, False, False, 0)
        bar = Gtk.Box()
        bar.get_style_context().add_class("gm-title-underline")
        bar.set_size_request(44, 3)
        bar.set_halign(Gtk.Align.START)
        box.pack_start(bar, False, False, 0)
        return box

    # ========================================
    # LIBRARY PAGE
    # ========================================
    def _build_library_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self.library_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.library_box.set_margin_top(20)
        self.library_box.set_margin_start(32)
        self.library_box.set_margin_end(32)

        # Loading indicator
        self.loading_label = Gtk.Label()
        self.loading_label.set_markup(
            '<span foreground="#9AA7B8" font="14">%s</span>' % _("Scanning for games..."))
        self.library_box.pack_start(self.loading_label, True, True, 40)

        scrolled.add(self.library_box)
        # Scroll the page to whatever the D-pad focuses.
        self.library_box.set_focus_vadjustment(scrolled.get_vadjustment())
        page.pack_start(scrolled, True, True, 0)
        return page

    def _populate_library(self):
        # Clear
        for child in self.library_box.get_children():
            self.library_box.remove(child)

        if not self.games:
            empty = Gtk.Label()
            empty.set_markup(
                '<span foreground="#E8EDF4" font="16">%s</span>\n'
                '<span foreground="#9AA7B8" font="12">%s</span>'
                % (_("No games found"),
                   _("Install Steam, Lutris, or Flatpak games to see them here"))
            )
            self.library_box.pack_start(empty, True, True, 80)
            self.library_box.show_all()
            return

        # Recent games section
        if self.recent_games:
            self.library_box.pack_start(self._section_title(_("Recent")), False, False, 0)

            recent_flow = Gtk.FlowBox()
            recent_flow.set_max_children_per_line(6)
            recent_flow.set_min_children_per_line(3)
            recent_flow.set_selection_mode(Gtk.SelectionMode.NONE)
            recent_flow.set_homogeneous(True)
            recent_flow.set_column_spacing(12)
            recent_flow.set_row_spacing(12)

            for game_id in self.recent_games[:6]:
                game = next((g for g in self.games if g["app_id"] == game_id), None)
                if game:
                    self._flow_add(recent_flow, self._create_game_card(game))
            self.library_box.pack_start(recent_flow, False, False, 0)

            sep = Gtk.Separator()
            sep.set_margin_top(8)
            sep.set_margin_bottom(8)
            self.library_box.pack_start(sep, False, False, 0)

        # All games by source
        sources = {}
        for game in self.games:
            src = game["source"]
            if src not in sources:
                sources[src] = []
            sources[src].append(game)

        source_labels = {
            "steam": _("Steam Games"),
            "lutris": _("Lutris Games"),
            "flatpak": _("Flatpak Apps"),
            "native": _("Native Games"),
        }

        self.game_cards = []
        for src, src_games in sources.items():
            self.library_box.pack_start(
                self._section_title(source_labels.get(src, src.title())),
                False, False, 4)

            count_label = Gtk.Label(label=_("%d games") % len(src_games))
            count_label.get_style_context().add_class("pill-badge")
            count_label.set_halign(Gtk.Align.START)
            self.library_box.pack_start(count_label, False, False, 0)

            flow = Gtk.FlowBox()
            flow.set_max_children_per_line(6)
            flow.set_min_children_per_line(3)
            flow.set_selection_mode(Gtk.SelectionMode.NONE)
            flow.set_homogeneous(True)
            flow.set_column_spacing(12)
            flow.set_row_spacing(12)

            for game in sorted(src_games, key=lambda g: g["name"]):
                card = self._create_game_card(game)
                self._flow_add(flow, card)
                self.game_cards.append(card)

            self.library_box.pack_start(flow, False, False, 8)

        self.library_box.show_all()

        # Focus the first game so controller/stick navigation works immediately
        # (only while the Library tab is active, to avoid stealing focus).
        if self.game_cards and self.current_tab == 0:
            GLib.idle_add(self._focus_current_page)

    def _create_game_card(self, game):
        card = Gtk.Button()
        card.get_style_context().add_class("gm-game-card")
        card.connect("clicked", self.on_game_launch, game)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)

        # Prefer real cover art (Steam library cache); fall back to an emoji.
        cover_pixbuf = None
        cover_path = game.get("cover")
        if cover_path and os.path.exists(cover_path):
            try:
                cover_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    cover_path, 184, 246, True
                )
            except Exception:
                cover_pixbuf = None

        if cover_pixbuf is not None:
            cover_img = Gtk.Image.new_from_pixbuf(cover_pixbuf)
            cover_img.get_style_context().add_class("gm-game-cover")
            box.pack_start(cover_img, False, False, 0)

            name_label = Gtk.Label(label=game["name"])
            name_label.get_style_context().add_class("gm-game-title")
            name_label.set_ellipsize(Pango.EllipsizeMode.END)
            name_label.set_max_width_chars(22)
            name_label.set_margin_bottom(8)
            box.pack_start(name_label, False, False, 0)
        else:
            box.set_margin_top(16)
            box.set_margin_bottom(12)
            box.set_margin_start(12)
            box.set_margin_end(12)

            source_icons = {
                "steam": "applications-games-symbolic",
                "lutris": "input-gaming-symbolic",
                "flatpak": "package-x-generic-symbolic",
                "native": "computer-symbolic",
            }
            icon_img = Gtk.Image.new_from_icon_name(
                source_icons.get(game["source"], "applications-games-symbolic"),
                Gtk.IconSize.DIALOG)
            icon_img.set_pixel_size(56)
            box.pack_start(icon_img, True, True, 0)

            name_label = Gtk.Label(label=game["name"])
            name_label.get_style_context().add_class("gm-game-title")
            name_label.set_ellipsize(Pango.EllipsizeMode.END)
            name_label.set_max_width_chars(20)
            box.pack_start(name_label, False, False, 0)

            src_label = Gtk.Label(label=game["source"].title())
            src_label.get_style_context().add_class("gm-game-source")
            box.pack_start(src_label, False, False, 0)

        card.add(box)
        return card

    @staticmethod
    def _flow_add(flow, button):
        """Add a card to a FlowBox with the FlowBoxChild as the focus target.

        WHY: GtkFlowBox moves directional focus between its children and
        then focuses the FlowBoxChild itself; a focusable button inside it
        made the D-pad stop on an invisible wrapper (or not move at all).
        The button stays clickable by touch/mouse; A and Enter activate it
        through _activate_focus().
        """
        button.set_can_focus(False)
        flow.add(button)

    # ========================================
    # QUICK LAUNCH PAGE
    # ========================================
    def _build_quick_launch_page(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page.set_margin_top(32)
        page.set_margin_start(32)
        page.set_margin_end(32)
        page.set_margin_bottom(32)

        page.pack_start(self._section_title(_("Quick Launch")), False, False, 0)

        desc = Gtk.Label(label=_("Launch apps and tools with one button press"))
        desc.get_style_context().add_class("gm-section-desc")
        desc.set_halign(Gtk.Align.START)
        page.pack_start(desc, False, False, 0)

        # Quick launch grid
        flow = Gtk.FlowBox()
        flow.set_max_children_per_line(4)
        flow.set_min_children_per_line(2)
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_homogeneous(True)
        flow.set_column_spacing(16)
        flow.set_row_spacing(16)

        quick_apps = [
            ("applications-games-symbolic", "Steam", "steam", _("Steam client")),
            ("input-gaming-symbolic", "Lutris", "lutris", _("Game manager")),
            ("media-optical-symbolic", "RetroArch", "retroarch", _("Retro emulator")),
            ("package-x-generic-symbolic", "Bottles", "flatpak run com.usebottles.bottles", _("Windows apps")),
            ("starred-symbolic", "Heroic", "flatpak run com.heroicgameslauncher.hgl", "Epic/GOG"),
            ("computer-symbolic", _("Desktop Mode"), "__desktop__", _("Switch to desktop")),
            ("utilities-system-monitor-symbolic", "MangoHud", "__mangohud__", _("Toggle overlay")),
            ("preferences-system-symbolic", _("Control Panel"), "nawaos-control-panel", _("System settings")),
            ("weather-clear-symbolic", _("Game Mode On"), "__gamemode_on__", _("Max performance")),
            ("weather-clear-night-symbolic", _("Game Mode Off"), "__gamemode_off__", _("Balanced mode")),
            ("input-tablet-symbolic", "AntiMicroX", "antimicrox", _("Controller mapping")),
            ("phone-symbolic", _("Companion"), "nawaos-companion-gui", _("Phone control")),
        ]

        self.quick_buttons = []
        for icon_name, name, cmd, desc_text in quick_apps:
            btn = Gtk.Button()
            btn.get_style_context().add_class("gm-quick-btn")
            btn.connect("clicked", self.on_quick_launch, cmd)

            btn_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
            icon.set_pixel_size(28)
            btn_box.pack_start(icon, True, True, 0)

            lbl = Gtk.Label(label=name)
            lbl.get_style_context().add_class("gm-game-title")
            btn_box.pack_start(lbl, False, False, 0)

            dlbl = Gtk.Label(label=desc_text)
            dlbl.get_style_context().add_class("gm-game-source")
            btn_box.pack_start(dlbl, False, False, 0)

            btn.add(btn_box)
            self._flow_add(flow, btn)
            self.quick_buttons.append(btn)

        page.pack_start(flow, False, False, 0)

        scrolled.add(page)
        page.set_focus_vadjustment(scrolled.get_vadjustment())
        outer.pack_start(scrolled, True, True, 0)
        return outer

    # ========================================
    # PERFORMANCE PAGE
    # ========================================
    def _build_performance_page(self):
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page.set_margin_top(32)
        page.set_margin_start(32)
        page.set_margin_end(32)
        page.set_margin_bottom(32)

        page.pack_start(self._section_title(_("Performance")), False, False, 0)

        # --- System stats grid ---
        stats_grid = Gtk.Grid()
        stats_grid.set_column_spacing(16)
        stats_grid.set_row_spacing(16)
        stats_grid.set_column_homogeneous(True)

        self.cpu_temp_label = self._create_stat_card(stats_grid, 0, 0, _("CPU Temp"), "---")
        self.gpu_temp_label = self._create_stat_card(stats_grid, 1, 0, _("GPU Temp"), "---")
        self.cpu_usage_label = self._create_stat_card(stats_grid, 2, 0, _("CPU Usage"), "---")
        self.ram_usage_label = self._create_stat_card(stats_grid, 3, 0, _("RAM"), "---")

        page.pack_start(stats_grid, False, False, 0)

        # --- TDP Control (for handhelds) ---
        tdp_title = self._section_title(_("TDP Control"))
        tdp_title.set_margin_top(16)
        page.pack_start(tdp_title, False, False, 0)

        tdp_desc = Gtk.Label()
        if self.is_handheld:
            tdp_desc.set_markup('<span foreground="#4ADE80">%s</span>'
                                % (_("Handheld detected: %s") % self.device_name))
        else:
            tdp_desc.set_markup('<span foreground="#9AA7B8">%s</span>'
                                % _("Adjust power limit for battery vs performance trade-off"))
        tdp_desc.set_halign(Gtk.Align.START)
        page.pack_start(tdp_desc, False, False, 0)

        tdp_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        tdp_box.get_style_context().add_class("gm-performance-card")

        # The range nawaos-tdp-helper enforces on this device (same table).
        tdp_min, tdp_max = self._tdp_range()
        tdp_start = max(tdp_min, min(tdp_max, 15))

        self.tdp_value_label = Gtk.Label()
        self.tdp_value_label.set_markup(
            f'<span foreground="#37BCE0" font="22" weight="bold">{tdp_start}W</span>')
        self.tdp_value_label.set_halign(Gtk.Align.START)
        tdp_box.pack_start(self.tdp_value_label, False, False, 0)

        self.tdp_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, tdp_min, tdp_max, 1)
        self.tdp_scale.set_value(tdp_start)
        self.tdp_scale.get_style_context().add_class("gm-tdp-slider")
        self.tdp_scale.set_draw_value(False)
        self.tdp_scale.connect("value-changed", self.on_tdp_changed)
        # WHY: the perf updater pushes the measured TDP into this scale; while
        # the user is dragging that would yank the knob out of their hand, so
        # track drag state and skip updates during a drag.
        self._tdp_slider_active = False
        self.tdp_scale.connect("button-press-event", self._on_tdp_slider_grab)
        self.tdp_scale.connect("button-release-event", self._on_tdp_slider_release)

        # Add marks
        for mark in sorted({tdp_min, tdp_max} |
                           {m for m in (15, 25, 35, 45) if tdp_min + 3 < m < tdp_max - 3}):
            self.tdp_scale.add_mark(mark, Gtk.PositionType.BOTTOM, f"{mark}W")

        tdp_box.pack_start(self.tdp_scale, False, False, 0)

        # TDP Presets
        preset_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        preset_box.set_margin_top(8)

        tdp_presets = [
            (_("Silent"), 8, _("Minimal fan noise")),
            (_("Battery"), 12, _("Max battery life")),
            (_("Balanced"), 18, _("Good performance")),
            (_("Performance"), 30, _("Maximum FPS")),
            (_("Boost"), 45, _("Short burst")),
        ]

        shown = set()
        for name, watts, tooltip in tdp_presets:
            # Presets outside the device range would be clamped by the helper;
            # show what will really be applied and drop duplicates.
            watts = max(tdp_min, min(tdp_max, watts))
            if watts in shown:
                continue
            shown.add(watts)
            btn = Gtk.Button(label=f"{name}\n{watts}W")
            btn.get_style_context().add_class("gm-profile-btn")
            btn.set_tooltip_text(tooltip)
            btn.set_can_focus(True)
            btn.connect("clicked", self.on_tdp_preset, watts)
            preset_box.pack_start(btn, True, True, 0)

        tdp_box.pack_start(preset_box, False, False, 0)
        page.pack_start(tdp_box, False, False, 0)

        # --- Performance Profiles ---
        profile_title = self._section_title(_("Performance Profile"))
        profile_title.set_margin_top(16)
        page.pack_start(profile_title, False, False, 0)

        profile_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        profiles = [
            (_("Power Saver"), "powersave", _("Max battery life")),
            (_("Balanced"), "balanced", _("Default balanced mode")),
            (_("Gaming"), "performance", _("Max CPU/GPU performance")),
        ]

        for label, profile_id, desc_text in profiles:
            btn = Gtk.Button()
            btn.get_style_context().add_class("gm-profile-btn")
            btn.set_can_focus(True)
            btn.connect("clicked", self.on_performance_profile, profile_id)

            bb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            lb = Gtk.Label(label=label)
            lb.get_style_context().add_class("gm-game-title")
            bb.pack_start(lb, False, False, 0)
            db = Gtk.Label(label=desc_text)
            db.get_style_context().add_class("gm-game-source")
            bb.pack_start(db, False, False, 0)
            btn.add(bb)
            profile_box.pack_start(btn, True, True, 0)

        page.pack_start(profile_box, False, False, 0)

        scrolled.add(page)
        page.set_focus_vadjustment(scrolled.get_vadjustment())

        # Start performance updater
        GLib.timeout_add(3000, self._update_perf_stats)
        self._update_perf_stats()

        return scrolled

    @staticmethod
    def _tdp_range():
        if nawaos_handheld is not None:
            lo, hi, _known = nawaos_handheld.tdp_limits()
            return lo, hi
        return 5, 45

    def _create_stat_card(self, grid, col, row, label, initial_value):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        card.get_style_context().add_class("gm-performance-card")

        lbl = Gtk.Label(label=label)
        lbl.get_style_context().add_class("gm-perf-label")
        lbl.set_halign(Gtk.Align.START)
        card.pack_start(lbl, False, False, 0)

        val = Gtk.Label(label=initial_value)
        val.get_style_context().add_class("gm-perf-value")
        val.set_halign(Gtk.Align.START)
        card.pack_start(val, False, False, 0)

        grid.attach(card, col, row, 1, 1)
        return val

    # ========================================
    # SETTINGS PAGE
    # ========================================
    def _build_settings_page(self):
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page.set_margin_top(32)
        page.set_margin_start(32)
        page.set_margin_end(32)
        page.set_margin_bottom(32)

        page.pack_start(self._section_title(_("Settings")), False, False, 0)

        # Settings items
        # WHY: GameScope defaults on only when this is a handheld AND the
        # binary actually exists — wrapping every launch in a missing
        # compositor used to make every game fail with FileNotFoundError.
        #
        # NOTE: the former "Controller Vibration" and "Night Light" switches
        # were removed on purpose: nothing ever read those settings, so the
        # toggles were dead UI that pretended to do something. Re-add them
        # only together with a real implementation.
        gamescope_default = self.is_handheld and shutil.which("gamescope") is not None
        settings = [
            (_("Auto-start Game Mode"), _("Start in Game Mode on handheld devices"), "auto_gamemode", self.is_handheld),
            (_("MangoHud Overlay"), _("Show FPS and performance overlay in games"), "mangohud_default", False),
            (_("GameScope Compositor"), _("Use Valve's gaming compositor for better scaling"), "use_gamescope", gamescope_default),
            (_("Auto TDP"), _("Automatically adjust TDP based on game demand"), "auto_tdp", self.is_handheld),
        ]

        for label, desc, key, default in settings:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            row.get_style_context().add_class("gm-performance-card")
            row.set_margin_bottom(4)

            text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            lbl = Gtk.Label()
            lbl.set_markup(f'<span foreground="#E8EDF4" font="13">{label}</span>')
            lbl.set_halign(Gtk.Align.START)
            text_box.pack_start(lbl, False, False, 0)

            dlbl = Gtk.Label()
            dlbl.set_markup(f'<span foreground="#9AA7B8" font="11">{desc}</span>')
            dlbl.set_halign(Gtk.Align.START)
            text_box.pack_start(dlbl, False, False, 0)

            row.pack_start(text_box, True, True, 0)

            switch = Gtk.Switch()
            switch.set_active(self._load_setting(key, default))
            switch.connect("state-set", self._on_setting_changed, key)
            switch.set_valign(Gtk.Align.CENTER)
            row.pack_end(switch, False, False, 0)

            page.pack_start(row, False, False, 0)

        # Exit button
        exit_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        exit_box.set_margin_top(24)

        desktop_btn = Gtk.Button(label=_("Switch to Desktop Mode"))
        desktop_btn.get_style_context().add_class("gm-quick-btn")
        desktop_btn.set_can_focus(True)
        desktop_btn.connect("clicked", self.on_switch_desktop)
        exit_box.pack_start(desktop_btn, True, True, 0)

        shutdown_btn = Gtk.Button(label=_("Shutdown"))
        shutdown_btn.get_style_context().add_class("gm-quick-btn")
        shutdown_btn.set_can_focus(True)
        shutdown_btn.connect("clicked", self.on_shutdown)
        exit_box.pack_start(shutdown_btn, True, True, 0)

        reboot_btn = Gtk.Button(label=_("Reboot"))
        reboot_btn.get_style_context().add_class("gm-quick-btn")
        reboot_btn.set_can_focus(True)
        reboot_btn.connect("clicked", self.on_reboot)
        exit_box.pack_start(reboot_btn, True, True, 0)

        page.pack_start(exit_box, False, False, 0)

        scrolled.add(page)
        page.set_focus_vadjustment(scrolled.get_vadjustment())
        return scrolled

    # ========================================
    # CALLBACKS
    # ========================================
    def on_tab_clicked(self, button, idx):
        self._switch_tab(idx)

    def _switch_tab(self, idx):
        if idx < 0 or idx >= len(self.tabs):
            return
        changed = idx != self.current_tab
        self.current_tab = idx
        for i, btn in enumerate(self.tab_buttons):
            ctx = btn.get_style_context()
            if i == idx:
                ctx.add_class("active-tab")
            else:
                ctx.remove_class("active-tab")

        pages = ["library", "quick", "performance", "settings"]
        self.content_stack.set_visible_child_name(pages[idx])
        if changed:
            # Never leave focus on a widget of the page that was just hidden.
            self._focus_current_page()

    def on_game_launch(self, button, game):
        # A second A press while the game is still starting (this window is
        # still active until the game's window appears) must not launch it twice.
        now = time.monotonic()
        if self._last_launch[0] == game["app_id"] and now - self._last_launch[1] < 10:
            return
        self._last_launch = (game["app_id"], now)
        self._add_to_recent(game["app_id"])
        notify_gaming(_("Launching"), game["name"], source="Game Mode")

        try:
            # Build an argument list instead of a shell string so game names
            # or .desktop Exec lines cannot inject extra shell commands.
            cmd_args = shlex.split(game["launch"])
            if not cmd_args:
                return
            env = os.environ.copy()
            # Enable MangoHud if setting is on
            if self._load_setting("mangohud_default", False):
                env["MANGOHUD"] = "1"
            # Use GameScope if setting is on (default: only on handhelds that
            # actually have it installed).
            gamescope_default = self.is_handheld and shutil.which("gamescope") is not None
            if self._load_setting("use_gamescope", gamescope_default):
                if shutil.which("gamescope") is not None:
                    width = Gdk.Screen.get_default().get_width()
                    height = Gdk.Screen.get_default().get_height()
                    cmd_args = ['gamescope', '-W', str(width), '-H', str(height),
                                '-f', '--'] + cmd_args
                else:
                    # WHY: launch the game anyway instead of dying with
                    # FileNotFoundError when the compositor is missing.
                    print("[GameMode] gamescope not installed; launching without it")
            subprocess.Popen(cmd_args, env=env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            notify_gaming(_("Launch Failed"), str(e), source="Game Mode")

    def on_quick_launch(self, button, cmd):
        if cmd == "__desktop__":
            self.on_switch_desktop(button)
        elif cmd == "__mangohud__":
            notify_gaming("MangoHud", _("Toggle via MANGOHUD=1 when launching games"), source="Game Mode")
        elif cmd == "__gamemode_on__":
            try:
                subprocess.Popen(['pkexec', '/usr/local/bin/nawaos-gamemode', 'on'],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                notify_gaming(_("Game Mode"), _("Performance mode enabled"), source="Game Mode")
            except:
                pass
        elif cmd == "__gamemode_off__":
            try:
                subprocess.Popen(['pkexec', '/usr/local/bin/nawaos-gamemode', 'off'],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                notify_gaming(_("Game Mode"), _("Balanced mode restored"), source="Game Mode")
            except:
                pass
        else:
            try:
                subprocess.Popen(shlex.split(cmd),
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

    def on_tdp_changed(self, scale):
        value = int(scale.get_value())
        self.tdp_value_label.set_markup(f'<span foreground="#37BCE0" font="22" weight="bold">{value}W</span>')

    def _on_tdp_slider_grab(self, scale, event):
        self._tdp_slider_active = True
        return False

    def _on_tdp_slider_release(self, scale, event):
        self._tdp_slider_active = False
        # Dragging the slider used to only move the label; apply the value.
        self.on_tdp_preset(scale, int(scale.get_value()))
        return False

    def _set_tdp_scale_value(self, tdp):
        """Push a measured TDP into the slider (idle callback).

        Skipped while the user drags; the value is clamped to the scale range
        so out-of-range hardware readings can't distort the widget.
        """
        # Also skip while the slider has focus: the D-pad is adjusting it.
        if self._tdp_slider_active or self.tdp_scale.has_focus():
            return False
        adj = self.tdp_scale.get_adjustment()
        clamped = max(adj.get_lower(), min(adj.get_upper(), float(tdp)))
        self.tdp_scale.set_value(clamped)
        return False

    def on_tdp_preset(self, button, watts):
        self.tdp_scale.set_value(watts)
        # Apply TDP
        threading.Thread(target=self._apply_tdp, args=(watts,), daemon=True).start()

    def _apply_tdp(self, watts):
        # WHY: persist the user-chosen wattage into the handheld daemon config so
        # auto-apply on game-mode switch uses it (the daemon reads tdp_gaming;
        # without this it stays None and falls back to the device default).
        # Written as an int to the SAME file the daemon reads.
        try:
            self._update_daemon_setting("tdp_gaming", int(watts))
        except Exception:
            pass

        # WHY: privileged TDP writes go through the fixed, argument-validated
        # nawaos-tdp-helper behind a polkit action (passwordless for active
        # sessions) instead of ad-hoc `pkexec bash -c` scripts. The helper
        # picks the right backend (asus-wmi / ryzenadj / RAPL) and verifies by
        # reading back, so its exit code is a real success signal.
        helper = "/usr/local/bin/nawaos-tdp-helper"
        ok = False
        try:
            if nawaos_handheld is not None:
                ok = nawaos_handheld.set_tdp(int(watts))
            elif os.path.exists(helper):
                result = subprocess.run(['pkexec', helper, 'set', str(int(watts))],
                                        capture_output=True, timeout=20)
                ok = result.returncode == 0
            else:
                ok = False          # no TDP helper (source checkout): report failure
        except Exception:
            ok = False

        if ok:
            GLib.idle_add(lambda: notify_gaming(_("TDP Control"), _("Power limit set to %dW") % watts, source="Game Mode"))
        else:
            GLib.idle_add(lambda: notify_gaming(_("TDP Control"), _("Failed to set TDP (not applied)."), source="Game Mode"))

    def on_performance_profile(self, button, profile_id):
        # Delegate to the single nawaos-gamemode backend (set-profile) instead
        # of inlining per-profile kernel-tuning scripts here. Keeps the tuning
        # logic in one place and consistent with the Control Panel / Gaming Center.
        if profile_id not in ("performance", "balanced", "powersave"):
            return
        try:
            subprocess.Popen(['pkexec', '/usr/local/bin/nawaos-gamemode', 'set-profile', profile_id],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            notify_gaming(_("Performance"), _("Switched to %s profile") % profile_id, source="Game Mode")
        except Exception:
            pass

    def on_switch_desktop(self, button):
        self.controller.stop()
        # WHY: tell the daemon about the mode change before tearing down the
        # window. nawaos-mode-switch writes the shared state file the daemon
        # polls AND runs the desktop restore path (governor/TDP), so daemon
        # state stays in sync instead of still believing we are in Game Mode.
        try:
            subprocess.Popen(['nawaos-mode-switch', 'desktop'],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (FileNotFoundError, OSError):
            # Fallback: at least update the shared state file directly.
            try:
                os.makedirs(HANDHELD_CONFIG_DIR, exist_ok=True)
                state_file = os.path.join(HANDHELD_CONFIG_DIR, "state.json")
                with open(state_file, 'w') as f:
                    json.dump({"mode": "desktop"}, f)
            except Exception:
                pass
        self.destroy()
        Gtk.main_quit()

    def on_shutdown(self, button):
        self._confirm_power(_("Shut down the device?"), _("Shutdown"),
                            ['systemctl', 'poweroff'])

    def on_reboot(self, button):
        self._confirm_power(_("Restart the device?"), _("Reboot"),
                            ['systemctl', 'reboot'])

    def _confirm_power(self, question, action_label, command):
        """Ask before a power action; the controller drives the dialog
        (D-pad moves, A activates the focused button, B cancels) and the
        focus starts on Cancel, so a stray A press does nothing."""
        if self._confirm_dialog is not None:
            return
        dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                                   message_type=Gtk.MessageType.QUESTION,
                                   buttons=Gtk.ButtonsType.NONE, text=question)
        dialog.format_secondary_text(
            _("Unsaved progress in open games will be lost.") + "\n"
            + _("D-pad: choose, A: confirm, B: cancel"))
        cancel_btn = dialog.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(action_label, Gtk.ResponseType.ACCEPT)
        dialog.set_default_response(Gtk.ResponseType.CANCEL)

        def on_response(dlg, response):
            self._confirm_dialog = None
            dlg.destroy()
            if response == Gtk.ResponseType.ACCEPT:
                subprocess.Popen(command)

        dialog.connect("response", on_response)
        self._confirm_dialog = dialog
        dialog.show_all()
        cancel_btn.grab_focus()

    def _dialog_controller_input(self, dialog, button_code):
        if button_code == BTN_A:
            focused = dialog.get_focus()
            if isinstance(focused, Gtk.Button):
                focused.clicked()
        elif button_code == BTN_B:
            dialog.response(Gtk.ResponseType.CANCEL)
        elif button_code in DPAD_DIRECTIONS:
            dialog.child_focus(DPAD_DIRECTIONS[button_code])

    # ========================================
    # CONTROLLER NAVIGATION
    # ========================================
    def on_controller_input(self, button_code):
        # WHY: the reader sees the controller system-wide, also while a game
        # has focus: A relaunched the focused game, Guide quit this UI and
        # RB then A could reach Shutdown. Only act while this window (or its
        # confirmation dialog) is the active one.
        dialog = self._confirm_dialog
        if dialog is not None:
            if dialog.is_active():
                self._dialog_controller_input(dialog, button_code)
            return False
        if not self.is_active():
            return False

        if button_code == BTN_A:
            self._activate_focus()

        elif button_code == BTN_B:
            # Esc / Back
            self._switch_tab(0)

        elif button_code == BTN_GUIDE:
            # Exit to desktop
            self.on_switch_desktop(None)

        elif button_code == BTN_LB:
            self._switch_tab(max(0, self.current_tab - 1))

        elif button_code == BTN_RB:
            self._switch_tab(min(len(self.tabs) - 1, self.current_tab + 1))

        elif button_code in DPAD_DIRECTIONS:
            self._navigate_focus(DPAD_DIRECTIONS[button_code])
        return False

    def _activate_focus(self):
        """A / Enter: activate whatever has focus."""
        focused = self.get_focus()
        if isinstance(focused, Gtk.FlowBoxChild):
            focused = focused.get_child()  # game card / quick-launch button
        if isinstance(focused, Gtk.Switch):
            focused.set_active(not focused.get_active())
        elif isinstance(focused, Gtk.Button):
            # Also check/toggle buttons: clicked() toggles them.
            focused.clicked()
        elif focused is self.tdp_scale:
            self.on_tdp_preset(focused, int(focused.get_value()))

    def _focus_current_page(self):
        page = self.content_stack.get_visible_child()
        if page is not None:
            self.set_focus(None)
            page.child_focus(Gtk.DirectionType.TAB_FORWARD)
        return False

    def _navigate_focus(self, direction):
        """Move focus like the arrow keys do, within the visible page.

        WHY: this called child_focus() on the focused leaf widget, which in
        GTK3 only returns FALSE for a widget that already has focus, so the
        D-pad never moved. Directional types (LEFT/RIGHT, not TAB_*) are
        geometric, so left on the D-pad is left on screen in RTL as well.
        """
        focused = self.get_focus()
        page = self.content_stack.get_visible_child()
        if page is None:
            return
        if focused is None or not focused.is_ancestor(page):
            self._focus_current_page()
            return
        if (isinstance(focused, Gtk.Scale)
                and focused.get_orientation() == Gtk.Orientation.HORIZONTAL
                and direction in (Gtk.DirectionType.LEFT, Gtk.DirectionType.RIGHT)):
            # Left/right adjust a slider (TDP) by one step, in screen
            # direction: a horizontal scale runs right-to-left under RTL.
            step = focused.get_adjustment().get_step_increment() or 1
            sign = 1 if direction == Gtk.DirectionType.RIGHT else -1
            if focused.get_direction() == Gtk.TextDirection.RTL:
                sign = -sign
            if focused.get_inverted():
                sign = -sign
            focused.set_value(focused.get_value() + sign * step)
            return
        page.child_focus(direction)

    def on_key_press(self, widget, event):
        key = event.keyval
        if (key in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space)
                and isinstance(self.get_focus(), Gtk.FlowBoxChild)):
            self._activate_focus()
            return True
        if key == Gdk.KEY_Escape:
            if self.current_tab != 0:
                self._switch_tab(0)
            else:
                self.on_switch_desktop(None)
            return True
        elif key == Gdk.KEY_F11:
            if self._is_fullscreen:
                self.unfullscreen()
            else:
                self.fullscreen()
            return True
        return False

    def on_window_state(self, widget, event):
        self._is_fullscreen = bool(event.new_window_state & Gdk.WindowState.FULLSCREEN)
        return False

    # ========================================
    # HELPERS
    # ========================================
    def _scan_games_async(self):
        def scan():
            self.games = GameScanner.scan_all()
            GLib.idle_add(self._populate_library)
        threading.Thread(target=scan, daemon=True).start()

    def _start_clock(self):
        def update_clock():
            now = time.strftime("%H:%M")
            self.clock_label.set_text(now)

            battery = SystemInfo.get_battery()
            if battery:
                self.battery_label.set_markup(f'<span foreground="#9AA7B8" font="13">{battery}</span>')

            return True
        update_clock()
        GLib.timeout_add(10000, update_clock)

    def _update_perf_stats(self):
        def update():
            cpu_temp = SystemInfo.get_cpu_temp()
            gpu_temp = SystemInfo.get_gpu_temp()
            cpu_usage = SystemInfo.get_cpu_usage()
            ram = SystemInfo.get_ram_usage()
            GLib.idle_add(self.cpu_temp_label.set_text, cpu_temp)
            GLib.idle_add(self.gpu_temp_label.set_text, gpu_temp)
            GLib.idle_add(self.cpu_usage_label.set_text, cpu_usage)
            GLib.idle_add(self.ram_usage_label.set_text, ram)

            tdp = SystemInfo.get_current_tdp()
            if tdp is not None:
                GLib.idle_add(self._set_tdp_scale_value, tdp)

        threading.Thread(target=update, daemon=True).start()
        return True

    def _load_recent(self):
        try:
            if os.path.exists(RECENT_FILE):
                with open(RECENT_FILE) as f:
                    return json.load(f)
        except:
            pass
        return []

    def _add_to_recent(self, game_id):
        if game_id in self.recent_games:
            self.recent_games.remove(game_id)
        self.recent_games.insert(0, game_id)
        self.recent_games = self.recent_games[:10]
        try:
            with open(RECENT_FILE, 'w') as f:
                json.dump(self.recent_games, f)
        except:
            pass

    def _load_setting(self, key, default):
        settings_file = os.path.join(CONFIG_DIR, "settings.json")
        try:
            if os.path.exists(settings_file):
                with open(settings_file) as f:
                    return json.load(f).get(key, default)
        except:
            pass
        return default

    def _save_setting(self, key, value):
        settings_file = os.path.join(CONFIG_DIR, "settings.json")
        settings = {}
        try:
            if os.path.exists(settings_file):
                with open(settings_file) as f:
                    settings = json.load(f)
        except:
            pass
        settings[key] = value
        try:
            with open(settings_file, 'w') as f:
                json.dump(settings, f, indent=2)
        except:
            pass

    def _on_setting_changed(self, switch, state, key):
        self._save_setting(key, state)
        # Mirror handheld-related toggles into the daemon's own config so they
        # actually take effect (the daemon does not read gamemode/settings.json).
        if key in DAEMON_SETTING_MAP:
            self._update_daemon_setting(DAEMON_SETTING_MAP[key], state)

    def _update_daemon_setting(self, daemon_key, value):
        config = {}
        try:
            if os.path.exists(HANDHELD_CONFIG_FILE):
                with open(HANDHELD_CONFIG_FILE) as f:
                    config = json.load(f)
        except Exception:
            config = {}
        config[daemon_key] = value
        try:
            os.makedirs(HANDHELD_CONFIG_DIR, exist_ok=True)
            with open(HANDHELD_CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception:
            pass

    def do_destroy(self):
        self.controller.stop()
        Gtk.Window.do_destroy(self)


# ========================================
# MAIN
# ========================================
def main():
    win = GameModeWindow()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    # Controller input only acts while the window is active (H1); ask the
    # window manager for focus when started by the daemon, not by a click.
    win.present()
    Gtk.main()

if __name__ == "__main__":
    main()
