// NawaOS Control Center panel applet (nawaos-control-center@nawaos)
//
// One panel button (network, sound and battery icons) that opens a gaming
// control center: Wi-Fi with a network list, Bluetooth, Game Mode, FPS
// overlay, Do Not Disturb, volume with output/input device choice,
// brightness, performance profile and, on handhelds, the power limit.
// It replaces Cinnamon's separate network, sound and power applets.
//
// The applet is only the UI. Every read and every change goes through the
// backend module nawaos_controlcenter:
//     python3 -m nawaos_controlcenter status | list wifi|audio | set KEY VALUE
// which is unit-tested and uses the tools NawaOS already ships
// (nawaos-gamemode, nawaos-tdp-helper via polkit; nmcli, bluetoothctl,
// wpctl/pw-dump, gsettings, the Cinnamon settings daemon). Wi-Fi passwords
// never pass through it: NetworkManager asks Cinnamon's own password dialog.
// Language and direction (Arabic = right to left) follow the NawaOS setting.

const Applet = imports.ui.applet;
const PopupMenu = imports.ui.popupMenu;
const Slider = imports.ui.slider;
const Main = imports.ui.main;
const Util = imports.misc.util;
const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const GLib = imports.gi.GLib;
const Gio = imports.gi.Gio;

const BACKEND = ["python3", "-m", "nawaos_controlcenter"];
const POLL_SECONDS = 15;
const APPLY_DELAY_MS = 150;
const SCROLL_STEP = 5;
const MEDIA_POLL_MS = 2000;

// Colours are not set here: every actor gets a .nawaos-cc-* style class
// from the NawaOS Cinnamon theme (apps/nawaos-theme/cinnamon/cinnamon.css,
// "CONTROL CENTER APPLET"), so NawaOS-Light, generated from it, stays
// readable. Inline styles only carry sizes and spacing.
const SLIDER_STYLE =
    "-slider-height: 6px; -slider-handle-radius: 8px; -slider-border-width: 0px;" +
    " -slider-border-color: transparent; -slider-active-border-color: transparent;" +
    " min-height: 20px;" +
    // The theme's natural slider width is too wide for a row that also holds
    // a label, the value and an expand button; x_expand still fills the row.
    " width: 90px; min-width: 60px;";

const AR = {
    "Control Center": "مركز التحكم",
    "Wi-Fi": "واي فاي",
    "Bluetooth": "بلوتوث",
    "Off": "متوقف",
    "On": "مفعّل",
    "Not connected": "غير متصل",
    "Not available": "غير متوفر",
    "%d connected": "%d متصل",
    "Game Mode": "وضع الألعاب",
    "On. CPU, GPU and network tuned for play": "مفعّل، والمعالج والرسوميات والشبكة مضبوطة للعب",
    "Off. Click to tune the system for play": "متوقف. انقر لضبط النظام للعب",
    "FPS overlay": "عدّاد الإطارات",
    "Shown in MangoHud games": "ظاهر في الألعاب مع MangoHud",
    "Hidden": "مخفي",
    "Do Not Disturb": "عدم الإزعاج",
    "Notifications paused": "الإشعارات متوقفة",
    "Volume": "الصوت",
    "Mute": "كتم الصوت",
    "Brightness": "السطوع",
    "Performance profile": "وضع الأداء",
    "Quiet": "هادئ",
    "Balanced": "متوازن",
    "Performance": "أداء",
    "Handheld power limit": "حدّ الطاقة للجهاز المحمول",
    "%d W": "%d واط",
    "%d W, longer battery": "%d واط، بطارية أطول",
    "%d W, most power": "%d واط، أقصى أداء",
    "Open Control Panel": "فتح لوحة التحكم",
    "Power options": "خيارات الطاقة",
    "Charging": "يشحن",
    "Could not apply the change": "تعذّر تطبيق التغيير",
    "Loading…": "جارٍ التحميل…",
    "Choose a network": "اختيار شبكة",
    "Choose sound devices": "اختيار أجهزة الصوت",
    "Networks": "الشبكات",
    "Searching for networks…": "جارٍ البحث عن الشبكات…",
    "No networks found": "لم يُعثر على شبكات",
    "Turn on Wi-Fi to see networks": "شغّل الواي فاي لرؤية الشبكات",
    "Connected": "متصل",
    "Secured": "محمية",
    "Network settings": "إعدادات الشبكة",
    "Connecting to %s…": "جارٍ الاتصال بـ %s…",
    "Connected to %s": "تم الاتصال بـ %s",
    "Could not connect to %s": "تعذّر الاتصال بـ %s",
    "Output": "الإخراج",
    "Input": "الإدخال",
    "No input devices": "لا توجد أجهزة إدخال",
    "Sound settings": "إعدادات الصوت",
    "Previous": "السابق",
    "Play": "تشغيل",
    "Pause": "إيقاف مؤقت",
    "Next": "التالي",
    "Paused": "متوقف مؤقتاً",
};

let LANG = "en";

function _(s) {
    if (LANG === "ar" && AR[s])
        return AR[s];
    return s;
}

function fmt(s, v) {
    return _(s).replace("%d", String(v)).replace("%s", String(v));
}

function wifiIconName(signal) {
    if (signal >= 75) return "network-wireless-signal-excellent-symbolic";
    if (signal >= 50) return "network-wireless-signal-good-symbolic";
    if (signal >= 25) return "network-wireless-signal-ok-symbolic";
    return "network-wireless-signal-weak-symbolic";
}

function volumeIconName(vol) {
    if (vol.muted || vol.percent === 0) return "audio-volume-muted-symbolic";
    if (vol.percent < 34) return "audio-volume-low-symbolic";
    if (vol.percent < 67) return "audio-volume-medium-symbolic";
    return "audio-volume-high-symbolic";
}

function batteryIconName(bat) {
    let lvl = Math.min(100, Math.round(bat.percent / 10) * 10);
    return "battery-level-" + lvl + (bat.charging ? "-charging" : "") + "-symbolic";
}

class NawaOSControlCenter extends Applet.Applet {

    constructor(metadata, orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);
        this.setAllowedLayout(Applet.AllowedLayout.BOTH);

        this._status = null;
        this._dragging = false;
        this._pollId = 0;
        this._applyIds = {};
        this._expanded = null;        // null | "wifi" | "audio"
        this._wifiList = null;        // null = not loaded yet
        this._audioList = null;
        this._inFlight = {};          // kind -> a backend call is running
        this._queued = {};            // kind -> run once more when it ends
        this._removed = false;
        this._media = null;           // MPRIS player shown in the media card
        this._mediaJson = "";
        this._mediaPollId = 0;

        // Panel button: network, sound and battery status, like the three
        // Cinnamon applets it replaces. Scrolling on it changes the volume.
        this._panelBox = new St.BoxLayout({ style: "spacing: 10px;", y_align: Clutter.ActorAlign.CENTER });
        // Game Mode indicator (2.2): replaces the separate Game Mode applet.
        this._gameIcon = this._icon("input-gaming-symbolic", 16);
        this._gameIcon.add_style_class_name("nawaos-cc-game-icon");
        this._gameIcon.visible = false;
        this._netIcon = this._icon("network-offline-symbolic", 16);
        this._volIcon = this._icon("audio-volume-high-symbolic", 16);
        this._batIcon = this._icon("battery-good-symbolic", 16);
        this._batLabel = new St.Label({ text: "", y_align: Clutter.ActorAlign.CENTER });
        this._volIcon.visible = false;
        this._batIcon.visible = false;
        this._batLabel.visible = false;
        [this._gameIcon, this._netIcon, this._volIcon, this._batIcon, this._batLabel].forEach((a) => this._panelBox.add_child(a));
        this.actor.add_child(this._panelBox);
        this.set_applet_tooltip(_("Control Center"));
        this.actor.connect("scroll-event", (actor, event) => this._onScroll(event));

        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new Applet.AppletPopupMenu(this, orientation);
        this.menuManager.addMenu(this.menu);
        this._root = new St.BoxLayout({
            vertical: true, style_class: "nawaos-cc",
            style: "width: 380px; padding: 6px; spacing: 10px;",
        });
        // On short screens (1280x800 handhelds) an expanded list plus the
        // power-limit slider is taller than the screen: scroll instead.
        this._scroll = new St.ScrollView({
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
        });
        this._scroll.add_actor(this._root);
        this.menu.addActor(this._scroll);
        this._root.add_child(new St.Label({ text: _("Loading…"), style_class: "nawaos-cc-dim" }));
        this.menu.connect("open-state-changed", (m, open) => {
            if (!open) {
                this._expanded = null;    // reopen compact
                this._stopMediaPoll();
                return;
            }
            this._loadMedia();
            this._stopMediaPoll();
            this._mediaPollId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, MEDIA_POLL_MS, () => {
                this._loadMedia(false);
                return true;
            });
            let mon = Main.layoutManager.primaryMonitor;
            if (mon)
                this._scroll.style = "max-height: " + Math.max(320, mon.height - 140) + "px;";
            if (this._status)
                this._build();            // last known state at once...
            this._refresh();              // ...then the current one
        });

        this._refresh();
        this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, POLL_SECONDS, () => {
            if (!this.menu.isOpen)
                this._refresh(false);
            return true;
        });
    }

    // ------------------------------------------------------------ backend --

    _backend(args, callback) {
        if (this._removed)
            return;
        let done = (stdout, code) => {
            if (this._removed)
                return;               // the applet and its actors are gone
            try {
                callback(stdout, code);
            } catch (e) {
                global.logError("nawaos-control-center: " + args.join(" ") + ": " + e);
            }
        };
        try {
            Util.spawnCommandLineAsyncIO("", (stdout, stderr, code) => done(stdout, code),
                { argv: BACKEND.concat(args) });
        } catch (e) {
            global.logError("nawaos-control-center: spawn " + args.join(" ") + " failed: " + e);
            done("", -1);             // report it, so a single-flight slot is freed
        }
    }

    // Single flight: at most one backend process per kind ("status",
    // "media", "list wifi", ...). NetworkManager, bluetoothd or a media
    // player can answer slowly, and the polls used to stack up processes.
    // A poll tick that finds a call still running is skipped (queue false);
    // an explicit request (menu opened, change applied) runs once more when
    // the running call ends, so it shows the new state.
    _single(kind, args, queue, handler) {
        if (this._inFlight[kind]) {
            if (queue)
                this._queued[kind] = true;
            return;
        }
        this._inFlight[kind] = true;
        this._backend(args, (stdout, code) => {
            this._inFlight[kind] = false;
            try {
                handler(stdout, code);
            } finally {
                if (this._queued[kind]) {
                    this._queued[kind] = false;
                    this._single(kind, args, false, handler);
                }
            }
        });
    }

    _refresh(queue = true) {
        this._single("status", ["status"], queue, (stdout, code) => {
            if (code !== 0 || !stdout)
                return;
            this._status = JSON.parse(stdout);
            LANG = this._status.language === "ar" ? "ar" : "en";
            this._updatePanel();
            if (this.menu.isOpen && !this._dragging)
                this._build();
        });
    }

    _loadList(kind) {
        this._single("list " + kind, ["list", kind], true, (stdout, code) => {
            let data = code === 0 && stdout ? JSON.parse(stdout) : null;
            if (kind === "wifi")
                this._wifiList = data || [];
            else
                this._audioList = data || { outputs: [], inputs: [] };
            if (this.menu.isOpen && !this._dragging)
                this._build();
        });
    }

    _loadMedia(queue = true) {
        this._single("list media", ["list", "media"], queue, (stdout, code) => {
            if (code !== 0 || !stdout)
                return;
            // Rebuild only when something changed, so a track or play-state
            // change shows up without redrawing the menu every two seconds.
            if (stdout === this._mediaJson)
                return;
            this._mediaJson = stdout;
            this._media = JSON.parse(stdout);
            if (this.menu.isOpen && !this._dragging)
                this._build();
        });
    }

    _stopMediaPoll() {
        if (this._mediaPollId > 0) {
            GLib.source_remove(this._mediaPollId);
            this._mediaPollId = 0;
        }
    }

    _mediaAction(action) {
        let player = this._media && this._media.player;
        if (!player)
            return;
        this._backend(["set", "media", action + ":" + player], () => {
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300, () => { this._loadMedia(); return false; });
        });
    }

    _set(key, value, done) {
        this._backend(["set", key, String(value)], (stdout, code) => {
            if (done)
                done(code);
            else if (code !== 0)
                Main.notify(_("Control Center"), _("Could not apply the change"));
            this._refresh();
        });
    }

    // Sliders send many values while dragging: apply the latest one shortly
    // after the movement pauses instead of spawning a process per pixel.
    _setLater(key, value) {
        if (this._applyIds[key])
            GLib.source_remove(this._applyIds[key]);
        this._applyIds[key] = GLib.timeout_add(GLib.PRIORITY_DEFAULT, APPLY_DELAY_MS, () => {
            this._applyIds[key] = 0;
            this._set(key, value);
            return false;
        });
    }

    // -------------------------------------------------------------- panel --

    _updatePanel() {
        let s = this._status;
        this._gameIcon.visible = !!(s.gamemode && s.gamemode.enabled);
        let net = s.network || { kind: "none" };
        if (net.kind === "ethernet")
            this._netIcon.icon_name = "network-wired-symbolic";
        else if (net.kind === "wifi")
            this._netIcon.icon_name = wifiIconName(s.wifi.signal || 0);
        else
            this._netIcon.icon_name = s.wifi.available && s.wifi.enabled
                ? "network-wireless-offline-symbolic" : "network-offline-symbolic";
        this._volIcon.visible = s.volume.available;
        if (s.volume.available)
            this._volIcon.icon_name = volumeIconName(s.volume);
        this._batIcon.visible = s.battery.available;
        this._batLabel.visible = s.battery.available;
        if (s.battery.available) {
            this._batIcon.icon_name = batteryIconName(s.battery);
            this._batLabel.text = s.battery.percent + "%";
        }
        let parts = [_("Control Center")];
        if (s.gamemode && s.gamemode.enabled)
            parts.push(_("Game Mode") + ": " + _("On"));
        if (net.kind === "wifi" && s.wifi.network)
            parts.push(s.wifi.network);
        if (s.volume.available)
            parts.push(_("Volume") + " " + s.volume.percent + "%");
        if (s.battery.available)
            parts.push(s.battery.percent + "%");
        this.set_applet_tooltip(parts.join(" · "));
    }

    _onScroll(event) {
        let s = this._status;
        if (!s || !s.volume.available)
            return Clutter.EVENT_PROPAGATE;
        let dir = event.get_scroll_direction();
        let step = dir === Clutter.ScrollDirection.UP ? SCROLL_STEP
            : dir === Clutter.ScrollDirection.DOWN ? -SCROLL_STEP : 0;
        if (step === 0)
            return Clutter.EVENT_PROPAGATE;
        s.volume.percent = Math.max(0, Math.min(100, s.volume.percent + step));
        s.volume.muted = false;
        this._updatePanel();
        this._setLater("volume", s.volume.percent);
        return Clutter.EVENT_STOP;
    }

    // --------------------------------------------------------------- menu --

    _icon(name, size) {
        return new St.Icon({ icon_name: name, icon_type: St.IconType.SYMBOLIC, icon_size: size });
    }

    // cls: a .nawaos-cc-* colour class; style: sizes and weight only.
    _label(text, cls, style) {
        let l = new St.Label({ text: text, style_class: cls, style: style || "" });
        l.clutter_text.line_wrap = true;
        l.clutter_text.ellipsize = 0;    // Pango.EllipsizeMode.NONE: wrap, never cut
        if (LANG === "ar")
            l.clutter_text.line_alignment = 2;   // Pango.Alignment.RIGHT for wrapped lines
        return l;
    }

    // Headings and hints in a vertical box. A vertical box places a label at
    // the left edge even right to left; a horizontal row packs from the start
    // side (the right edge in Arabic), so wrap the label in one.
    _addFull(box, actor) {
        let row = new St.BoxLayout({ x_expand: true });
        row.add_child(actor);
        box.add_child(row);
    }

    _section() {
        return new St.BoxLayout({
            vertical: true, style_class: "nawaos-cc-section",
            style: "padding: 12px 14px; spacing: 8px; border-radius: 16px;",
        });
    }

    _chevron(kind, label) {
        let open = this._expanded === kind;
        let b = new St.Button({
            can_focus: true, style_class: open ? "nawaos-cc-chevron-open" : "nawaos-cc-chevron",
            style: "width: 30px; height: 30px; border-radius: 10px;",
        });
        b.accessible_name = label;
        b.set_child(this._icon(open ? "pan-up-symbolic" : "pan-down-symbolic", 14));
        b.connect("clicked", () => this._toggleExpand(kind));
        return b;
    }

    _toggleExpand(kind) {
        this._expanded = this._expanded === kind ? null : kind;
        if (this._expanded === "wifi")
            this._loadList("wifi");
        else if (this._expanded === "audio")
            this._loadList("audio");
        this._build();
    }

    // A toggle tile. big = the Game Mode tile (filled with the accent).
    // half = one of two tiles in a row. more = [kind, label] adds an expand
    // button beside the toggle area (a sibling, not nested in it).
    _tile(iconName, title, subtitle, info, onClick, big, half, more) {
        let on = info.available && info.enabled;
        let filled = big && on;
        let frameClass = filled ? "nawaos-cc-tile-active" : on ? "nawaos-cc-tile-on" : "nawaos-cc-tile";
        let pad = big ? 14 : 12;
        let frameStyle = (half ? "width: 153px; " : "") +
            "padding: " + pad + "px; border-radius: " + (big ? 18 : 16) + "px;";

        let row = new St.BoxLayout({ style: "spacing: 12px;", x_expand: true });
        let size = big ? 44 : 36;
        let badge = new St.Bin({
            style_class: filled ? "nawaos-cc-badge-active" : on ? "nawaos-cc-badge-on" : "nawaos-cc-badge",
            style: "width: " + size + "px; height: " + size + "px; border-radius: " + (big ? 14 : 12) + "px;",
        });
        badge.set_child(this._icon(iconName, big ? 24 : 18));
        row.add_child(badge);
        let text = new St.BoxLayout({ vertical: true, x_expand: true, y_align: Clutter.ActorAlign.CENTER });
        text.add_child(this._label(title, filled ? "nawaos-cc-on-accent" : "nawaos-cc-text",
            "font-weight: bold; font-size: " + (big ? 15 : 13) + "px;"));
        text.add_child(this._label(info.available ? subtitle : _("Not available"),
            filled ? "nawaos-cc-on-accent" : "nawaos-cc-dim", "font-size: 11px;"));
        row.add_child(text);

        let toggle = new St.Button({
            reactive: info.available, can_focus: info.available, x_expand: true,
            x_fill: true, y_fill: true,
            style_class: more ? "" : frameClass,
            style: more ? "" : frameStyle,
        });
        toggle.accessible_name = title;
        toggle.set_child(row);
        toggle.connect("clicked", () => onClick(!on));

        let result = toggle;
        if (more) {
            // The frame carries the tile look; toggle and expand button sit in it.
            result = new St.BoxLayout({ style_class: frameClass, style: frameStyle + " spacing: 6px;", x_expand: true });
            result.add_child(toggle);
            if (info.available)
                result.add(this._chevron(more[0], more[1]), { y_fill: false, y_align: St.Align.MIDDLE });
        }
        if (!info.available)
            result.opacity = 110;
        return result;
    }

    _pair(a, b) {
        let box = new St.BoxLayout({ style: "spacing: 10px;", x_expand: true });
        box.add_child(a);
        box.add_child(b);
        return box;
    }

    _listRow(iconName, title, trailing, onClick, active) {
        let b = new St.Button({
            can_focus: true, x_expand: true, x_fill: true,
            style_class: active ? "nawaos-cc-row-active" : "",
            style: "padding: 8px 10px; border-radius: 10px;",
        });
        b.accessible_name = title;
        let row = new St.BoxLayout({ style: "spacing: 10px;", x_expand: true });
        row.add_child(iconName ? this._icon(iconName, 16) : new St.Bin({ style: "width: 16px;" }));
        row.add_child(this._label(title, "nawaos-cc-text", "font-size: 13px;" + (active ? " font-weight: bold;" : "")));
        row.add_child(new St.Bin({ x_expand: true }));
        if (trailing)
            row.add_child(trailing);
        b.set_child(row);
        if (onClick)
            b.connect("clicked", onClick);
        return b;
    }

    _linkButton(text, argv) {
        let b = new St.Button({
            label: text, can_focus: true, x_align: St.Align.START, style_class: "nawaos-cc-accent",
            style: "padding: 6px 10px; border-radius: 10px; font-size: 12px;",
        });
        b.connect("clicked", () => { this.menu.close(); this._launch(argv); });
        return b;
    }

    _hint(text) {
        return this._label(text, "nawaos-cc-dim", "font-size: 12px; padding: 4px 10px;");
    }

    _mediaButton(iconName, label, action, enabled, primary) {
        let size = primary ? 40 : 34;
        let b = new St.Button({
            can_focus: enabled, reactive: enabled,
            style_class: primary ? "nawaos-cc-media-play" : "nawaos-cc-media-button",
            style: "width: " + size + "px; height: " + size + "px; border-radius: " + (size / 2) + "px;",
        });
        b.accessible_name = label;
        b.set_child(this._icon(iconName, primary ? 18 : 16));
        if (!enabled)
            b.opacity = 90;
        b.connect("clicked", () => this._mediaAction(action));
        return b;
    }

    _buildMedia() {
        let m = this._media;
        let card = new St.BoxLayout({
            style_class: "nawaos-cc-media",
            style: "padding: 12px 14px; spacing: 12px; border-radius: 16px;",
            x_expand: true,
        });
        let art = new St.Bin({
            style_class: "nawaos-cc-art",
            style: "width: 48px; height: 48px; border-radius: 12px;",
        });
        if (m.art)
            art.set_child(new St.Icon({ gicon: Gio.icon_new_for_string(m.art), icon_size: 48 }));
        else
            art.set_child(this._icon("audio-x-generic-symbolic", 22));
        card.add(art, { y_fill: false, y_align: St.Align.MIDDLE });

        let text = new St.BoxLayout({ vertical: true, x_expand: true, y_align: Clutter.ActorAlign.CENTER });
        let title = m.title || m.identity;
        let sub = [m.artist, m.title ? m.identity : ""].filter((x) => x).join(" · ");
        if (m.status === "Paused")
            sub = sub ? sub + " · " + _("Paused") : _("Paused");
        this._addFull(text, this._label(title, "nawaos-cc-text", "font-weight: bold; font-size: 13px;"));
        if (sub)
            this._addFull(text, this._label(sub, "nawaos-cc-dim", "font-size: 11px;"));
        card.add_child(text);

        // Transport controls keep the previous-play-next order from left to
        // right in Arabic too: the arrows describe time, not reading
        // direction. The box itself mirrors right to left (setting its own
        // direction has no effect here), so add the buttons reversed there.
        let controls = new St.BoxLayout({ style: "spacing: 6px;", y_align: Clutter.ActorAlign.CENTER });
        let playing = m.status === "Playing";
        let mid = { y_fill: false, y_align: St.Align.MIDDLE };
        let buttons = [
            this._mediaButton("media-skip-backward-symbolic", _("Previous"), "previous", m.can_previous, false),
            this._mediaButton(playing ? "media-playback-pause-symbolic" : "media-playback-start-symbolic",
                playing ? _("Pause") : _("Play"), "play-pause", m.can_play_pause, true),
            this._mediaButton("media-skip-forward-symbolic", _("Next"), "next", m.can_next, false),
        ];
        if (this._status && this._status.rtl)
            buttons.reverse();
        buttons.forEach((b) => controls.add(b, mid));
        card.add(controls, mid);
        return card;
    }

    _buildNetworks() {
        let box = this._section();
        this._addFull(box, this._label(_("Networks"), "nawaos-cc-text", "font-weight: bold; font-size: 13px;"));
        let s = this._status;
        if (!s.wifi.enabled) {
            this._addFull(box, this._hint(_("Turn on Wi-Fi to see networks")));
        } else if (this._wifiList === null) {
            // Only the very first load shows this. Later the last known list
            // stays on screen while a rescan (several seconds) refreshes it.
            this._addFull(box, this._hint(_("Searching for networks…")));
        } else if (this._wifiList.length === 0) {
            this._addFull(box, this._hint(_("No networks found")));
        } else {
            this._wifiList.forEach((net) => {
                let trailing = new St.BoxLayout({ style: "spacing: 6px;" });
                if (net.in_use)
                    trailing.add_child(new St.Label({ text: _("Connected"), style_class: "nawaos-cc-accent", style: "font-size: 11px;" }));
                if (net.secure) {
                    let lock = this._icon("changes-prevent-symbolic", 12);
                    lock.accessible_name = _("Secured");
                    trailing.add_child(lock);
                }
                box.add_child(this._listRow(wifiIconName(net.signal), net.ssid, trailing,
                    net.in_use ? null : () => this._connect(net.ssid), net.in_use));
            });
        }
        box.add_child(this._linkButton(_("Network settings"), ["cinnamon-settings", "network"]));
        return box;
    }

    _connect(ssid) {
        // Close the menu first: for a new secured network NetworkManager asks
        // Cinnamon's password dialog, which needs the keyboard.
        this.menu.close();
        Main.notify(_("Wi-Fi"), fmt("Connecting to %s…", ssid));
        this._set("wifi-connect", ssid, (code) => {
            if (code === 0)
                Main.notify(_("Wi-Fi"), fmt("Connected to %s", ssid));
            else
                Main.notify(_("Wi-Fi"), fmt("Could not connect to %s", ssid));
            if (this._expanded === "wifi")
                this._loadList("wifi");   // keep the old list visible meanwhile
        });
    }

    _buildAudio() {
        let box = this._section();
        let list = this._audioList;
        if (list === null) {
            this._addFull(box, this._hint(_("Loading…")));
        } else {
            [["outputs", _("Output"), "output"], ["inputs", _("Input"), "input"]].forEach(([field, title, key]) => {
                this._addFull(box, this._label(title, "nawaos-cc-text", "font-weight: bold; font-size: 13px;"));
                if (list[field].length === 0 && key === "input")
                    this._addFull(box, this._hint(_("No input devices")));
                list[field].forEach((dev) => {
                    box.add_child(this._listRow(dev.default ? "object-select-symbolic" : null, dev.description, null,
                        dev.default ? null : () => {
                            this._set(key, dev.id, (code) => {
                                if (code !== 0)
                                    Main.notify(_("Control Center"), _("Could not apply the change"));
                                this._loadList("audio");
                            });
                        }, dev.default));
                });
            });
        }
        box.add_child(this._linkButton(_("Sound settings"), ["cinnamon-settings", "sound"]));
        return box;
    }

    _sliderRow(iconButton, title, percent, onChange, more) {
        let row = new St.BoxLayout({ style: "spacing: 12px;", x_expand: true });
        row.add(iconButton, { y_fill: false, y_align: St.Align.MIDDLE });
        let label = this._label(title, "nawaos-cc-text", "min-width: 72px; font-size: 13px;");
        label.y_align = Clutter.ActorAlign.CENTER;
        row.add_child(label);
        let value = new St.Label({
            text: percent + "%", style_class: "nawaos-cc-dim",
            style: "min-width: 36px; font-size: 12px;", y_align: Clutter.ActorAlign.CENTER,
        });
        let slider = new Slider.Slider(Math.min(1, percent / 100));
        slider.actor.add_style_class_name("nawaos-cc-slider");
        slider.actor.style = SLIDER_STYLE;
        slider.actor.x_expand = true;
        slider.actor.can_focus = true;
        slider.actor.accessible_name = title;
        slider.connect("drag-begin", () => { this._dragging = true; });
        slider.connect("drag-end", () => { this._dragging = false; });
        slider.connect("value-changed", (sl, v) => {
            let pct = Math.round(v * 100);
            value.text = pct + "%";
            onChange(pct);
        });
        row.add_child(slider.actor);
        row.add_child(value);
        if (more)
            row.add(more, { y_fill: false, y_align: St.Align.MIDDLE });
        return row;
    }

    _build() {
        let s = this._status;
        if (!s)
            return;
        this._root.destroy_all_children();
        this._root.set_text_direction(s.rtl ? Clutter.TextDirection.RTL : Clutter.TextDirection.LTR);

        // Now playing: only while a media player is running
        if (this._media && this._media.available)
            this._root.add_child(this._buildMedia());

        // Wi-Fi + Bluetooth, then the network list when expanded
        let wifiSub = s.wifi.enabled ? (s.wifi.network || _("Not connected")) : _("Off");
        let btSub = !s.bluetooth.enabled ? _("Off")
            : s.bluetooth.connected > 0 ? fmt("%d connected", s.bluetooth.connected) : _("On");
        this._root.add_child(this._pair(
            this._tile("network-wireless-symbolic", _("Wi-Fi"), wifiSub, s.wifi,
                (on) => this._set("wifi", on ? "on" : "off"), false, true, ["wifi", _("Choose a network")]),
            this._tile("bluetooth-active-symbolic", _("Bluetooth"), btSub, s.bluetooth,
                (on) => this._set("bluetooth", on ? "on" : "off"), false, true)));
        if (this._expanded === "wifi" && s.wifi.available)
            this._root.add_child(this._buildNetworks());

        // Game Mode
        this._root.add_child(this._tile("input-gaming-symbolic", _("Game Mode"),
            s.gamemode.enabled ? _("On. CPU, GPU and network tuned for play")
                : _("Off. Click to tune the system for play"),
            s.gamemode, (on) => this._set("gamemode", on ? "on" : "off"), true));

        // FPS overlay + Do Not Disturb
        this._root.add_child(this._pair(
            this._tile("utilities-system-monitor-symbolic", _("FPS overlay"),
                s.fps.enabled ? _("Shown in MangoHud games") : _("Hidden"), s.fps,
                (on) => this._set("fps", on ? "on" : "off"), false, true),
            this._tile("notifications-disabled-symbolic", _("Do Not Disturb"),
                s.dnd.enabled ? _("Notifications paused") : _("Off"), s.dnd,
                (on) => this._set("dnd", on ? "on" : "off"), false, true)));

        // Volume (mute button, device chooser) + brightness
        if (s.volume.available || s.brightness.available) {
            let box = this._section();
            if (s.volume.available) {
                let mute = new St.Button({ can_focus: true });
                mute.accessible_name = _("Mute");
                mute.set_child(this._icon(volumeIconName(s.volume), 16));
                mute.connect("clicked", () => this._set("mute", s.volume.muted ? "off" : "on"));
                box.add_child(this._sliderRow(mute, _("Volume"), s.volume.percent,
                    (pct) => this._setLater("volume", pct), this._chevron("audio", _("Choose sound devices"))));
            }
            if (s.brightness.available)
                box.add_child(this._sliderRow(this._icon("display-brightness-symbolic", 16), _("Brightness"),
                    s.brightness.percent, (pct) => this._setLater("brightness", pct)));
            this._root.add_child(box);
            if (this._expanded === "audio" && s.volume.available)
                this._root.add_child(this._buildAudio());
        }

        // Performance profile (+ handheld power limit)
        let perf = this._section();
        this._addFull(perf, this._label(_("Performance profile"), "nawaos-cc-text", "font-weight: bold; font-size: 13px;"));
        let seg = new St.BoxLayout({
            style_class: "nawaos-cc-well", style: "spacing: 4px; padding: 4px; border-radius: 12px;", x_expand: true,
        });
        [["quiet", _("Quiet")], ["balanced", _("Balanced")], ["performance", _("Performance")]].forEach(([key, title]) => {
            let active = s.profile === key;
            let b = new St.Button({
                label: title, x_expand: true, can_focus: true,
                style_class: active ? "nawaos-cc-segment-active" : "nawaos-cc-segment",
                style: "padding: 8px 0; border-radius: 9px; font-size: 13px;" + (active ? " font-weight: bold;" : ""),
            });
            // After a reboot nothing is applied (profile_applied false): the
            // highlighted default can be clicked to apply it too.
            b.connect("clicked", () => { if (!active || !s.profile_applied) this._set("profile", key); });
            seg.add_child(b);
        });
        perf.add_child(seg);
        if (s.tdp && s.tdp.available) {
            let head = new St.BoxLayout({ x_expand: true });
            head.add_child(this._label(_("Handheld power limit"), "nawaos-cc-text", "font-size: 13px;"));
            head.add_child(new St.Bin({ x_expand: true }));
            let watts = new St.Label({
                text: fmt("%d W", s.tdp.watts), style_class: "nawaos-cc-accent",
                style: "font-weight: bold; font-size: 13px;",
            });
            head.add_child(watts);
            perf.add_child(head);
            let span = s.tdp.max - s.tdp.min;
            let slider = new Slider.Slider((s.tdp.watts - s.tdp.min) / span);
            slider.actor.add_style_class_name("nawaos-cc-slider");
            slider.actor.style = SLIDER_STYLE;
            slider.actor.x_expand = true;
            slider.actor.can_focus = true;
            slider.actor.accessible_name = _("Handheld power limit");
            let current = s.tdp.watts;
            slider.connect("drag-begin", () => { this._dragging = true; });
            slider.connect("value-changed", (sl, v) => {
                current = Math.round(s.tdp.min + v * span);
                watts.text = fmt("%d W", current);
            });
            // The power limit goes through polkit: apply once, on release.
            slider.connect("drag-end", () => {
                this._dragging = false;
                this._set("tdp", current);
            });
            perf.add_child(slider.actor);
            let ends = new St.BoxLayout({ x_expand: true });
            ends.add_child(this._label(fmt("%d W, longer battery", s.tdp.min), "nawaos-cc-dim", "font-size: 11px;"));
            ends.add_child(new St.Bin({ x_expand: true }));
            ends.add_child(this._label(fmt("%d W, most power", s.tdp.max), "nawaos-cc-dim", "font-size: 11px;"));
            perf.add_child(ends);
        }
        this._root.add_child(perf);

        // Footer: battery, Control Panel, power options
        let foot = new St.BoxLayout({ style: "spacing: 8px; padding: 2px 4px 0;", x_expand: true });
        if (s.battery.available) {
            foot.add_child(this._icon(batteryIconName(s.battery), 18));
            foot.add_child(this._label(s.battery.percent + "%" + (s.battery.charging ? "  " + _("Charging") : ""),
                "nawaos-cc-dim", "font-size: 13px;"));
        }
        foot.add_child(new St.Bin({ x_expand: true }));
        foot.add_child(this._roundButton("emblem-system-symbolic", _("Open Control Panel"),
            () => this._launch(["nawaos-control-panel"])));
        foot.add_child(this._roundButton("system-shutdown-symbolic", _("Power options"),
            () => this._launch(["cinnamon-session-quit", "--power-off"])));
        this._root.add_child(foot);
    }

    _roundButton(iconName, label, onClick) {
        let b = new St.Button({
            can_focus: true, style_class: "nawaos-cc-round",
            style: "width: 44px; height: 44px; border-radius: 14px;",
        });
        b.accessible_name = label;
        b.set_child(this._icon(iconName, 18));
        b.connect("clicked", () => { this.menu.close(); onClick(); });
        return b;
    }

    _launch(argv) {
        try {
            if (GLib.find_program_in_path(argv[0]))
                Util.spawn(argv);
        } catch (e) {
            global.logError("nawaos-control-center: launch " + argv[0] + " failed: " + e);
        }
    }

    on_applet_clicked(event) {
        this.menu.toggle();
    }

    on_applet_removed_from_panel() {
        this._removed = true;         // late backend callbacks are ignored
        if (this._pollId > 0) {
            GLib.source_remove(this._pollId);
            this._pollId = 0;
        }
        this._stopMediaPoll();
        Object.keys(this._applyIds).forEach((k) => {
            if (this._applyIds[k])
                GLib.source_remove(this._applyIds[k]);
        });
        this._applyIds = {};
        this.menu.destroy();
    }
}

function main(metadata, orientation, panelHeight, instanceId) {
    return new NawaOSControlCenter(metadata, orientation, panelHeight, instanceId);
}
